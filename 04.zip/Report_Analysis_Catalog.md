# Report Analysis Catalog — Master Document

**Purpose:** Analysis-only catalog of source data, dimensions, KPIs, formulas, layouts, and business
vocabulary found in the client's existing report workbooks/decks, to be used later to define a data
model and reporting requirements. **No redesign or implementation is included in this document.**

**Method / tooling note:** Workbooks were inspected programmatically (read-only) using Python
(`openpyxl` for `.xlsx` internals — sheet XML, defined names, tables, comments, merged cells,
protection flags — and raw ZIP-part inspection for pivot caches/connections/Power Query/VBA/customXml;
`python-pptx` for `.pptx` slide content). Files were **not modified**. Helper scripts live in
`_analysis/` in this same folder (not part of the client deliverables).

**Labeling convention used throughout:** `[INFERRED]` = my interpretation, not explicitly stated in
the file. `[UNVERIFIED]` = plausible reading of ambiguous label/abbreviation. `[NOT AVAILABLE]` =
looked for and not present. Anything not labeled is a **directly observed fact** (cell value, XML
structure, etc.), not an inference.

---

## 0. Workbook / File Inventory (top-level)

| # | File | Type | Status | Notes |
|---|------|------|--------|-------|
| 1 | `NIQ_Customer Loyalty analysis.xlsx` | Excel workbook | ✅ Analyzed | See §1 |
| 2 | `NIQ_Datasheet_Liftcampaign.xlsx` | Excel workbook | ✅ Analyzed | See §2 |
| 3 | `NIQ_Performance analysis.xlsx` | Excel workbook | ✅ Analyzed | See §3 |
| 4 | `NIQ_Product_Extraction.xlsx` | Excel workbook | ✅ Analyzed | See §4 |
| 5 | `NIQ_Temporal_evolution.xlsx` | Excel workbook | ✅ Analyzed | See §5 |
| 6 | `NIQ_Measurement Report example.pptx` | PowerPoint deck | ✅ Analyzed | See §7 |
| 7 | `NIQ_Presales_Insights_Example.pptx` | PowerPoint deck | ✅ Analyzed | See §6 |

Excluded from analysis: `~$NIQ_Measurement Report example.pptx`, `~$NIQ_Presales_Insights_Example.pptx`
— these are Office lock/temp files (created while the real files are open in PowerPoint), contain no
report content, and are not part of the client's actual report set.

---

## 1. Workbook: `NIQ_Customer Loyalty analysis.xlsx`

### 1.1 Workbook Inventory

- **File name:** `NIQ_Customer Loyalty analysis.xlsx`
- **File type:** Excel Open XML Workbook (`.xlsx`, no macros — no `vbaProject.bin` part present)
- **Workbook purpose `[INFERRED]`:** A client-facing "Customer Loyalty Analysis" report exported from
  NIQ's **"Memory 360"** platform (source line printed on every sheet: *"analyse-fidelite-clients -
  Plateforme Memory 360"*). It quantifies customer retention/churn ("gained"/"lost"/"constant"
  customers) for a specific brand's product scope at a specific retailer (Carrefour), with breakdowns
  by customer value, top products/brands, behavioral segmentation, and region.
- **Document metadata (docProps/core.xml):** creator = `In The Memory`; last modified by = `Eran
  Center`; created 2026‑03‑31; last modified 2026‑08‑04. `docProps/app.xml`: authored with
  "Microsoft Excel Online". `docProps/custom.xml` only contains SharePoint content-type metadata
  (no business info).
- **customXml parts (item1–3.xml):** SharePoint document-library metadata schemas (managed metadata
  columns, compliance policy placeholders). No business content — these are boilerplate produced by
  the SharePoint library the file was saved to/from, not report data.
- **Worksheets (4, all Visible — none hidden or very hidden):**
  1. `Paramètres` ("Parameters" / settings)
  2. `Bilan` ("Summary/Balance")
  3. `Profil` ("Profile")
  4. `Lexique` ("Glossary")
- **Used range per sheet** (Excel's stored `dimensions` overstates the range — see note below):

  | Sheet | Stored `dimension` (openpyxl) | **Actual non-empty content range** |
  |---|---|---|
  | Paramètres | A1:KN33 | A1:E33 |
  | Bilan | A1:KN31 | A1:I30 |
  | Profil | A1:KN1756 | A1:O1755 |
  | Lexique | A1:KN74 | A1:C74 |

  `[NOTE]` All 4 sheets report a stored dimension extending to column `KN` (~300) because formatting
  (not real data) was applied across a wide column range at specific rows, leaving literal empty-string
  (`""`) cell values, not `None`. These are **not data** — they were excluded to compute the "actual"
  range above. This is a common artifact of platform-generated exports and should not be mistaken for
  additional hidden data columns.
- **Named ranges:** None (workbook-scoped `defined_names` is empty; no sheet-scoped defined names found).
- **Excel Tables (ListObjects):** None on any sheet.
- **Pivot tables / pivot caches:** None (`xl/pivotCache*`, `xl/pivotTables*` parts absent from the
  package).
- **Charts:** None. The 4 `xl/drawings/drawingN.xml` parts + 3 `xl/media/imageN.png` files are **static
  logo/header images** (anchored at row 0 of each sheet), not charts — confirmed by inspecting the
  drawing XML (picture/`blipFill` shapes only, no `<c:chart>` references) and by the absence of any
  `xl/charts/` parts in the package.
- **Slicers / filters / timelines:** None (`xl/slicers`, `xl/slicerCaches`, `xl/timelines` parts absent).
  Filtering appears to have been applied **before export** (see `Paramètres` sheet, which documents the
  filter selections as static text — this is a "parameters used" record, not a live/interactive filter).
- **External workbook links:** None found.
- **Data connections / Power Query / Data Model / Power Pivot:** None (`xl/connections.xml`,
  `xl/queryTables`, `xl/dataModel`, `customXml` DataMashup blobs all absent). This workbook is a
  **static data export/snapshot**, not a live BI/self-service model.
- **Macros / VBA:** None (no `vbaProject.bin`; file loads cleanly with `keep_vba=True` and reports no
  VBA project).
- **Formulas:** **None.** Every cell in every sheet was checked; there are zero formula cells (all
  values are static/hardcoded numbers, strings, or dates). This means all KPI calculation logic is
  **not visible in this file** — it happened upstream in the Memory 360 platform before export.
  `[IMPORTANT — no formulas/business logic to extract from this file; see catalog item 4 below]`.
- **Comments / notes / text boxes with business definitions:** No cell comments (`.comment`) found on
  any sheet. However, the entire `Lexique` sheet is a **structured business glossary** (see §1.6) —
  this is the primary source of KPI/dimension definitions for this workbook.
- **Workbook / sheet protection:** None. `wb.security` is empty; no sheet reports
  `sheet.protection.sheet = True`. The workbook is fully open/unprotected — no inaccessible content.
- **Freeze panes:** None set on any sheet.
- **Merged cells:** Present on all 4 sheets (mostly used for section headers/titles and multi-column
  group headers, e.g. `Bilan!B2:L2`, `Profil!C6:O6`). Full detail in per-sheet sections below.
- **Hidden rows/columns:** None detected on any sheet.

### 1.2 Sheet-Level Analysis

#### Sheet: `Paramètres` (Parameters)

- **Visibility:** Visible
- **Apparent purpose:** Documents the report's metadata and the filter/scope selections that were
  active at export time (retailer, banner, region, store surface, product hierarchy/level, brand
  filters, analysis period vs. comparison period). This is a **parameter/configuration record**, not
  live filters — values are static.
- **Classification:** Configuration / parameter sheet.
- **Structure:**
  - Row 1–2: report title (`analyse-fidelite-clients - Plateforme Memory 360`) and data-source
    statement: *"Source : Memory sur la base des données transactionnelles des clients encartés et
    non encartés de Carrefour"* (i.e., source = Memory platform, based on transactional data of
    Carrefour's carded ["encartés" = loyalty-card] and non-carded customers).
  - Row 4–6: report name (`Analyse fidélité Herta_Test_0326`), retailer (`Carrefour`), category
    (`Analyser`, `[UNVERIFIED]` — likely a category/report-type label rather than "Category" in the
    merchandising sense).
  - Row 8–15: "Périmètre Magasin" (store scope) parameters: Banner, Region, Store surface,
    Constants/Current stores toggle (`Courants`), Transaction type (`Total`), plus the selected
    performance indicator for filtering (`Indicateur de performance: CA` = revenue).
  - Row 17–23: "Périmètre Produits" (product scope) parameters: product nomenclature/hierarchy name
    (`EAN_HERTA_310326`), the specific product level members selected (row 19 — a very long
    semicolon-delimited list of ~100+ specific Herta SKUs/EANs by description — this is the literal
    product filter list used to build the report), Bio filter, Nutriscore filter, "Triptyque" filter,
    Brand filter (all `Pas de filtre` = no filter applied).
  - Row 25–26: analysis-level parameters (labels present, values blank in this export).
  - Row 28–33: period parameters — period type = `CAM` (Cumul Annuel Mobile / rolling annual
    total — see glossary), Analysis period 2025‑03‑24 → 2026‑03‑22, Comparison period 2024‑03‑25 →
    2025‑03‑23 (i.e., a rolling 12-month period vs. the prior rolling 12-month period).
- **Multi-level headers:** Row 8 has a two-part header split across columns A–B ("Paramètres du
  rapport") and D onward ("Filtres sélectionnés au moment de l'export"), effectively two side-by-side
  parameter blocks.
- **Merged cells (8):** `B1:L1`, `B2:L2` (title/source banner), `A8:B8`, `A10:B10`, `A17:B17`,
  `A24:B24`, `A27:B27`, `D8:E8` (label groupings).
- **Filters/slicers:** None (static parameter record only).
- **Totals/subtotals:** N/A (not a data table).
- **Notable formatting:** None beyond header banner/merges.

#### Sheet: `Bilan` (Summary)

- **Visibility:** Visible
- **Apparent purpose:** Executive summary of the customer base movement between the comparison period
  and analysis period, split by CA (revenue), UVC (unit sales), and Clients (customer count), each
  shown for both periods side by side.
- **Classification:** Report output (KPI summary table).
- **Structure — two stacked tables:**
  1. **"Vision simplifiée"** (Simplified view), rows 8–15: customer-type rows = `Total`, `Encartés`
     (carded/loyalty customers), `Non encartés` (non-carded), `Constants` (retained customers),
     `Gagnés (tous)` (all gained customers), `Perdus (tous)` (all lost customers). Columns = CA
     (comparison/analysis), UVC (comparison/analysis), Clients (comparison/analysis) — i.e. a 6-row ×
     6-value (3 metrics × 2 periods) grid.
  2. **"Vision détaillée"** (Detailed view), rows 19–30: same metric/period column structure, but with
     customer-type rows expanded to distinguish **why** a customer was gained/lost: `Gagnés (tous)`,
     `Gagnés (périmètre produits)` (gained within the specific product scope), `Gagnés (enseigne)`
     (gained at the retailer/banner level), and the mirrored three `Perdus (...)` (lost) variants, plus
     `Constants` and `Total`.
- **Multi-level headers:** Row 8/19 = metric group header (`CA`, `UVC`, `Clients`) each merged over 2
  columns; row 9/20 = sub-header (`Période de comparaison`, `Période d'analyse`) under each metric.
  `Type de clients` label in column C is the row-dimension header.
- **Merged cells (13):** title/source banner (`B1:L1`, `B2:L2`), section titles (`B4:J4` "Bilan
  clients"), metric group headers (`D8:E8`, `F8:G8`, `H8:I8`; `D19:E19`, `F19:G19`, `H19:I19`),
  section labels (`C6:I6` "Vision simplifiée", `C17:I17` "Vision détaillée"), and row-header merges
  (`C8:C9`, `C19:C20` for "Type de clients" spanning the 2-row header).
- **Totals/subtotals:** The `Total` row is effectively a grand total across customer types; not a
  spreadsheet SUM formula (values are static), but conceptually `Total = Encartés + Non encartés` and
  `Total ≈ Constants + Gagnés(tous) + Perdus(tous)` conceptually — **not verified by formula**, only
  by the glossary definitions.
- **Filters/slicers:** None (static export).
- **Notable formatting:** Numeric values are large plain floats (e.g. `257675500.459997`) with no
  visible thousand-separator formatting captured at the value level (actual number formatting/styles
  were not further decoded in this pass, `[NOT FULLY REVIEWED]` — style/number-format codes from
  `xl/styles.xml` were not individually mapped to cells; can be done in a follow-up pass if display
  formatting matters for the target app).

#### Sheet: `Profil` (Profile)

- **Visibility:** Visible
- **Apparent purpose:** The detailed analytical body of the report — customer value metrics,
  product-level and brand-level rankings, and customer segmentation/geographic breakdowns, each cut by
  the same customer-type dimension (`Total`, `Encartés`, `Non encartés`, `Constants`, `Gagnés (*)`,
  `Perdus (*)`, `Clients`).
- **Classification:** Report output (multi-block KPI detail table). Very large used range (1,755 rows)
  because it stacks multiple independent tables vertically.
- **Structure (5 stacked blocks, in row order):**
  1. **Rows 6–17 — "Périmètre produits" (Product-scope) customer value table.** Row dimension =
     customer type (`Perdus (enseigne/tous/périmètre produits)`, `Gagnés (enseigne/tous/périmètre
     produits)`, `Constants`, `Clients`). Column groups (2-level header, rows 8–9): `CA/Client` (revenue
     per customer), `Client` (customer count/value), `Poids promo CA` (% of revenue from
     promotion), `Poids promo UVC` (% of unit sales from promotion) — each with sub-columns `Valeur`
     (value), `Ecart vs. constants` (variance vs. the "Constants" baseline row), `Evolution` (period
     over period % change).
  2. **Rows 19–30 — "Total enseigne" (Total retailer) customer value table.** Same column structure as
     block 1, but scoped to the whole retailer/banner rather than just the product scope — a
     benchmark comparison table.
  3. **Rows 33–1349 — "Top EAN/Marque" → "Top EAN" (Top products) ranking table.** Header row 37:
     `Type de clients`, `EAN` (barcode), `Libellé` (product description), `Marque` (brand), `CA`, `UVC`,
     `Indice CA` (revenue index vs. total, see glossary), `Indice UVC`, `Evolution CA`, `Evolution
     UVC`. This block repeats the full top-product ranking **once per customer-type segment** —
     confirmed counts: `Perdus (enseigne)`=180 rows, `Perdus (tous)`=181, `Perdus (périmètre
     produits)`=180, `Gagnés (tous)`=183, `Gagnés (périmètre produits)`=181, `Gagnés (enseigne)`=180,
     `Constants`=226 rows — i.e., a ranked list of individual EAN/products (all branded `HERTA` in this
     export) purchased by customers in each segment, sorted descending by CA (largest first).
  4. **Rows 1351–1360 — "Top Marques" (Top brands) table.** Same customer-type row dimension, but
     aggregated to brand level (only `HERTA` appears in this dataset — single-brand analysis). Columns:
     `Marque`, `CA`, `UVC`, `Indice CA`, `Indice UVC`, `Evolution CA`, `Evolution UVC`.
  5. **Rows 1363–1696 — "Segmentations" table.** Row dimension = customer type (47 rows per segment ×
     7 segments = 329 data rows). Columns: `Segmentation` (segmentation family — observed values:
     `Structurelle Multiformat`, `Promotion`, `Consostyle Multiformat`, `Lifestage`), `Détail`
     (`Macro`/`Micro` — level of granularity within the segmentation), `Segment` (the specific segment
     label, e.g. `Inactif court 6 mois`, `Petit % CA promo, Moyen régul`, `Familles avec enfant entre 0
     et 2 ans`), `Indice CA`, `Indice UVC`, `Part de CA` (share of revenue), `Part des UVC` (share of
     units), `Evolution CA`, `Evolution UVC`.
  6. **Rows 1697–1755 — "Répartition géographique" (Geographic breakdown) table.** Row dimension =
     customer type (8 rows per segment × 7 segments = 56 data rows). Columns: `Région` (8 French sales
     regions: Sud Est, Ouest, Paris, Nord, Centre Ouest, Centre Est, Sud Ouest, Est), `Indice CA`,
     `Indice UVC`, `Part de CA`, `Part des UVC`, `Part de CA (évol.)`, `Part des UVC (évol.)`.
- **Multi-level headers:** Blocks 1–2 use a genuine 2-row multi-level header (metric group row +
  Valeur/Ecart/Evolution sub-row). Blocks 3–6 use single-row headers per block.
- **Merged cells (18):** title/source banner and section/sub-section title merges only (e.g.
  `B33:M33` "Top EAN/Marque", `B1363:M1363` "Segmentations" (label appears to actually read
  "Segmentations" per row 1363 col B — noted as `B1363` in the raw dump), `B1697:K1697` "Répartition
  géographique", plus header group merges in blocks 1–2 (`G8:I8`, `J8:L8`, `M8:O8`, `D20:F20`,
  `G20:I20`, `J20:L20`, `M20:O20`, `C6:O6`, `C18:O18`).
- **Totals/subtotals/grouping:** No spreadsheet subtotal rows; grouping is purely by the repeating
  `Type de clients` block structure described above (i.e., grouping is structural/row-based, not via
  Excel's outline/group feature — no outline levels were detected).
- **Filters/slicers:** None.
- **Data quality note `[OBSERVED]`:** Many "Constants" rows in the Top-EAN block (rows ~1300–1349) have
  `CA=0`, `UVC=0`, `Evolution=-1` — i.e., -100% evolution for products with zero current activity;
  worth flagging as an edge case for KPI/evolution-% logic (division by zero / prior-period-only
  products) when the calculation logic is later reverse-engineered from other sources.

#### Sheet: `Lexique` (Glossary)

- **Visibility:** Visible
- **Apparent purpose:** Formal business glossary defining every KPI, dimension, and segmentation label
  used elsewhere in the workbook. **This is the single most valuable sheet in this workbook for KPI
  business-logic documentation.**
- **Classification:** Lookup/reference data (business definitions), not a data table.
- **Structure:** Simple 2-column key/value table, header row 6 (`Mot clé` / `Définition`), 68 term rows
  (rows 7–74). Full term list transcribed:

  | Term (`Mot clé`) | Definition (`Définition`) |
  |---|---|
  | Segmentation Lifestage - 18 et 24 ans sans enfant | Adultes sans enfants ayant entre 18 et 24 ans |
  | Segmentation Lifestage - 25 et 39 ans sans enfant | Adultes sans enfants ayant entre 25 et 39 ans |
  | Segmentation Lifestage - 40 et 64 ans sans enfant | Adultes sans enfants ayant entre 40 et 64 ans |
  | Segmentation Lifestage - 65 ans et + sans enfant | Adultes sans enfants ayant plus de 65 ans |
  | Bannière | Désigne le format du magasin (Hyper, Market Contact, Express ou City) |
  | CA encartés | Chiffre d'affaires réalisé par les clients encartés |
  | CA non encartés | Chiffre d'affaires réalisé par les clients non encartés |
  | CA/client | Chiffre d'affaires moyen réalisé par un client |
  | CAD (Cumul A Date) | Correspond au cumul des périodes comprises entre le début de la première période Nielsen de l'année en cours et la fin d'une période Nielsen donnée. Ex: le CAD P6 2019 court du début de la P1 2019 à la fin de la P6 2019 |
  | CAM (Cumul Annuel Mobile) | Correspond aux 13 périodes Nielsen qui précèdent la date de fin d'une période donnée. Ex: le CAM P6 2019 court du début de la P7 2018 à la fin de la P6 2019 |
  | Client gagné (benchmark produits) | Acheteur du périmètre produits en période d'analyse; en comparaison, acheteur à l'enseigne mais pas au benchmark ni au périmètre produits |
  | Client gagné (enseigne) | Acheteur du périmètre produits en analyse; en comparaison, pas acheteur du tout (ni enseigne, ni benchmark, ni périmètre) |
  | Client gagné (périmètre produits) | Acheteur du périmètre produits en analyse; en comparaison, acheteur de l'enseigne et du benchmark mais pas du périmètre produits |
  | Client gagné (tous) | Acheteur du périmètre produits en analyse mais pas en comparaison |
  | Client perdu (benchmark produits) | Acheteur du périmètre produits en comparaison; en analyse, n'achète plus le périmètre ni le benchmark, mais achète encore l'enseigne |
  | Client perdu (enseigne) | Acheteur du périmètre produits en comparaison; en analyse, n'achète plus ni le périmètre, ni le benchmark, ni même l'enseigne |
  | Client perdu (périmètre produits) | Acheteur du périmètre produits en comparaison; en analyse, n'achète plus le périmètre produits mais continue d'acheter le benchmark |
  | Client perdu (tous) | Acheteur du périmètre produits en comparaison mais pas en analyse |
  | Constants enseigne | Acheteur du périmètre produits à la fois en comparaison et en analyse |
  | Cumul 4 semaines | Période de 4 semaines glissantes |
  | EAN maître | Déclinaison principale d'un ensemble de produits identiques du point de vue consommateur; un ou plusieurs EAN esclave(s) (ventes sans suite / switchs) y sont associés |
  | Nomenclature Super | Nomenclature produits propre à Carrefour |
  | Evolution % | Evolution en % de l'indicateur entre deux périodes |
  | Indice CA | Sur/sous-représentation d'un indicateur vs. la part de CA totale (indice 120 = part de dépense 20% plus élevée) |
  | Indice UVC | Idem, sur la base de la part d'UVC |
  | Macro/micro | Niveau de détail des segmentations clients |
  | Magasins courants | Magasins ayant vendu au moins une fois sur les deux périodes (≠ magasins constants, qui gèrent aussi ouvertures/fermetures/changements de surface) |
  | Nomenclature Client | Nomenclature produits Memory basée sur la nomenclature Carrefour Hyper + vision UR (Univers de Report) + UBC (Unité Besoin Client); intègre le chaînage des produits |
  | Nomenclature Hyper | Nomenclature produits propre à Carrefour |
  | Nomenclature Proxi | Nomenclature produits propre à Carrefour |
  | Période d'analyse | Intervalle de temps sur lequel est menée l'analyse |
  | Période de comparaison | Intervalle de même amplitude que la période d'analyse, servant de référence |
  | Période Nielsen | Période de 28 jours consécutifs (13 par année civile) |
  | Poids promo | Part du CA réalisée en prospectus promotion sur les EAN gencodés (hors poids variables) |
  | PP (Premiers Prix) | Type de marque des produits premiers prix |
  | Segmentation Consostyle | Segmentation des clients selon leurs habitudes de consommation d'achat |
  | Segmentation Consostyle - Bons plans | Clients à la recherche des bonnes affaires (promotions, lots, comparateurs), sensibles aux Marques Nationales |
  | Segmentation Consostyle - Budget | Clients contraints budgétairement, sensibles aux MDD (Carrefour Discount) et Premiers Prix |
  | Segmentation Consostyle - Gourmet | Clients recherchant qualité/provenance/terroir, peu sensibles aux promotions |
  | Segmentation Consostyle - Nutrition | Clients recherchant des produits sains/qualitatifs, fidèles aux MDD (hors Carrefour Discount) |
  | Segmentation Consostyle - Pratique | Clients recherchant simplicité/praticité, attirés par l'innovation, contraints par le temps |
  | Segmentation Lifestage | Segmentation selon critères sociologiques: nb d'enfants + âges des enfants et adultes |
  | Segmentation Lifestage - Adultes - sans enfants | Adultes sans enfants ≥18 ans (~70% des clients encartés) |
  | Segmentation Lifestage - Familles +5ans | Familles avec enfant(s) 5–25 ans |
  | Segmentation Lifestage - Familles -5ans | Familles avec enfant(s) 0–5 ans |
  | Segmentation Promo | Segmentation selon poids CA promo + régularité d'achat |
  | Segmentation Promo - Gros % CA promo, Gros régul | ~2% des clients Carrefour |
  | Segmentation Promo - Gros % CA promo, Moyen régul | ~5% |
  | Segmentation Promo - Gros % CA promo, Petit régul | ~7% |
  | Segmentation Promo - Moyen % CA promo, Gros régul | ~8% |
  | Segmentation Promo - Moyen % CA promo, Moyen régul | ~14% |
  | Segmentation Promo - Moyen % CA promo, Petit régul | ~14% |
  | Segmentation Promo - Petit % CA promo, Gros régul | ~7% |
  | Segmentation Promo - Petit % CA promo, Moyen régul | ~15% |
  | Segmentation Promo - Petit % CA promo, Petit régul | ~28% |
  | Segmentation Structurelle | Segmentation selon récence, ancienneté, régularité, fréquence |
  | Segmentation Structurelle - Actifs | Achète ≥1×/6 mois en alimentaire (~65% des clients Carrefour) |
  | Segmentation Structurelle - Bi-mensuel | Achète 2–3 semaines/mois |
  | Segmentation Structurelle - Hebdo | Achète toutes les semaines |
  | Segmentation Structurelle - Inactif court | Inactif depuis ≥6 mois, dernier achat entre 6–12 mois (~8%) |
  | Segmentation Structurelle - Inactif long | Inactif depuis ≥12 mois, dernier achat entre 1–4 ans (~11%) |
  | Segmentation Structurelle - Irrégulier | Achète 1–6×/an |
  | Segmentation Structurelle - Mensuel | Achète ≥2 semaines/mois |
  | Segmentation Structurelle - Nouveau | Client depuis <3 mois |
  | Segmentation Structurelle - Perdu de vue | Inactif depuis >2 ans, dernier achat entre 2–4 ans (~16%) |
  | Segmentation Structurelle - Réactivé | Client depuis >3 mois (réactivation) |
  | Total enseigne | Ensemble des produits vendus par l'enseigne |
  | UVC – Unité de Vente Consommateur | Nombre de produits vendus |

  `[NOTE]` Two terms (`EAN maître`, `Nomenclature Client`) contain the longest/most technical
  definitions and describe Memory-platform-specific data modeling concepts (master/slave EAN chaining,
  custom product hierarchy) that will likely matter for the target data model's product dimension.
- **Merged cells (72):** Each definition row merges `C{row}:L{row}` so the long French definition text
  wraps across the full row width — purely cosmetic, not structural.
- **Filters/totals/grouping:** None (flat reference list).

### 1.3 Dimensions & Attributes Catalog (this workbook)

| Dimension | Values observed | Source sheet |
|---|---|---|
| Customer type / movement segment | Total, Encartés, Non encartés, Constants, Gagnés (tous / périmètre produits / enseigne), Perdus (tous / périmètre produits / enseigne), Clients | Bilan, Profil |
| Period | Période de comparaison, Période d'analyse | Bilan, Profil |
| Product (EAN) | Individual EAN/barcode + Libellé (description) + Marque (brand) | Profil (Top EAN block) |
| Brand | HERTA (only brand present in this export) | Profil (Top Marques block) |
| Segmentation family | Structurelle Multiformat, Promotion, Consostyle Multiformat, Lifestage | Profil (Segmentations block) |
| Segmentation granularity | Macro, Micro | Profil |
| Segment (value within a family) | ~30+ distinct labels, see Lexique | Profil |
| Region | Sud Est, Ouest, Paris, Nord, Centre Ouest, Centre Est, Sud Ouest, Est | Profil (Répartition géographique) |
| Banner (report-parameter only, not a data column in this export) | Hyper, Market Contact, Express, City (per glossary definition) | Lexique / Paramètres |

### 1.4 KPIs / Measures Catalog (this workbook)

| KPI / Measure | Appears in | Definition source | Notes |
|---|---|---|---|
| CA (Chiffre d'affaires / Revenue) | Bilan, Profil | Lexique (implicitly; "CA encartés/non encartés" defined) | Currency amount, large float values, no currency symbol captured in raw value |
| UVC (Unité de Vente Consommateur / unit sales) | Bilan, Profil | Lexique: "Désigne le nombre de produits vendus" | Integer count |
| Clients (customer count) | Bilan | `[INFERRED]` count of distinct customers per segment | |
| CA/Client | Profil | Lexique: "CA moyen réalisé par un client" | = CA ÷ Clients `[INFERRED formula, not shown as a spreadsheet formula]` |
| Poids promo CA | Profil | Lexique: "Part du CA réalisée en prospectus promotion sur les EAN gencodés (hors poids variables)" | Expressed as a decimal fraction (e.g. `0.1257`) |
| Poids promo UVC | Profil | `[INFERRED]` same definition as Poids promo CA, applied to UVC instead of CA | |
| Ecart vs. constants | Profil | `[INFERRED]` difference between a segment's value and the "Constants" baseline value for the same metric | Appears only alongside CA/Client, Client, Poids promo CA/UVC in blocks 1–2 |
| Evolution / Evolution % | Profil | Lexique: "Evolution en % de l'indicateur entre deux périodes" | Values like `-1` = -100% (e.g., no activity in one period) |
| Indice CA | Profil | Lexique: over/under-representation vs. total CA share; 100 = neutral | |
| Indice UVC | Profil | Lexique: same, based on UVC share | |
| Part de CA / Part des UVC | Profil (Segmentations, Région blocks) | `[INFERRED]` = share (%) of CA/UVC attributable to a segment/region | Decimal fraction |
| Part de CA (évol.) / Part des UVC (évol.) | Profil (Région block) | `[INFERRED]` = period-over-period change in the share, not the share itself | Only in geographic block |

### 1.5 KPI Formulas & Business Logic

**No spreadsheet formulas exist in this workbook** (confirmed: 0 formula cells across all sheets).
All KPI values are static numbers computed upstream by the Memory 360 platform prior to export. The
only "business logic" documentable from this file is the **textual definitions in the Lexique sheet**
(§1.2/§1.3/§1.4 above) plus the **customer gain/loss taxonomy**, which is precise enough to be
treated as a specification:

- A customer is **"Constants"** if they bought the product scope in both the comparison period and
  the analysis period.
- A customer is **"Gagné (tous)"** (gained, all) if they bought the product scope in the analysis
  period but not in the comparison period. This is further decomposed into three mutually-referenced
  sub-populations based on what they *did* buy in the comparison period:
  - **Gagné (périmètre produits)** — was buying the retailer (enseigne) *and* the benchmark product
    set, just not this specific product scope, in the comparison period.
  - **Gagné (benchmark produits)** — was buying the retailer, but neither benchmark nor this product
    scope, in the comparison period.
  - **Gagné (enseigne)** — was not buying anything at this retailer at all in the comparison period
    (fully new to the retailer).
- **"Perdu (tous)"** (lost, all) is the symmetric opposite: bought the product scope in the comparison
  period but not the analysis period, decomposed the same way (Perdu périmètre produits / benchmark
  produits / enseigne) based on what they still buy in the analysis period.
- **`[GAP — NOT AVAILABLE]`** The glossary defines "Client gagné (benchmark produits)" and "Client
  perdu (benchmark produits)" but **no "benchmark produits" values actually appear** in the Bilan or
  Profil data tables in this workbook (only `tous`, `périmètre produits`, `enseigne` variants are
  present as data rows). The benchmark-product variant may be used in other report variants/workbooks
  not yet analyzed, or may only be surfaced elsewhere in the platform — flagged for confirmation.

### 1.6 Report Layout / Where KPIs Are Displayed

| Sheet | Section | KPIs shown | Layout |
|---|---|---|---|
| Bilan | Vision simplifiée (rows 8–15) | CA, UVC, Clients | 6 customer-type rows × (metric × period) grid |
| Bilan | Vision détaillée (rows 19–30) | CA, UVC, Clients | 10 customer-type rows × (metric × period) grid |
| Profil | Product-scope value table (rows 6–17) | CA/Client, Client, Poids promo CA, Poids promo UVC (each: Valeur / Ecart vs. constants / Evolution) | 8 customer-type rows × 4 metric groups × 3 sub-columns |
| Profil | Total-enseigne value table (rows 19–30) | Same as above, retailer-wide benchmark | same layout |
| Profil | Top EAN (rows 33–1349) | EAN, Libellé, Marque, CA, UVC, Indice CA, Indice UVC, Evolution CA, Evolution UVC | Ranked list, repeated per customer-type segment |
| Profil | Top Marques (rows 1351–1360) | Marque, CA, UVC, Indice CA, Indice UVC, Evolution CA, Evolution UVC | 1 row per customer-type segment (single brand in this export) |
| Profil | Segmentations (rows 1363–1696) | Indice CA, Indice UVC, Part de CA, Part des UVC, Evolution CA, Evolution UVC | Segmentation × Détail × Segment rows, repeated per customer-type |
| Profil | Répartition géographique (rows 1697–1755) | Indice CA, Indice UVC, Part de CA, Part des UVC, Part de CA (évol.), Part des UVC (évol.) | Région rows, repeated per customer-type |
| Lexique | Glossary | N/A (definitions only) | 2-column key/value list |
| Paramètres | N/A (parameters, not KPIs) | N/A | Label/value pairs |

### 1.7 Embedded SQL / Queries / Transformations / Dependencies

None found. No Power Query (`M` code), no SQL, no external data connections, no data model
relationships, no VBA. This workbook is a **flat, static export** — all transformation/aggregation
logic occurred outside the file, in the Memory 360 platform, and is not recoverable from this file
alone.

### 1.8 Protection / Inaccessible Content

None. The workbook has no workbook-level or sheet-level protection, no password, and every part of
the ZIP package opened and parsed cleanly. Nothing was inaccessible.

### 1.9 Open Questions / Gaps Flagged for This Workbook

1. Exact calculation formulas for `CA/Client`, `Ecart vs. constants`, `Evolution %`, `Indice CA/UVC`,
   `Poids promo` are described in prose (glossary) but not shown as executable formulas — precise
   rounding/edge-case behavior (e.g., division by zero when a segment has 0 clients) is
   `[UNVERIFIED]` and should be confirmed with the client or against another data source.
2. "Benchmark produits" gain/loss categories are defined in the glossary but have no corresponding
   data rows in this specific export — unclear if used elsewhere.
3. Cell-level number formatting (currency symbols, percentage display, decimal precision) was not
   mapped in this pass; only raw values were captured. Can be revisited if exact display formatting is
   needed.

---

## 2. Workbook: `NIQ_Datasheet_Liftcampaign.xlsx`

### 2.1 Workbook Inventory

- **File name:** `NIQ_Datasheet_Liftcampaign.xlsx`
- **File type:** Excel Open XML Workbook (`.xlsx`, no macros)
- **Workbook purpose `[INFERRED]`:** The **raw tabular data export behind a media "Lift
  Campaign"/incrementality measurement study** — i.e., the underlying datasheet for a report that
  measures the sales impact of an advertising/retail-media campaign by comparing an **Exposed** group
  vs. a **Control** group of shoppers, and a **Campaign** period vs. a **Pre Campaign** (baseline)
  period. This is almost certainly the data source feeding a deck like
  `NIQ_Measurement Report example.pptx` (not yet analyzed — to be cross-checked in that section).
  Every sheet shares one `Study Id` GUID (`2b178f13-2fff-4333-b4c6-28e7a1d76e83`), confirming all 37
  sheets belong to a single measurement study/campaign.
- **Document metadata:** creator blank; last modified by `Eran Center`; created 2026‑07‑30, modified
  2026‑08‑04. Same SharePoint boilerplate `customXml` parts as workbook 1 (no business content).
- **Worksheets: 37, all Visible** (none hidden/very hidden). Several names are truncated to Excel's
  31-character sheet-name limit (noted below with their likely full name `[INFERRED]`):

  | # | Sheet name (as stored) | Likely full name `[INFERRED]` |
  |---|---|---|
  | 1 | Appendix Pvalues | (complete) |
  | 2 | Appendix SKU Validation | (complete) |
  | 3 | Audience Affinity | (complete) |
  | 4 | Business Equation vs Control | (complete) |
  | 5 | Business Equation by Audience | (complete) |
  | 6 | Business Equation by Channel | (complete) |
  | 7 | Business Equation by SKU | (complete) |
  | 8 | Buying Behaviour - SKU | (complete) |
  | 9 | Buying Behaviour - Channels | (complete) |
  | 10 | Performance by Channel | (complete) |
  | 11 | Performance Evolution by Chann | Performance Evolution by Channel |
  | 12 | Exposure Overview - exposure | (complete) |
  | 13 | Exposure Overview - frequency | (complete) |
  | 14 | Exposure Evolutions | (complete) |
  | 15 | Frequency Impact | (complete) |
  | 16 | Scope - campaigns | (complete) |
  | 17 | Scope - audiences | (complete) |
  | 18 | Scope - targets products | (complete) |
  | 19 | Scope - additionals products | (complete) |
  | 20 | New Shoppers Acquisition | (complete) |
  | 21 | Numeric Distribution by SKU | (complete) |
  | 22 | Sales Overview - trade | (complete) |
  | 23 | Sales Overview - reach_vs_buye | Sales Overview - reach_vs_buyers |
  | 24 | Sales Overview - distribution | (complete) |
  | 25 | Sales Overview - new_buyers | (complete) |
  | 26 | Overall Business Equation on E | Overall Business Equation on Exposed [or similar] |
  | 27 | Sales Impact Evolution | (complete) |
  | 28 | Sales Uplift | (complete) |
  | 29 | Sales Uplift by Audience | (complete) |
  | 30 | Performance by Audience | (complete) |
  | 31 | Loyalty Profiles - Per Audienc | Loyalty Profiles - Per Audience |
  | 32 | Loyalty Profiles - Per Channel | (complete) |
  | 33 | Loyalty Profiles - Total | (complete) |
  | 34 | Loyalty Profiles - Number of P | Loyalty Profiles - Number of Products [or "Purchases"] `[UNVERIFIED]` |
  | 35 | Loyalty Profiles - Distributio | Loyalty Profiles - Distribution |
  | 36 | Shoppers Profiles | (complete) |
  | 37 | Shoppers Profiles Exposed vs C | Shoppers Profiles Exposed vs Control |

- **Used range per sheet:** ranges from tiny (1 header row only, e.g. `Exposure Overview -
  frequency`, `Frequency Impact` — headers present but **zero data rows**, `[OBSERVED — empty data
  sheets]`) up to 4,385 rows (`Appendix SKU Validation`). Unlike workbook 1, there is **no
  column-range inflation artifact** here — `ws.dimensions` matches the real data extent on every
  sheet (max column ≤ 25, no stray empty-string cells found).
- **Named ranges:** None.
- **Excel Tables:** None (plain ranges with header row 1, no `ListObject` tables defined).
- **Pivot tables / pivot caches:** None.
- **Charts:** None (no `xl/charts` or `xl/drawings` parts at all in this workbook — no logos/images
  either, unlike workbook 1).
- **Slicers / filters / timelines:** None.
- **External workbook links / data connections / Power Query / Data Model / VBA:** None — same as
  workbook 1, this is a fully static, formula-free data export (confirmed: 0 formula cells across all
  37 sheets, 0 cell comments, 0 defined names).
- **Comments / notes / text boxes with business definitions:** None. **No glossary sheet exists in
  this workbook** (unlike workbook 1's `Lexique`) — column headers are self-descriptive English metric
  names, but there is **no authoritative textual definition source within this file**
  `[GAP — flagged]`.
- **Workbook / sheet protection:** None found; fully open.
- **Freeze panes / merged cells / hidden rows or columns:** None on any sheet.

### 2.2 Sheet-Level Analysis

All 37 sheets share the same general shape: a **flat fact table**, one header row, data rows below,
with a small, closed set of repeating dimension values sliced every possible way. General
classification: **Report output / analytical data extract** (pre-aggregated at various grains — none
of these are raw/atomic transaction-level rows; every sheet is already grouped/aggregated by some
combination of dimensions). No sheet is source/staging/lookup data in the traditional sense — this
entire workbook plays the same conceptual role as the `Bilan`/`Profil` sheets in workbook 1 (i.e., it
is the "flattened star schema output" of an analytical platform), just without a cover/parameters
sheet.

**Common dimensions found repeated across most sheets** (each sheet mixes a subset of these,
typically alongside `Study Id` as a constant, unused-for-reporting join key):

- **`Period`** — 2 values: `Pre Campaign` (baseline), `Campaign` (measurement window).
- **`Product List`** (a.k.a. product scope) — 2 values: `Target Products` (the products being
  promoted/measured), `Total` (all products, the shoppers' full basket/benchmark).
- **`Group`** — 2 values: `Control` (not exposed to the campaign/ad), `Exposed` (was exposed).
- **`Audience`** — observed values: `Acheteurs_ProduitsDuMonde_24M_V3_Dedup` (a named audience segment,
  "World Products buyers, 24 months, v3, deduplicated" `[UNVERIFIED translation]`), `Acheteurs_
  Reghalal_24M_V3` ("Regular Halal buyers, 24 months, v3" `[UNVERIFIED translation]`), plus a `Total`
  roll-up. Audience names appear to be **client/category-specific segment definitions** configured for
  this specific study (not a fixed universal taxonomy) — this is a **halal/world-foods campaign**,
  distinct in subject matter from workbook 1's Herta charcuterie loyalty analysis.
- **`Channel`** — 6 values: `HYPERMARKET`, `SUPERMARKET`, `E-COMMERCE`, `PROXIMITY - CONVENIENCE`,
  `CASH & CARRY`, plus `Total`.
- **`SKU` / `Product Name`** — individual product barcode + description (French packaged-goods
  products: couscous, semolina, chickpeas, halal ready meals, etc. — brands e.g. `SAMIA`, `DOUNIA
  HALAL`, `LA PASTA`/`LA PAST`, `Renard`, `Cap Bon`, `Freshly`).
- **`Hierarchy 1` / `Hierarchy 2`** (in the two `Shoppers Profiles*` sheets) — customer segmentation
  families/values: `CONSOSTYLE` (e.g. `CONSOSTYLE 8 - Nutrition Bio`, `CONSOSTYLE 3 - Bons Plans
  accro`), `LIFESTAGE`, `PROMO`, `RFM` (e.g. `RFM 5 - Panier Très Fréquent` = "Very frequent basket").
  `[NOTE]` These segmentation labels are conceptually similar to (but not identical in naming to) the
  `Segmentation Consostyle`/`Segmentation Lifestage`/`Segmentation Promo`/`Segmentation Structurelle`
  families defined in workbook 1's `Lexique` — likely the same underlying Memory-platform segmentation
  system reused across NIQ report types. `RFM` (Récence/Fréquence/Montant = Recency/Frequency/
  Monetary) does not appear in workbook 1's glossary — `[GAP]` no definition available for this
  family or its specific segment labels in either workbook so far.
- **`Is Control` / `Is New Shopper`** — Yes/No flags used as an alternate way of encoding the
  Control/Exposed and New/Returning shopper splits on some sheets.

**Per-sheet purpose summary** (grouped by theme; full column lists are in §2.4):

| Sheet | Classification | Purpose `[INFERRED from headers/data]` |
|---|---|---|
| Appendix Pvalues | Report output (statistical appendix) | Statistical significance (p-values) of the lift results for each KPI (Buyer Rate, Revenue per Shopper, Receipts per Shopper, Quantity per Shopper, Avg. Basket Value, Avg. Price per Product), per Audience/Product List/Period, plus an `Is Multisegment Resampled` flag (methodology flag, `[UNVERIFIED]` likely indicates whether resampling was used for a multi-segment audience) |
| Appendix SKU Validation | Report output (statistical appendix / data QA) | Per-SKU price validation data: first/last transaction date, unit price, min/max unit price — likely used to validate/clean SKU price outliers before computing KPIs |
| Audience Affinity | Report output | Per-SKU, per-audience revenue/quantity/shopper metrics and "Percentage of Sales" — measures which products each audience over/under-indexes on |
| Business Equation vs Control | Report output (core KPI table) | The core "business equation" (Buyer Rate, Revenue/Receipts/Quantity per Shopper, Avg. Basket Value, Avg. Price per Product) computed for Control vs. Exposed groups, by Audience, Period, Product List — this is the primary lift comparison table |
| Business Equation by Audience | Report output | Same business-equation metrics, broken out by Audience only (no Control/Exposed split) |
| Business Equation by Channel | Report output | Same metrics broken out by retail Channel |
| Business Equation by SKU | Report output | Same metrics broken out by individual SKU, plus `Selling Stores`/`Total Stores`/`Numeric Distribution` (distribution metrics) |
| Buying Behaviour - SKU | Report output | Exposed vs. Non-Exposed shopper counts/revenue/quantity and their % shares, per SKU |
| Buying Behaviour - Channels | Report output | Same Exposed vs. Non-Exposed breakdown, per Channel |
| Performance by Channel | Report output | Revenue/Receipts/Quantity/Shoppers and their % shares, per Channel |
| Performance Evolution by Chann(el) | Report output (time series) | Daily/monthly Revenue/Quantity/Shoppers/Receipts trend per Channel |
| Exposure Overview - exposure | Report output | Media exposure metrics: Reachable, Paid/Analysed Impressions, Campaign/Analysed Cost, Shoppers, Frequency, Reach Rate, Buyer Rate, Cost per 1000 Exposed — by Total and by Audience |
| Exposure Overview - frequency | Report output (headers only, **no data rows**) | Intended to show Impressions/Exposed/Buyer Rate/Revenue by frequency bucket — empty in this export `[OBSERVED — no data]` |
| Exposure Evolutions | Report output (time series) | Daily Impressions/Reach/New Reached trend — **all values are 0 in this export** `[OBSERVED — data present but all-zero; likely a tracking/measurement gap or a channel with no exposure tracking enabled]` |
| Frequency Impact | Report output (headers only, **no data rows**) | Intended to show impact of exposure frequency on Buyer Rate/Revenue/Quantity — empty in this export |
| Scope - campaigns | Configuration/parameter (scope definition) | Lists the `Study Id` associated with this export — effectively a 1-row scope marker, not descriptive campaign metadata |
| Scope - audiences | Configuration/parameter (scope definition) | Lists the 2 audience names in scope for this study |
| Scope - targets products | Lookup/reference data | Full list of 1,096 target-product SKUs and names in scope (the campaign's promoted product list) |
| Scope - additionals products | Configuration/parameter (scope definition, **no data rows**) | Intended to list "additional products" in scope — empty in this export |
| New Shoppers Acquisition | Report output (core KPI table) | New vs. Returning shopper counts/revenue/quantity and rates, split by Control/Exposed group, Product List, and Audience |
| Numeric Distribution by SKU | Report output | Per-SKU distribution metrics (Buyer Rate, Selling Stores, Total Stores, Numeric Distribution %) by Period |
| Sales Overview - trade | Report output | Revenue/Receipts/Quantity/Shoppers plus loyalty metric ("Number/Percentage of Loyal Shoppers - more than 2 Receipts") and cost efficiency metrics (Cost per Receipt, Cost per Shopper), by Audience/Product List |
| Sales Overview - reach_vs_buyers | Report output | Compares Analysed Reach vs. Shoppers (buyers) and their % of Total Reach/Shoppers, by Audience |
| Sales Overview - distribution | Report output | Distribution of shopper counts by purchase quantity bucket (1, 2, 3, ... 20+ units) — a basket-size histogram |
| Sales Overview - new_buyers | Report output | New shopper counts and % of new shoppers/revenue, by Audience (only, no Period/Group split) |
| Overall Business Equation on Exposed | Report output (core KPI table) | The business-equation metrics further broken out combining `Analysed Reach` + all core KPIs, by Period and Product List |
| Sales Impact Evolution | Report output (time series) | Daily cumulative Reach/Shoppers/Revenue/Quantity trend, with `Cumulative Buyer Rate` and `Percentage of Total` |
| Sales Uplift | Report output (core KPI table — the headline lift result) | The single most important row(s): Incremental Revenue, Incremental Quantity, Return on Ad Spend, Incremental Shoppers/Buyer Rate, decomposition of incremental revenue into "due to Buyer Rate Increase" vs. "due to Revenue per Shopper Increase", plus p-values for Buyer Rate and Revenue per Shopper |
| Sales Uplift by Audience | Report output | Same uplift metrics, broken out per Audience |
| Performance by Audience | Report output | Buyer Rate/Revenue per Shopper/etc. by Audience — data in this sheet is anomalous (see Data Quality Note below) |
| Loyalty Profiles - Per Audience | Report output | New vs. Returning shopper % of revenue/quantity/count, by Audience |
| Loyalty Profiles - Per Channel | Report output | Same, by Channel |
| Loyalty Profiles - Total | Report output | Same, at Total Product List level, split Is New Shopper Yes/No |
| Loyalty Profiles - Number of Products | Report output | Shopper counts by "Loyalty" bucket (units purchased: `3 units`, `4+ units`, `2 units`, etc.), split by Audience and New/Returning shopper flag |
| Loyalty Profiles - Distribution | Report output | Shopper counts by purchase Quantity, split by New/Returning shopper flag |
| Shoppers Profiles | Report output | Shopper counts and % shares by customer segmentation Hierarchy (Consostyle/Lifestage/Promo/RFM) and sub-segment, for the full audience/study |
| Shoppers Profiles Exposed vs Control | Report output | Same segmentation profile, but split by Exposed vs. Control (`Is Control` Yes/No) — used to check whether the Exposed and Control groups are demographically/behaviorally comparable (a standard lift-study "balance check") |

- **Multi-level headers:** None — every sheet uses a single flat header row.
- **Totals/subtotals/grouping:** No explicit subtotal rows; "Total" appears as a **dimension member**
  (e.g., `Product List = 'Total'`, `Channel = 'Total'`) rather than a spreadsheet-computed subtotal row
  — i.e., aggregation happened upstream, and the "Total" rows are just additional pre-computed data
  rows at a coarser grain, mixed in with the detail rows in the same flat table.
- **Filters/slicers:** None (static export; equivalent filtering would be done downstream in the
  target application).
- **Freeze panes / hidden rows-columns / merged cells:** None on any sheet.
- **Data quality notes `[OBSERVED]`:**
  - `Exposure Overview - frequency` and `Frequency Impact` have headers only, zero data rows.
  - `Exposure Evolutions` has 50 data rows, but every metric value is `0` for the full date range
    (2025‑02‑10 through 2025‑03‑23) — exposure/reach tracking appears not to have produced data for
    this study, or this metric pipeline was not populated for this campaign type/channel mix.
  - `Performance by Audience` contains highly anomalous values that look like normalized indices
    rather than real KPI values (e.g. `Buyer Rate = 0` or `1` exactly, `Revenue per Shopper` values
    like `7.03e-16` or exactly `0`/`1`) — this strongly suggests either a formula/export bug in the
    source system, or these are actually z-scores/normalized index values mislabeled with the same
    column names as the raw KPIs elsewhere. **Flagged as an anomaly requiring client clarification —
    do not treat these values as literal Buyer Rate/Revenue-per-Shopper figures.**
  - Several rows in large sheets (e.g., `Appendix SKU Validation` row 2) have SKU but missing
    `Product Name`, `First/Last Transaction Date` — sparse/partial rows exist particularly toward the
    top of some sheets (`[OBSERVED]`, cause not determinable from this file alone).

### 2.3 Dimensions & Attributes Catalog (this workbook)

| Dimension | Values observed | Notes |
|---|---|---|
| Study Id | Single GUID `2b178f13-2fff-4333-b4c6-28e7a1d76e83` | Study/campaign identifier; constant across this whole file |
| Period | Pre Campaign, Campaign | Baseline vs. measurement window |
| Product List | Target Products, Total | Promoted product scope vs. full/all-products benchmark |
| Group / Is Control | Control / Exposed (or Is Control Yes/No) | Lift-test treatment split |
| Audience | Acheteurs_ProduitsDuMonde_24M_V3_Dedup, Acheteurs_Reghalal_24M_V3, Total | Named target audiences for this campaign |
| Channel | HYPERMARKET, SUPERMARKET, E-COMMERCE, PROXIMITY - CONVENIENCE, CASH & CARRY, Total | Retail channel/format |
| SKU / Product Name | Individual barcodes + descriptions | Product-level grain, halal/world-foods category |
| Segmentation Hierarchy 1 | CONSOSTYLE, LIFESTAGE, PROMO, RFM | Customer segmentation families (RFM not defined in workbook 1's glossary — gap) |
| Segmentation Hierarchy 2 | e.g. "CONSOSTYLE 8 - Nutrition Bio", "RFM 5 - Panier Très Fréquent" | Specific segment values within each family |
| Is New Shopper | Yes, No | New vs. returning shopper flag |
| Grouping Key / Grouping Value | Audience / Total (key); audience name or "Total" (value) | Generic pivot-style key/value pair used on Exposure Overview sheet |
| Date | Weekly/monthly buckets, 2025‑02 to 2025‑04 | Time series grain on evolution sheets |
| Loyalty (units bucket) | "2 units", "3 units", "4+ units", etc. | Purchase-frequency bucket |
| Quantity bucket | 1, 2, 3, ... "20+" | Basket-size histogram bucket |

### 2.4 KPIs / Measures Catalog (this workbook)

No business glossary exists in this file, so definitions below are `[INFERRED]` from standard
retail-media lift-study terminology and column naming; **none are confirmed by the client**.

| KPI / Measure | Appears in (examples) | Definition `[INFERRED]` |
|---|---|---|
| Buyer Rate | Business Equation*, Sales Uplift, Appendix Pvalues | Share of the audience/reach that purchased (Shoppers ÷ Audience Size or Reach) |
| Revenue / Revenue per Shopper | Most sheets | Total sales value; average revenue per buying shopper |
| Receipts / Receipts per Shopper | Most sheets | Number of purchase transactions; average transactions per shopper |
| Quantity / Quantity per Shopper | Most sheets | Units sold; average units per shopper |
| Avg. Basket Value | Business Equation*, Sales Overview | Average revenue per receipt/basket |
| Avg. Items per Basket | Business Equation*, Sales Overview | Average unit quantity per receipt/basket |
| Avg. Price per Product | Business Equation*, Appendix SKU Validation | Average unit selling price |
| Audience Size / Reachable / Analysed Reach | Exposure Overview, Business Equation vs Control | Size of the addressable/targetable audience population and how much of it was actually reachable/reached by media |
| Impressions / Paid Impressions / Analysed Impressions / Number of Impressions | Exposure sheets | Ad impression counts (paid vs. those included in the analysis) |
| Campaign Cost / Analysed Cost | Exposure Overview - exposure | Media spend for the campaign (total vs. the portion attributable to the analyzed scope) |
| Frequency / Buyers Frequency | Exposure Overview - exposure | Average number of ad exposures per person / per buyer |
| Reach Rate | Exposure Overview - exposure | Analysed Reach ÷ Reachable |
| Cost per 1000 Exposed | Exposure Overview - exposure | Standard media CPM-style cost efficiency metric |
| Incremental Revenue / Incremental Quantity / Incremental Shoppers / Incremental Buyer Rate | Sales Uplift, Sales Uplift by Audience | The lift attributable to the campaign: Exposed-group KPI minus what it would have been absent exposure (estimated via the Control group) |
| Return on Ad Spend (ROAS) | Sales Uplift | Incremental Revenue ÷ Campaign Cost `[INFERRED — exact formula not shown]` |
| Incremental Revenue due to Buyer Rate Increase / due to Revenue per Shopper Increase | Sales Uplift | Decomposition of total incremental revenue into the portion driven by more buyers vs. by buyers spending more — a "waterfall" style KPI split |
| Incremental Quantity due to Buyer Rate Increase / due to Quantity per Shopper Increase | Sales Uplift | Same decomposition applied to incremental quantity |
| P-Value (Buyer Rate / Revenue per Shopper / Quantity per Shopper / Avg. Basket Value / Avg. Price per Product) | Appendix Pvalues, Sales Uplift* | Statistical significance test result for each KPI's lift — used to assess whether the observed lift is statistically meaningful |
| Is Multisegment Resampled | Appendix Pvalues, New Shoppers Acquisition | Methodology flag — likely indicates whether a resampling technique was applied because the audience spans multiple segments `[UNVERIFIED]` |
| New/Returning Shoppers (+ Revenue/Quantity and their %) | New Shoppers Acquisition, Loyalty Profiles* | Split of shoppers (and their spend) between first-time buyers in the period vs. previously-existing buyers |
| Percentage of Loyal Shoppers / Number of Loyal Shoppers - more than 2 Receipts | Sales Overview - trade | Loyalty proxy: share of shoppers with >2 receipts in the period |
| Cost per Receipts / Cost per Shopper | Sales Overview - trade | Media cost efficiency relative to transactions/shoppers generated |
| Numeric Distribution / Selling Stores / Total Stores | Numeric Distribution by SKU, Business Equation by SKU | Store-level product availability/distribution metrics (Selling Stores ÷ Total Stores = Numeric Distribution) |
| Unit Price / Min Unit Price / Max Unit Price | Appendix SKU Validation | Price validation/QA metrics per SKU |
| Cumulative Reach / Cumulative Shoppers / Cumulative Buyer Rate / Percentage of Total | Sales Impact Evolution | Running (cumulative) versions of the core KPIs over the campaign's daily/weekly time series |

### 2.5 KPI Formulas & Business Logic

**No spreadsheet formulas exist in this workbook** (0 formula cells confirmed across all 37 sheets).
As with workbook 1, all KPI values are static, pre-computed by an upstream analytics platform (a
retail-media/lift-measurement product, not confirmed by name in this file — the `Study Id` GUID and
column vocabulary suggest a purpose-built "lift study" engine, distinct from the "Memory 360" platform
credited in workbook 1, though both may be part of the same NIQ product suite `[UNVERIFIED]`).

The only recoverable "business logic" is **structural inference from column relationships**, clearly
labeled as such:

- **Lift/incrementality logic `[INFERRED]`:** `Incremental X` = `Exposed group's X` − `(Control
  group's X, scaled/adjusted for population differences)`. The presence of separate `Control` and
  `Exposed` rows with matching dimensions (see `Business Equation vs Control`) plus a single
  `Incremental X` result (see `Sales Uplift`) confirms a **test-vs-control lift methodology**, but the
  exact statistical adjustment (e.g., propensity weighting, matching) is **not visible/documented in
  this file** `[GAP]`.
- **Reach/Frequency relationship `[INFERRED]`:** `Reach Rate = Analysed Reach / Reachable`; `Frequency
  = Impressions / Reach` (standard media math) — not confirmed by a formula, only plausible given
  column co-occurrence.
- **Numeric Distribution `[INFERRED]`:** `Numeric Distribution = Selling Stores / Total Stores`
  (values are consistent with this ratio in the sampled rows, e.g. row with Selling Stores=1373,
  Total Stores=4255 → Numeric Distribution=0.3227 ≈ 1373/4255=0.3227 ✓ **verified by recomputation
  from the sampled data**, though not shown as a live formula).
- **New vs. Returning shopper split `[INFERRED]`:** `Total Shoppers = New Shoppers + Returning
  Shoppers` (consistent across sampled `New Shoppers Acquisition` rows).

### 2.6 Report Layout / Where KPIs Are Displayed

This workbook has **no visual report layout** to describe (no merges, multi-level headers, charts, or
formatting-driven presentation) — every sheet is a plain flat data table, one KPI-set per sheet/theme
as cataloged in §2.2's per-sheet table. This supports the inference that **this file is a data extract
meant to feed a separate presentation layer** (e.g., dashboards or the PowerPoint deck
`NIQ_Measurement Report example.pptx`, to be confirmed when that file is analyzed) rather than being
a client-facing deliverable itself.

### 2.7 Embedded SQL / Queries / Transformations / Dependencies

None found — no Power Query, SQL, connections, data model, or VBA. Fully static, same as workbook 1.

### 2.8 Protection / Inaccessible Content

None. No workbook or sheet protection; everything opened and parsed cleanly.

### 2.9 Open Questions / Gaps Flagged for This Workbook

1. No glossary/definitions sheet exists in this workbook — all KPI definitions in §2.4 are
   `[INFERRED]` from column names and standard lift-study conventions, **not confirmed by the
   client**. Recommend validating the full KPI list with the client or against the measurement
   report deck before finalizing calculation logic.
2. `Performance by Audience` sheet contains values that look like normalization artifacts/errors
   rather than genuine KPIs (near-zero/near-one values across the board) — needs client
   clarification.
3. `Exposure Overview - frequency`, `Frequency Impact`, and `Scope - additionals products` sheets are
   present but empty (headers only) in this specific export — unclear if these are simply unused for
   this particular study (e.g., no "additional products" were in scope) or an export gap.
4. `Exposure Evolutions` sheet has all-zero values for every date — likely means exposure/reach
   tracking data was not available or not applicable for this study's media channels; needs
   confirmation.
5. The `RFM` segmentation family (and its Hierarchy 2 values, e.g. "Panier Très Fréquent") has no
   definition source in either workbook analyzed so far.
6. Exact statistical methodology behind the Control-vs-Exposed lift calculation (matching/weighting
   approach, p-value test type) is not visible in this file.
7. Relationship between this workbook and `NIQ_Measurement Report example.pptx` is `[INFERRED]` based
   on shared terminology (Exposed/Control, Reach, Incremental Revenue) — to be confirmed once that
   file is analyzed.

---

## 3. Workbook: `NIQ_Performance analysis.xlsx`

### 3.1 Workbook Inventory

- **File name:** `NIQ_Performance analysis.xlsx`
- **File type:** Excel Open XML Workbook (`.xlsx`, no macros)
- **Workbook purpose `[OBSERVED]`:** A **product-performance analysis report** generated by the same
  "Memory 360" platform as workbook 1 (`NIQ_Customer Loyalty analysis.xlsx`), for the same retailer
  (**Carrefour**) but a **different product/brand scope**: this export's "Paramètres" sheet states
  report name `Perf KitKat_Barres_0226 - BENCH`, product scope = **KIT KAT** bars (Nestlé) — 36 KitKat
  SKU labels listed (`104G KIT KAT MINI BREAK PEANUT`, `KIT KAT CHUNKY`, `KIT KAT SENSES`, etc.),
  benchmarked against the wider **`BARRES CHOCOLATEES`** (chocolate bars) category at the `Hyper`
  nomenclature level. Analysis type = performance-vs-benchmark trend analysis (not loyalty
  segmentation, though it reuses the same customer segmentation taxonomy as workbook 1).
- **Document metadata:** creator `In The Memory`; last modified by `Eran Center`; created 2020‑08‑31,
  modified 2026‑08‑04. Same SharePoint boilerplate `customXml` parts as the other workbooks.
- **Worksheets: 12, all Visible.** `['Paramètres', 'Performance (CA)', 'Performance (UVC)', 'Quoi
  (CA)', 'Quoi (UVC)', 'Quand (CA)', 'Quand (UVC)', 'Où (CA)', 'Où (UVC)', 'Qui (CA)', 'Qui (UVC)',
  'Lexique']`. Sheets are organized as **5 analytical themes, each duplicated for CA (Chiffre
  d'Affaires = Revenue) and UVC (Unité de Vente Consommateur = Sales Units)** measurement bases, plus
  a parameters cover sheet and a glossary: `Performance` (headline KPIs), `Quoi` ("What" — product/
  brand breakdown), `Quand` ("When" — weekly/monthly/quarterly time series), `Où` ("Where" — banner/
  channel/region/store breakdown), `Qui` ("Who" — customer segmentation breakdown).
- **Used range per sheet:** Small to medium (`Paramètres` A1:N38 real used cols only A:B; `Performance
  (CA)` A1:P40 real A:G; `Quoi (CA)/(UVC)` A1:AJ48 real A:AJ~AI i.e. up to col 35; `Quand (CA)/(UVC)`
  A1:Q87 real A:H; `Où (CA)/(UVC)` A1:R70 real A:L; `Qui (CA)/(UVC)` raw dimensions inflated to
  A1:GT70 (col 202) — **same empty-string artifact as workbook 1** — real content is only A:P (16
  cols), rows 1‑69; `Lexique` raw A1:GN86 (col 196) inflated, real content only A:C, rows 1‑86).
- **Named ranges:** None. **Excel Tables:** None. **Pivot tables:** None. **Slicers/timelines:** None.
- **Charts:** None detected by openpyxl parsing (no `xl/charts` parts in the zip). **Images/drawings:**
  12 drawing parts (`xl/drawings/drawing1.xml` .. `drawing12.xml`, one per sheet) containing only
  **decorative logo images** (`xl/media/image1.png`, `image2.png`, `image3.svg`, `image4.png` — e.g. a
  "Memory 360"/NIQ-style logo and a small icon), anchored at the top of each sheet — confirmed by
  inspecting the raw drawing XML (`<xdr:pic>` picture elements only, no `<c:chart>` references). No
  business-data charts.
- **Webextensions:** `xl/webextensions/taskpanes.xml` + `webextension1.xml` present — an Office
  Add-in task-pane reference (likely the "Memory 360" reporting add-in used to generate/refresh this
  export) — metadata only, no embedded business logic accessible from the file.
- **External workbook links / data connections / Power Query / Data Model / VBA:** None. Confirmed 0
  formula cells, 0 comments, 0 defined names across all 12 sheets — fully static export, same pattern
  as workbook 1.
- **Comments / notes / text boxes with business definitions:** None as comments, but a full **glossary
  sheet (`Lexique`) is present** — 79 terms (rows 7‑86), the richest and most detailed glossary of the
  three workbooks analyzed so far (see §3.4 for full transcription-based catalog).
- **Workbook / sheet protection:** None found; fully open.
- **Freeze panes:** None on any sheet. **Merged cells:** 2‑3 per sheet, all decorative header-banner
  merges (title row spans, e.g. `B1:L1`, `B2:L2`) — not used for data layout. **Hidden rows/columns:**
  None found.

### 3.2 Sheet-Level Analysis

- **`Paramètres`** (Visibility: visible; Classification: cover/parameters sheet — identical role to
  workbook 1's `Paramètres`): Documents the exact report configuration used to generate this export:
  report name `Perf KitKat_Barres_0226 - BENCH`; Retailer `Carrefour`; Category `Analyser`; product
  scope (`Nomenclature` = `EANs_KITKAT_Barres_0725`, 36 explicit KitKat SKU/pack labels); benchmark
  scope (`Nomenclature` = `Hyper`, level = `BARRES CHOCOLATEES`); store scope filters (Bannière/
  Régions/Superficie = "Non renseigné" i.e. not restricted; Constants/Courants = `Courants`; Type de
  transactions = `Total`); analysis level = `Magasin physique / e-commerce`; period type `CAM` (Cumul
  Annuel Mobile — rolling 13-period/annual cumulative, per the Lexique definition) spanning
  2025‑01‑27 to 2026‑01‑25, compared against 2024‑01‑29 to 2025‑01‑26. **This sheet is the single
  source of truth for what "période d'analyse" vs. "période de comparaison" mean throughout the rest
  of the workbook.**
- **`Performance (CA)` / `Performance (UVC)`** (Classification: report output — headline KPI
  dashboard): Three stacked blocks per sheet: (1) **`KPIs`** — a short list of top-line indicators
  (Taux d'encartés / Cardholder rate, VMH "Vente Moyenne Hebdomadaire"=avg weekly sale, Nombre de
  produits vendus = count of distinct products sold, CA promo / UVC promo, Poids CA promo / Poids UVC
  promo) each with current-period value + period-over-period evolution %; (2) **`Equation
  commerciale`** — the full "business equation" KPI tree (CA/UVC total, split by encartés/non
  encartés, paniers, panier moyen, fréquence, prix moyen) each with période d'analyse / période de
  comparaison / evolution val. / evolution %, in the same left-hand "translation" labeling style as
  workbook 1 (English translations in column A, e.g. `CA (Revenue)`, `Panier Moyen (Average Basket)`,
  `Délai Interachat (Time between Purchases)`, `DN (Numeric Detention) = {Share of stores stocking the
  product(s) under study}`); (3) **`Formule de vente`** — a condensed sales-formula view (CA/UVC,
  Nb de paniers, Panier moyen, UVC par panier, Prix moyen) with English glosses in column B
  (`Average Basket $`, `unit in basket`, `avg price per unit`).
- **`Quoi (CA)` / `Quoi (UVC)`** (Classification: report output — product/brand breakdown, "What"):
  Five stacked blocks: (1) **Fond de rayon vs Promotion split** (CA/UVC fond de rayon = regular-shelf
  sales vs. promo sales); (2) **Performance par type de marque** (by brand-type: only `MN` = National
  Brand present in this export); (3) **Performance des marques** (by individual brand — only `KIT
  KAT` present, with Contribution à la croissance %, Part de marché % = market share, Part d'offre %
  = share of assortment); (4) **Performance du niveau d'analyse** (`TOTAL`/`Magasin`/`Drive` rows,
  ~30 KPI columns spanning CA, CA promo, CA fond de rayon, contribution to growth, market share, share
  of assortment, `DN`/`DV` distribution metrics, VMH, product count); (5) **Equation commerciale**
  (encartés and non-encartés KPI trees, again split by `TOTAL`/`Magasin`/`Drive`).
- **`Quand (CA)` / `Quand (UVC)`** (Classification: report output — time series, "When"): Three
  stacked time-series blocks at different granularities: **weekly** (`Performance à la semaine`, 52
  weekly rows spanning 2025‑01‑27 to 2026‑01‑19), **monthly** (`Performance au mois`, 13 monthly
  rows), **quarterly** (`Performance au trimestre`, 5 quarterly rows) — each row giving Période
  d'analyse / Période de comparaison / Evolution (val./%) / Ecart vs Benchmark for CA or UVC.
- **`Où (CA)` / `Où (UVC)`** (Classification: report output — channel/geography breakdown, "Where"):
  Four stacked blocks: (1) **Performance des bannières** (by store banner: `HYPER`, `EXPRESS`,
  `CONTACT`, `CITY`, `MARKET`); (2) **Performance selon le type de transaction** (`e-commerce` vs.
  `Total magasins (hors e-commerce)`); (3) **Performance selon le type de magasins** (`Constants` vs.
  `Non constants`, per the Lexique's store-comparability definitions); (4) **Performance des régions**
  (8 French sales regions + TOTAL, with Part CA %, Indice CA) followed by **Top/Flop magasins** — top
  10 and bottom 10 individual stores ranked by period-over-period evolution, each with Région,
  Bannière, values, and an `Indice CA` (index vs. some baseline, always shown with `evol %` = 0 for
  the top/flop list, suggesting the index itself doesn't have its own separate comparison-period
  value in this cut).
- **`Qui (CA)` / `Qui (UVC)`** (Classification: report output — customer segmentation breakdown,
  "Who"): A single large **"Segmentations clients"** table (real extent ~69 rows × 16 cols, not the
  raw-inflated 202 cols) listing every segment across 4 segmentation families — `Lifestage`,
  `Structurelle Multiformat`, `Consostyle Multiformat`, `Promotion` — at both `Macro` and `Micro`
  detail levels, each row giving: Période d'analyse / Période de comparaison / Evolution (val./%),
  Nombre de clients (+ evolution %), Ecart vs Benchmark, Indice (CA) (+ evolution %), Part CA (+
  evolution %). This is structurally the same "Segmentations" concept as workbook 1's `Profil` sheet,
  but presented as one flat table per measurement base (CA/UVC) rather than split across many stacked
  customer-type blocks.
- **`Lexique`** (Classification: reference/glossary — **primary definitions source for this
  workbook**): 79-term business glossary (rows 7‑86, columns B=`Mot clé`/term, C=`Définition`). Fully
  transcribed in §3.4. Notably includes **full definitions for all 4 segmentation families and every
  one of their segment values** (`Lifestage`, `Structurelle`, `Promo`, `Consostyle` — including the
  more granular Consostyle sub-segments like `Budget serré`, `Bons plans accro`, `Gourmet panier
  frais`, etc. that appeared undefined/only partially defined in workbook 1 and totally undefined in
  workbook 2's `RFM`/`CONSOSTYLE`/`LIFESTAGE`/`PROMO` hierarchies) plus retailer-specific concepts
  (`Magasins constants` vs. `Magasins courants`, `CAM`/`CAD` period types, `Nomenclature Client/Hyper/
  Proxi/Super`, `EAN maître`, `UBC`, `Triptyque` MN/MDD/PP brand types).
- **Totals/subtotals/grouping:** As in workbook 1, "TOTAL"/"Magasin"/"Drive" and family/segment names
  are dimension members embedded as data rows, not spreadsheet-computed subtotal rows.
- **Filters/slicers:** None (all filtering already baked into the export per the `Paramètres` sheet).
- **Merged cells:** Only decorative title-row merges (see §3.1); no data-layout merges.

### 3.3 Dimensions & Attributes Catalog (this workbook)

| Dimension | Values observed | Notes |
|---|---|---|
| Measurement basis | CA (Chiffre d'Affaires/Revenue), UVC (Unité de Vente Consommateur/Units) | Every theme sheet is duplicated for these 2 bases |
| Période | Période d'analyse (2025‑01‑27 → 2026‑01‑25, CAM), Période de comparaison (2024‑01‑29 → 2025‑01‑26) | Defined once in `Paramètres`, reused implicitly everywhere |
| Type de marque | MN (Marque Nationale) | Only MN present in this export (single-brand KitKat analysis) |
| Marque | KIT KAT | Single brand in scope |
| Type de transaction | e-commerce, Total magasins (hors e-commerce) | Channel split |
| Bannière (banner) | HYPER, EXPRESS, CONTACT, CITY, MARKET | Carrefour store formats |
| Etat magasin | Constants, Non constants | Store comparability status, defined in Lexique |
| Région | NORD, REGION PARISIENNE, EST, CENTRE EST, SUD EST, SUD OUEST, CENTRE OUEST, OUEST, + TOTAL | French sales regions |
| Magasin (store) | Individual store names, e.g. "Ronchin -Lavoisier", "Atacadao Aulnay" | Used only in Top/Flop store rankings |
| Temporal granularity | Semaine (week), Mois (month), Trimestre (quarter) | 3 time series grains on Quand sheets |
| Segmentation family | Lifestage, Structurelle Multiformat, Consostyle Multiformat, Promotion | Customer segmentation taxonomies, fully defined in Lexique |
| Détail (segmentation level) | Macro, Micro | Coarse vs. fine segmentation granularity |
| Segment | e.g. "Familles avec enfant entre 0 et 2 ans", "Bons plans accro", "Hebdo", "Petit % CA promo, Moyen régul" | Specific segment values, all defined in Lexique |

### 3.4 KPIs / Measures Catalog (this workbook)

Definitions below are transcribed/paraphrased from this workbook's own `Lexique` sheet (authoritative
`[DEFINED IN SOURCE]`), supplemented with `[INFERRED]` notes where the Lexique doesn't cover a
specific derived metric.

| KPI / Measure | Appears in | Definition (from Lexique where available) |
|---|---|---|
| CA (Chiffre d'Affaires) / CA total | Performance*, Quoi*, Quand*, Où* | Total revenue realized by cardholders and non-cardholders combined; gross incl. tax |
| CA encartés / CA non encartés | Performance* | Revenue from cardholding vs. non-cardholding customers |
| CA promo | Performance*, Quoi* | Revenue realized under promotion on barcoded EANs (excl. variable-weight products) |
| CA/client | (Lexique-defined, used implicitly) | Average revenue per customer |
| Poids CA promo / Poids UVC promo | Performance* | Share of revenue/units realized via promotional flyer/catalog |
| Fond de rayon | Quoi* | All non-promotional ("regular shelf") products |
| UVC (Unité de Vente Consommateur) | Performance*, Quoi*, Quand*, Où* | Number of products sold (unit sales) |
| Taux d'encartés | Performance* | Share of total revenue from cardholders |
| VMH (Vente Moyenne Hebdomadaire) | Performance* | `[INFERRED]` Average weekly sale (CA or UVC per store/week) — term itself not in Lexique but consistent with standard NIQ/Nielsen vocabulary |
| Panier moyen (Average Basket) | Performance*, Quoi* | Revenue or avg. product count per checkout visit, cardholders or non-cardholders |
| Paniers | Performance* | Number of checkout visits by non-cardholders |
| Nb de clients | Performance*, Quoi* | Number of (cardholding) customers |
| Fréquence | Performance*, Lexique | Average number of visits by cardholders over the selected period |
| Délai Interachat (Time between Purchases) | Performance (CA) | `[TRANSLATION LABEL ONLY]` — Average time between purchases; not separately defined in Lexique |
| DN (Numeric Detention) | Performance (CA), Quoi* | Share of stores stocking the product(s) under study (per the workbook's own translation label) |
| DV | Quoi* | `[INFERRED]` Likely "Distribution Valeur" (value distribution) — paired with DN in the `Quoi` distribution block; not explicitly defined in Lexique |
| Contribution à la croissance (%) | Quoi* | Share of total growth attributable to this brand/segment |
| Part de marché (%) | Quoi* | Market share |
| Part d'offre (%) | Quoi*, Lexique | Ratio of number of products at a given level (brand/supplier/etc.) to total products sold |
| Indice (CA/UVC) | Où*, Qui* | `[INFERRED]` An indexed comparison value (base 100 = some reference); exact base not specified in Lexique |
| Ecart vs Benchmark | Performance*, Quoi*, Quand*, Où* | Gap between this product's evolution % and the benchmark category's evolution % (category defined in Paramètres as `BARRES CHOCOLATEES`) |
| Part CA (%) | Où*, Qui* | Share of total revenue held by this region/segment |
| Nombre de produits vendus | Performance* | Count of distinct products sold in the scope |
| Prix moyen (avg price) | Performance*, Quoi* | For a set of products, the average of their selling prices |
| Top/flop magasins | Où* | Ranking of best/worst-performing stores by the selected KPI |
| CAM (Cumul Annuel Mobile) | Paramètres, Lexique | Rolling 13-Nielsen-period (annual) cumulative window ending at the selected period |
| CAD (Cumul A Date) | Lexique | Year-to-date cumulative from the start of the current Nielsen year to a given period |

### 3.5 KPI Formulas & Business Logic

No spreadsheet formulas exist (0 formula cells confirmed across all 12 sheets) — same static-export
pattern as workbooks 1 and 2, generated by the "Memory 360" platform.

Recoverable business logic, all `[INFERRED]` from column relationships (cross-checked against sample
values) unless otherwise noted:

- **Evolution (%) `[INFERRED, verified]`:** `Evolution (%) = (Période d'analyse − Période de
  comparaison) / Période de comparaison`. Verified via recomputation on sampled rows (e.g. CA row 17:
  (12,931,233.30 − 11,884,336.71) / 11,884,336.71 = 0.08809 ✓ matches G17 exactly).
- **Ecart vs Benchmark `[INFERRED]`:** Appears to be the percentage-point (or scaled) difference
  between this item's own Evolution % and the benchmark category's (`BARRES CHOCOLATEES`) Evolution %
  over the same period — consistent with the `Paramètres` sheet defining an explicit "Périmètre
  Benchmark". Exact scaling/units not fully verifiable from visible data alone.
- **Panier moyen (Average Basket) `[INFERRED, verified]`:** `Panier moyen = CA / Nb de paniers` (e.g.
  Performance (CA) row 37: 12,931,233.30 / 2,203,942 ≈ 5.867 ✓ matches D37).
  Similarly `UVC par panier = UVC / Nb de paniers` and `Prix moyen = CA / UVC`.
  Same "business equation" chain documented for workbook 1's `Bilan` sheet: **CA = Nb clients ×
  Fréquence × Panier moyen**, and **Panier moyen = UVC par panier × Prix moyen**.
- **Taux d'encartés `[INFERRED]`:** `CA encartés / CA total` (or the equivalent for UVC).
- **DN (Numeric Detention) `[DEFINED IN SOURCE]`:** Explicitly documented in the workbook itself
  (Performance (CA) row 26 label) as "Share of stores stocking the product(s) under study".
- **Part d'offre `[DEFINED IN SOURCE — Lexique]`:** Ratio of product count at a given level to total
  products sold.
- All customer segmentation definitions (`Lifestage`, `Structurelle`, `Consostyle`, `Promotion` and
  every one of their Macro/Micro segment values) are **explicitly defined in this workbook's own
  Lexique** (§3.4-adjacent, full text in §3.2) — this is the strongest glossary of the workbooks
  analyzed so far and should be treated as the **authoritative reference for these 4 segmentation
  taxonomies across the whole file set**, since the same taxonomy names recur (with less complete
  definitions) in workbook 1 and in a different-but-related form in workbook 2's Hierarchy 1/2 values.

### 3.6 Report Layout / Where KPIs Are Displayed

Each theme sheet uses the same visual convention as workbook 1: a title banner (merged cells B1:L1 /
B2:L2, logo image top-left), a bold section-title cell (e.g. `B4='KPIs (CA)'`), then one or more
tables with a header row directly above the data (columns C onward; column B sometimes used for
English/glossary-style labels). Themes are laid out as **repeatable stacked blocks within a sheet**
(e.g. `Quoi (CA)` stacks Fond-de-rayon-vs-Promo → Type-de-marque → Marques → Niveau-d'analyse →
Equation-commerciale, top to bottom), separated by blank rows and a bold sub-title cell. No
dashboard-style visual charts are present anywhere in this workbook — all "reporting" is table-based;
any charts a client-facing consumer would see are presumably rendered live in the Memory 360 web
platform rather than embedded in this static export.

### 3.7 Embedded SQL / Queries / Transformations / Dependencies

None — no Power Query, SQL, external connections, Data Model, or VBA. Fully static, same pattern as
workbooks 1 and 2. The only "query-like" artifact is the `Paramètres` sheet, which documents the
filter/scope parameters (product nomenclature, benchmark nomenclature, store scope, period) that were
presumably used as inputs to an upstream query/report-generation job in the Memory 360 platform.

### 3.8 Protection / Inaccessible Content

None. No workbook or sheet protection; everything opened and parsed cleanly.

### 3.9 Open Questions / Gaps Flagged for This Workbook

1. `VMH`, `DV`, and the exact numeric definition/base of `Indice (CA/UVC)` and `Ecart vs Benchmark`
   are not explicitly defined in this workbook's Lexique (or any Lexique seen so far) — flagged for
   client clarification, though directional/structural inference is provided in §3.5.
2. The `Top/Flop magasins` blocks show an `Indice CA (evol %)` column that is `0` for every row in
   the sampled data — unclear if this is a genuine constant for this cut or an export limitation.
3. This workbook's Lexique should be treated as the master/authoritative definition source for the
   `Lifestage`/`Structurelle`/`Consostyle`/`Promotion` segmentation families across the entire file
   set (more complete than workbook 1's glossary for the same terms) — recommend consolidating all
   three workbooks' glossaries into one master business-vocabulary section in the final deliverable.
4. Cell-level number formatting (currency, percentage, decimal precision) was not mapped in this
   pass; only raw values were captured.

---

## 4. Workbook: `NIQ_Product_Extraction.xlsx`

### 4.1 Workbook Inventory

- **File name:** `NIQ_Product_Extraction.xlsx`
- **File type:** Excel Open XML Workbook (`.xlsx`, no macros)
- **Workbook purpose `[OBSERVED]`:** Distinctly different role from workbooks 1‑3: this is a
  **"Product Extraction" data-export tool output** from the Memory 360 platform (title on every sheet:
  `Extraction produits - Plateforme Memory 360`), not a curated analytical report. It combines (a) a
  small KPI summary aggregated at one product-hierarchy level, with (b) two large **reference/master
  data dumps** — a full product master and a full store master — for the selected scope. Report name
  (from `Paramètres`): `Extract_produits_NIQ_-_Familles`. Category = `Extraction` (vs. `Analyser` for
  workbook 3), product scope = **`SOFTS DRINKS`** (soft drinks, French retail "PGC/BOISSONS" nomenclature),
  same "Courants" store scope, "Total (E-commerce + Magasin)" transaction type. Retailer is not
  explicitly named in `Paramètres` this time (no `Retailer`/`Bannière`-scoping row equivalent to
  workbook 3's `Carrefour` label was found), but the store list (`Informations magasins`, banner
  values `HYPER/MARKET/CITY/CONTACT/EXPRESS`) strongly matches the same Carrefour banner taxonomy
  seen in workbook 3 `[INFERRED — likely also Carrefour data]`.
- **Document metadata:** creator `In The Memory`; last modified by `Noa Condrea`; created 2020‑06‑02,
  modified 2026‑08‑03. Same SharePoint boilerplate `customXml` parts as the other workbooks.
- **Worksheets: 4, all Visible.** `['Paramètres', 'Indicateurs', 'Informations produits',
  'Informations magasins']` — no `Lexique`/glossary sheet in this workbook `[GAP]`.
- **Used range per sheet:** `Paramètres` A1:M111 raw (real content A:B, rows 1‑41 — inflation
  artifact on raw dims as usual); `Indicateurs` A1:AJ17 (real content matches raw, rows 1‑16, cols
  A‑AJ, no inflation this time); `Informations produits` A1:P5370 (real content cols A‑O only, `P`
  is an empty merged spacer column — 5,369 product rows); `Informations magasins` A1:I4300 (real
  content cols A‑G only — 4,299 store rows).
- **Named ranges:** None. **Excel Tables:** None. **Pivot tables:** None. **Slicers/timelines:** None.
- **Charts:** None. **Images/drawings:** 4 drawing parts (one per sheet), containing only decorative
  logo images (`xl/media/image1.jpeg`, `image2.jpeg`) — same pattern as workbook 3, confirmed by
  `<xdr:pic>`-only drawing XML, no charts.
- **Webextensions:** None in this workbook (unlike workbook 3).
- **External workbook links / data connections / Power Query / Data Model / VBA:** None. Confirmed 0
  formula cells, 0 comments, 0 defined names across all 4 sheets — fully static export.
- **Comments / notes / text boxes with business definitions:** None as comments/notes, but the
  `Paramètres` sheet itself contains **inline definitions for the 10 KPIs selected for this
  extraction** (rows 32‑41, see §4.4) — a report-scoped mini-glossary embedded directly in the
  parameters, distinct from a full `Lexique` sheet (which this workbook lacks).
- **Workbook / sheet protection:** None found; fully open.
- **Freeze panes:** None. **Merged cells:** `Paramètres` has 10 merges (label-pairs `A_:B_` plus
  title-banner merges); `Indicateurs` has 16 merges (title banner + 10 two/three-column KPI-group
  header merges, e.g. `C6:D6`, `G6:I6`); `Informations produits`/`Informations magasins` have a
  handful of title-banner merges only. All decorative/label-grouping, not data-layout. **Hidden
  rows/columns:** None found.

### 4.2 Sheet-Level Analysis

- **`Paramètres`** (Classification: cover/parameters sheet): Documents the extraction's configuration
  — store scope (Format = all 5 Carrefour-style banners; Région = 8 French regions, i.e. national
  scope; Tranche de surface = a long list of per-banner store-size brackets, effectively "all sizes,
  explicitly enumerated"; Constants/Courants = `Courants`; transaction type = `Total (E-commerce +
  Magasin)`); product scope (`Nomenclature` = `hyper`, `Niveaux` = `SOFTS DRINKS`, no additional
  filter); period (`Type de période d'analyse` = `CAM`, 2025‑07‑14 → 2026‑07‑12 vs. 2024‑07‑15 →
  2025‑07‑13); analysis level (`Niveau hiérarchique 4`); and a list of **10 selected KPIs each with
  an inline one-sentence business definition** (CA, CA encartés, CA promo, Panier moyen, UVC, UVC
  encartés, Nombre UVC par panier, DN, Fréquence d'achat, Délai interachat) — this list defines
  exactly the KPI set materialized in the `Indicateurs` sheet.
- **`Indicateurs`** (Classification: report output — aggregated KPI table): One table, header rows 6‑7
  (row 6 = KPI group name spanning 3 merged sub-columns each; row 7 = `Valeur analyse` / `Valeur
  comparaison` / `Evolution` for each KPI), one data row per **Niveau hiérarchique 4** category:
  `Total`, `GAZEIFIES` (carbonated), `NON GAZEIFIES` (non-carbonated), `SIROPS` (syrups), `SNACKING
  SOFTS DRINKS` — i.e. only 5 data rows total (row 8 = grand total, rows 9‑12 = the 4 sub-categories).
  Column A repeats the same English-translation labels seen in workbooks 1 and 3 (`CA (Revenue)`,
  `Panier Moyen (Average Basket)`, `Nb UVC par panier (Volume per basket)`, `Délai Interachat (Time
  between Purchases)`, `Fréquence d'achat (Purchase Frequency)`, `DN (Numeric Detention)`).
- **`Informations produits`** (Classification: **reference/lookup data**, not an analytical report):
  A flat product master list, one row per EAN barcode (5,369 rows) with columns: `EAN`, `EAN libelle`
  (product description), `EAN maître` / `EAN maitre libelle` (master/chained EAN — links slave EANs
  like special editions to their principal reference, per the "EAN maître" glossary concept from
  workbook 3's Lexique), `Marque` (brand), `Triptyque` (brand type: `national`/MN etc.), `Fournisseur`
  (supplier), and the full 6-level product hierarchy (`Niveau hiérarchique 1`…`6`, e.g. `PGC` →
  `BOISSONS` → `SOFTS DRINKS` → `GAZEIFIES`/`NON GAZEIFIES`/etc. → sub-category → detailed segment).
  This is a **dimension/lookup table**, not a fact table — no KPI values, no time dimension, one row
  per unique product in the "SOFTS DRINKS" scope (Coca-Cola, Pressade, Sous le Pommier and other
  brands observed).
- **`Informations magasins`** (Classification: **reference/lookup data**): A flat store master list,
  one row per store (4,299 rows) with columns: `Code` (store code, alphanumeric e.g. `750100`,
  `H00016`, `S01703` — prefix letter likely encodes banner: `H`=Hyper, `S`=Supermarket/Market),
  `Magasin` (store name), `Région`, `Bannière`, `Superficie` (surface-area bracket, matching the
  bracket definitions from `Paramètres` row 12). Also a **dimension/lookup table**, directly usable as
  a store dimension for joining against other workbooks' store-level data (e.g. workbook 3's Top/Flop
  magasins store names).
- **Totals/subtotals/grouping:** `Indicateurs` includes an explicit `Total` row as its first data row
  (row 8) rather than only sub-category rows — the only workbook among the four analyzed so far to
  present the grand total as a literal first row rather than purely a separate/implicit rollup.
- **Filters/slicers:** None (scope already fixed by `Paramètres`).
- **Data quality note `[OBSERVED]`:** In `Informations produits`, some rows show `EAN` ≠ `EAN maître`
  (e.g. last sampled row: `EAN=5000112609592` but `EAN maître=5449000283900`), confirming the
  "chainage"/EAN-linking concept (slave EAN rolled up to a master EAN) is actively used in this
  product master, exactly as defined in workbook 3's Lexique (`EAN maître`).

### 4.3 Dimensions & Attributes Catalog (this workbook)

| Dimension | Values / Structure observed | Notes |
|---|---|---|
| Niveau hiérarchique 4 (product category) | Total, GAZEIFIES, NON GAZEIFIES, SIROPS, SNACKING SOFTS DRINKS | The single analysis grain used in `Indicateurs` |
| Niveau hiérarchique 1‑6 (full product hierarchy) | e.g. PGC → BOISSONS → SOFTS DRINKS → GAZEIFIES → COLAS → BRSA COLA STD PET 2L | Full 6-level hierarchy captured per-EAN in `Informations produits` |
| EAN / EAN libellé | Individual barcodes + descriptions | Product grain, 5,369 distinct SKUs |
| EAN maître / EAN maitre libellé | Master/chained EAN reference | Links slave EANs (variants/special editions) to a principal reference |
| Marque (brand) | e.g. COCA COLA, PRESSADE, SOUS LE POMMIER | Brand dimension |
| Triptyque | national (MN observed; MDD/PP presumably also possible per workbook 3's Lexique) | Brand-type classification |
| Fournisseur (supplier) | e.g. COCA COLA EUROPACIFI, CELLIERS ASSOCIES, PRESSADE | Supplier dimension |
| Store Code | Alphanumeric codes, e.g. `750100`, `H00016`, `S01703` | Store identifier; prefix letter appears banner-correlated |
| Magasin (store name) | e.g. "Atacadao Aulnay", "Paris -Lancry" | Matches store names seen in workbook 3's Top/Flop magasins |
| Région | 8 French regions (same set as workbook 3) | Store region |
| Bannière | HYPER, MARKET, CITY, CONTACT, EXPRESS | Same banner set as workbook 3 |
| Superficie (store size bracket) | e.g. "[HYPER] 8000 - 12000", "[CITY] < 250" | Per-banner store-size buckets |

### 4.4 KPIs / Measures Catalog (this workbook)

All 10 KPI definitions below are **`[DEFINED IN SOURCE]`** — transcribed verbatim/near-verbatim from
this workbook's own `Paramètres` sheet (rows 32‑41), which is this workbook's substitute for a full
Lexique sheet:

| KPI / Measure | Definition (verbatim from `Paramètres`) |
|---|---|
| CA | Chiffre d'affaires total réalisé sur le périmètre sélectionné (Total revenue on the selected scope) |
| CA encartés | Chiffre d'affaires réalisé sur les clients encartés sur le périmètre sélectionné (Revenue from cardholding customers) |
| CA promo | Chiffre d'affaires réalisé sous promotion catalogue sur le périmètre sélectionné (Revenue under catalog/flyer promotion) |
| Panier moyen | Chiffre d'affaires moyen réalisé par passage en caisse pour l'ensemble des clients (Average revenue per checkout visit, all customers) |
| UVC | Unité de Vente Consommateur — nombre total de produits vendus pour l'ensemble des clients (Total units sold, all customers) |
| UVC encartés | Unité de Vente Consommateur — nombre total de produits vendus pour les clients encartés (Units sold to cardholding customers) |
| Nombre UVC par panier | Nombre de produits vendus par passage en caisse pour l'ensemble des clients (Units per checkout visit, all customers) |
| DN (Numeric Detention) | Part des magasins détenant le ou les produit(s) étudié(s) (Share of stores stocking the studied product(s)) |
| Fréquence d'achat | Nombre de visites moyennes réalisées par les clients encartés sur la période sélectionnée (Average number of visits by cardholding customers) |
| Délai interachat | Nombre de jours moyens entre deux actes d'achat par les clients encartés sur la période sélectionnée (Average number of days between purchase acts, cardholding customers) |

Each KPI in `Indicateurs` is materialized with 3 sub-columns: `Valeur analyse` (analysis-period
value), `Valeur comparaison` (comparison-period value), `Evolution` (or `Evolution (pts)` for `DN`,
suggesting DN's evolution is expressed in percentage points rather than relative %).

### 4.5 KPI Formulas & Business Logic

No spreadsheet formulas exist (0 formula cells confirmed across all 4 sheets) — same static-export
pattern as the prior workbooks.

- **Evolution `[INFERRED, verified]`:** `(Valeur analyse − Valeur comparaison) / Valeur comparaison`
  — verified on sampled row 8 (Total): CA (1,618,216,346.88 − 1,514,330,289.94) / 1,514,330,289.94 =
  0.068602 ✓ matches I8 exactly.
  Confirmed similarly for CA promo, CA encartés, Panier moyen, UVC, UVC encartés on the same row.
- **DN's "Evolution (pts)" `[INFERRED]`:** Given DN's `Valeur analyse`/`Valeur comparaison` are
  already expressed as ratios close to 1 (e.g. 0.99953 vs. 1.00171), the "Evolution (pts)" column
  (e.g. `AJ8=-0.218`) does **not** equal the simple relative-% formula used elsewhere — consistent
  with it being a **percentage-point difference scaled ×100** (i.e. `(0.99953 − 1.00171) × 100 =
  -0.218` ✓ matches AJ8 exactly) rather than a relative evolution.
- **EAN maître / chainage logic `[DEFINED IN SOURCE — via workbook 3's Lexique]`:** A slave EAN
  (e.g. a limited-edition pack) is chained/rolled up to a master EAN representing "the main variant
  of a set of consumer-identical products"; sales attributed to slave EANs are consolidated under the
  master EAN for higher-level reporting — confirmed by real EAN≠EAN maître rows found in this
  workbook's product master.

### 4.6 Report Layout / Where KPIs Are Displayed

Only the `Indicateurs` sheet displays KPIs in report form (5 rows × 10 KPIs × 3 sub-columns each, with
a two-row header: KPI group name merged across its 3 sub-columns, then `Valeur analyse`/`Valeur
comparaison`/`Evolution` column labels) — otherwise identical visual convention to workbooks 1 and 3
(title banner with logo, bold section title). The two large sheets (`Informations produits`,
`Informations magasins`) are plain reference tables with no special layout — single header row (or
two header rows on `Informations produits`: a grouping row 6 + a detailed column-name row 7), no
merges beyond the title banner, no totals.

### 4.7 Embedded SQL / Queries / Transformations / Dependencies

None — no Power Query, SQL, external connections, Data Model, or VBA. Fully static export.
Conceptually, this workbook's two reference tables (`Informations produits`, `Informations magasins`)
are exactly the kind of **dimension tables** that would be joined (by EAN and by store Code
respectively) against the fact-level KPI data seen in workbooks 1‑3 if this file set were to be
consolidated into a single data model — this is the clearest evidence in the file set of how the
underlying Memory 360 data model is structured (product dimension + store dimension + fact/KPI
tables, sliced various ways per report).

### 4.8 Protection / Inaccessible Content

None. No workbook or sheet protection; everything opened and parsed cleanly.

### 4.9 Open Questions / Gaps Flagged for This Workbook

1. No `Lexique` sheet in this workbook — the only definitions available are the 10 KPI definitions
   embedded in `Paramètres`, which is comprehensive for this file's own KPI set but doesn't cover
   product-hierarchy terms (e.g. `Triptyque`, `Nomenclature`) — those are covered by workbook 3's
   Lexique and should be cross-referenced.
2. The retailer is not explicitly labeled in this workbook's `Paramètres` (unlike workbook 3's
   explicit `Retailer = Carrefour` field) — inferred to be Carrefour from matching banner/region/store
   naming conventions, but not confirmed by an explicit field.
3. Store `Code` prefix-letter-to-banner mapping (e.g. `H`=Hyper, `S`=?) is `[INFERRED]` from a small
   sample and not explicitly documented — would need the full code list cross-tabulated with
   `Bannière` to confirm a definitive mapping.
4. Relationship between this "Product Extraction" file and the curated report workbooks (1/3) is
   `[INFERRED]` (shared store/region/banner taxonomy, shared KPI vocabulary) but not explicitly stated
   in either file — likely the same underlying Memory 360 data warehouse, exported via different
   report templates.

---

## 5. Workbook: `NIQ_Temporal_evolution.xlsx`

### 5.1 Workbook Inventory

- **File name:** `NIQ_Temporal_evolution.xlsx`
- **File type:** Excel Open XML Workbook (`.xlsx`, no macros)
- **Workbook purpose `[OBSERVED]`:** A **"Temporal Extraction" data-export** from the Memory 360
  platform (title on every sheet: `Extraction temporelle produits - Plateforme Memory 360`) — same
  family of extraction tool as workbook 4, but configured for a **daily time series** rather than a
  category snapshot. Report name (from `Paramètres`): `Tempo_Coca_S126_Epsilon_-_Copie`. Product
  scope = `Nomenclature: Groupe`, a specific enumerated list of ~135 EANs (Coca-Cola family products,
  confirmed by `Informations produits`), analysis level = **`Marque x Jour`** (Brand × Day). Custom
  period 2026‑01‑01 → 2026‑06‑30 (181 days), explicitly **no comparison period** — the `Paramètres`
  sheet states `"Pas de periode de comparaison pour l'extraction temporelle"` (No comparison period
  for the temporal extraction) for both comparison-period fields. Only **one KPI was selected for
  this extraction: `CA`** (vs. 10 KPIs in workbook 4's extraction).
- **Document metadata:** creator `In The Memory`; last modified by `Eran Center`; created 2020‑06‑02,
  modified 2026‑08‑04. Same SharePoint boilerplate `customXml` parts as the other workbooks.
- **Worksheets: 4, all Visible**, identical sheet names/roles to workbook 4: `['Paramètres',
  'Indicateurs', 'Informations produits', 'Informations magasins']` — no `Lexique` sheet `[GAP]`,
  same as workbook 4.
- **Used range per sheet:** `Paramètres` A1:M111 raw / real A:B rows 1‑32 (only 1 KPI definition row,
  vs. 10 in workbook 4); `Indicateurs` A1:M554 raw / real content only cols A‑I, rows 1‑554 (**549
  data rows** — by far the largest `Indicateurs` sheet of the two extraction workbooks, driven by
  daily granularity); `Informations produits` A1:P137 raw / real A‑O, 131 product rows (much smaller
  product scope than workbook 4's 5,369 — this is a narrow "Groupe"/specific-EAN-list scope, not a
  full category); `Informations magasins` A1:I4239 raw / real A‑G, 4,234 store rows (same national
  store universe as workbook 4, near-identical row count, same 5 banners/8 regions).
- **Named ranges:** None. **Excel Tables:** None. **Pivot tables:** None. **Slicers/timelines:** None.
- **Charts:** None. **Images/drawings:** 4 drawing parts (one per sheet) with the same decorative
  logo images as workbook 4 (`xl/media/image1.jpeg`, `image2.jpeg`) — confirmed no charts.
- **External workbook links / data connections / Power Query / Data Model / VBA:** None. Confirmed 0
  formula cells, 0 comments, 0 defined names — fully static export.
- **Comments / notes / text boxes with business definitions:** None as comments; `Paramètres` again
  embeds the definition for its one selected KPI (`CA`) inline, same convention as workbook 4. No
  `Lexique` sheet.
- **Workbook / sheet protection:** None. **Freeze panes:** None. **Merged cells:** Same
  decorative title-banner/label-pair merge pattern as workbook 4 (10/6/9/5 merges per sheet
  respectively). **Hidden rows/columns:** None found.

### 5.2 Sheet-Level Analysis

- **`Paramètres`** (Classification: cover/parameters sheet): Same fields as workbook 4's Paramètres,
  with these key differences: `Nomenclature = Groupe` (a specific, ad-hoc product group rather than a
  full category) with an explicit enumerated EAN list (~135 codes) rather than a category name;
  `Type de période d'analyse = Periode personnalisee` (custom period) instead of `CAM`; explicit
  **no-comparison-period** statement; `Niveau d'analyse = Marque x Jour` (vs. workbook 4's `Niveau
  hiérarchique 4`); only 1 KPI selected (`CA`, same definition text as workbook 4's `CA` entry:
  "Chiffre d'affaires total réalisé sur le périmètre sélectionné").
- **`Indicateurs`** (Classification: report output — **daily time-series KPI table**): Header rows
  6‑7 define 3 dimension/value groups: `Dimension produits` → `Marque` (brand), `Dimension
  temporelle` → `Date`/`Date debut`/`Date fin`, plus `Date première vente`/`Date dernière vente`, and
  the single KPI `CA` → `Valeur`. Data rows: a `Total` roll-up row (all brands, whole period), then
  one **brand-total row per brand** (`Marque='Total'` for date but a specific brand name, whole-period
  sum), then **one row per brand per calendar day** for the full 181‑day window. Three brand labels
  observed: `COCA COLA` (206.95M€ over the period), `COCA COLA SANS SUCRE` (738K€), and `COCA-COLA`
  (note the **hyphenated vs. spaced brand-name inconsistency** — likely two source-system brand codes
  that both roll up to "Coca-Cola" but were not normalized before export `[DATA QUALITY ISSUE
  FLAGGED]`). This is a genuine **daily fact table** — the only true day-level, non-aggregated time
  series encountered across all 5 Excel workbooks (workbook 3's `Quand` sheets were weekly/monthly/
  quarterly at best).
- **`Informations produits`** (Classification: reference/lookup data): Same column structure as
  workbook 4's product master (`EAN`, `EAN libelle`, `EAN maître`/`EAN maitre libelle`, `Marque`,
  `Triptyque`, `Fournisseur`, 6-level hierarchy), but scoped to just the ~131 Coca-Cola-family EANs in
  this extraction's "Groupe". **Notable/anomalous rows `[OBSERVED]`:** a handful of EANs in this
  product list are categorized under hierarchy `BAZAR → AUTO → EQUIPEMENT ET DECO AUTO → CONFORT
  INTERIEUR → DESODORISANT` (car air fresheners branded "Coca-Cola", e.g. `DESO COCA VANILLE 3D`) —
  i.e. **licensed non-beverage merchandise carrying the Coca-Cola brand** is included in this "Groupe"
  product scope alongside the beverage SKUs (`PGC → BOISSONS → SOFTS DRINKS → GAZEIFIES → COLAS`).
  This confirms the "Groupe" nomenclature in this extraction is a **manually curated brand-based
  product list**, not a strict category filter (unlike workbook 4's clean single-category
  `SOFTS DRINKS` scope).
- **`Informations magasins`** (Classification: reference/lookup data): Same structure as workbook 4's
  store master, same national store universe (4,234 stores this time vs. 4,299 in workbook 4 — minor
  count difference, likely due to store openings/closures between the two extraction dates or scope
  differences).
- **Totals/subtotals/grouping:** `Indicateurs` includes an explicit grand-`Total` row and per-brand
  whole-period total rows (`Marque=<brand>`, `Date='Total'`) interleaved with the daily detail rows —
  same "Total as a literal row" convention as workbook 4.
- **Filters/slicers:** None (scope fixed by `Paramètres`).

### 5.3 Dimensions & Attributes Catalog (this workbook)

| Dimension | Values / Structure observed | Notes |
|---|---|---|
| Marque (Brand) | Total, COCA COLA, COCA COLA SANS SUCRE, COCA-COLA | Brand dimension at the `Indicateurs` grain; naming inconsistency between "COCA COLA" and "COCA-COLA" flagged |
| Date | Total (whole-period), then daily dates 2026‑01‑01 → 2026‑06‑30 | Daily time dimension — finest granularity seen in the whole file set |
| EAN / EAN libellé / EAN maître | ~131 SKUs (beverage + licensed merchandise) | Same structure as workbook 4's product master, narrower "Groupe" scope |
| Niveau hiérarchique 1‑6 | e.g. PGC→BOISSONS→SOFTS DRINKS→GAZEIFIES→COLAS→(sub-type); also BAZAR→AUTO→...→DESODORISANT | Two distinct hierarchy branches present because "Groupe" spans both beverages and branded merchandise |
| Store Code / Magasin / Région / Bannière / Superficie | Same national store universe as workbook 4 | 4,234 stores, same 5 banners / 8 regions |

### 5.4 KPIs / Measures Catalog (this workbook)

| KPI / Measure | Definition (verbatim from `Paramètres`) |
|---|---|
| CA | Chiffre d'affaires total réalisé sur le périmètre sélectionné (Total revenue on the selected scope) |

Only this single KPI is materialized in `Indicateurs`, at daily × brand grain, with a single `Valeur`
column (no comparison-period or evolution columns, consistent with the workbook's explicit "no
comparison period for temporal extraction" design).

### 5.5 KPI Formulas & Business Logic

No spreadsheet formulas exist (0 formula cells confirmed across all 4 sheets) — same static-export
pattern as all prior workbooks. There is no derived/computed logic to infer here beyond straightforward
aggregation: **brand-total CA (per brand, whole period) = sum of that brand's daily CA values**, and
**grand-Total CA = sum of all brands' totals** `[INFERRED, plausible from row structure but not
individually re-verified by summing all 181 days per brand]`.

### 5.6 Report Layout / Where KPIs Are Displayed

`Indicateurs` is a plain flat time-series table (single header pair, one row per brand/day
combination) — no dashboard/chart layout. Same title-banner + logo convention as the other workbooks.
`Informations produits`/`Informations magasins` are plain reference tables, structurally identical to
workbook 4's equivalents.

### 5.7 Embedded SQL / Queries / Transformations / Dependencies

None — no Power Query, SQL, connections, Data Model, or VBA. Fully static export. Same dimension-table
role as workbook 4: `Informations produits` and `Informations magasins` again serve as lookup/join
tables (by EAN and store Code) for the `Indicateurs` fact rows.

### 5.8 Protection / Inaccessible Content

None. No workbook or sheet protection; everything opened and parsed cleanly.

### 5.9 Open Questions / Gaps Flagged for This Workbook

1. **Brand-name inconsistency** (`COCA COLA` vs. `COCA-COLA`) in the `Indicateurs` sheet's `Marque`
   column — appears to be two distinct source-system brand codes for what is conceptually the same
   brand; should be normalized/reconciled before this data is used for trend analysis, to avoid
   under-counting "Coca-Cola" volumes by splitting them across two labels.
2. This "Groupe" product scope mixes **beverage SKUs and licensed non-beverage merchandise** (car air
   fresheners) under the same brand-based extraction — worth confirming with the client whether this
   is intentional (true brand-equity tracking across all licensed categories) or an unintended
   inclusion that should be filtered out for a "sales performance" narrative.
3. No `Lexique` sheet in this workbook, same gap as workbook 4 — only the single `CA` KPI definition
   is available inline.
4. As with workbook 4, the retailer is not explicitly named, but banner/region naming strongly
   suggests the same Carrefour store universe `[INFERRED, unconfirmed]`.

---

## 6. Deck: `NIQ_Presales_Insights_Example.pptx`

> Note: Analyzed before `NIQ_Measurement Report example.pptx` (out of the file-list's nominal order)
> because it is far smaller (329 KB vs. 7 MB) and was used to validate the new PowerPoint inspection
> tooling before tackling the larger deck. Both decks are fully covered by the time this catalog is
> complete.

### 6.1 Deck Inventory

- **File name:** `NIQ_Presales_Insights_Example.pptx`
- **File type:** PowerPoint Open XML (`.pptx`), authored in **Google Slides** (confirmed: all shape
  names follow the `Google Shape;<id>;p<n>` convention; no `docProps/core.xml` or `app.xml` parts,
  only a minimal `docProps/custom.xml` with a SharePoint `ContentTypeId` — consistent with a Google
  Slides export re-uploaded to a SharePoint/OneDrive library). Slide size 10.0in × 5.62in (16:9-ish
  widescreen, non-standard PowerPoint default).
- **Slide count: 3.** All three slides use the same custom layout (`BLANC 1` — "Blank 1").
- **Content type:** A **"presales insights"** example — i.e., a small, templated slide excerpt
  intended to sell/demonstrate the kind of category-performance insight NIQ/Unlimitail can deliver to
  a retailer or brand, with the actual brand name anonymized as **`XXX`** (placeholder, confirming this
  is a generic example/template rather than a real client deliverable).
- **Retailer explicitly named: "Carrefour"** — footer text on every slide: *"Base encartés Carrefour ;
  données confidentielles ; Période : S126, soit du 01/01/2026 au 01/06/2026 ; Circuit global"*
  (Carrefour card-holder base; confidential data; Period S1‑26 = 01/01/2026–01/06/2026; all channels).
  This **confirms the Carrefour retailer identity** that was only `[INFERRED]` for workbooks 1, 3, 4,
  and 5.
- **Platform/vendor branding:** An embedded logo image (`ppt/media/image2.png`) reads **"unlimitail"**
  — this is the actual named vendor/platform behind the "Memory 360" branding seen throughout the
  Excel workbooks (Unlimitail is a Carrefour/Publicis retail-media joint venture) `[OBSERVED, useful
  cross-file confirmation]`.
- **Embedded media:** 2 images — `image1.png` (208 KB, a rendered line chart, see §6.2) and
  `image2.png` (5.7 KB, the "unlimitail" logo).
- **Native PowerPoint charts:** **None** — the one chart-like visual on slide 3 is a **flattened
  PNG image**, not a native/editable PPTX chart object, so no underlying chart data or series values
  are recoverable from the file itself beyond what's visible in the rendered image.
- **Tables:** 2 native PPTX tables (slides 1 and 2), fully text-extractable (see §6.2/6.3).
- **Speaker notes:** None found on any slide.
- **Animations / transitions:** Not inspected in detail (out of scope for this data/KPI catalog); no
  VBA or macros possible in `.pptx` format.

### 6.2 Slide-by-Slide Content

- **Slide 1 — "Performances de XXX sur S1 26 par catégorie"** (Performance of XXX in H1‑26 by
  category): Subtitle/insight text: *"Des évolutions positives en accord avec leur catégories
  respectives sur les pâtes et les sauces chaudes, mais des performances en baisse sur les segments de
  taille inférieurs"* (Positive trends in line with their respective categories for pasta and hot
  sauces, but declining performance on the smaller segments). Contains a **9‑row × 10‑column table**
  comparing brand ("Marque") vs. category ("Catégorie") performance across 4 categories: `PATES`,
  `SAUCES CHAUDES`, `PLATS CUISINES`, `SEMOULES / COUSCOUS`. Columns: `Part de CA` (CA share), `CA
  encartés` (value + evolution %, two-line cell), `Nombre de clients encartés`, `CA par client
  encartés`, `Fréquence d'achat`, `Panier moyen encartés`, `UVC par panier encartés`, `Prix moyen
  encartés` — **this KPI set matches workbook 1's Customer Loyalty analysis almost exactly** (CA,
  clients, fréquence, panier moyen, UVC, prix moyen), confirming this deck is very plausibly a
  presentation-layer output built from the same KPI family as workbook 1.
- **Slide 2 — same title, no subtitle:** A second **9‑row × 6‑column table**, same category/brand row
  structure, but different KPI columns: `Part de CA`, `Part UVC`, `Evol. CA encartés`, `Evol. UVC
  encartés` — a condensed evolution-focused view of the same categories.
  the same categories.
- **Slide 3 — "Performances des catégories pâtes et sauces chaudes sur S1 26 par mois"** (Performance
  of pasta and hot-sauce categories in H1‑26 by month): Subtitle: *"Un recul légèrement visible sur
  les sauces chaudes, ainsi que des performances plus inconstantes sur la catégorie pâtes"* (A slight
  decline visible in hot sauces, and more inconsistent performance in the pasta category). Contains
  **one embedded PNG chart image** (`image1.png`), titled inside the image itself: *"Evolution du CA
  encartés sur les catégories sauces chaudes et pâtes, parcours global, 18DM"* (Evolution of
  card-holder revenue for the hot-sauce and pasta categories, all-channel, **last 18 months**) — a
  weekly line chart (x-axis = week numbers `202502`…`202622`, i.e., ISO year+week codes spanning ~18
  months) with two series: `Sauces chaudes` (teal) and `Pâtes` (red), y-axis `CA encartés` in raw €
  (1,000,000–3,500,000 range).

### 6.3 Dimensions & Attributes Catalog (this deck)

| Dimension | Values observed |
|---|---|
| Catégorie | PATES, SAUCES CHAUDES, PLATS CUISINES, SEMOULES / COUSCOUS |
| Niveau (Marque vs. Catégorie) | Marque (brand-level row) vs. Catégorie (category-level row) — same brand-vs-category benchmark pattern as workbook 3 |
| Semaine (week) | ISO week codes `202502`–`202622` (~18 months of weekly data) |
| Période | Fixed to "S126" (semester 1, 2026: 01/01/2026–01/06/2026) for the tables; 18-months for the chart |
| Circuit | "Circuit global" (all channels) — single value, stated in footer |

### 6.4 KPIs / Measures Catalog (this deck)

| KPI | Where displayed | Notes |
|---|---|---|
| Part de CA (CA share) | Slides 1, 2 | Brand's % share of category CA; category row shows "-" (share of itself is not meaningful) |
| CA encartés | Slide 1 | Card-holder revenue, value + evolution % in same cell (two-line text) |
| Nombre de clients encartés | Slide 1 | Card-holder customer count |
| CA par client encartés | Slide 1 | Revenue per card-holder customer |
| Fréquence d'achat | Slide 1 | Purchase frequency |
| Panier moyen encartés | Slide 1 | Average basket value |
| UVC par panier encartés | Slide 1 | Units per basket |
| Prix moyen encartés | Slide 1 | Average unit price |
| Part UVC | Slide 2 | Brand's % share of category unit volume |
| Evol. CA encartés / Evol. UVC encartés | Slide 2 | Evolution % versions of CA and UVC, condensed view |

No formulas/definitions text is present in the deck itself for these KPIs — their definitions must be
cross-referenced against workbook 1's glossary/definitions (same KPI names, "encartés" = card-holder
scoped, matching workbook 1's terminology) `[CROSS-FILE INFERENCE]`.

### 6.5 KPI Formulas & Business Logic

No formulas are present (flattened tables/images, not live data). The **evolution % values shown are
almost certainly `(valeur période analysée − valeur période comparaison) / valeur période comparaison`**,
matching the `Evolution %` convention verified in workbooks 1/3/4 `[INFERRED, not independently
recomputable here since only the deck-level output values are visible, not the underlying comparison
raw values]`.

### 6.6 Report Layout / Where KPIs Are Displayed

Three-slide narrative flow: (1) full KPI table by category+brand, (2) condensed
share/evolution table by category+brand, (3) a time-series trend chart by category over 18 months.
Consistent NIQ/Unlimitail branding: top banner with an "INSIGHTS" pill label, title + narrative-insight
subtitle text (i.e., pre-written business commentary, not just raw numbers), and a confidentiality/
scope footer on every slide.

### 6.7 Embedded SQL / Queries / Transformations / Dependencies

None — this is a finished, flattened presentation (tables are static PPTX tables; the trend visual is
a static PNG). No live data connections, no embedded workbook objects, no VBA (not possible in
`.pptx`).

### 6.8 Protection / Inaccessible Content

None — no password protection; all content parsed and extracted cleanly, including both embedded
images.

### 6.9 Open Questions / Gaps Flagged for This Deck

1. Brand name is anonymized as `XXX` throughout — confirms this is a **generic template/example deck**
   (as its filename suggests: "_Example"), not a real client deliverable; safe to treat purely as a
   **layout and KPI-vocabulary reference** for design purposes.
2. The slide-3 chart is a flattened image with no recoverable underlying data table in the file
   itself — if the replacement report needs this exact trend view, the weekly CA-by-category data
   would need to be sourced from elsewhere (e.g., workbook 3's `Quand` sheets follow a similar
   weekly/monthly pattern, though for a different category).
3. `[CONFIRMED]` — the "Unlimitail" platform name and "Carrefour" retailer name, both previously only
   inferred from workbook 1/3/4/5 content, are explicitly stated in this deck. This should be treated
   as reliable, deck-sourced confirmation for the whole file set's retailer/platform identity.

---

## 7. Deck: `NIQ_Measurement Report example.pptx`

> Note: This is file #6 in the top-level inventory (§0), analyzed last/second among the two decks. It
> is the final file in the 7-file analysis scope.

### 7.1 Deck Inventory

- **File name:** `NIQ_Measurement Report example.pptx`
- **File type:** PowerPoint Open XML (`.pptx`), ~7 MB (large mainly due to embedded high-resolution
  background/photo images, notably one ~5.1 MB PNG). Also authored in **Google Slides** (all shapes
  named `Google Shape;<id>;p<n>`; layouts named `CUSTOM_30`/`CUSTOM_33`/`CUSTOM_37_1`).
- **Slide count: 15.** Slide size 10.0in × 5.62in (same widescreen ratio as the Presales deck).
- **Content type:** A **retail-media campaign measurement report** — i.e., the presentation-layer
  deliverable summarizing the results of a specific sponsored/social advertising campaign measured
  against Carrefour loyalty-card transactional data. This is very plausibly the **narrative report
  built from the same KPI family as workbook 2 (`NIQ_Datasheet_Liftcampaign.xlsx`)** — shared
  vocabulary: Exposable group, Shoppers, Conversion rate, Reach, Impressions, Revenue/client,
  Frequency, Avg. basket — though the exact underlying campaign/product differs between the two files
  `[INFERRED — same KPI/report family, not proven to be the same literal campaign instance]`.
- **Retailer:** **Carrefour**, explicitly named — every data slide's footer reads *"Source: Carrefour
  loyalty card holders database, confidential data, campaign period and 30-day attribution window,
  from April 28th, 2026, to June 30th, 2026"*.
- **Platform/vendor:** **Unlimitail**, explicitly named on the KPI slide footer (*"Source: Unlimitail,
  internal & confidential data"*) — same vendor identity confirmed in the Presales deck (§6).
- **Product / brand:** Anonymized as `XXX`/`XXXX` in most narrative text (consistent with this being
  an "example" template), but the **real brand name "Saint Germain" leaks through unredacted on
  slide 11** (twice: as a data label `"Saint Germain"` on the e-commerce-share chart, and implicitly
  via context) — Saint-Germain is an elderflower liqueur brand; product category = **liquor
  ("Liquor")**, confirmed via slide 12/13 category-comparison labels. `[OBSERVED — data leak /
  anonymization gap in the source example file, worth flagging to the client]`.
- **Campaign parameters (from slide 1 & slide 3's table):** Campaign type = `Social`; campaign period
  `29/04/2026` to `31/05/2026`; attribution window `01/06/2026` to `30/06/2026` (30-day post-campaign
  attribution window); redirection = link to `Carrefour.fr`; 5 shopper-targeting segments defined by
  prior purchase behavior (see §7.3).
- **Embedded media:** 24 raster images (`image2.png`…`image42.png`, various sizes from ~2.8 KB to
  5.1 MB) — a mix of decorative background photography (large files, e.g. `image32.png` at 5.1 MB,
  `image36.png` a duotone lifestyle photo) and small flattened **data-visualization images** (bar
  charts for shopper-loyalty breakdown and lifestage/consostyle profiling — see §7.2).
- **Native PowerPoint charts:** **None** — all quantitative visuals are flattened PNG images with
  data labels overlaid as separate text boxes (values are extractable from the surrounding text boxes,
  but the chart geometry itself is a static image, not an editable chart object).
- **Tables:** 5 native PPTX tables (slides 3, 7, 8, 9, 11), fully text-extractable.
- **Speaker notes:** `notesSlide` XML parts exist for slides 6, 10, 12, and 13, but all are **empty**
  (verified via direct XML text-run extraction) — no actual speaker-note content in any slide.
- **Protection:** None. No VBA (not possible in `.pptx`).

### 7.2 Slide-by-Slide Content

- **Slide 1 (cover):** "Campaign from 29/04/2026 to 31/05/2026"; "Report" / "Alternative conversion"
  (sub-label, suggesting this deck may be one of several "alternative conversion" report variants for
  this campaign).
- **Slide 2 (section divider "01."):** "Campaign overview".
- **Slide 3 — Campaign details:** A 6-row table: `Campaign type = Social`; `Campaign period = 29/04/2026
  au 31/05/2026`; `Attribution window = 01/06/2026 au 30/06/2026`; `Social media used` (value blank/
  redacted); `Redirection = Link to Carrefour.fr`; `Shopper targeting based on Carrefour's data` listing
  5 segments (see §7.3). Narrative text: "The product was launched in April throughout the Carrefour
  network".
- **Slide 4 — Campaign KPIs:** 4 headline media KPIs with actual-vs-estimated comparison: **Impressions**
  = 14 M (estimated: 7.8 M); **CPM** = 2.4 € (estimated: 4.3 €); **Reach** = 1.5 M; **Clics (Clicks)** =
  38.7 K. Narrative: "An effective campaign, as shown by the competitive CPM and impressions compared
  to the estimated values (almost x2 on impressions and 0.5x on the CPM)". Footer explicitly credits
  **"Unlimitail"** as the data source.
- **Slide 5 (section divider "02."):** "Offsite sales report".
- **Slide 6 — Methodology:** A 3-step visual process: **(1) Audience building** — "Audience segments
  are created based on buying habits"; **(2) Exposable group** — "Audiences are activated"; **(3)
  Sales measure** — "Measure of the sales KPIs based on the different audiences pushed". This is the
  clearest **methodology statement in the whole file set** for how the exposed/control-style lift
  measurement (as seen in workbook 2) is actually constructed operationally.
- **Slide 7 — Conversion overview:** Table (`Segment | Exposable group | Shoppers | Conversion rate`):
  `Total = 4.8 M exposable | 12.1 K shoppers | 0.2% conversion rate`. Narrative: "12.1 K shoppers have
  bought at least one bottle of XXX during the campaign".
- **Slide 8 — Conversion funnel:** Expanded table with per-segment breakdown: `Total` (4.8M/12.1K/
  0.2%), `Prosecco/white wine buyers` (3.3M/4.6K/0.1%), `Summer liquor buyers` (537K/4.3K/0.8%),
  `Winter liquor buyers` (477K/2.3K/0.5%), `Vermouth/Martini buyers` (505K/1K/0.2%). Narrative:
  "summer liquor buyers... conversion rate largely superior to its counterparts by a minimum of 3
  points"; "Prosecco/white wine and summer liquor buyers constitute more than ⅔ of the overall
  shoppers".
- **Slide 9 — Business equation by audience:** A 7‑row × 9‑col table decomposing the CA/business
  equation per segment: `Segment | Shoppers | Revenue | Transactions | Revenue/client | Frequency |
  Avg. basket | Item/basket | Price/product`. Total row: `12,152 shoppers | 334 K€ revenue | 13,487
  transactions | 27.5 € revenue/client | 1.1 frequency | 24.8 € avg. basket | 1.1 item/basket | 22.6 €
  price/product`. Per-segment rows for the same 4 targeting segments. This table is the **direct
  English-language equivalent of workbook 1's French business-equation KPI set** (CA = clients ×
  fréquence × panier moyen), confirming the same underlying formula: `Revenue = Shoppers × Frequency ×
  Avg. basket` (and `Avg. basket = Item/basket × Price/product`) `[CROSS-FILE FORMULA CONFIRMATION]`.
- **Slide 10 — Shopper breakdown: loyalty:** A flattened bar-chart image (dark bar = 12.1 K total
  shoppers, light-blue bar = 1.1 K "loyal shoppers") with the narrative: "9% of the total shoppers
  throughout the campaign have bought at least two separate times"; definition given inline: *"A loyal
  shopper is a customer who has bought the product at least twice during the campaign"* — a clear,
  citable **business definition** for "loyal shopper" specific to this campaign-measurement context.
- **Slide 11 — Performance by channel:** Two KPI callouts: "E-commerce share of turnover" — `7%` for
  "Saint Germain" (brand — **name leak, see §7.1**) vs. `3%` for "Liquor's category", a `+4 pts`
  difference. A 5-row table `Channel | Revenue/client | Avg. basket | Avg. price per product | Nb. of
  items per basket` broken down by `Total / E-Commerce / Hypermarket / Supermarket`. Narrative: "XXX
  e-commerce share of revenue is higher than the liquor's category by 4 pts".
- **Slide 12 — Profiling: lifestage:** Two flattened 100%-stacked-bar images comparing the brand's
  buyer lifestage mix (`1% / 10% / 29% / 13% / 47%` for age bands `18-24 / 25-39 / 40-64 / 65+ /
  Families`) against the category's mix (`4% / 10% / 26% / 18% / 40%` for the same bands, values
  recovered by direct image inspection). Narrative: "Buyers... are mainly parents (families) with
  47%"; "almost null apparition of the youngest segment (18-24 years old) for the brand (at 1%), even
  though it is also small at the category level (4%)".
- **Slide 13 — Profiling: consostyle:** Same paired-bar-chart pattern for a 5-value "Consostyle"
  taxonomy: `Deal seekers / Budget / Gourmet / Nutrition / Convenience`, with brand values `9% / 9% /
  36% / 28% / 19%` (values recovered by direct image inspection). Narrative: "Gourmet and nutrition
  represent the top consostyles... respectively +10 pts and +12 pts compared to the category" — i.e.,
  category values are ~26% (Gourmet) and ~16% (Nutrition). **This "Consostyle" segmentation is the
  same named taxonomy defined in workbook 3's `Lexique` glossary** — direct cross-file confirmation
  that the `Lexique` definitions apply beyond workbook 3 `[CROSS-FILE CONFIRMATION]`.
- **Slide 14 (section divider "03."):** "Conclusion".
- **Slide 15 — Learnings / Recommandations (two-column summary):** **Learnings:** "A visible impact on
  e-commerce sales" (the +4pt e-commerce bump); "A more unique clientele" (brand buyers seek quality/
  heritage, skew slightly older than category); "A clear targeting path" (revenue/client count show
  summer-liquor and prosecco/white-wine buyers as the two main audiences). **Recommandations:** "Focus
  on the right segments" (double down on Summer & Winter liquor buyers; split "Prosecco/white wine"
  into two separate segments for clearer attribution; consider engagement vs. recruitment segment
  strategies depending on objectives); "Social Retail" (test Meta Social Retail format, bundled
  products).

### 7.3 Dimensions & Attributes Catalog (this deck)

| Dimension | Values observed |
|---|---|
| Shopper-targeting segment | Summer liquor buyers, Winter liquor buyers (w/o summer), Prosecco/white wine buyers (w/o summer & winter), Vermouth/Martini buyers (w/o summer, winter & prosecco), "All audiences" (new-product recruitment) |
| Channel | Total, E-Commerce, Hypermarket, Supermarket |
| Lifestage (age band) | 18-24 years old, 25-39 years old, 40-64 years old, 65 years old and +, Families |
| Consostyle | Deal seekers, Budget, Gourmet, Nutrition, Convenience — same taxonomy as workbook 3's `Lexique` |
| Loyalty status | Shoppers (≥1 purchase), Loyal shoppers (≥2 separate purchases during campaign) |
| Campaign metadata | Campaign type (Social), Campaign period, Attribution window (30-day), Redirection URL |

### 7.4 KPIs / Measures Catalog (this deck)

| KPI | Slide(s) | Notes |
|---|---|---|
| Impressions | 4 | Actual vs. estimated (benchmark) comparison |
| CPM | 4 | Cost per mille, actual vs. estimated |
| Reach | 4 | Unique users reached |
| Clics (Clicks) | 4 | Raw click count |
| Exposable group | 7, 8 | Size of the audience exposed/targetable for the segment |
| Shoppers | 7, 8, 9 | Count of unique converting shoppers |
| Conversion rate | 7, 8 | = Shoppers / Exposable group |
| Revenue | 9 | Total € revenue attributed to the segment |
| Transactions | 9 | Count of purchase transactions |
| Revenue / client | 9, 11 | = Revenue / Shoppers |
| Frequency | 9 | = Transactions / Shoppers |
| Avg. basket | 9, 11 | = Revenue / Transactions |
| Item / basket | 9, 11 | Units per transaction |
| Price / product | 9, 11 | = Avg. basket / Item per basket |
| E-commerce share of turnover | 11 | % of revenue via e-commerce channel, brand vs. category |
| Loyal shopper % | 10 | % of shoppers with ≥2 purchases in-campaign |

### 7.5 KPI Formulas & Business Logic

No live formulas (flattened deck), but the **business-equation decomposition on slide 9 explicitly
confirms**, in English, the same identity independently verified via recomputation in workbooks 1/3/4:

$$\text{Revenue} = \text{Shoppers} \times \text{Frequency} \times \text{Avg. basket}$$
$$\text{Avg. basket} = \text{Item/basket} \times \text{Price/product}$$
$$\text{Conversion rate} = \frac{\text{Shoppers}}{\text{Exposable group}}$$

These are **stated as a coherent "business equation" narrative** on slide 9's title itself ("Business
equation by audience"), making this the most explicit, self-labeled confirmation of the CA-decomposition
formula anywhere in the 7-file set.

### 7.6 Report Layout / Where KPIs Are Displayed

Three-act narrative structure mirrored by the "01./02./03." section dividers: **(1) Campaign overview**
(details + media KPIs), **(2) Offsite sales report** (methodology → conversion → business equation →
loyalty → channel → profiling), **(3) Conclusion** (learnings + recommendations). Every data slide
carries a standard footer citing its data source (Carrefour or Unlimitail) and the exact
campaign/attribution date range — a strong, consistent provenance-labeling convention worth replicating
in any redesigned report.

### 7.7 Embedded SQL / Queries / Transformations / Dependencies

None — fully flattened, static presentation content (tables + images only). No connections, Power
Query, or VBA. The methodology slide (6) is the closest thing to a "process/pipeline" description in
the entire 7-file set, describing (in prose, not code) a 3-stage audience-building → exposable-group →
sales-measurement pipeline that conceptually matches workbook 2's Exposed/Control cohort methodology.

### 7.8 Protection / Inaccessible Content

None — no protection; all text, tables, and images extracted successfully. Two data-visualization
images (slides 12/13) required direct visual inspection (rather than text extraction) to recover their
underlying percentage values, since those values are baked into the image pixels rather than present
as separate text/XML.

### 7.9 Open Questions / Gaps Flagged for This Deck

1. **Brand-name redaction is inconsistent/incomplete** — "Saint Germain" (real product name) appears
   unredacted on slide 11 even though the rest of the deck uses "XXX"/"XXXX" placeholders. If this
   deck is used as a design/template reference going forward, this should be treated purely as
   incidental and the brand name should not be propagated into any new templates.
2. Slide 1's "Alternative conversion" sub-label is unexplained — may indicate this specific deck is a
   variant (among several) using an alternative conversion-measurement methodology; no other slide
   clarifies what makes it "alternative" `[GAP]`.
3. The `Social media used` table cell (slide 3) is blank in this example — likely redacted or simply
   not filled in for this template instance.
4. Category-side percentage values for lifestage/consostyle (slides 12/13) are only stated narratively
   as point-differences (e.g., "+10 pts") rather than shown in a clean side-by-side table — recovering
   them required visual inspection of the second bar-chart image per slide; a redesigned report should
   consider a single combined table/chart for easier comparison.
5. This deck and workbook 2 (`NIQ_Datasheet_Liftcampaign.xlsx`) share KPI vocabulary and the
   Exposed/Control-style methodology, but **no direct file-level link** (e.g., matching campaign name
   or ID) was found connecting them — the relationship remains `[INFERRED]` at the KPI/methodology
   level only.

---

## Analysis Complete — Summary

All 7 files in scope have now been analyzed and documented (§1–§7), fulfilling the user's original
request for a "thorough, workbook-by-workbook (and deck-by-deck) analysis" covering incoming/source
data, dimensions, KPIs, formulas, report layout, embedded logic, and business vocabulary. Cross-file
highlights:

- **Retailer:** Carrefour (confirmed explicitly in both PowerPoint decks; inferred from taxonomy in
  all 5 Excel workbooks).
- **Platform/vendor:** Two distinct platforms observed — **"Memory 360"** (branding seen in workbooks
  1, 3, 4, 5) and **"Unlimitail"** (explicitly named in both PowerPoint decks) — very likely the same
  underlying analytics vendor/JV, with "Memory 360" as the product/platform name and "Unlimitail" as
  the corporate/brand name `[INFERRED]`.
- **Two report families identified:** (1) Curated category/loyalty performance reports (workbooks 1,
  3) and their presentation counterpart (deck 7, Presales Insights); (2) Retail-media lift/campaign
  measurement (workbook 2) and its presentation counterpart (deck 6, Measurement Report). Workbooks 4
  and 5 are raw data-extraction outputs (dimension tables + narrow KPI/time-series pulls) from the same
  underlying Memory 360 data model, usable as building blocks for either report family.
- **Consistent core business-equation formula** verified/confirmed independently across workbooks 1,
  3, 4 (via recomputation) and deck 6 (via explicit slide narrative): `CA (Revenue) = Clients ×
  Fréquence × Panier moyen`, with `Panier moyen = UVC/panier × Prix moyen`.
- **All 5 Excel workbooks are fully static exports** (0 formulas, 0 comments, 0 named ranges, no
  pivots/Power Query/Data Model/VBA/connections) — any replacement reporting solution will need to
  either re-derive these KPIs from raw transactional data or continue consuming Memory 360's exports
  as a source layer.
- **Both PowerPoint decks are Google-Slides-authored, fully flattened** (no native charts; all
  quantitative visuals are static images with separately overlaid text labels).
- **Richest glossary/vocabulary source:** workbook 3's `Lexique` sheet (79 terms), whose segmentation
  taxonomies (Lifestage, Structurelle, Consostyle, Promotion) are also used, unlabeled/undefined
  in-file, by deck 6's profiling slides (12–13) — this cross-file link should be preserved in any
  consolidated business glossary for the replacement solution.

Per the user's explicit instruction, **this phase is analysis and documentation only** — no design or
implementation of replacement reports has been undertaken. Awaiting further direction before proceeding
to any design/build phase.
