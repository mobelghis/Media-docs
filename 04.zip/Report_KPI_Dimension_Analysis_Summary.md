# Report_KPI_Dimension_Analysis — Executive Summary

**Companion file:** `Report_KPI_Dimension_Analysis.xlsx`
**Generated:** 2026-09-10 (FE Field Mapping sheets + methodology added 2026-09-13)
**Scope:** All 7 source files in this workspace — 5 Excel workbooks (61 worksheets) and 2 PowerPoint decks (18 slides). No files were excluded; every worksheet and slide, including empty sheets, glossary tabs, configuration/parameter sheets, and presentation-only slides, was inventoried.

## 1. Executive Summary

This analysis works in the opposite direction from the canonical data model in `Data_Model_Design/`: rather than starting from source data and building up to a physical schema, it starts from the **reports themselves** and asks, for each one, "what KPIs and dimensions does it actually use, and which other reports is it functionally the same as?"

The 7 files produce **84 distinct report/worksheet/slide units**, built from **43 canonical KPIs** and **34 canonical dimensions**. Of those 84 units, a large share are **not independent report designs** — they are the same underlying template re-run with a different dimensional cut, measurement basis, benchmark scope, or presentation layer. The comparison analysis identifies **15 comparison groups**, of which **10 groups (66 report instances)** are recommended for consolidation into a single parametrized template, which would reduce the effective number of report *templates* needed for a redesigned system from 84 physical instances down to roughly **35–40 distinct templates**.

Three questions are **Blocking** — they must be resolved with the client before certain KPIs (campaign lift/incremental measures, WB3's evolution/benchmark indices, and the retail-vs-campaign customer identity link) can be safely implemented in any new system. All 7 source files were fully readable; none could not be processed.

## 2. Key Counts

| Metric | Count |
|---|---|
| Source files analyzed | 7 (5 xlsx + 2 pptx) |
| Source worksheets/slides | 79 (61 xlsx sheets + 18 pptx slides) |
| Report Inventory rows | 84 *(WB1's `Profil` sheet was split into 6 report-section rows since it contains 6 structurally distinct value-tables)* |
| Canonical KPIs identified | 43 |
| Canonical Dimensions identified | 34 |
| Report Comparison Groups | 15 |
| Groups recommended for template consolidation | 10 (covering 66 report instances) |
| Report Signatures computed | 84 (mechanical KPI+Dimension fingerprint) |
| Open Questions | 20 (3 Blocking / 10 Important / 7 Nice-to-have) |
| Validation Findings (data-quality issues) | 14 (2 High / 6 Medium / 6 Low severity) |
| Source files unreadable | 0 |
| FE Field Mapping rows (new, 2026-09-13) | 43 KPI rows + 34 Dimension rows = 77 (see §12) |

## 3. Duplicates and Near-Duplicates Identified

Using the Report Signatures sheet (a deterministic hash of each report's exact KPI-ID-set + Dimension-ID-set), several reports share an **identical** signature, meaning they use the exact same KPIs and dimensions and differ only in scope/filter values, not structure. The Report Comparison Summary groups these (and looser, judgment-based similarities) into 15 named groups. The most significant duplicate/near-duplicate clusters:

- **WB3 measurement-basis pairs** (CG01): 5 pairs of sheets (10 sheets total) that are identical except for a CA-vs-UVC measurement-basis toggle.
- **WB2 Business Equation family** (CG03): 4 sheets sharing one core KPI set, differing only by slicing dimension (Control/Audience, Audience, Channel, SKU).
- **WB2 Loyalty Profiles family** (CG04): 5 sheets sharing the same New/Returning Shopper KPI, differing only by cut dimension.
- **WB4/WB5 extraction-tool pattern** (CG05): both workbooks use an identical 4-sheet structure (parameters, indicators, product info, store info), differing only in product scope and time grain.
- **WB1 Profil benchmark pair** (CG02) and **WB1 ranking pair** (CG06): identical templates, different scope or ranked entity.

## 4. Dimension/Filter/Period-Only Variants

Beyond outright duplicates, several groups of reports are genuinely distinct **business questions** but reuse the same KPI set with only the analysis dimension changed:

- Performance-by-Channel snapshot vs. trend (CG11) — same KPIs, adds a Date axis.
- Buying Behaviour by SKU vs. by Channel (CG12) — same exposed/non-exposed KPI, different cut.
- Sales Uplift total vs. by-audience (CG09) — same incremental KPIs, optional Audience breakdown.
- Conversion Overview vs. Funnel (CG14) — same conversion KPI set, total vs. segment view.

These are recommended for consolidation into a single template with a **selectable cut dimension**, rather than being treated as unrelated reports.

## 5. Reports With Genuinely Unique Logic (Not Recommended for Consolidation)

- **Segmentation/profiling family** (CG08 — WB1, WB3, WB2, deck7): superficially similar (all profile customers/shoppers), but each uses a **different KPI set** and serves a different report family (retail performance vs. campaign measurement). Consolidating the *segment-value glossary* is recommended; consolidating the *reports* is not.
- **Sales Overview family** (CG10): shares a sheet-naming convention but the 4 WB2 sheets carry **non-overlapping KPI sets** (trade, reach, basket-size histogram, new buyers) — kept as distinct blocks within one narrative, not merged.
- **Performance by Audience vs. Business Equation by Audience** (CG15): flagged as **insufficient evidence** to compare — R044's values are internally inconsistent with R023's for the same audiences (see Validation Finding VF07); do not assume these are interchangeable cuts of the same data until the anomaly is resolved.

## 6. Recommended Reusable Templates

Consolidating the 10 recommended comparison groups (see Report Comparison Summary sheet for full rationale) would replace **66 individual report instances** with **10 parametrized templates**:

1. WB3 Performance-by-X template (measurement-basis parameter: CA/UVC)
2. WB1 Profil value-table template (benchmark-scope parameter)
3. Business Equation by-X template (cut-dimension parameter: Control/Audience/Channel/SKU)
4. Loyalty Profile by-X template (cut-dimension parameter)
5. Product/Temporal Extraction template (product-scope + time-grain + KPI-list parameters)
6. Top-N Ranking template (hierarchy-level parameter: EAN/Brand)
7. Sales Uplift template (optional Audience breakdown)
8. Performance-by-Channel template (snapshot/trend toggle)
9. Buying Behaviour template (cut-dimension parameter: SKU/Channel)
10. Conversion Overview/Funnel template (total/segment toggle)

Combined with the remaining ~18 reports that are already unique (parameter/glossary/reference rows aside), this suggests a redesigned system would need on the order of **35–40 distinct report templates** to cover all 84 currently-produced report instances.

## 7. Blocking Gaps (Must Be Resolved Before Re-Implementation)

| ID | Area | Question |
|---|---|---|
| OQ01 | Campaign lift methodology | What matching/weighting methodology and significance test produced the Incremental Revenue/Quantity/Shoppers/Buyer-Rate and ROAS KPIs? |
| OQ02 | WB3 evolution/benchmark KPIs | What are the exact formulas and reference populations for Ecart vs Benchmark, Indice CA/UVC, and VMH, and what is the enumerated benchmark product list? |
| OQ03 | Population identity | Is "Clients" (retail family) the same underlying customer population as "Shoppers" (campaign family)? |

## 8. Other Key Open Questions (Important priority — 10 total, see Open Questions sheet)

Highlights: loyal-shopper threshold discrepancy (>2 vs ≥2 receipts), undefined RFM/Hierarchy segmentation values in WB2, brand-name inconsistency in WB5 ("COCA COLA" vs "COCA-COLA"), three sheets with no data rows (Exposure Overview - frequency, Frequency Impact, and all-zero Exposure Evolutions), anomalous values in "Performance by Audience", undefined new-shopper lookback window, unconfirmed gross/net tax treatment, an unredacted real brand name on deck7 slide 11, an unexplained "Alternative conversion" label on deck7 slide 1, and no confirmed shared campaign ID linking WB2 and deck7.

## 9. Data Quality Findings (see Validation Findings sheet for full list)

Two **High** severity findings: (1) the term "Constants" is used for two unrelated concepts (customer-level movement type vs. store-level comparability status) — a terminology collision that must be disambiguated in any consolidated glossary; (2) the loyal-shopper threshold is stated inconsistently across files (>2 vs. ≥2 receipts).

## 10. Next Steps

1. Route the 3 Blocking questions to the client / Memory 360 / Unlimitail measurement teams before any KPI is hard-coded into a production system.
2. Resolve the 2 High-severity terminology/threshold conflicts before building a shared glossary.
3. Investigate the empty/all-zero/anomalous sheets (OQ07, OQ08) as likely export defects.
4. Use the Report Comparison Summary and Report Signatures sheets as the basis for template consolidation in any redesigned reporting system.
5. Cross-reference this deliverable against `Data_Model_Design/04_KPI_Lineage_and_Formulas.md` and `05_Report_Traceability_Matrix.md` — this analysis uses a finer report granularity (84 rows vs. 22) and an expanded KPI set (43 vs. 31, reflecting additional campaign/media KPIs found during the report-first pass).

## 11. Validation Checklist Confirmation

All required validation checks (report-source-reference completeness, KPI/dimension referential integrity between the catalogs and the matrices, formula-status accuracy, statistical-output separation, matrix-legend completeness, worksheet-count/structure, and workbook load-integrity) were performed against the generated `.xlsx` file before this summary was finalized. See the **Validation Findings** sheet for data-quality issues found in the *source data itself* (distinct from workbook-construction validation, which passed with no open issues).

## 12. FE Field Mapping — Methodology (new, 2026-09-13)

**Purpose:** Two new sheets, **"FE Field Mapping - KPIs"** and **"FE Field Mapping - Dimensions"**, give front-end developers one clean row per field stating exactly which UI component to use and how to badge its confidence, so no developer has to re-derive UI treatment from the raw KPI/Dimension Catalog columns themselves.

**This is a UI/UX design layer, not new client-confirmed data.** Every row is generated by a small, fixed rule table applied mechanically to fields that already exist in the KPI Catalog (`Category`, `Formula Status`) and the Dimension Catalog (`Type`) — no new business facts, formulas, or client statements are introduced. Each row also carries a `Design Rationale` column stating exactly which rule fired, so the mapping is fully auditable back to the source catalog value.

**KPI → UI Component rule** (keyed off `Category`, with one override):

| Category | Recommended UI Component |
|---|---|
| Core Business Equation | KPI Card (headline metric) + Trend Sparkline |
| Evolution & Comparison | KPI Card delta/arrow indicator — always paired with its base metric, never shown standalone |
| Market & Assortment / Promotion & Distribution | Table Column / Ranked List |
| Customer Movement & Purchase-Pattern | Segment Breakdown Chart / Table Column |
| Campaign / Retail-Media, Campaign Media & Supporting | KPI Card / Funnel Stage Tile |
| *(override)* Campaign / Retail-Media KPI whose name contains "lift", "incremental", "roas", "p-value(s)", or "significan..." | KPI Card **+ Confidence Badge** (methodology-sensitive metric) |

**KPI → Confidence Badge rule** (keyed off `Formula Status`, directly operationalizing the mode's confidence-tiering requirement — modeled/unverified measures must never carry the same visual weight as deterministic ones):

| Formula Status | Badge Treatment |
|---|---|
| CONFIRMED | None required — deterministic, confirmed formula |
| DERIVED_AND_VALIDATED | None required — derived from 2 confirmed KPIs, independently recomputed and matched |
| INFERRED | Low-emphasis info icon: "Standard convention — not independently confirmed" |
| UNVERIFIED | **Required** visible badge: "Estimated — methodology pending client confirmation"; must never share color/weight with a Confirmed KPI |
| NOT_AVAILABLE | Do not display in any UI — blocked pending data availability |
| NOT_APPLICABLE | N/A — atomic/ingested value, no formula-confidence badge applies |

**KPI → Display Format Hint rule** (keyed off `Format`): Percentage → 1 decimal, signed where applicable; Index → base-100 gauge/threshold styling; Currency → 2 decimals, localized symbol; Whole number/Count → integer, K/M abbreviation above threshold; Ratio/Decimal → 1-2 places; Statistical → diagnostic view only, never a headline card.

**Dimension → Interaction Pattern rule** (keyed off `Type`):

| Type | Interaction Pattern |
|---|---|
| Time | Chart X-axis / period-range picker (Analysis vs Comparison) |
| Product | Filter dropdown (typeahead) + hierarchy drill-down breadcrumb |
| Store | Filter dropdown + map/region drill-down |
| Channel | Filter dropdown / tab selector |
| Customer | Filter dropdown + segment-breakdown chart axis |
| Campaign | Filter dropdown (campaign/audience picker) |
| Metric Basis | Toggle control (e.g. CA/UVC switch), not a filter |

**Implementation:** `_analysis/report_kpi_data.py` computes `FE_KPI_MAPPING`/`FE_DIM_MAPPING` from the existing `KPIS`/`DIMENSIONS` lists via `_fe_kpi_row()`/`_fe_dim_row()`; `_analysis/build_report_kpi_workbook.py` writes them to sheets 6c/6d. Regenerate with:

```
cd "/Users/mohammadbelghiszadeh/Downloads/Sample reports"
source .analysis_venv/bin/activate
python3 _analysis/build_report_kpi_workbook.py
```

**Limitation:** these rules are a first-pass, consistent default — they are a starting point for FE/design review, not a substitute for validating each component choice against the actual report mockups once available (e.g. `PRD/10_Report_Consolidation_Plan.md`).

## 13. Measurement Methodology — As Evidenced in the Sample Reports (new, 2026-09-13)

This section documents what the **7 sample report files themselves** show (or fail to show) about campaign lift/incrementality measurement. It is scoped narrowly to this report-first analysis — for the fuller, client-discovery-informed methodology (control-group sourcing options, attribution-window boundary rules, 5-layer measurement model, Indexes), see the authoritative **`PRD/05_Measurement_Methodology.md`**, which incorporates 20 source documents including meeting transcripts not present in this 7-file sample set. Do not treat the two as conflicting — this section is a subset, grounded only in WB2 (`NIQ_Datasheet_Liftcampaign.xlsx`) and deck7 (`NIQ_Measurement Report example.pptx`).

**Confirmed structural facts:**
- A test-vs-control design **exists** — WB2 and deck7 both contain paired Exposed-group and Control-group rows for the same KPI set (e.g. Business Equation vs Control sheets), and a single "Incremental" result row sits alongside them.
- Attribution window: deck7 states a **fixed 30-day window** (campaign period 29/04/2026–31/05/2026, attribution window 01/06/2026–30/06/2026). WB2 states no explicit attribution-window dates anywhere in the workbook itself.
- Conversion Rate (F1) and the New/Returning Shopper identity (F9, `Total = New + Returning`) are **CONFIRMED** — both are stated verbatim or independently recomputed and matched against sampled values.
- Loyal Shopper Rate (F8) is confirmed as a concept, but its exact threshold is **discrepant between sources** (WB2: `>2` receipts i.e. ≥3; deck6: "at least twice" i.e. ≥2) — both variants are preserved side by side, not merged.

**Blocking gaps — no formula is invented anywhere in this file set for these:**
| KPI | Gap |
|---|---|
| F5 — Incremental Revenue/Quantity/Shoppers/Buyer Rate (Lift) | The matching/weighting methodology and significance-test type behind the single "Incremental" result are **not documented in any of the 7 files**. |
| F6 — ROAS | Inherits F5's gap (divides an unverified Incremental Revenue by Campaign Cost). |
| F7 — P-Values | Statistical test type (t-test, bootstrap, etc.) is **never stated**; must never be aggregated/averaged across segments once implemented. |

**What this means for implementation:** F5/F6/F7 must ship as `UNVERIFIED`/Blocking in the KPI Catalog and carry the `Confidence Badge Treatment` defined in §12 (never the same visual weight as F1/F8/F9). Resolving these requires the client/methodology evidence tracked separately — see `06_Open_Questions.md` Blocking items #2 and #4 in this workspace's Data_Model_Design layer, and `PRD/05_Measurement_Methodology.md` §3/§5 (Incrementality Methodology / Control-Group Sourcing) and DEC-001 in `PRD/07_Decision_Assumption_Risk_Register.md` for the current candidate options and decision status.
