# Campaign story prototype v3 — design notes

Working draft, 14 September 2026. Product owner: Mo. Companion to Retail_Media_Campaign_Story_Prototype_v3.html.

## What the research said

**The problem with dashboards.** Practitioner guidance on data storytelling converges on one diagnosis: a dashboard shows every metric with equal weight and leaves the reader to find the point. A story answers four questions in order — what happened, compared to what, why, and so what — and leads with the answer. Executives get one headline and a recommendation; analysts get the breakdown. (Basedash, "Data storytelling: a practical framework", 2026; Nussbaumer Knaflic, *Storytelling with Data*: write the headlines first and make each one a section title.)

**Progressive disclosure.** A well-structured report reads at three depths — headline only, main text, full detail — and the reader chooses how far to go. (Data Viz with Python, ch. 9, 2026.)

**What advertisers want from retail media reporting.** Mars United's 2026 report cards note that brands are moving past impressions, clicks and ROAS to business outcomes — incrementality, household penetration, basket growth, market share — and reward networks whose reporting is transparent and actionable. Trade coverage agrees that ROAS is a surface metric and that attribution and incrementality answer different questions; several vendors now structure closed-loop reporting explicitly as delivery → attributed → incremental, each labelled. (Mars United, Retail Media Report Card Canada, June 2026; Front Row, 2025; Footprints AI, 2026.)

**What the leading networks do.** Amazon's AMC positions itself as an analytics environment for questions, not a report; its most valued outputs are new-to-brand, frequency and overlap analyses, and exposed-versus-unexposed comparisons. Tesco Media / dunnhumby Sphere sells in-flight sales reporting and sales-lift measurement as the core of the advertiser experience. Walmart Connect publishes third-party-benchmarked lift and iROAS and offers 3/14/30-day windows in on-demand reports. Unlimitail — our first client's partner — now reports e-commerce and omnichannel ROAS separately and a brand-halo ROAS, and the NIQ–Unlimitail collaboration (June 2026) puts NIQ measurement at the centre of their stack.

**The first client's own sample.** The Unlimitail deck is already a narrative pack: campaign context, a methodology page, one chart per page with a headline sentence, learnings and recommendations at the end. That is the format the advertiser is used to. It lacks status language, method disclosure on the page, "compared to what", and any distinction between attributed and caused.

## What the prototype does with it

1. **One question per chapter, one sentence per finding.** The finding is the largest text on the page; the chart beneath it is evidence, not decoration.
2. **"Compared to what" is always explicit** — expected from history at this retailer, the category at this retailer, the partner's own number.
3. **Honesty is a chapter.** "What would not have happened anyway" is in the story from Release 1, dimmed, with the reason and the date it arrives. The reader meets the attributed/caused distinction before they meet a number.
4. **Three depths.** Cover (headline and four figures) → story (scroll) → evidence drawer on every figure (formula, population, period, scope, standard, status and why, checks, version).
5. **Every chart ends in an action** that writes somewhere: the next brief, a learning, a scheduled read, a re-export request.
6. **The release switch** shows the same story at Release 1 (transactions only), 2 (exposure joined) and 3 (control group). Chapters fill in; nothing is rewritten. The status stamp moves from Directional to Certified only at Release 3.
7. **Status and method travel with the page**: the chips under the headline and the method footer are what an advertiser sees when the report is shared.

## Demo data

Fictional retailer Nordmark, advertiser Aurelia Foods, product Amaro Solstice. Scale and shape follow the first-client sample (4.8 M audience in four nested recruitment segments, 12.2 K buyers, €334 K). Release 3 figures assume a partner-held 5% control of matched shoppers; because the product was on shelf network-wide, the control also buys, so lift is expressed as a multiple of the control's rate. All numbers are demo values.

## Open for validation with users

- Does a network account manager read the cover and answer "what did this campaign do and how sure are we?" without an analyst?
- Does an advertiser accept the Directional stamp on a Release 1 story, given the unanswered chapters are visible with dates?
- Is "not proven" (interval crossing zero) understood, or does it need a plainer word?
- Chapter order: should "Who are they?" come before "Where did they buy?" for a recruitment objective?
