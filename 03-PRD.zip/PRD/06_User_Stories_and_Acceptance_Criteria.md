# 06 — User Stories and Acceptance Criteria

**Purpose:** Epics, capabilities, and user stories for the Retail Media Closed-Loop Measurement
capability, each traced back to a Functional Requirement (FR-###, defined in
[02_Retail_Media_Closed_Loop_PRD.md](02_Retail_Media_Closed_Loop_PRD.md) Section 9) and its underlying
evidence (FR-C### in [03_Requirement_Evidence_Register.md](03_Requirement_Evidence_Register.md)).
Acceptance criteria use Given/When/Then and explicitly cover happy path, validation failure, and
data-quality/failure-handling scenarios per the PRD's own quality checklist.

---

## Epic A — Campaign & Measurement Setup (BP-05, BP-06, BP-07)

### US-001 — Configure a campaign for closed-loop measurement
*As an* Unlimitail Measurement/Product Owner, *I want* to define a campaign's Attribution Window,
Attribution Model, and primary Product/Category/Brand scope at setup, *so that* the closed-loop match
job runs against a correctly-configured campaign. *(Traces to FR-005, FR-C009, FR-C010, FR-C006)*

- **AC1 (happy path):** Given a campaign with a defined start/end date and a primary product category,
  When the campaign is activated, Then the system MUST persist the default 14-day Attribution Window
  and "last touch" Attribution Model unless explicitly overridden.
- **AC2 (validation failure):** Given a campaign is submitted with no primary category/brand, When the
  campaign is saved, Then the system MUST reject the save and surface a validation error.
- **AC3 (data quality):** Given a campaign references a product hierarchy node that does not exist in
  the Product Catalogue, When the campaign is saved, Then the system MUST reject the save.

### US-002 — Assign a PROGRAMME id at campaign setup
*As an* Unlimitail Integration Owner, *I want* to write a PROGRAMME id into the activation partner's
`dim_campaign_attr` at campaign setup, *so that* spend, exposure, and attributed outcomes can later be
reconciled to the correct Unlimitail campaign. *(Traces to FR-C032, DEC-004; status: proposed, pending
partner confirmation)*

- **AC1 (happy path — contingent on DEC-004 resolution):** Given the activation partner confirms
  support for `dim_campaign_attr` write-back, When a campaign is created, Then the system MUST write a
  unique PROGRAMME id before the first audience export.
- **AC2 (unresolved dependency):** Given the activation partner has NOT confirmed `dim_campaign_attr`
  write-back support, When a campaign is created, Then the system MUST fall back to a manually
  maintained cross-reference mapping and flag the campaign as "unreconciled — manual mapping in use."

## Epic B — Audience & Control-Group Management (DOC03, DOC05, DOC10)

### US-003 — Export a target audience to the activation platform
*As an* Unlimitail Campaign Manager, *I want* to publish a segment/audience to the activation platform
via file (GCS/SFTP/HTTPS), *so that* the campaign can be activated against the correct shopper set.
*(Traces to FR-C029, DS-11)*

- **AC1 (happy path):** Given a segment has been finalized, When it is published, Then the system MUST
  deliver the file to the configured mechanism and log a `log_status` entry with row count.
- **AC2 (feed-integrity failure):** Given the rows-exported count does not match the rows-returned
  count reported by the partner, When the daily reconciliation job runs, Then the system MUST flag the
  campaign's join-rate metrics as below the 100% feed-integrity floor and suppress dependent KPIs.

### US-004 — Withhold a randomized control group before export (Option A)
*As an* Unlimitail Measurement Owner, *I want* the platform to withhold a randomized control group
before the target audience is sent to the activation platform, *so that* a clean causal incrementality
measurement is possible. *(Traces to DEC-001 Option A; status: one of three undecided options — do
not implement until DEC-001 is resolved)*

- **AC1 (happy path, contingent on Option A selection):** Given a target audience of size N and a
  configured control percentage, When the audience is published, Then the system MUST randomly
  withhold the configured percentage and exclude them from the exported file, retaining their assignment
  for later comparison.
- **AC2 (control-group cap):** Given a shopper has already been assigned to a control group in another
  active campaign, When a new campaign's control group is drawn, Then the system SHOULD respect any
  configured cap on repeat control-group membership (per FR-C054's Personalization precedent).

### US-005 — Reconcile a partner-separated or ghost-bid control group (Options B/C)
*As an* Unlimitail Measurement Owner, *I want* to ingest the activation partner's own control-group
designation (Option B) or ghost-bid/PSA exposure log (Option C), *so that* incrementality can be
measured without an Unlimitail-side reach loss. *(Traces to DEC-001 Options B/C; status: undecided —
do not implement until DEC-001 is resolved)*

- **AC1 (Option C happy path, contingent on partner confirmation):** Given the activation partner
  supports ghost-bid/PSA and returns a per-shopper ghost/served flag, When the daily inbound feed is
  processed, Then the system MUST classify shoppers into Exposed/Control based on the partner-supplied
  flag.
- **AC2 (Option B validity warning):** Given the activation platform separates control post-hoc by
  exposure status alone (no randomization), When results are computed under this method, Then the
  system MUST label the output "non-causal / selection-based" and MUST NOT present it as validated
  incremental lift, per DOC03's explicit policy.

## Epic C — Ingestion & Data Quality (BP-08, BP-09, BP-10)

### US-006 — Ingest and validate the daily T-Log feed
*As a* Data Engineer, *I want* the T-Log ingestion pipeline to validate row counts and key join rates
daily, *so that* downstream KPIs are only computed on trustworthy data. *(Traces to FR-C003, DS-03,
DS-29 gap)*

- **AC1 (happy path):** Given a T-Log file arrives within the expected daily window, When ingestion
  completes, Then the system MUST record completeness/accuracy metrics against the prior period's
  volume baseline.
- **AC2 (missing data):** Given the daily T-Log file does not arrive within SLA, When the ingestion
  monitor runs, Then the system MUST raise an alert and MUST NOT silently proceed with a partial or
  stale dataset.
- **AC3 (blocking gap):** Given no atomic Tlog/transaction table has been confirmed in the physical
  schema (`Data_Model_Design/12` §5), When this story is estimated for delivery, Then it MUST be
  flagged as blocked pending confirmation of the correct source table (RISK-003).

### US-007 — Monitor join/match-rate floors
*As a* Data Engineer, *I want* daily join-rate metrics computed for Product/Shopper/Session/Feed-integrity
keys, *so that* below-floor joins are flagged rather than silently degrading reported KPIs. *(Traces to
FR-C031, DS-30, RISK-005)*

- **AC1 (happy path):** Given all 4 join keys meet their published floors (99%/95%/90%/100%), When the
  daily job completes, Then all dependent KPIs MUST be marked "eligible to report."
- **AC2 (below-floor):** Given the Shopper join rate falls below 95%, When the daily job completes,
  Then all shopper-level KPIs for the affected period MUST be flagged and excluded from the standard
  report until resolved.

## Epic D — Reporting & Reconciliation (BP-11–BP-14)

### US-008 — View a campaign measurement report (KPI cards + trend + drill-down)
*As a* Retailer Media Analyst, *I want* to view Impressions/Clicks/CTR/Attributed Sales/ROAS for a
campaign with a trend chart and drill-down table, *so that* I can assess campaign performance.
*(Traces to FR-C013, FR-C014, FR-C020)*

- **AC1 (happy path):** Given a campaign has completed at least one full reporting period, When the
  Analyst opens the Measurement Report, Then the system MUST display KPI cards, a trend chart, and a
  drill-down table filtered to campaigns/products the Analyst has access to.
- **AC2 (RLS enforcement):** Given a CPG/Advertiser user views the same report, When data loads, Then
  the system MUST restrict visible rows/columns to that Advertiser's own campaigns only (FR-C017).
- **AC3 (dual-clock labeling):** Given both partner-reported and Unlimitail-measured attribution values
  exist for a campaign, When the report renders, Then both values MUST be shown side by side, clearly
  labeled, and never combined into a single blended number (FR-C034).

### US-009 — Distinguish deterministic from modeled exposure results
*As a* Retailer Media Analyst, *I want* walled-garden results (e.g., Meta) clearly labeled as modeled/
aggregate, *so that* I do not mistake them for deterministic, individually measured exposure.
*(Traces to NFR-EV-05)*

- **AC1 (happy path):** Given a campaign includes a walled-garden placement, When its results are
  displayed, Then the UI MUST show a "Modeled — aggregate" label distinct from deterministic onsite/
  offsite results.

### US-010 — Reprocess a corrected campaign after late/corrected transactions
*As a* Data Engineer, *I want* to reprocess a campaign's measurement after a correction to upstream
T-Log data, *so that* reported KPIs reflect the corrected figures. *(Traces to Section 3 gap in
[05_Measurement_Methodology.md](05_Measurement_Methodology.md) — no source-confirmed restatement
policy exists; this story is proposed pending a decision)*

- **AC1 (proposed, pending decision):** Given a correction is received for a previously reported
  period, When the reprocessing job runs, Then the system SHOULD recompute affected KPIs and record an
  audit entry showing the prior and corrected values (no source document confirms this behavior —
  flagged as a design decision required, not a confirmed requirement).

## Epic E — Access Control & Governance (BP-04, DOC02)

### US-011 — Enforce Phase 1 internal-only access
*As an* Unlimitail Program Owner, *I want* Retail Media Measurement reporting restricted to ~100 named
internal users in Phase 1, *so that* no external Advertiser/CPG has premature access. *(Traces to
FR-C027, CON-002)*

- **AC1 (happy path):** Given a user is not on the approved internal Phase 1 access list, When they
  attempt to log in to the Measurement Report, Then access MUST be denied.
- **AC2 (unauthorized escalation):** Given an Advertiser/CPG-tagged account attempts access during
  Phase 1, When authentication is attempted, Then the system MUST deny access and log the attempt for
  governance review.

### US-012 — Progress through governance sign-off gates
*As a* Program Manager, *I want* each of the 6 governance sign-off gates enforced before the next phase
of work begins, *so that* delivery cannot silently proceed without approval. *(Traces to FR-C028)*

- **AC1 (happy path):** Given Gate N has not been signed off, When a delivery team attempts to begin
  Gate N+1 work, Then the system/process MUST block progression and require explicit sign-off first.

---

## Coverage Note

This set of 12 stories covers the highest-priority, most-evidenced flows across setup, audience/
control-group handling, ingestion/data-quality, reporting, and governance. Stories US-004/US-005 are
explicitly **not to be built** until [DEC-001](07_Decision_Assumption_Risk_Register.md) is resolved —
they are included here as designed options, not committed backlog items. Additional stories (e.g.,
full walled-garden ingestion detail, clean-room/segmentation stories from DOC11) are deferred to
post-MVP per Section 8 (Scope) of [02_Retail_Media_Closed_Loop_PRD.md](02_Retail_Media_Closed_Loop_PRD.md).
