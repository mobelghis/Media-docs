# 05 — Measurement Methodology

**Purpose:** Consolidate every methodology fact, formula, and open decision needed to compute
Retail Media Closed-Loop KPIs. Grounded in DOC01 (closed-loop concept design), DOC03 (integration
architecture and control-group options), DOC08 (as-is measurement taxonomy), DOC10/DOC11 (platform
lift-measurement roadmap), and [Data_Model_Design/13_KPI_Calculation_Tiering.md](../Data_Model_Design/13_KPI_Calculation_Tiering.md)
(43-KPI data-sufficiency tiering). **No formula is invented here that is not present in source
material; every gap is marked as a decision required.**

---

## 1. Campaign Objective, Populations, and Scope

| Concept | Definition | Source | Status |
|---|---|---|---|
| Campaign Objective | Not itself defined generically in source (varies by brief: win-back, recruitment, upsell, retention, awareness, consideration, conversion). | BP-15 (DOC08) | Confirmed (taxonomy); no single canonical objective model |
| Eligibility Population | The shopper base meeting basic eligibility (e.g., loyalty tier, opt-in) before any targeting is applied. | DOC05 (Marketing Policy eligibility segment, analogous concept in Personalization) | Confirmed for Personalization; **not explicitly defined for Retail Media Measurement (media) campaigns** — decision required |
| Target Population / Audience | The named audience segment(s) built for a campaign (e.g., `Acheteurs_ProduitsDuMonde_24M_V3_Dedup` in WB2). | WB2 (Report_Analysis_Catalog.md §2.3) | Example only (existing lift-study output), not a confirmed target design |
| Exposable Group / Audience Size (Reachable) | Size of the addressable/targetable audience population for a segment; denominator of Conversion Rate (F1). | Report_KPI_Dimension_Analysis (KPI G2) | Confirmed concept; exact audience-building rule not fully documented |
| Test Population (Exposed) | Shoppers who received media exposure / were part of the "Exposed" group. | WB2 dimension "Group" (Control/Exposed) | Example (existing lift-study structure) |
| Control Population | Shoppers withheld from exposure, used as the counterfactual baseline for incrementality. | DOC03 (3 candidate sourcing methods, see §5 below) | **Sourcing methodology is an open decision** — see Section 11 of the PRD / DEC-001 |
| Exclusion Rules | Not documented anywhere in source for media campaigns. | — | **Gap — decision required** |
| Audience Deduplication | Segment names in WB2 include "_Dedup" suffix, implying deduplication is applied upstream, but the dedup logic itself is not documented. | WB2 | INFERRED from naming convention only |
| Randomization / Matching | Three candidate control-group designs exist (Section 5); no confirmed matching/propensity methodology is documented for any of them. | DOC03; F5 in Data_Model_Design/04 | **UNVERIFIED/BLOCKING** — the single largest methodology gap in the whole corpus |
| Sample-Size Considerations | Not documented in any source. | — | **Gap — decision required** |

## 2. Exposure, Period, and Attribution Definitions

| Concept | Definition | Source | Status |
|---|---|---|---|
| Exposure Definition | An Ad Interaction event: Impression (I), View (V)/Video View (W), Click (C), or Conversion/Purchase (P). | DOC01 | Confirmed (TTD-specific field codes; concept portable) |
| Exposure Timestamp | The impression/view event timestamp, used as the anchor for the Attribution Window. | DOC01 | Confirmed |
| Campaign Period | The Campaign's start/end dates (DOC05: "Wave" start/end — critical, defines the exact window redemptions are measured in). | DOC05 | Confirmed for Personalization; media-campaign equivalent not separately documented |
| Pre-Campaign Period | "Pre Campaign" is a named dimension value in WB2 (baseline window). | WB2 | Example only; exact length/definition not documented |
| Post-Campaign Period | Redemption/exposure data continues to update a Campaign for ~2 months after "Completed" status, per DOC05 (Eran, not fully confirmed exact duration). | DOC05 | Requires validation |
| Attribution Window | Maximum time lag between exposure and purchase to be considered attributable. **Two different windows are documented for two different attribution clocks** — see Dual-Clock Attribution below. | DOC01, DOC03 | Confirmed (two coexisting values) |
| — DOC01's window | Default 14 days / 336 hours from impression/view to purchase, configurable. | DOC01 | Confirmed; **reconfirmed by a separate Aug 13, 2026 sync (DOC16) as "a 14-day post-exposure lookback... confirmed in the referenced correspondence, subject to exact boundary rules"** — DOC16 itself leaves day-zero inclusion, multi-exposure logic, multi-purchase logic, creative overlap, time zone, and returns/cancellations still open (its own §5.1 "Required boundary rules" table); does not resolve CF-005's 14-vs-28-day tension with DOC03 below (AS-026). |
| — DOC03's Unlimitail-measured window | 28 days, measured on the campaign's product set, against a randomized holdout, with confidence interval and power state. | DOC03 | Confirmed |
| — Partner's own window (per DOC03) | Understood to be ~14–30 days depending on campaign type, using the partner's own touch-logic model. | DOC03 | Requires validation (Unlimitail's own understanding of the partner, not a partner-confirmed fact) |
| Attribution Model | MVP = "last touch" (most recent qualifying impression/view gets 100% credit). Even-split and first-touch are explicitly deferred (post-MVP). | DOC01 | Confirmed (MVP scope) |
| Conversion Definition | A T-Log purchase matched to a prior ad interaction within the Attribution Window, for the ad's primary product/category/brand. | DOC01 | Confirmed (concept) |
| Product / Category Scope | MVP measures a single **primary** category/brand per ad, even though the underlying Ad Products mapping supports many-to-many. | DOC01 | Confirmed (MVP simplification) |

### Dual-Clock Attribution (per DOC03)

Two independently reported, **never-blended** attribution measures:
1. **Retailer's/partner's own attribution** — their window (~14–30 days), their touch model, reported
   to the brand, stored as-is and never recomputed by Unlimitail.
2. **Unlimitail's measurement attribution** — 28-day window, measured on the campaign's product set,
   against a randomized holdout, with confidence interval and power state.

**Business rule (confirmed, DOC03):** these two numbers are always shown side by side, clearly
labeled, and never combined into a single blended figure.

## 3. Incrementality / Statistical Methodology

| Concept | Status | Detail |
|---|---|---|
| Incrementality (concept) | Confirmed as a target capability, explicitly **out of scope for DOC01's MVP** ("Incremental ROAS vs. control will not be part of the MVP"). | DOC01 |
| Statistical Significance / Confidence Intervals | DOC03 states the Unlimitail-measured attribution number includes "a confidence interval and power state" — the exact statistical test is not documented anywhere. | DOC03; F7 in Data_Model_Design/04 — **UNVERIFIED/BLOCKING** |
| Addressable (Intent-to-Treat) Lift vs. Served Lift (new, 2026-09-13) | A Sep 8, 2026 control-group deep-dive (DOC18) introduces formal vocabulary for the upfront-holdout candidate specifically: **addressable/intent-to-treat lift** = total incremental value ÷ all matched treatment shoppers (including never-served ones); **served lift** = addressable lift ÷ delivery rate, i.e. rescaled to only actually-exposed shoppers; **delivery rate** = exposed shoppers ÷ matched treatment shoppers. Both are legitimate, differently-scoped readings of the same total incremental value — DOC18 explicitly flags that "a carefully reviewed methodology note and naming convention" is still needed before client presentation. | DOC18 — **Candidate methodology, not yet client-approved or NIQ-committed; see DEC-001 addendum in [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md) and OQ-C049** |
| Worked Numerical Example (illustrative only, DOC18) | 1,000-shopper audience, 90/10 test/control split (900/100), 50% channel match rate (450 matched treatment / 50 matched control), control fully suppressed from delivery (0 control exposed; 300 of 450 matched treatment actually exposed = 66.7% delivery rate); illustrative spend $9,000 observed treatment / $800 control; control mean $16/shopper; treatment counterfactual $7,200 (=$16×450); **total incremental value $1,800** (=$9,000−$7,200); **addressable lift/shopper $4** (=$1,800/450); **served lift/shopper $6** (=$4/66.7%). | DOC18 | **Illustrative only — DOC18 explicitly states this "should not be treated as a production specification."** Included here for methodology-literacy purposes only; do not hardcode these figures anywhere. |
| Outlier Handling | A per-SKU price-validation QA step exists in the sample lift-study data (Appendix SKU Validation: min/max unit price) but its exact exclusion rule is not documented. | WB2; G6 in Report_KPI_Dimension_Analysis | INFERRED |
| Returns / Cancellations | Not documented anywhere in source. | — | **Gap — decision required** |
| Late-Arriving Transactions | Personalization redemption data is known to continue arriving ~2 months post-Campaign-Completion (DOC05); no equivalent statement exists for media-attributed sales. | DOC05 | Requires validation (media-campaign equivalent) |
| Cross-Channel Exposure / Multiple Campaigns / Overlapping Audiences | Not addressed in any source document for media campaigns; the Personalization module does cap a shopper's membership in control groups ("no more than 2, configurable," per DOC10/FR-C054) but this is a different mechanism (coupon allocation, not media). | DOC10 | Gap for media; partial for Personalization |
| Repeated Exposure | "Frequency (media)" = Impressions ÷ Reach is defined (F3 in Data_Model_Design/04), but no rule for how repeated exposure affects attribution credit beyond the "last touch" model is documented. | DOC01; Data_Model_Design/04 F3 | Confirmed (Frequency formula); Gap (repeat-exposure attribution policy) |
| Household vs. Individual Measurement | Not addressed in any source; all measurement discussed is at the individual shopper/loyalty-ID level. | — | Not applicable per source (individual-level only observed) |
| KPI Recalculation / Restatement Rules | Not documented for Retail Media Measurement. Personalization's Campaign continues updating for ~2 months post-completion (DOC05) is the closest analogue. | DOC05 | Gap — decision required |

## 4. Walled-Garden Exposure Tiers (confirmed, DOC03)

| Tier | Exposure data available | Measurement method | Deterministic or Modeled |
|---|---|---|---|
| Onsite | Customer-level exposure | Full measurement incl. randomized holdout | Deterministic |
| Offsite open web | Exposure where identity resolves | Measurable with published match rate | Deterministic (subject to match rate) |
| Walled gardens (e.g., Meta) | No exposed-user data available | Partner lift / aggregate methods only | **Modeled — must be explicitly labeled, never presented as deterministic** |
| In-store | No individual exposure | Store-level matched-market comparison | Modeled (aggregate) |

**Business rule (confirmed, DOC03):** Unlimitail will not report a walled-garden "exposed vs.
non-exposed" comparison as causal lift — delivery is not random there, so it measures audience-selection
bias, not campaign effect.

## 5. Control-Group Sourcing — Three Candidate Methodologies (confirmed as candidates, DOC03; decision not yet made)

| Option | Mechanism | Causal Validity | Reach Impact |
|---|---|---|---|
| **A — Chosen at export** | Randomized when the segment is published; held only on Unlimitail's side | Clean causal claim | Loses reach (the held-back group is never exposed) |
| **B — Built after the fact** | Unexposed shoppers become the control group post-hoc | **Not statistically valid** — measures audience-selection bias, not effect | No reach lost |
| **C — Ghost-bid / PSA** | Partner's ad server withholds/serves a placebo to a random subset of the reachable audience | Keeps causal validity | Keeps reach — but requires partner-side ad-server capability (Unlimitail's preferred ask, per OQ-C022) |

This is elevated to a dedicated decision brief in the main PRD (Section 11) and in
[07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md) as **DEC-001**,
per explicit user instruction not to select a preferred approach without source support. Option C is
described as Unlimitail's own stated preference, but is not confirmed as decided or as technically
feasible with the (unnamed) activation partner.

### 5.1 Addendum (2026-09-13) — 3 new discovery-meeting transcripts

Three later, more detailed transcripts (DOC16, Aug 13 2026; DOC18, Sep 8 2026; DOC19, Sep 9 2026)
deepen, but do not resolve, the above candidates:

- **Option-lettering is inconsistent across documents** (see CF-011): DOC16 letters its own 3
  candidates A = upfront holdout, B = post-exposure control, C = channel without shopper exposure
  (a data-availability constraint, not a construction method) — this does **not** map cleanly onto
  DOC03's A/B/C above (DOC03's Option C, ghost-bid/PSA, is not reintroduced by name in DOC16/DOC18/
  DOC19). Do not assume ghost-bid/PSA has been dropped as a candidate; see OQ-C047.
- **DOC16 records a client preference for post-exposure control** ("Option B" in its own lettering,
  conceptually equivalent to DOC03's Option B above) where exposure-level data exists, "so small
  segments are not reduced upfront" — explicitly flagged in DOC16 itself as "not automatically valid"
  and requiring data-science review before adoption. This is additional evidence, not a resolution.
- **DOC18 (Sep 8, 2026) provides a full worked numerical example and new vocabulary (addressable/
  served lift, delivery rate) for the upfront-holdout option specifically** — see Section 3 above.
  DOC18 explicitly states its own "Option B" was **not reviewed in this meeting** and requires a
  follow-up session (OQ-C048); its detail therefore applies only to upfront holdout, not to
  post-exposure control.
- **DOC19 reconfirms audience-scale figures** relevant to any control-group design: ~14M total
  shopper base, up to 10-12M for a large campaign audience, 5-6M typical large-brand audience, ~300K
  minimum-audience prerequisite, 10-20% typical a-priori holdout, 30-60% DSP match/drop range.
- **Lookalike/control-store matching is explicitly out of scope** (DOC17, AS-029) — not a 4th
  candidate for this decision.

**This addendum does not change the decision status.** DEC-001 remains **Open**; see the full
addendum in [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md).

## 5.2 "Indexes" — Category-Benchmark Reporting (new, unconfirmed, 2026-09-13)

A Sep 9, 2026 discovery meeting (DOC19) introduces "Indexes" — brand/advertiser share compared against
a category benchmark — as a reporting capability. This is assumed (AS-027) to be the same underlying
capability as the sample reports' undocumented `Indice CA`/`Indice UVC`/`Ecart vs Benchmark` KPIs
(`Data_Model_Design/04_KPI_Lineage_and_Formulas.md` §C3/C4, both UNVERIFIED).

| Concept | Definition | Source | Status |
|---|---|---|---|
| Index (illustrative formula) | `Index = (Brand share / Category share) × 100` — a base-100 reading of over/under-representation. | DOC19 | **Candidate, not finalized** — DOC19 itself states "the meeting did not finalize a formal formula specification." |
| Point-difference alternative | `Point difference = Brand share − Category share` — proposed as an easier-to-interpret companion for less statistically sophisticated users. | DOC19 | Candidate, not finalized |
| Benchmark definition | The "relevant category" for the selected brand/advertiser (not the total retailer) — exact category-scoping rule not specified. | DOC19 | Gap — decision required |
| Requirements register | RPT-01–14 (reporting), MEA-01–04 (measurement), UX-01–02, NFR-01–02 — full register in DOC19 §10. | DOC19 | Proposed/open — see DEC-005 in [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md) |

**Do not treat this section as resolving §C3/C4's UNVERIFIED status.** DOC19 itself flags all of its
own content as "proposed" or "open," requiring product/data validation before commitment (its own
Appendix B). See DEC-005 and OQ-C050.

## 5.3 Five-Layer Measurement Model (new, unconfirmed, 2026-09-13, DOC20)

An Aug 5, 2026 discovery discussion (DOC20 — chronologically the earliest of the newly reviewed
transcripts) describes measurement/reporting as five conceptual layers. These are presented as
descriptive framing from that discussion, not as a confirmed architecture superseding this document's
existing §1–§6 structure; each layer maps to concepts already tracked elsewhere in this PRD.

| Layer (DOC20 §7.1) | Description | Relationship to existing PRD structure |
|---|---|---|
| Delivery funnel | Impressions → clicks/engagement → exposed reach, at campaign/channel grain. | Existing exposure/reach KPIs (§6 Tier 1/2 catalog). |
| Conversion-attribution | Deterministic T-Log purchase matched to a prior ad interaction, within the confirmed Attribution Window. | Existing §2 Conversion Definition / Dual-Clock Attribution — no change. |
| Incrementality | Exposed-vs-control comparison producing a lift estimate. | Existing §5 Control-Group Sourcing / §3 Incrementality Methodology — still UNVERIFIED/BLOCKING (DEC-001). |
| Post-campaign behavior | Repeat-purchase/persistence observed over a 4-week or 6-week post-campaign window (DOC20 does not define these windows precisely). | **New, unconfirmed concept — see window-distinction note below.** |
| Cross-channel program | Aggregated view across a multi-channel advertiser initiative (depends on a `campaign_group` parent entity that does not currently exist). | Ties to DEC-006 and the proposed `dim_campaign_group` entity in `Data_Model_Design/03_Canonical_Data_Model.md` §5 — PROPOSED/NOT AVAILABLE. |

**MEA-09 reinforcement (DOC20):** deterministic conversion-attribution reporting (layer 2 above) is
explicitly described as valuable and deliverable independently of incrementality (layer 3) being
resolved — this is consistent with, and does not change, this PRD's existing Walled-Garden Exposure
Tiers framing (§4) and Tier 1/2 KPI catalog (§6), which already treat conversion-level KPIs as
computable ahead of any lift methodology decision.

**Window-distinction note (AS-033, OQ-C060):** the 4-week/6-week "post-campaign" windows mentioned in
DOC20 are a **separate, unconfirmed concept** from this document's existing confirmed 14-day
Attribution Window (§2). They are not interchangeable, and no source document states a formula or
exact definition for either window — do not substitute one for the other in any KPI implementation
pending client confirmation.

## 6. KPI Catalog — Data-Sufficiency Tiering (all 43 KPIs)

The full per-KPI formula, required base fields, and confirmation status for all 43 KPIs identified
across the sample reports (31 in `Data_Model_Design/04_KPI_Lineage_and_Formulas.md`, A1–F9; plus 11
more, G1–G11, in `Report_KPI_Dimension_Analysis.xlsx`'s KPI Catalog / "KPI Tiering" sheet) are
maintained in [Data_Model_Design/13_KPI_Calculation_Tiering.md](../Data_Model_Design/13_KPI_Calculation_Tiering.md).
Summary:

| Tier | Count | Description | Blocking dependency |
|---|---|---|---|
| **Tier 1** | 25 | Computable from Tlog (transaction line) + reference-master dimensions only (store, product/brand, shopper, calendar). No campaign/exposure data required. | **No atomic Tlog table has been supplied in any of the 3 real physical schemas reviewed** (`Data_Model_Design/12_Client_Feed_Onboarding_Mapping.md` §5, Blocking). |
| **Tier 2** | 13 | Requires Tlog **and/or** exposure/campaign-audience data (impression log, audience roster, campaign cost); direct arithmetic, no statistical modeling. | Same Tlog gap for the Tlog-dependent members; the exposure/impression-log interface is **also not confirmed as physically supplied** (`Data_Model_Design/11_Standard_Model_Gap_Analysis.md` §5, CF-008 evidence). |
| **Tier 3** | 3 (F5 Incremental Lift, F6 ROAS, F7 P-Values) | Requires us to design and implement a control-group/matching methodology and a significance-test approach — cannot be resolved by any amount of additional document review. | **UNVERIFIED/BLOCKING** — this is the same methodology gap as Section 5 above (control-group sourcing) and DOC03's unconfirmed statistical test type. |

**Do not implement any Tier 3 formula (F5/F6/F7) without an explicit client-confirmed methodology.**
Per source instruction (DOC01/DOC03's own text): "Do NOT invent this formula."

## 7. KPI Definition Table (all confirmed/documented KPIs, condensed — full detail in Data_Model_Design/04 and 13)

| KPI | Business Definition | Formula | Grain | Status | Owner (TBD) |
|---|---|---|---|---|---|
| Impressions | Count of ad-load events | `SUM(impression)` | Campaign/Channel/Period | Confirmed | TBD |
| Clicks | Raw ad-click count | `SUM(click_count)` | Campaign/Channel/Period | Confirmed | TBD |
| CTR | Share of impressions resulting in a click | `Clicks / Impressions` | Campaign/Channel/Period | Confirmed | TBD |
| Conversion Rate | Share of exposable/reachable audience that purchased | `Shoppers / Exposable Group` | Audience/Period | Confirmed | TBD |
| CPM | Cost per 1,000 impressions | `Advertising Cost / (Impressions/1000)` | Campaign/Channel | Confirmed | TBD |
| CPC | Cost per click | `Advertising Cost / Clicks` | Campaign/Channel | Confirmed | TBD |
| Attributed Sales | T-Log revenue matched to a prior ad interaction within the Attribution Window | `SUM(matched purchase revenue)` | Campaign/Ad/Period | Confirmed (concept); extrapolation method TBD | TBD |
| ROAS | Return on ad spend | `Attributed Sales / Advertising Cost` | Campaign/Audience | Confirmed (concept); cost basis is an open decision (OQ-C007) | TBD |
| Reach / Reach Rate | Unique individuals reached; share of reachable population reached | `Analysed Reach / Reachable` | Audience/Channel/Period | Confirmed (formula INFERRED, not independently recomputed) | TBD |
| Frequency (media) | Average exposures per reached individual | `Impressions / Reach` | Audience/Channel/Period | INFERRED | TBD |
| Incremental Revenue/Quantity/Shoppers/Buyer Rate (Lift) | Exposed-group KPI minus a control-adjusted counterfactual | `Exposed_X − Adjusted_Control_X` | Audience/Product list/Period | **UNVERIFIED/BLOCKING** — methodology not documented | TBD |
| ROAS (incremental) | Incremental revenue per unit of ad spend | `Incremental Revenue / Campaign Cost` | Campaign/Audience | **UNVERIFIED/BLOCKING** (inherits Incremental Revenue's gap) | TBD |
| P-Values | Statistical significance of observed lift | Not documented (test type unconfirmed) | Audience/Product list/KPI | **UNVERIFIED/BLOCKING** | TBD |

*(This table is illustrative of the highest-priority MVP + Tier-3 KPIs; the complete 43-KPI catalog
with full formula/status/lineage detail is authoritative in `Data_Model_Design/04` and `13`.)*

## 8. Recap

- **Entities/KPIs affected:** All 43 KPIs; the closed-loop attribution/ROAS chain (DOC01); the
  control-group/incrementality chain (DOC03, F5–F7); the Ecart vs Benchmark/Indice CA/UVC KPIs and
  new "Indexes" candidate capability (§5.2, DEC-005, added 2026-09-13).
- **Design decisions & rationale:** Methodology sections are structured to separate "confirmed
  concept, unconfirmed exact math" (e.g., Reach Rate, CTR) from "genuinely undesigned" (control-group
  sourcing, significance testing) — only the latter blocks MVP delivery of incrementality features;
  the former can proceed with a documented assumption pending client sign-off. 3 new discovery-meeting
  transcripts (DOC16, DOC18, DOC19, 2026-09-13) add substantial candidate detail — worked numerical
  example, addressable/served-lift vocabulary, Indexes formula — without resolving DEC-001 or DEC-005;
  a terminology-only conflict (CF-011) in control-group option lettering was also surfaced.
- **Data quality/privacy considerations:** Consented-only ingestion (DOC01) applies to every exposure
  KPI in this document; walled-garden modeled results must never be blended with deterministic ones.
  DOC17 reiterates pseudonymous-ID handling (masked IDs, client-side remapping) consistent with
  existing constraints — no new privacy requirement, but reconfirmed.
- **Confidence level:** High for concept-level definitions (directly stated in DOC01/DOC03/DOC08);
  Low for exact statistical methodology (F5–F7) — explicitly marked BLOCKING throughout, consistent
  with the source documents' own unresolved-open-question framing (OQ-C006, DOC03's control-group
  questions, DOC10/DOC11's unbuilt lift-measurement framework). The new DOC16/DOC18/DOC19 content is
  Medium confidence as candidate methodology — internally consistent and richly detailed, but
  explicitly not yet client-approved or NIQ-committed.
