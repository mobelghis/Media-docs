# 10 — Report Consolidation Plan

**Purpose:** Consolidate the 84 report/slide instances found across the 7 sample report artifacts
(WB1–WB5, deck6, deck7 — see [Report_KPI_Dimension_Analysis_Summary.md](../Report_KPI_Dimension_Analysis_Summary.md)
and the workbook's **Report Comparison Summary** sheet, 15 comparison groups) into the **fewest
possible production reports** that still satisfy every KPI/dimension need identified. This document
does not invent new KPIs or business logic — every report below is a regrouping of existing,
already-catalogued report instances and their already-documented KPI/dimension sets.

**Companion artifact:** [10_Report_Consolidation_Prototype.html](10_Report_Consolidation_Prototype.html)
— an interactive HTML mockup showing what each of the 6 reports looks like and which delivery phase
(per [02_Retail_Media_Closed_Loop_PRD.md](02_Retail_Media_Closed_Loop_PRD.md) Section 24) it belongs to.

---

## 1. Guiding Principle

Per Comparison Group CG08's own finding, the two business families identified in the source reports —
**Retail Performance** (WB1, WB3, WB4, WB5) and **Campaign/Media Measurement** (WB2, deck6, deck7) —
answer different business questions with different KPI sets and **should not be merged into one
report**, even though some of their segmentation taxonomies overlap. Within each family, however, the
comparison groups show heavy structural duplication that consolidates cleanly. Result: **6 reports**
replace all 84 instances.

## 2. Suite A — Retail Performance Reports

### Report 1 — Customer Loyalty & Segmentation

| Field | Detail |
|---|---|
| Consolidates | WB1 `Bilan`+`Profil` (CG02), Top-N Ranking (CG06), retail half of the segmentation glossary (CG08) |
| Core KPIs | Gained/Lost/Constant customers, value segments, Lifestage/Structurelle/Consostyle/Promotion segments, Top-N products/brands (CA, UVC, Indice, Evolution) |
| Parameters | Benchmark scope (product vs. enseigne); ranking level (EAN vs. Brand) |
| Delivery phase | **Phase 1** (Standard Product Activation — parity report) |
| Dependencies | None blocking; uses standard onboarded reference data |

### Report 2 — Product/Trade Performance

| Field | Detail |
|---|---|
| Consolidates | WB3, 5 measurement-basis pairs (CG01) |
| Core KPIs | Ecart vs Benchmark, Indice CA, Indice UVC, VMH, evolution trends |
| Parameters | Measurement basis toggle (CA vs. UVC); product/store/period scope |
| Delivery phase | **Phase 1** (Standard Product Activation — parity report) |
| Dependencies | **Blocking:** OQ02 — exact formulas/reference population for Ecart vs Benchmark, Indice CA/UVC, and VMH are undocumented; do not hard-code until resolved with the client |

### Report 3 — Product & Temporal Extraction

| Field | Detail |
|---|---|
| Consolidates | WB4 + WB5 (CG05) |
| Core KPIs | Configurable KPI list (category snapshot or daily trend) |
| Parameters | KPI list, product scope, time grain |
| Delivery phase | **Phase 1** (Standard Product Activation — parity report) |
| Dependencies | None blocking |

## 3. Suite B — Campaign / Retail Media Measurement Reports

### Report 4 — Campaign Measurement Overview

| Field | Detail |
|---|---|
| Consolidates | Business Equation twins (CG07: WB2 R040 + deck7 R060), Conversion Overview/Funnel (CG14) |
| Core KPIs | Revenue = Shoppers × Frequency × Avg Basket; Exposable group; Conversion rate; Impressions/Clicks/CTR/Attributed Sales/ROAS (non-incremental) |
| Parameters | Total vs. segment-level toggle |
| Delivery phase | **Phase 2** (Full Non-Modeled KPI Reporting) |
| Dependencies | Requires activation/DSP partner identity confirmation (ASM-001) and Core Dataset access-tier resolution (OQ-C020) per [04_Data_Requirements_and_Model.md](04_Data_Requirements_and_Model.md) |

### Report 5 — Audience & Business Equation Analysis

| Field | Detail |
|---|---|
| Consolidates | Business Equation by-X (CG03), Sales Uplift (CG09), Buying Behaviour (CG12), Performance by Channel (CG11) |
| Core KPIs (non-modeled) | F1/A1–A9 business-equation set, exposed/non-exposed share — **Phase 2** |
| Core KPIs (modeled) | Incremental Revenue/Quantity/Shoppers/Buyer Rate (F5), ROAS-incremental (F6), P-Values (F7) — **Phase 3, BLOCKED** |
| Parameters | Cut dimension (Control/Audience/Channel/SKU); optional Audience breakdown; snapshot/trend toggle |
| Delivery phase | **Split: Phase 2 (non-modeled sections) / Phase 3 (modeled sections)** |
| Dependencies | Modeled KPIs are gated by **OQ01** (lift methodology undocumented) and **DEC-001** (control-group architecture) — same guardrail as FR-008 in [02_Retail_Media_Closed_Loop_PRD.md](02_Retail_Media_Closed_Loop_PRD.md). Do not surface F5/F6/F7 in this report until both are resolved. |

### Report 6 — Shopper Loyalty & Acquisition

| Field | Detail |
|---|---|
| Consolidates | Loyalty Profiles (CG04), Sales Overview + New Shoppers Acquisition (CG10), campaign half of the segmentation glossary (CG08) |
| Core KPIs | New/Returning Shopper measure, trade KPIs, reach-vs-buyers, basket-size histogram, new-buyer count |
| Parameters | Cut dimension (Audience/Channel/Total/Unit bucket/Quantity bucket) |
| Delivery phase | **Phase 2** (Full Non-Modeled KPI Reporting) |
| Dependencies | None blocking beyond standard exposure-data ingestion (Report 4's dependencies apply) |

## 4. Explicitly Not Turned Into a 7th Report

- **deck6 (CG13, Presales/Executive slides):** treated as a curated export/snapshot *view* of Reports
  1–2, not new KPI logic — no new report needed.
- **CG15 (R044 vs. R023 data-quality conflict):** left out of Report 5 until the anomaly is
  investigated and resolved with the source system owner — do not wire either sheet in until then.

## 5. Phase Mapping Summary

| Phase | Reports (or report sections) delivered |
|---|---|
| **Phase 1 — Standard Product Activation** | Report 1 (Customer Loyalty & Segmentation), Report 2 (Product/Trade Performance — pending OQ02), Report 3 (Product & Temporal Extraction) |
| **Phase 2 — Full Non-Modeled KPI Reporting + Begin Measurement Modeling** | Report 4 (Campaign Measurement Overview), Report 5 non-modeled sections (Business Equation, Buying Behaviour, Channel Performance), Report 6 (Shopper Loyalty & Acquisition) |
| **Phase 3 — Complete and Ship the Measurement Model** *(inferred phase, see PRD Section 24)* | Report 5 modeled sections (Incremental Revenue/Quantity/Shoppers/Buyer Rate, ROAS-incremental, P-Values) — gated on DEC-001 and OQ01 |

## 6. Net Result

84 report/slide instances → **6 production reports**, each parametrized rather than duplicated, fully
traceable back to their source comparison groups (CG01–CG14) and gated appropriately against the same
open decisions and blocking gaps already tracked in
[07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md).
