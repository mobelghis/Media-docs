# 03 — Requirement Evidence Register

**Purpose:** A single traceable register of every requirement candidate extracted from source
material, classified by category and status. This register is the evidentiary backbone for the PRD
(02), the Data Requirements (04), Measurement Methodology (05), User Stories (06), and Traceability
Matrix (08). It reuses the FR-C### candidate IDs already established in
[Knowledge_Base/Requirements Inventory.md](../Knowledge_Base/Requirements%20Inventory.md) rather than
re-numbering them, and adds NFR/SEC/UX-category entries synthesized from the same source base.

**Status legend:** Confirmed | Inferred | Proposed | Requires validation | Conflicting | Deferred

---

## Business & Functional Requirement Candidates

| Req ID | Statement | Category | Source | Source Location | Status | Confidence | Notes/Interpretation |
|---|---|---|---|---|---|---|---|
| FR-C001 | Ingest daily Customer Mapping file (Loyalty ID ↔ Retail Media ID) with historization. | Data | DOC01 | Data model section | Confirmed (concept); Deferred (Unlimitail-specific field format) | Medium | TTD-specific field names not directly portable (AS-001, AS-004) |
| FR-C002 | Ingest daily Ad Interactions data (impression/view/click/conversion), consented users only. | Data / Privacy | DOC01 | Data model section | Confirmed (concept) | Medium | Hard privacy constraint: unconsented data must never be ingested |
| FR-C003 | Ingest daily T-Log transaction data via NIQ's existing T-Log interface. | Data | DOC01 | Data model section | Confirmed | High | Reuses existing Insights Premium onboarding pipeline (AS-020, confirmed) |
| FR-C004 | Ingest daily Targeting file (who was targeted, when). | Data | DOC01 | Data model section | Confirmed (concept) | Medium | |
| FR-C005 | Ingest daily Campaign/Ad Group/Ad metadata files (current-state only). | Data | DOC01 | Data model section | Confirmed (concept) | Medium | No change-history tracking in MVP |
| FR-C006 | Ingest Ad Products file (Ad → Product/Brand/Category), MVP = 1 primary category/brand per ad. | Data | DOC01 | Data model section | Confirmed (concept) | Medium | |
| FR-C007 | Ingest daily Campaign Engagement file (aggregated cost/impressions/views/clicks). | Data | DOC01 | Data model section | Requires validation | Medium | Overlaps conceptually with interaction-level detail (OQ-C003) |
| FR-C008 | Ingest Advertisers Mapping file (Advertiser↔CPG↔Brand) for RLS. | Data / Security | DOC01 | Data model section | Confirmed (concept) | Medium | |
| FR-C009 | Match ad interactions to T-Log purchases within a configurable Attribution Window (default 14 days). | Measurement | DOC01 | Attribution section | Confirmed (concept) | Medium | Field format TTD-specific; window/logic concept portable |
| FR-C010 | Apply a "last touch" Attribution Model for MVP (even-split/first-touch deferred). | Measurement | DOC01 | Attribution section | Confirmed (MVP choice) | Medium | |
| FR-C011 | Calculate ROAS = Attributed Sales ÷ Advertising Cost (default cost basis = advertiser cost). | Measurement | DOC01 | KPI section | Confirmed (concept); Conflicting (cost basis, OQ-C007) | Medium | |
| FR-C012 | Extrapolate matched-customer-universe results to total customer base. | Measurement | DOC01 | Measurement section | Proposed | Low | Methodology and bias-control approach explicitly undefined (OQ-C006, Blocking) |
| FR-C013 | Deliver Measurement Report via self-serve SaaS UI (KPI cards + trend chart + drill-down table). | Reporting / UX | DOC01 | Reporting section | Confirmed (concept); UI/UX itself TBD | Medium | Mockup explicitly marked TBD in source |
| FR-C014 | Support report filters: Campaign hierarchy, Engagement, Product hierarchy, single-period selection. | Reporting | DOC01 | Reporting section | Confirmed (concept) | Medium | No period-compare in MVP |
| FR-C015 | Support report breakdown grains: Daily/Weekly/Monthly/Quarterly (Hourly deferred). | Reporting | DOC01 | Reporting section | Confirmed | Medium | |
| FR-C016 | Support report dimensions: Campaign hierarchy, Engagement, Creative, Product hierarchy, Geo. | Reporting | DOC01 | Reporting section | Confirmed (concept) | Medium | Engagement/Creative not mandatory MVP |
| FR-C017 | Enforce Row-Level Security (Retailer = all; Advertiser/CPG = own only). | Security | DOC01 | RLS section | Confirmed | High | Competitor visibility explicitly out of scope |
| FR-C018 | Support permission tiering (filters/dimensions/KPIs by user type, monetization-driven). | Security / Reporting | DOC01 | RLS section | Confirmed (concept) | Medium | |
| FR-C019 | Refresh reports daily (real-time/near-real-time deferred to Phase 2). | Non-functional | DOC01 | Reporting section | Confirmed | High | |
| FR-C020 | Provide MVP KPI set (Impressions, Views, Clicks, Conversions, CTR, Conv. Rate, Cost, Attributed Sales, ROAS, Reach, CPM, CPC). | Measurement / Reporting | DOC01 | KPI section | Confirmed (list); formulas partially confirmed | Medium | Full KPI definitions doc referenced but not accessible |
| FR-C021 | Provision 3 country-specific Activate portal instances (FR/ES/BR), 1 shared Business Config Doc. | Operational | DOC02 | Roadmap/architecture slide | Confirmed | High | Conflicts with DOC12/DOC13's single-portal claim (CF-010, low reliability) |
| FR-C022 | Support a single combined data-injection/onboarding project spanning all 3 countries. | Operational | DOC02 | Onboarding slide | Confirmed | High | |
| FR-C023 | Ingest NIQ-provided reference/taxonomy data (FMCG syndicated characteristics, category hierarchies) into the data lake, then Activate. | Data | DOC02 | Onboarding slide | Confirmed | High | |
| FR-C024 | Support 24-month historical load, 2 free load cycles, daily incremental uploads, weekly refreshes. | Data / Operational | DOC02 | Onboarding slide | Confirmed | High | |
| FR-C025 | Support Phase 1 baseline scale of ~15M shoppers / ~10B transactions. | Non-functional (scale) | DOC02 | Volumetrics slide | Confirmed | High | |
| FR-C026 | Provide Event Analyzer and Assortment Distribution reports (Insights Premium). | Reporting | DOC02 | Roadmap slide | Confirmed | High | Out of scope for Retail Media Measurement itself, but shares onboarded data (AS-020) |
| FR-C027 | Restrict Phase 1 access to ~100 internal Unlimitail users only (no external Advertiser/CPG access). | Security | DOC02 | Access scope slide | Confirmed | High | Directly affects when the Advertiser/CPG persona becomes active |
| FR-C028 | Implement a 6-gate sign-off governance workflow blocking progression without approval. | Operational | DOC02 | Governance slide | Confirmed | High | |
| FR-C029 | Send 4 outbound feeds to activation/DSP partner as files (GCS preferred; SFTP/HTTPS supported). | Integration | DOC03 | Handshakes H1–H3 | Confirmed | High | |
| FR-C030 | Ingest 8 inbound data objects from partner via BigQuery Core Dataset share (retailer tier). | Integration | DOC03 | Handshakes H5–H7 | Confirmed | High | Must use Core Dataset, not Reporting Datamart (loses history) |
| FR-C031 | Publish daily join/match-rate metrics for 4 keys with defined floors; flag rather than report below-floor numbers. | Data Quality | DOC03 | Join-rate slide | Confirmed | High | |
| FR-C032 | Write Unlimitail's PROGRAMME id into partner's `dim_campaign_attr` at campaign setup. | Integration | DOC03 | Handshake H4 | Proposed | Medium | Not yet confirmed adopted by partner (OQ-C023) |
| FR-C033 | Support per-campaign ghost-bid/PSA control mechanism. | Measurement / Integration | DOC03 | Control-group Option C | Proposed | Medium | Requires partner-side capability (OQ-C022); Unlimitail's preferred ask |
| FR-C034 | Report attribution/lift dual-labeled and never blended (partner's own vs. Unlimitail's measured). | Measurement / Reporting | DOC03 | Dual-clock attribution slide | Confirmed (policy) | High | |
| FR-C035 | Ingest country-specific FMCG syndicated reference-data flat file. | Data | DOC04 | Handover deck | Confirmed | Medium | Not yet on the delivery workplan per DOC04 |
| FR-C036 | Perform full gap analysis against incumbent system (LiveRamp + legacy Memory) before onboarding. | Operational | DOC04 | Handover deck | Confirmed | Medium | System-replacement project |
| FR-C037 | Assign a named Product Owner from Activate for the engagement. | Operational / Governance | DOC04 | Open questions slide | Deferred | Medium | Unassigned at time of document |
| FR-C038 | Support custom period/look-back window setup and custom segment indexing. | Functional | DOC04 | Product-CR list | Proposed | Low | Requested, not committed |
| FR-C039 | Provide self-serve UI for bulk coupon import. | Functional (Personalization) | DOC05 | Product gaps | Proposed | Low | Known gap, not committed |
| FR-C040 | Provide diagnostic/what-if tooling for allocation-failure root cause. | Functional (Personalization) | DOC05 | Product gaps | Proposed | Low | Known gap, not committed |
| FR-C041 | Provide reliable pre-allocation redemption estimate. | Functional (Personalization) | DOC05 | Product gaps | Proposed | Low | Directly affects supplier billing trust |
| FR-C042 | Document tacit Personalization business-process knowledge before departure of key SME. | Operational | DOC05 | KT session | Confirmed (risk) | High | Knowledge-continuity risk, not a product requirement |
| FR-C043 | Maintain consistent Universal Shopper ID across countries/banners. | Data / Identity | DOC06 | Config workshop | Confirmed (goal) | Medium | Reinforces OQ-C025 |
| FR-C044 | Support configurable homepage presentation (filters/KPI dropdown/segment split). | UX | DOC06 | Config workshop | Confirmed | Medium | |
| FR-C045 | Require full historical reload when a new transactional attribute is added. | Data / Operational | DOC06 | Config workshop | Confirmed | High | Attribute scope must be finalized at onboarding-spec sign-off |
| FR-C046 | Support role-based permissions distinguishing internal vs. external users, read-only for external. | Security | DOC07 | Ownership Matrix | Proposed | Medium | Discovery-workshop candidate, not yet a committed requirement |
| FR-C047 | Provide a shared Campaign ID as common key across Activate, CDP, and downstream channels. | Data / Integration | DOC07 | E2E process roles | Proposed | Medium | Supports CF-006 (PROGRAMME id) |
| FR-C048 | Provide a unified, cross-platform campaign view/repository. | Functional | DOC08 | As-is pain points | Proposed | Medium | Addresses #1 client-stated pain point |
| FR-C049 | Provide a benchmarking capability compiling historical results by campaign feature. | Reporting | DOC08 | As-is pain points | Proposed | Low | Not yet scoped/prioritized |
| FR-C050 | Record per-shopper, per-wave arm (test/control) assignment, deterministic from a recorded seed. | Measurement / Platform | DOC10 | Jira epic CR-40346 | Proposed | Medium | Generic platform epic, not confirmed Unlimitail-specific |
| FR-C051 | Maintain a "ghost log" of offers control-group shoppers would have received. | Measurement / Platform | DOC10 | Jira epic CR-40346 | Proposed | Medium | Prerequisite for per-offer lift attribution |
| FR-C052 | Capture frozen per-wave eligibility snapshot + frozen parameter set/seed. | Measurement / Platform | DOC10 | Jira epic CR-40346 | Proposed | Medium | Row-per-shopper-per-offer ruled out at 15M scale |
| FR-C053 | Support configurable Net vs. Gross lift calculation conventions per retailer. | Measurement / Platform | DOC10 | Jira epic CR-38880 | Proposed | Low | Still in Draft, targeted PI 2027.3 |
| FR-C054 | Fix control-group selection logic to statistically mirror the test group; cap shopper's control-group membership. | Measurement / Platform | DOC10 | Jira CR-31111/CR-30454 | Proposed | Medium | Directly relevant to DOC05's Marketing Policy Control Group % mechanic |
| FR-C055 | Provide a Sales Impact Review capability (incremental KPIs vs. control, validated Incrementality Test). | Measurement | DOC11 | RFQ use case #2 | Proposed; **Coverage: None at RFQ time** | Medium | Directly relevant to CF-008/CF-009 and to Section 11 of the PRD |
| FR-C056 | Support Brand Lift Measurement for Meta. | Measurement | DOC11 | RFQ use case #7 | Proposed; **Coverage: None** | Low | |
| FR-C057 | Support custom audience creation/export/activation across 8+ external channels. | Integration | DOC11 | RFQ use cases #21–27 | Proposed; rated "Full" coverage at RFQ time | Low | Far broader than DOC02's actual delivered Phase 1 — see CF-009 |
| FR-C058 | Support a Data Access Model Configuration / Analytics Access Environment (clean room). | Security / Integration | DOC11 | RFQ use cases #36, #39 | Proposed | Low | |
| FR-C059 | Provide Custom Shopper Segmentation and Prepackaged Segments. | Functional | DOC11 | RFQ use cases #31, #33 | Proposed | Medium | Ties to AS-020 (shared onboarding data reuse) |
| FR-C060 | Provide Shopper Insights reporting suite. | Reporting | DOC11 | RFQ use cases #4-6,#56,#65 | Proposed | Medium | Out of Retail Media Measurement scope proper |
| FR-C061 | Provide Trade Insights reporting suite. | Reporting | DOC11 | RFQ use cases #3,#53,#54 | Proposed | Medium | Out of Retail Media Measurement scope proper |
| FR-C062 | Export outbound audience file with fields: universal_id/loyalty_id, segment_id, banner_id/banner_name, country/portal, control_flag, export timestamp/batch ID. | Integration / Data | DOC16 | §2, outbound audience file spec | Proposed | Medium | Requirements register SEG-01–04 |
| FR-C063 | Ingest inbound exposure file with fields: loyalty/universal ID, segment ID, ad/creative ID, exposure timestamp, campaign/ad-set metadata key, channel/platform. | Integration / Data | DOC16 | §3, inbound exposure file spec | Proposed | Medium | Requirements register MEA-01–06; requires creative-to-SKU mapping to close the loop |
| FR-C064 | Support 3 control-group construction options: (A) upfront holdout, (B) post-exposure control (client's stated preference, flagged as requiring data-science validation), (C) channel without shopper exposure (aggregate-only). | Measurement | DOC16 | §1, control-group options | Proposed; Conflicting (lettering, CF-011) | Medium | See DEC-001 addendum in [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md) |
| FR-C065 | Confirm 14-day post-exposure attribution lookback, subject to explicit boundary rules (day-zero inclusion, multi-exposure, multi-purchase, creative overlap, time zone, returns/cancellations). | Measurement | DOC16 | §5.1, required boundary rules table | Proposed; boundary rules still open | Medium | AS-026; does not resolve CF-005's 14-vs-28-day tension with DOC03 |
| FR-C066 | Governance: NIQ must not receive directly identifying IDs; pseudonymous/masked IDs with client-side remapping required. | Privacy / Governance | DOC16, DOC17 | GOV-01 (both docs) | Confirmed (policy) | High | Consistent with existing CON-001 |
| FR-C067 | Sequence product delivery across 4 workstreams: segmentation (Eran/Neta), retail-media measurement (Mohammad), loyalty/lookback config (PI4), indexes (in discovery, not committed). | Program / Operational | DOC17 | §1, workstream ownership | Confirmed (planning artifact) | Medium | Introduces new personas Mohammad, Neta (Knowledge_Base/Personas.md updated 2026-09-13) |
| FR-C068 | Roll out sample data as one country + 3 months, then full history for 3 country portals after validation. | Data / Operational | DOC17 | §2, rollout plan | Proposed | Medium | As of DOC17 (Sep 1, 2026), sample data delivery was still delayed (AS-028, OQ-C051) |
| FR-C069 | Treat lookalike/control-store matching as a separate, unfunded/unapproved data-science initiative, explicitly not part of current control-group scope. | Measurement | DOC17 | §3, scope clarification | Confirmed (negative constraint) | High | AS-029; rules out a 4th DEC-001 option |
| FR-C070 | Support randomized-holdout experimental design with addressable/intent-to-treat lift, served lift, and delivery-rate metrics for the upfront-holdout control-group option. | Measurement | DOC18 | §2-3, EXP-01–03, MET-01–03 | Proposed | Medium | See DEC-001 addendum and Section 3/5.1 of [05_Measurement_Methodology.md](05_Measurement_Methodology.md); worked example is illustrative only |
| FR-C071 | Define confidence intervals and minimum-detectable-effect/power guardrails for incrementality measurement. | Measurement | DOC18 | §5.1, open DS action | Proposed; unassigned owner | Low | OQ-C052 |
| FR-C072 | Report incrementality via a defined hierarchy: business summary, delivery funnel, methodology panel, diagnostic view, per-shopper view. | Reporting | DOC18 | §6, report hierarchy proposal | Proposed | Medium | Relevant to Report 5 (Audience & Business Equation Analysis) in `PRD/10_Report_Consolidation_Plan.md` |
| FR-C073 | Account for cost implications of control-group/measurement design (e.g., DSP push costs for suppressed control). | Cost / Operational | DOC18 | COST-01 | Proposed | Low | |
| FR-C074 | Provide "Indexes" reporting: brand/advertiser share vs. category-benchmark comparison, illustrative formula `(Brand share / Category share) × 100`, with a point-difference alternative for less statistically sophisticated users. | Reporting / Measurement | DOC19 | §2, RPT-01–14, MEA-01–04 | Proposed; formula explicitly not finalized | Medium | AS-027; see DEC-005 and §5.2 of [05_Measurement_Methodology.md](05_Measurement_Methodology.md); may resolve Data_Model_Design §C3/C4 UNVERIFIED status pending validation |
| FR-C075 | Define population-label taxonomy: built/pushed/matched/reached-exposed/non-exposed/measured audience. | Data / Reporting | DOC19 | §4, audience taxonomy | Proposed | Medium | Relevant to the entity model in `PRD/04_Data_Requirements_and_Model.md` |
| FR-C076 | Reconfirm control-group audience-scale figures: ~14M total shopper base, up to 10-12M large-campaign audience, 5-6M typical large-brand audience, ~300K minimum-audience prerequisite, 30-60% DSP match/drop loss. | Measurement | DOC19 | §7.3 | Confirmed (reconfirms DOC16 figures) | Medium | Relevant to DEC-001 and to when an Index can be reliably computed |
| FR-C077 | Support UX/accessibility requirements for Indexes reporting (UX-01–02) and non-functional requirements (NFR-01–02). | Reporting / Non-functional | DOC19 | §10 | Proposed | Low | DOC19 Appendix B flags all its own content as "proposed"/"open," requiring validation before commitment |
| FR-C078 | Standardize the currently manual planning workflow (opportunity discovery, reporting-package generation, budget/channel/expected-outcome recommendation) into a defined product capability (PLN-01–07). | Functional / Planning | DOC20 | §4, planning workflow tables | Proposed | Low | See DEC-006 in [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md); DOC20 itself states the underlying budgeting/forecast methodology remains unknown and requires explicit discovery |
| FR-C079 | Support 5 audience-export delivery slices (A–E) and 8 segmentation/export requirements (AUD-09–16), including preserving segment-ID lineage from export through campaign exposure return. | Data / Integration | DOC20 | §6, segmentation/audience export section | Proposed | Medium | Distinct numbering from DOC16's SEG-01–04 export-field spec (FR-C062); potential overlap must be reconciled if both are pursued (RISK-013) |
| FR-C080 | Support a `campaign_group`/`advertiser_initiative` parent entity rolling up multiple channel-specific campaigns into one cross-channel program view, and 6 measurement/reporting requirements (MEA-09–14) covering the 5-layer measurement model. | Data / Measurement | DOC20 | §7, §8, campaign/exposure ingestion + measurement/reporting sections | Proposed | Low | AS-031; entity added as PROPOSED/NOT AVAILABLE in `Data_Model_Design/03_Canonical_Data_Model.md` §5; see DEC-006, §5.3 of [05_Measurement_Methodology.md](05_Measurement_Methodology.md) |

---

## Additional Cross-Cutting Requirement Candidates (synthesized, not individually FR-C-numbered in the Knowledge Base)

| Req ID | Statement | Category | Source | Status | Confidence | Notes |
|---|---|---|---|---|---|---|
| NFR-EV-01 | ETL/architecture must be designed for extensibility to DSPs beyond the MVP partner. | Non-functional | Requirements Inventory (cross-cutting notes) | Confirmed (design principle) | Medium | No specific target metric given — see NFR register (Section 16) |
| NFR-EV-02 | Data ingestion completeness/accuracy must be automatically validated (data-quality acceptance criterion). | Non-functional / Data Quality | Requirements Inventory (cross-cutting notes) | Confirmed (principle) | Medium | |
| NFR-EV-03 | Only consented interaction data may ever be ingested/processed. | Privacy | DOC01 (hard constraint) | Confirmed | High | Non-configurable |
| NFR-EV-04 | SLA: 24/5 availability, 99.9% uptime, 4 severity levels, monthly DB backup, DRP RTO 1–2 business days. | Non-functional | DOC04 | Confirmed | High | Applies to the Activate platform generally, not confirmed Retail-Media-Measurement-specific |
| NFR-EV-05 | Walled-garden exposure results must be labeled modeled/aggregate, never deterministic. | Measurement / Reporting | DOC03 | Confirmed (policy) | High | |

---

## Quality Notes on This Register

- Every row above traces to a DOC## and, where possible, a specific slide/section — see
  [Knowledge_Base/Requirements Inventory.md](../Knowledge_Base/Requirements%20Inventory.md) for the
  original per-row source-location detail (the Knowledge Base tracks candidate statements; this
  register adds Category/Status/Confidence classification per the PRD's Phase 2 instructions).
- **No formulas or business rules have been invented.** Every KPI-related row (FR-C009–FR-C011,
  FR-C020, FR-C050–FR-C056) is either transcribed from source or explicitly marked with its
  confirmation status; unconfirmed formulas are cross-referenced to
  [05_Measurement_Methodology.md](05_Measurement_Methodology.md) where they remain marked TBD/decision-required.
- **Status "Conflicting"** is reserved for requirements with a directly contradicting counterpart
  elsewhere in the corpus; the master conflict list (CF-001–CF-011) lives in
  [Knowledge_Base/Open Questions.md](../Knowledge_Base/Open%20Questions.md) and is carried into
  [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md).
