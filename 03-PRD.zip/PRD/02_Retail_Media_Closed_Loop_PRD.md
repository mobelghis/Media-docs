# 02 — Retail Media Closed-Loop Measurement: Product Requirements Document

## Document Control

| Field | Value |
|---|---|
| Product | Unlimitail Retail Media Closed-Loop Measurement |
| Prepared for | Unlimitail (Carrefour + Publicis Groupe JV) / NIQ Activate delivery team |
| Status | **Draft — grounded in existing analysis, contains open decisions and gaps by design** |
| Evidence base | 15 client documents (DOC01–DOC15), 7 sample report artifacts (WB1–WB5, 2 decks), real physical schema (`Source files/*.sql`), `Knowledge_Base/*`, `Data_Model_Design/*` |
| Companion documents | [01_Source_Inventory.md](01_Source_Inventory.md) · [03_Requirement_Evidence_Register.md](03_Requirement_Evidence_Register.md) · [04_Data_Requirements_and_Model.md](04_Data_Requirements_and_Model.md) · [05_Measurement_Methodology.md](05_Measurement_Methodology.md) · [06_User_Stories_and_Acceptance_Criteria.md](06_User_Stories_and_Acceptance_Criteria.md) · [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md) · [08_Traceability_Matrix.md](08_Traceability_Matrix.md) · [09_Executive_Review_Summary.md](09_Executive_Review_Summary.md) |
| Revision log | v1.0 — initial synthesis from Knowledge Base + Data Model Design artifacts |

---

## 1. Executive Summary

Unlimitail (the Carrefour/Publicis Groupe retail media joint venture) is contracting NIQ Activate to
deliver Retail Media Closed-Loop Measurement: the capability to tie retail-media ad exposure to actual
retailer sales (T-Log) and report ROAS, attribution, and — eventually — statistically valid
incrementality. This capability sits on top of an already-scoped Insights Premium onboarding
(3-country portal, ~15M shoppers, ~10B transactions, DOC02) and a documented but partially unresolved
integration architecture with an activation/DSP partner (8 handshakes, DOC03). The single largest
open item is whether this capability is contractually part of Phase 1 or Phase 2 (**CF-008/DEC-002**);
the single largest design item is how the control group for incrementality is created
(**DEC-001**, three documented options, no preferred option selected per instruction). A physical-schema
review found **no atomic transaction/Tlog table** in the three real schemas inspected — a blocking gap
for roughly 60% of the identified 43-KPI catalog. See [09_Executive_Review_Summary.md](09_Executive_Review_Summary.md)
for the condensed leadership view.

## 2. Background and Problem Statement

Per the as-is process description (DOC08, BP-15), Unlimitail's current retail-media measurement is
fragmented across per-partner reports with no unified cross-platform view, no benchmarking capability,
and (per DOC03) walled-garden channels that structurally cannot provide individual-level exposure data.
Legacy tooling (LiveRamp identity resolution, "Memory" 360 reporting, per DOC04) is being replaced.
The problem this PRD addresses: give Unlimitail (and eventually its Advertiser/CPG customers) a single,
governed, closed-loop measurement capability spanning campaign setup through reconciled reporting,
built on real onboarded retailer data.

## 3. Product Vision

A single Retail Media Measurement capability, built on the same onboarded shopper/product/store data
that already powers Insights Premium (AS-020, confirmed), that (a) closes the loop between ad exposure
and retailer sales for onsite/offsite channels, (b) transparently and separately reports partner-
measured vs. Unlimitail-measured attribution without blending them (DOC03), and (c) can extend to
statistically valid incrementality once a control-group architecture is confirmed (DEC-001). Walled-
garden and modeled results are always clearly distinguished from deterministic ones.

## 4. Objectives (OBJ-###)

| ID | Objective | Evidence | Success looks like |
|---|---|---|---|
| OBJ-001 | Enable ad-exposure-to-sales attribution for onsite/offsite channels within a defined attribution window. | DOC01 | Attributed Sales, ROAS, CTR, Conv. Rate computed and reported per campaign |
| OBJ-002 | Provide a governed, RLS-enforced, self-serve reporting UI for internal (Phase 1) and eventually external (Advertiser/CPG) users. | DOC01, DOC02 | Report accessible with correct row/column-level restriction |
| OBJ-003 | Establish a reliable integration with the activation/DSP partner covering audience export, exposure ingestion, spend ingestion, and reconciliation. | DOC03 | 8 handshakes operating within published join-rate floors |
| OBJ-004 | Resolve and implement a statistically valid incrementality methodology. | DOC03, DOC10, DOC11 | DEC-001 resolved; F5/F6/F7 KPIs computable |
| OBJ-005 | Ensure every KPI is computed only from confirmed, quality-checked source data — no invented formulas. | Cross-cutting | Every KPI in [05_Measurement_Methodology.md](05_Measurement_Methodology.md) is either "Confirmed" or explicitly flagged BLOCKING |

## 5. Users, Personas, and Stakeholders

Full persona detail is in [Knowledge_Base/Personas.md](../Knowledge_Base/Personas.md). Summary:

| Persona | Role | Phase 1 Access | Primary Needs |
|---|---|---|---|
| Retailer Media Analyst (Unlimitail internal) | Consumes campaign measurement reports | Yes (one of ~100 internal users, DOC02) | Self-serve KPI cards/trend/drill-down, RLS-correct view |
| Unlimitail Measurement/Product Owner | Owns methodology decisions, campaign setup config | Yes | Control-group design, attribution config, KPI accuracy |
| Unlimitail Integration/Data Engineering | Builds/operates ingestion pipelines, monitors join-rate floors | Yes | Reliable feeds, clear DQ signal, reconciliation keys |
| NIQ Activate Delivery/Product Owner | Delivers the platform capability | Yes (once assigned — FR-C037 unassigned at time of DOC04) | Clear, confirmed requirements; unblock BLOCKING gaps |
| Advertiser / CPG (external) | Future consumer of self-serve reports, restricted to own data | **No — out of scope for Phase 1** (CON-002) | RLS-correct, read-only access (future) |
| Activation/DSP Partner (external) | Provides exposure/spend data, executes control-group mechanics | N/A (data partner, not a system user) | Clear handshake spec, PROGRAMME id adoption (DEC-004) |

## 6. End-to-End Closed-Loop Workflow

1. **Onboarding** — Store/Shopper/Product/Segment reference data loaded (24-month history, 2 free
   load cycles, daily incrementals) — DOC02, `Data_Model_Design/12`.
2. **Campaign setup** — Campaign/Ad Group/Ad metadata defined; Attribution Window/Model configured;
   primary product/category/brand set (US-001).
3. **Audience build & control-group decision point** — target audience built; **DEC-001** determines
   whether/how a control group is withheld or separated (US-003, US-004, US-005).
4. **Activation** — Audience/segment published to the activation partner via file (H1–H3); campaign
   executes.
5. **Exposure & spend ingestion** — Daily inbound feeds from the partner (H5–H7, BigQuery Core
   Dataset: `fact_realised_ad_agg_2`, `fact_realised_ad`, `fact_ad_request`, `fact_enhanced_attribution`,
   `fact_ledger`/`fta_campaign_spend`, `dim_campaign_attr`, `dim_product`/`dim_category`, `log_status`).
6. **Join-rate / data-quality check** — Product/Shopper/Session/Feed-integrity floors evaluated daily
   (US-007); below-floor numbers flagged, not reported.
7. **Closed-loop match** — Ad interaction matched to T-Log purchase within the Attribution Window,
   "last touch" model (US-006, pending resolution of the Tlog-table gap, RISK-003).
8. **KPI computation** — Tier 1/2 KPIs computed directly; Tier 3 KPIs (incrementality) blocked pending
   DEC-001 and statistical-methodology confirmation.
9. **Reporting & reconciliation** — Dual-clock attribution displayed side by side (US-008); PROGRAMME
   id (if adopted, DEC-004) used to reconcile spend/exposure/outcome back to the Unlimitail campaign.
10. **Governance** — Each of the above steps progresses only through the 6-gate sign-off workflow
    (US-012, DOC02).

## 7. Scope

### 7.1 In Scope — MVP (per DOC01's own explicit MVP framing + confirmed Phase 1 facts)
- File-based ingestion of the 9 DOC01 datasets (adapted to Unlimitail's actual DSP once confirmed).
- Closed-loop match: ad interaction → T-Log purchase, 14-day default window, last-touch model.
- MVP KPI set: Impressions, Clicks, CTR, Conversions, Conv. Rate, Cost, Attributed Sales, ROAS
  (non-incremental), Reach, CPM, CPC (Tier 1/Tier 2 per `Data_Model_Design/13`).
- Self-serve reporting UI with RLS (Retailer=all, Advertiser/CPG=own only), daily refresh.
- Governance sign-off gates (6 gates, DOC02).
- Restricted to ~100 internal Unlimitail users (CON-002).

### 7.2 Explicitly Out of Scope for MVP (source-confirmed exclusions)
- Incremental ROAS / statistically validated lift (DOC01: "will not be part of the MVP").
- Even-split and first-touch attribution models (deferred).
- Hourly report grain and period-over-period comparison (deferred).
- Real-time/near-real-time refresh (Phase 2 per DOC01).
- External Advertiser/CPG access (CON-002).
- Campaign metadata change-history (current-state only in MVP).

### 7.3 Ambiguous / Decision-Pending Scope
- Whether Retail Media Measurement itself is Phase 1 or Phase 2 of the contract at all (**DEC-002/CF-008**).
- The 60 broader RFQ use cases in DOC11 (clean room, 8+ activation channels, segmentation) — status
  unconfirmed as current commitments (ASM-006).
- Single-portal vs. 3-country-portal architecture (CF-010, low-reliability evidence only).
- **"Indexes" (brand/advertiser vs. category-benchmark reporting), newly surfaced by a Sep 9, 2026
  discovery meeting (DOC19), is not yet a formally scoped Phase 1/Phase 2 deliverable** — see
  **DEC-005** in [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md).
  It is assumed (AS-027) to be the same underlying capability as the sample reports' undocumented
  `Indice CA`/`Indice UVC`/`Ecart vs Benchmark` KPIs, but this linkage is unconfirmed.
- **"Planning" (pre-campaign opportunity discovery, standardized reporting-package generation),
  newly surfaced by an Aug 5, 2026 discovery discussion (DOC20), is not yet a formally scoped
  product capability** — see **DEC-006** in
  [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md). The same
  discussion also surfaces a `campaign_group`/`advertiser_initiative` parent-entity gap (no current
  data model rolls up a multi-channel advertiser initiative's separate channel campaigns) and a
  Brazil shopper-identity duplication risk (3 banners sharing 1 portal) — both logged as PROPOSED
  entities/attributes in `Data_Model_Design/03_Canonical_Data_Model.md` §5, not committed scope
  (AS-031, AS-032).

## 8. Assumptions and Constraints

See [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md) Sections B–C
for the full ASM-###/CON-### register. Headline items: ASM-001 (DSP identity unconfirmed), ASM-004
(Insights Premium data reuse — **confirmed** by client), CON-001 (consent-only ingestion, hard
constraint), CON-005 (no atomic Tlog table found).

## 9. Functional Requirements (FR-###)

Each FR-### below is a formalized, RFC-2119-worded statement derived from one or more FR-C### evidence
rows in [03_Requirement_Evidence_Register.md](03_Requirement_Evidence_Register.md). Status values:
Confirmed = directly source-stated; Inferred = logically implied by confirmed facts; Proposed = this
analysis's recommendation, not yet source/client-confirmed.

| ID | Statement | Priority | Evidence | Status |
|---|---|---|---|---|
| FR-001 | The system MUST ingest daily Customer Mapping data (Loyalty ID ↔ Retail Media ID) with historization (Effective_From/To). | Must (MVP) | FR-C001 | Confirmed (concept) |
| FR-002 | The system MUST ingest only consented Ad Interaction events (impression/view/click/conversion). | Must (MVP) | FR-C002, CON-001 | Confirmed |
| FR-003 | The system MUST ingest daily T-Log transaction data via the existing NIQ T-Log interface. | Must (MVP) | FR-C003 | Confirmed |
| FR-004 | The system MUST ingest daily Campaign/Ad Group/Ad metadata (current-state only for MVP). | Must (MVP) | FR-C005 | Confirmed (concept) |
| FR-005 | The system MUST support configuration of Attribution Window (default 14 days) and Attribution Model (MVP: last touch) per campaign. | Must (MVP) | FR-C009, FR-C010 | Confirmed (concept) |
| FR-006 | The system MUST match ad interactions to T-Log purchases within the configured Attribution Window, scoped to the ad's primary product/category/brand. | Must (MVP) | FR-C009, FR-C006 | Confirmed (concept) |
| FR-007 | The system MUST compute the MVP KPI set (Impressions, Clicks, CTR, Conversions, Conv. Rate, Cost, Attributed Sales, ROAS, Reach, CPM, CPC). | Must (MVP) | FR-C020 | Confirmed (list); formulas Tier-classified in `Data_Model_Design/13` |
| FR-008 | The system MUST NOT compute incremental lift, incremental ROAS, or p-values until a control-group methodology (DEC-001) and statistical test are confirmed. | Must (MVP guardrail) | Section 5 of 05_Measurement_Methodology.md | Confirmed (explicit MVP exclusion, DOC01) |
| FR-009 | The system MUST provide a self-serve reporting UI with KPI cards, a trend chart, and a drill-down table. | Must (MVP) | FR-C013 | Confirmed (concept); exact UI TBD |
| FR-010 | The system MUST support report filters for Campaign hierarchy, Engagement, Product hierarchy, and single-period selection. | Must (MVP) | FR-C014 | Confirmed (concept) |
| FR-011 | The system MUST support Daily/Weekly/Monthly/Quarterly report breakdown grains. | Must (MVP) | FR-C015 | Confirmed |
| FR-012 | The system MUST enforce Row-Level Security: Retailer role sees all data; Advertiser/CPG role sees only its own data. | Must (MVP) | FR-C017 | Confirmed |
| FR-013 | The system MUST refresh reports on a daily cadence for MVP. | Must (MVP) | FR-C019 | Confirmed |
| FR-014 | The system MUST restrict Phase 1 access to the approved list of ~100 internal Unlimitail users. | Must (MVP) | FR-C027, CON-002 | Confirmed |
| FR-015 | The system MUST enforce the 6-gate sign-off governance workflow before each subsequent delivery phase begins. | Must (Program) | FR-C028 | Confirmed |
| FR-016 | The system MUST send the 4 outbound feeds (Product Catalogue, Shopper Dimensions, Segment Membership, Orders&Customers) to the activation partner via the confirmed mechanism (GCS preferred). | Must (MVP) | FR-C029 | Confirmed |
| FR-017 | The system MUST ingest the 8 inbound BigQuery Core Dataset objects from the activation partner. | Must (MVP) | FR-C030 | Confirmed; access tier (Core vs. Reporting Datamart) unresolved — OQ-C020 |
| FR-018 | The system MUST compute and publish daily join/match-rate metrics for the 4 defined keys against their published floors, and MUST flag (not report) below-floor numbers. | Must (MVP) | FR-C031 | Confirmed |
| FR-019 | The system SHOULD write Unlimitail's PROGRAMME id into the activation partner's `dim_campaign_attr` at campaign setup, pending partner confirmation (DEC-004). | Should | FR-C032 | Proposed, pending confirmation |
| FR-020 | The system MUST display partner-measured and Unlimitail-measured attribution values side by side, distinctly labeled, and MUST NOT blend them into one figure. | Must (MVP) | FR-C034 | Confirmed (policy) |
| FR-021 | The system MUST label walled-garden exposure results as "Modeled/aggregate," never as deterministic. | Must (MVP) | NFR-EV-05 | Confirmed (policy) |
| FR-022 | The system MAY support a ghost-bid/PSA control mechanism if the activation partner confirms capability (Option C of DEC-001). | May (conditional) | FR-C033 | Proposed, pending DEC-001 |
| FR-023 | The system MUST maintain a Universal Shopper ID consistent across countries/banners for identity resolution. | Must (Program) | FR-C043 | Confirmed (goal); mechanism TBD (OQ-C025) |
| FR-024 | The system MUST require a full historical reload whenever a new transactional attribute is added; attribute scope MUST be finalized before onboarding-spec sign-off. | Must (Program) | FR-C045 | Confirmed |

*(Full evidence-to-requirement mapping, including lower-priority/Proposed items FR-C037–FR-C061, is in
[03_Requirement_Evidence_Register.md](03_Requirement_Evidence_Register.md) and
[08_Traceability_Matrix.md](08_Traceability_Matrix.md).)*

## 10. Measurement Methodology

Full methodology (attribution window/model, dual-clock attribution, walled-garden tiers, KPI catalog
and tiering, and statistical-methodology gaps) is documented in full in
[05_Measurement_Methodology.md](05_Measurement_Methodology.md). This is incorporated by reference.

## 11. Control-Group Architecture Decision (Decision Brief — no preferred option selected)

This is the single most consequential open design decision in the entire program. Per DOC03, three
candidate architectures exist for sourcing the control group needed for incrementality measurement:

- **Option A — Platform holds back control before export.** Our platform defines and withholds the
  control group before the target audience is sent to the activation platform.
- **Option B — Full audience sent; activation platform separates control.** The complete audience is
  exported; the activation platform creates/identifies control shoppers as part of its own delivery
  process (post-hoc, non-randomized per DOC03 unless the platform can randomize at serving time).
- **Option C (hybrid) — Ghost-bid / PSA.** The activation partner's ad server withholds exposure or
  serves a placebo/PSA to a randomly selected subset of the reachable audience, preserving both reach
  and causal validity — contingent on partner-side technical capability.

The full comparison table (methodological integrity, randomization control, contamination risk, reach
impact, activation-platform dependency, auditability, reporting accuracy, operational complexity, and
scalability) is maintained as **DEC-001** in
[07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md), along with
dependencies, information still needed, recommended decision owners, and impact of delaying.
**Per explicit instruction, this PRD does not recommend a preferred option** — DOC03 states Option C is
Unlimitail's own stated preference, but frames it as requiring partner confirmation, not as a decision
that has been made. FR-008 (Section 9) encodes the guardrail that no incrementality KPI may be built
against any option until DEC-001 is resolved.

**Update (2026-09-13):** 3 new discovery-meeting transcripts (DOC16, DOC18, DOC19) add substantially
richer candidate detail — a formal worked numerical example and addressable/served-lift vocabulary for
the upfront-holdout option (DOC18), and a client preference signal for post-exposure control where
exposure data exists (DOC16) — without resolving which option is adopted. These documents also use a
**different A/B/C lettering scheme than DOC03 above**, and do not reintroduce ghost-bid/PSA by name —
this is tracked as a terminology-only conflict, **CF-011**, not evidence that Option C has been
dropped. See the full DEC-001 addendum in
[07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md) and
[05_Measurement_Methodology.md](05_Measurement_Methodology.md) §5.1.

## 12. Data Requirements

Full dataset catalog (inbound file feeds, BigQuery Core Dataset objects, real physical schema tables,
output datasets), conceptual entity model, identity-resolution approach, data-quality floors, and
reconciliation logic are documented in [04_Data_Requirements_and_Model.md](04_Data_Requirements_and_Model.md).
Headline finding: **no atomic Tlog/transaction table was found in any of the 3 real physical schemas
reviewed** (`Data_Model_Design/12` §5) — this blocks the majority of Tier 1 KPIs until resolved
(RISK-003).

## 13. Integration Requirements (INT-###)

| ID | Integration | Direction | Mechanism | Status |
|---|---|---|---|---|
| INT-001 | Product Catalogue export to activation partner | Outbound | File (GCS/SFTP/HTTPS) | Confirmed (DOC03, Handshake H1) |
| INT-002 | Shopper Dimensions export | Outbound | File | Confirmed (H2) |
| INT-003 | Segment Membership export | Outbound | File | Confirmed (H3) |
| INT-004 | PROGRAMME id write-back | Outbound | `dim_campaign_attr` field write | Proposed, pending partner confirmation (H4, DEC-004) |
| INT-005 | Exposure/Spend/Status ingestion | Inbound | BigQuery Core Dataset share | Confirmed as required objects; access tier unresolved (H5–H7, OQ-C020) |
| INT-006 | Join/match-rate publication | Internal | Daily batch job | Confirmed (business rule, DOC03) |
| INT-007 | T-Log ingestion | Inbound | Existing NIQ T-Log interface | Confirmed (DOC01); underlying atomic table unresolved (RISK-003) |

## 14. UX Requirements

- Self-serve report UI: KPI cards, trend chart, drill-down table (FR-009). Exact wireframe/mockup is
  explicitly marked TBD in DOC01 — **no source-confirmed UI spec exists**; `deck7` (Measurement Report
  example) is the closest style reference but is an **example**, not an approved design (per
  [01_Source_Inventory.md](01_Source_Inventory.md) §B).
- Homepage configurability: filters/KPI dropdown/segment split configurable per DOC06 (FR-C044).
- Permission-tiered UI: filters/dimensions/KPIs shown vary by user type per monetization tier
  (FR-C018) — tiering logic itself not documented, flagged as an open question.
- Dual-clock attribution MUST be visually distinguished (FR-020); walled-garden results MUST carry a
  "Modeled" visual indicator (FR-021).

## 15. Reporting Requirements

- Filters: Campaign hierarchy, Engagement, Product hierarchy, single period (FR-010).
- Grains: Daily/Weekly/Monthly/Quarterly (FR-011).
- Dimensions: Campaign hierarchy, Engagement, Creative, Product hierarchy, Geo (FR-C016).
- RLS enforcement on every report view (FR-012).
- Daily refresh cadence for MVP (FR-013).
- No period-over-period comparison or hourly grain in MVP (Section 7.2).

## 16. Non-Functional Requirements (NFR-###)

| ID | Requirement | Evidence | Status |
|---|---|---|---|
| NFR-001 | The platform MUST support a baseline scale of ~15M shoppers / ~10B transactions (Phase 1 volumetrics). | DOC02 | Confirmed |
| NFR-002 | The platform MUST support 24-month historical load with 2 free load cycles and daily incremental uploads. | DOC02 | Confirmed |
| NFR-003 | The platform MUST meet the confirmed SLA: 24/5 availability, 99.9% uptime, 4 severity levels, monthly DB backup, DRP RTO 1–2 business days. | DOC04 | Confirmed (platform-level; Retail-Media-Measurement-specific SLA not separately confirmed) |
| NFR-004 | The architecture SHOULD be designed for extensibility to activation partners/DSPs beyond the MVP partner. | Requirements Inventory cross-cutting notes | Confirmed (design principle); no specific target metric |
| NFR-005 | Data ingestion completeness and accuracy MUST be automatically validated per load. | Requirements Inventory cross-cutting notes | Confirmed (principle) |
| NFR-006 | Row-per-shopper-per-offer eligibility tracking MUST NOT be used at 15M-shopper scale; aggregate/snapshot designs MUST be used instead. | DOC10 (CON-004) | Confirmed |

## 17. Security, Privacy, and Compliance

- Only consented Ad Interaction data may ever be ingested (CON-001, hard constraint, non-configurable).
- RLS: Retailer=all, Advertiser/CPG=own only; no competitor visibility (FR-012, FR-C017).
- Phase 1 restricted to ~100 named internal users, no external access (CON-002).
- A GDPR/removal-adjacent table (`CV_R_SHPR_REMOVAL`) exists in the real schema but its content/behavior
  is not fully verified (`Data_Model_Design/12`) — **no compliance claim is made here beyond what is
  directly evidenced**.
- **Gap:** no document specifies data retention/deletion policy specific to Retail Media Measurement —
  flagged as an open question (Section 22) rather than assumed.

## 18. User Stories

The full epic/story/acceptance-criteria set (12 stories across 5 epics: Setup, Audience & Control-Group
Management, Ingestion & Data Quality, Reporting & Reconciliation, Access Control & Governance) is in
[06_User_Stories_and_Acceptance_Criteria.md](06_User_Stories_and_Acceptance_Criteria.md).

## 19. QA and Validation Strategy

- **Data quality gates:** daily join/match-rate floor checks (Product 99%, Shopper 95%, Session 90%,
  Feed integrity 100%) must pass before dependent KPIs are marked reportable (FR-018).
- **KPI validation:** every KPI must trace to a Tier classification in
  [Data_Model_Design/13_KPI_Calculation_Tiering.md](../Data_Model_Design/13_KPI_Calculation_Tiering.md);
  Tier 3 (F5/F6/F7) MUST NOT ship without a confirmed methodology (FR-008).
- **RLS validation:** access-control tests MUST verify Advertiser/CPG accounts cannot see other
  Advertisers' data or Retailer-only views (FR-012, US-008 AC2).
- **Reconciliation validation:** feed-integrity checks (rows exported vs. returned) MUST be part of
  every integration test cycle (US-003 AC2).
- **Regression on governance gates:** each of the 6 sign-off gates MUST have an explicit test/checklist
  before the next phase of work is unblocked (US-012).

## 20. Analytics and Observability

- Daily join/match-rate metrics MUST be logged and made queryable for operational monitoring (FR-018).
- `log_status` (load start/end/status) from the activation partner MUST be ingested as the pipeline's
  own trigger/monitoring signal (DS-20).
- **Gap:** no source document defines an audit-log schema for measurement corrections/reprocessing —
  DS-32 (Audit Events) is proposed, not source-confirmed.

## 21. Dependencies

- Confirmation of Unlimitail's actual DSP/activation partner identity (ASM-001) — blocks finalizing
  FR-001–FR-006, FR-016–FR-022.
- Confirmation of Core Dataset (vs. Reporting Datamart) access tier at the activation partner
  (OQ-C020) — blocks FR-017.
- NIQ Activate Product Owner assignment (FR-C037, unassigned at time of DOC04) — blocks program
  governance cadence.
- Resolution of CF-008/DEC-002 (Phase 1 vs. Phase 2 placement) — blocks realistic delivery sequencing
  for this entire PRD.
- Physical confirmation of an atomic Tlog/transaction table (RISK-003) — blocks the majority of
  Tier 1/2 KPIs.

## 22. Risks

Full risk register (RISK-001–RISK-007, with probability/impact/severity/mitigation/owner/status) is in
[07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md) Section D. Top risks:
control-group methodology undecided (RISK-001), Phase placement unresolved (RISK-002), missing atomic
Tlog table (RISK-003).

## 23. Assumptions and Open Decisions Summary

See [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md) Sections A–B for
the full Decision Register (DEC-001–DEC-004) and Assumption Register (ASM-001–ASM-007). Every open
question (OQ-C001–OQ-C046) and conflict (CF-001–CF-010) from the Knowledge Base is grouped by PRD area
in Section E of that document.

## 24. Delivery Recommendation

The client/program has directed a 3-phase delivery structure for this capability. Phase 1 and Phase 2
are stated directly; **Phase 3 is inferred by this analysis** as the natural completion of the
modeling work begun in Phase 2 (statistically valid incrementality) — this inference is flagged below
rather than assumed silently, per this PRD's evidentiary discipline. Each phase is mapped to the
requirements, datasets, and KPI tiers already defined earlier in this document.

### Phase 1 — Standard Product Activation

- **Data onboarding and ingestion:** T-Log and standard Insights-related reference data (Store,
  Shopper, Product/Brand hierarchies — DS-03, DS-21–DS-27), per the confirmed 24-month history /
  2 free load cycles / daily incremental cadence (NFR-002, DOC02). This is the same onboarding
  foundation Insights Premium already uses (ASM-004, confirmed by client).
- **Insights Premium + Segmentation Studio configuration:** stand up the reporting/segmentation
  platform capability itself (FR-C026, DS-24 Custom Segments) ahead of any measurement-specific work.
- **Exposure data analysis and initial ingestion modeling:** analyze the sample exposure data supplied
  by Unlimitail (the WB2 lift-study datasheet and equivalent exposure fields — DS-13/DS-14 in
  [04_Data_Requirements_and_Model.md](04_Data_Requirements_and_Model.md)) and begin data modeling and
  ingestion design for exposure reporting (FR-002, FR-016, FR-017; INT-001–INT-005). This is
  exploratory/foundational — it does not require the activation partner's identity or DEC-001 to be
  resolved to begin, only to complete.
- **Parity reports:** build one or a few reports that recreate the sample reports Unlimitail already
  sent (WB1–WB5, deck6, deck7 — see [01_Source_Inventory.md](01_Source_Inventory.md) §B), as a
  validation checkpoint that onboarded data reproduces known-good output before new KPIs are layered
  on top.
- **Requirements delivered in this phase:** FR-001, FR-003, FR-004, FR-009–FR-015, FR-023, FR-024
  (onboarding/config/reporting-shell requirements); excludes exposure-dependent KPI computation.
- **Not required to start this phase:** resolution of DEC-001 (control-group architecture) or
  DEC-002 (Phase 1/2 contract placement) — Phase 1 work is foundational-platform activation, not
  measurement computation.
- **Still blocking within this phase:** RISK-003 (no atomic Tlog table confirmed in the reviewed
  physical schemas) must be resolved before T-Log ingestion can be finalized, even though the rest of
  Phase 1 can proceed in parallel.

### Phase 2 — Full KPI Reporting for Non-Modeled KPIs + Begin Measurement Modeling

- **Report all Unlimitail KPIs that do not require statistical modeling:** this is Tier 1 (25 KPIs,
  Tlog + reference dimensions only) and Tier 2 (13 KPIs, Tlog + exposure/campaign data — direct
  arithmetic, no modeling) per
  [Data_Model_Design/13_KPI_Calculation_Tiering.md](../Data_Model_Design/13_KPI_Calculation_Tiering.md).
  This includes both Unlimitail's own supplied/calculated measures and exposure-derived measures
  (Impressions, Clicks, CTR, Conv. Rate, Attributed Sales, ROAS non-incremental, Reach, Frequency,
  CPM, CPC — FR-007).
- **Requirements delivered in this phase:** FR-005–FR-008, FR-018–FR-021 (matching logic, KPI
  computation guardrails, join-rate monitoring, dual-clock/walled-garden labeling).
- **Begin modeling of the measurement (incrementality):** start the design/validation work for the
  Tier 3 KPIs (F5 Incremental Revenue/Quantity/Shoppers/Buyer Rate, F6 ROAS-incremental, F7 P-Values) —
  this means engaging DEC-001 (control-group architecture options A/B/C) with the activation partner
  and drafting the statistical test approach. **This phase does not ship incremental/modeled KPIs to
  users** — it produces the design and, ideally, a validated prototype, gated by FR-008's explicit
  guardrail that no incrementality KPI may be exposed without a confirmed methodology.
- **Dependencies carried into this phase:** confirmed activation/DSP partner identity (ASM-001);
  Core Dataset access-tier confirmation (OQ-C020); CF-008/DEC-002 phase-placement resolution ideally
  closed by this point given its program-wide sequencing impact.

### Phase 3 — Complete and Ship the Measurement Model *(inferred continuation, not explicitly stated by the user — confirm before treating as committed)*

- **Resolve DEC-001** (control-group architecture: platform-withhold, partner-separated, or
  ghost-bid/PSA) with the activation partner, closing the single largest open methodology decision in
  the program.
- **Implement and validate Tier 3 KPIs** (F5, F6, F7) using the confirmed methodology from Phase 2's
  modeling work; remove FR-008's guardrail once validation passes QA (Section 19).
- **Extend reporting** to show incremental/modeled results alongside the Phase 2 KPI set, maintaining
  the dual-clock (FR-020) and walled-garden modeled-vs-deterministic labeling (FR-021) throughout.
- **Optionally extend access** to external Advertiser/CPG users (lifting CON-002) once the full KPI
  set — including incrementality — has been internally validated, though this was not explicitly
  scoped into Phase 3 by the user and should be confirmed as in/out of scope before planning.

**Recommendation:** confirm with the client whether Phase 3 should be defined exactly as inferred above,
or whether it should be split further (e.g., a separate "external access" phase 4) — this PRD does not
treat the Phase 3 definition above as client-confirmed.

## 25. Definition of Ready

A requirement/story is Ready when: (a) it traces to a DOC##/FR-C### evidence row or is explicitly
labeled Proposed; (b) its data dependencies are listed in
[04_Data_Requirements_and_Model.md](04_Data_Requirements_and_Model.md) and are not marked Blocking; (c)
its acceptance criteria are written in Given/When/Then form; (d) any open decision it depends on
(DEC-###) is either resolved or the story is explicitly scoped as "build-when-resolved."

## 26. Definition of Done

A requirement/story is Done when: (a) all acceptance criteria pass; (b) RLS/security tests pass where
applicable; (c) join/match-rate monitoring is in place for any new data dependency; (d) the
corresponding row in [08_Traceability_Matrix.md](08_Traceability_Matrix.md) is updated to "Implemented";
(e) no KPI is exposed to users without a Confirmed or client-signed-off formula.

## 27. Traceability Matrix

See [08_Traceability_Matrix.md](08_Traceability_Matrix.md) for the full
Objective → Requirement → User Story → Acceptance Criteria → Dataset → Integration → KPI → Source
matrix.

## 28. Quality Check Summary

- All requirement IDs (FR-###, NFR-###, INT-###, US-###, DEC-###, RISK-###, ASM-###, CON-###, OBJ-###,
  DS-###) are unique within and across files 02–08.
- All MVP-tagged functional requirements (FR-001–FR-021) have at least one linked user story and
  acceptance criteria in [06_User_Stories_and_Acceptance_Criteria.md](06_User_Stories_and_Acceptance_Criteria.md).
- Every requirement is linked to evidence (FR-C### / DOC##) or explicitly labeled Proposed/Inferred.
- KPI formulas are documented (Confirmed) or explicitly marked BLOCKING — none are invented
  (see [05_Measurement_Methodology.md](05_Measurement_Methodology.md) Section 7).
- The control-group architecture decision (Section 11) is presented as an open brief, not a
  recommendation, per explicit instruction.
- Cross-document conflicts (CF-001–CF-010) are preserved side-by-side, not silently resolved — see
  [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md) Section E.
- Remaining completeness gaps (no confirmed UI mockup, no confirmed audit-log schema, no confirmed
  data-retention policy) are explicitly logged rather than filled with assumptions — see Sections 14,
  17, and 20 above.
