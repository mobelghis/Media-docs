# 01 — Source Inventory

**Purpose:** Complete inventory of every material in this workspace relevant to the Retail Media
Closed-Loop Measurement PRD. This document does not extract requirements — it classifies each source
by type, apparent purpose, and reliability, per the PRD's own Phase 1 instructions. All requirement
extraction is deferred to [03_Requirement_Evidence_Register.md](03_Requirement_Evidence_Register.md).

**Method:** No new file parsing was performed for this inventory. It consolidates the file-by-file
analysis already completed and recorded in `Knowledge_Base/*.md` (15 client documents, DOC01–DOC15),
`Report_Analysis_Catalog.md` (7 sample report files, WB1–WB5 + 2 decks), `Report_KPI_Dimension_Analysis_Summary.md`
/ `Report_KPI_Dimension_Analysis.xlsx` (report-first KPI/dimension re-analysis), and `Data_Model_Design/`
(canonical data model built from real physical DDL). Where this PRD package references a fact, it cites
the originating DOC##/WB#/file so it can be re-verified against the primary source.

---

## A. Client Business/Requirements Documents (DOC01–DOC15)

| Doc ID | File | Type | Apparent Purpose | Reliability | Key Sections Used | Conflicts/Gaps |
|---|---|---|---|---|---|---|
| DOC01 | Retail Media Measurement – closed loop concept design (no incrementality).docx | Word | TTD-based concept design for closed-loop measurement (MVP, no incrementality) | **Template/example** — TTD-specific, explicitly flagged as needing adaptation to Unlimitail's actual DSP partner (AS-001–AS-005) | Data model, attribution logic, KPI list, RLS model | Multiple TTD-specific facts assumption-flagged; own "Open Issues" section is itself a gap register (OQ-C001–OQ-C010) |
| DOC02 | Unlimitail - Kick-off Meeting.pptx | PowerPoint | Phase 1 (Carrefour) kickoff: scope, workstreams, timeline, governance | **Confirmed/authoritative** for Phase 1 Insights Premium scope | Roadmap slide, sign-off gates, volumetrics, Order Form | Places Retail Media Measurement under "Phase 2 and beyond (TBD)" — conflicts with DOC04 (CF-002, CF-008) |
| DOC03 | 7_Integration_Deck_Unlimitail.pptx | PowerPoint | Integration architecture workshop: data flows, handshakes, control-group options | **Confirmed/authoritative** for integration architecture and control-group option analysis | 8 handshakes, control-group A/B/C, walled-garden tiers, dual-clock attribution, open questions | Directly informs Section 11 (Control-Group Architecture Decision) of the PRD — this is the single richest source for that section |
| DOC04 | Unlimitail - Sales to Delivery handover.pptx | PowerPoint | Internal NIQ handover deck: contract, company background, org, SLA | **Confirmed/authoritative** for contract/commercial facts | Contract phase table, TCV, SLA, legacy systems (LiveRamp/Memory) | Contract table places Retail Media Measurement under "Phase 1" — conflicts with DOC02/DOC06/DOC07/DOC09 (CF-008, unresolved) |
| DOC05 | Eran_Mo KT - Session 1.docx | Word | Personalization module knowledge-transfer session | **Confirmed for generic product mechanics**; Unlimitail-specific linkage is inferred (AS-015) | Coupon Bank/Marketing Policy/Campaign/Offer/Allocation model, known product gaps | Not Unlimitail-specific by name; 3 product gaps flagged (FR-C039–FR-C041) |
| DOC06 | Unlimitail Business Stream.pptx | PowerPoint | Business/configuration workshop: hierarchies, segments, homepage config | **Confirmed/authoritative** for Insights reporting model | Generic Hierarchy vs. Attributes, Product/Store Hierarchy, Shopper Segments | Slide 13 labels its own integration/measurement diagram "phase 2 scope" — reopens CF-008 |
| DOC07 | Unlimitail & NIQ Discovery Workshop July 2026 (3).pptx | PowerPoint | Discovery workshop deck: process, ownership matrix, solution assumptions | **Confirmed/authoritative, most granular Phase 1 vs Phase 2 breakdown to date** | Ownership Matrix, E2E process roles, Measurement Maturity Model, Solution Assumptions slide | Most direct evidence that closed-loop measurement itself is Phase 2 (non-walled-garden only) — see CF-008 |
| DOC08 | Unlimitail July 2027 workshop - discovery summary.docx | Word | Client's own as-is operating-model narrative | **Confirmed as-is description** (secondary/derived summary, not raw transcript — AS-018) | 7-stage as-is process, Measurement Type Taxonomy, pain points | Corroborates DOC03's walled-garden limitations; does not itself resolve CF-008 |
| DOC09 | Unlimitail Workshop June 26.xlsx | Excel | Discovery workshop agenda/planning workbook | **Confirmed** as a planning artifact; introduces a named contract instrument ("Phase 2 SOW") | Day-1 kickoff objective, 4-track discovery structure, deliverables list | Strongest concrete evidence yet for CF-008 (named "Phase 2 SOW"), but the SOW itself has not been produced (OQ-C042) |
| DOC10 | ADLM Jira 2026-09-12T16_26_03-0400.xls | Excel (Jira export) | NIQ Activate Personalization product backlog (generic, all customers) | **Confirmed platform roadmap, NOT Unlimitail-specific** — "Customer: All" on every ticket | Arm assignment, ghost log, frozen eligibility snapshot, control-group selection-logic fix, Net/Gross lift | None of the 22 epics name Unlimitail (OQ-C043); Advanced Lift Measurement Framework still in Draft, targeted PI 2027.3 |
| DOC11 | Unlimitail_Dataplatform RFQ_UCs list - NIQ Response V1 - UPDATED 20 Jan 26 _Phase 1 estimations.xlsx | Excel | Pre-sales RFQ use-case catalog (107 rows) with NIQ feasibility/coverage ratings | **Confirmed artifact, but likely superseded/narrowed by kickoff** (AS-022) — reliability is high for what NIQ said in Jan 2026, low as a statement of *current* committed scope | Sales Impact Review / Brand Lift Measurement (both flagged Phase 1, Coverage=None), 8+ activation channels, clean-room/segmentation use cases | Scope is far broader than DOC02's actual delivered Phase 1 (CF-009); not reconciled by any later document |
| DOC12 | Unlimitail_Detailed_Email_Analysis.docx | Word | AI/enterprise-search-generated summary of internal email threads | **Low reliability** — secondary, generic, no named individuals/dates/quotes for most claims (AS-023) | Single-portal architecture debate | Only data point (with DOC13) for CF-010; treat as one data point, not independent corroboration |
| DOC13 | Unlimitail_Email_Summary(2).docx | Word | Companion secondary email summary | **Low reliability**, same caveats as DOC12 | Single-portal architecture "prevailing direction" | Same as DOC12 — likely same underlying generation process (AS-023) |
| DOC14 | Unlimitail_NIQ_Discovery_Questionnaire_ to_send.docx | Word | Blank pre-workshop discovery prep template | **Template, not a filled response** | 4-track discovery structure (Operating Model / Measurement & Reporting / Personalization / Data & Tech) | Confirms "iROAS" terminology; otherwise no new facts (it is unanswered) |
| DOC15 | Unlimitail_Retail_Media_Research_Pack.docx | Word | Corpus-level index/summary of DOC01–DOC09 | **Low-medium reliability** — likely another AI-generated secondary summary (AS-024) | One net-new claim: "Q4 2026 and Q1 2027" roadmap timeframe | Timeframe unconfirmed by any primary document (OQ-C046) |

**Full extraction detail for all 15 documents** (entities, business rules, personas, requirement
candidates, assumptions, open questions, glossary terms) already lives in `Knowledge_Base/`:
[Domain Model.md](../Knowledge_Base/Domain%20Model.md), [Business Processes.md](../Knowledge_Base/Business%20Processes.md),
[Personas.md](../Knowledge_Base/Personas.md), [Requirements Inventory.md](../Knowledge_Base/Requirements%20Inventory.md),
[Assumptions Log.md](../Knowledge_Base/Assumptions%20Log.md), [Open Questions.md](../Knowledge_Base/Open%20Questions.md),
[Glossary.md](../Knowledge_Base/Glossary.md). This PRD package reuses those IDs (BP-##, FR-C###, AS-###,
OQ-C###, CF-###) directly rather than re-deriving them.

---

## B. Sample Report Workbooks/Decks (Report_Analysis_Catalog.md, §0–§7)

These are **existing-system outputs**, not requirements documents. Per the PRD's own Phase-1 instruction,
each is classified below as example/limitation/unresolved rather than an approved design.

| File | Type | Apparent Purpose | Classification | Reliability |
|---|---|---|---|---|
| `NIQ_Customer Loyalty analysis.xlsx` (WB1) | Excel export | Customer loyalty/movement report from "Memory 360" platform | **Example of existing/legacy report output** (Memory 360 = confirmed legacy tool, DOC04) — not evidence of NIQ Activate's target design | High for what it shows; not applicable as a forward requirement |
| `NIQ_Datasheet_Liftcampaign.xlsx` (WB2) | Excel export | Raw datasheet behind a lift/incrementality measurement study (37 sheets) | **Example of an existing lift-study output** — no glossary, no documented statistical methodology (this is the same F5/F6/F7 methodology gap as DOC01/DOC03's control-group open questions) | High for structure/column vocabulary; methodology itself UNVERIFIED |
| `NIQ_Performance analysis.xlsx` (WB3) | Excel export | Product-performance retail report ("Memory 360") | **Example of existing/legacy report output** | High; richest glossary of the 5 workbooks |
| `NIQ_Product_Extraction.xlsx` (WB4) | Excel export | Product-scope KPI extraction tool | **Example of existing report output** | High |
| `NIQ_Temporal_evolution.xlsx` (WB5) | Excel export | Time-series KPI extraction tool | **Example of existing report output** | High |
| `NIQ_Measurement Report example.pptx` (deck7) | PowerPoint | Client-facing campaign measurement report example | **Example of a target-style deliverable** — closest artifact to what Section 15 (Reporting Requirements) should resemble, but not a confirmed UI/UX spec | Medium-High |
| `NIQ_Presales_Insights_Example.pptx` (deck6) | PowerPoint | Pre-sales insights example deck | **Example/marketing collateral** | Medium |

**Full per-workbook detail** (sheets, dimensions, KPIs, formulas, layout, data-quality notes) is in
[Report_Analysis_Catalog.md](../Report_Analysis_Catalog.md) §1–§7, and the KPI/dimension re-analysis
(84 report units, 43 KPIs, 34 dimensions, 15 comparison groups) is in
[Report_KPI_Dimension_Analysis_Summary.md](../Report_KPI_Dimension_Analysis_Summary.md) and
`Report_KPI_Dimension_Analysis.xlsx` (13 sheets, incl. the new **KPI Tiering** sheet).

---

## C. Physical Data Model / Schema Artifacts (`Source files/`, `Data_Model_Design/`)

| File/Artifact | Type | Apparent Purpose | Reliability |
|---|---|---|---|
| `Source files/cv-retailer-schema.sql` | SQL DDL | Real physical schema: store/POS, shopper, product/brand catalog, attributes | **Confirmed/authoritative** — actual production DDL, partially read in full (see Data_Model_Design/11 §7) |
| `Source files/cv-campaigns-schema.sql` | SQL DDL | Real physical schema: Personalization waves/campaigns/offers/coupons/control groups | **Confirmed/authoritative**; mostly read via targeted grep, not fully line-read |
| `Source files/cv-retailerrprt-schema.sql` | SQL DDL | Real physical schema: KPI thresholds, brand/category affinity/lift formulas, report config | **Confirmed/authoritative**; mostly read via targeted grep |
| `Source files/nga-poc-all-table-ddls.md` | Markdown (DDL dump) | An **unrelated** proof-of-concept's staging tables | **Explicitly excluded from the canonical model** per user instruction — not used anywhere in this PRD |
| `Source files/offers-mgmt-entity-relationship.md` | Markdown | Offers-management entity-relationship reference | Context-only |
| `Source files/Activate Data Interface v8.0.xlsx` / `Activate DB Schema.xlsx` | Excel | NIQ Activate's standard product data interface/schema | **Confirmed/authoritative** for the *standard product*, cross-checked against real DDL in `Data_Model_Design/11` |
| `Data_Model_Design/03_Canonical_Data_Model.md` | Markdown | Canonical data model derived from sample reports | Derived/synthesized — not a client-approved design |
| `Data_Model_Design/04_KPI_Lineage_and_Formulas.md` | Markdown | Full KPI lineage (31 KPIs, A1–F9) | Derived/synthesized from sample reports (WB1–WB5, decks) |
| `Data_Model_Design/11_Standard_Model_Gap_Analysis.md` | Markdown | NIQ standard product vs. canonical model, corrected against real DDL | Derived; §7 grounded directly in real DDL |
| `Data_Model_Design/12_Client_Feed_Onboarding_Mapping.md` | Markdown | Client-feed-to-physical-table onboarding mapping, with explicit gaps | Derived; grounded directly in real DDL — **critical finding: no atomic Tlog/transaction table found in any of the 3 real schemas** |
| `Data_Model_Design/13_KPI_Calculation_Tiering.md` | Markdown | All 43 KPIs (31 from file 04 + G1–G11 from the attached workbook) tiered by required data class | Derived; directly informs [05_Measurement_Methodology.md](05_Measurement_Methodology.md) |

---

## D. Source Reliability Legend

- **Confirmed/authoritative** — a primary document/artifact directly stating the fact, or a schema/data
  file inspected programmatically.
- **Example** — an existing system output; shows *what is produced today*, not *what should be built*.
  Per PRD Phase-1 instructions, sample reports are never auto-treated as requirements.
- **Derived/synthesized** — built by this analysis from primary sources; traceable but not
  client-approved.
- **Secondary/low-medium reliability** — AI-generated or indirect summaries (DOC12, DOC13, DOC15) with
  no named individuals, dates, or direct quotes for their key claims.

## E. Cross-Cutting Gaps Identified at the Inventory Stage

1. No single document defines Unlimitail's actual DSP/activation partner identity — DOC01 uses
   TheTradeDesk as a placeholder (AS-001); DOC03 refers to "the activation platform partner" generically.
2. No document supplies field-level record layouts for the DOC03 integration feeds (object/mechanism
   level is known; column-level schema is not) — OQ-C018.
3. No atomic transaction/Tlog table exists in any of the 3 real physical schemas reviewed —
   `Data_Model_Design/12_Client_Feed_Onboarding_Mapping.md` §5 (Blocking).
4. The single largest unresolved conflict across the whole corpus is **CF-008** (is Retail Media
   Measurement Phase 1 or Phase 2 of the Unlimitail contract?) — this affects almost every section of
   the PRD and is carried through as an open Decision (see
   [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md), DEC-001).
