# 08 — Traceability Matrix

**Purpose:** Link Objectives → Business/Functional Requirements → User Stories → Acceptance Criteria →
Datasets → Integrations → KPIs → Source Evidence, so every deliverable in this PRD package can be
traced back to its origin and forward to its implementation artifact.

---

## Master Traceability Table

| OBJ-### | FR-### | US-### | Dataset(s) | Integration(s) | KPI(s) | Source Evidence (DOC##/FR-C###) |
|---|---|---|---|---|---|---|
| OBJ-001 (attribution) | FR-001, FR-002, FR-003, FR-005, FR-006 | US-001, US-006 | DS-01, DS-02, DS-03, DS-29 | INT-007 | Attributed Sales, ROAS, CTR, Conv. Rate | DOC01; FR-C001–FR-C003, FR-C009, FR-C010 |
| OBJ-001 (attribution) | FR-004 | US-001 | DS-05, DS-06 | — | Campaign/Ad hierarchy (structural) | DOC01; FR-C005, FR-C006 |
| OBJ-002 (reporting/RLS) | FR-009, FR-010, FR-011, FR-012, FR-013, FR-014 | US-008, US-011 | DS-30, DS-31 | — | All MVP KPIs (display) | DOC01, DOC02; FR-C013–FR-C020, FR-C027 |
| OBJ-003 (integration) | FR-016, FR-017, FR-018, FR-019 | US-002, US-003, US-007 | DS-09–DS-20 | INT-001–INT-006 | Join-rate metrics; Reach, Frequency | DOC03; FR-C029–FR-C032 |
| OBJ-004 (incrementality) | FR-008, FR-022 | US-004, US-005 | DS-13 (`fact_realised_ad_agg_2`) | INT-005 | Incremental Revenue/Quantity/Shoppers/Buyer Rate (F5), ROAS-incremental (F6), P-Values (F7) | DOC03, DOC10, DOC11; FR-C033, FR-C050–FR-C056; **DEC-001** |
| OBJ-005 (KPI integrity) | FR-007, FR-008 | US-008, US-009 | DS-30 | — | All 43 KPIs (tiered) | `Data_Model_Design/13_KPI_Calculation_Tiering.md`; FR-C020 |
| Governance (cross-cutting) | FR-015 | US-012 | — | — | — | DOC02; FR-C028 |
| Security/Privacy (cross-cutting) | FR-002, FR-012, FR-014 | US-008 (AC2), US-011 | DS-25 | — | — | DOC01, DOC02; FR-C002, FR-C017, FR-C027; CON-001, CON-002 |
| Identity (cross-cutting) | FR-023 | US-001 (implicit) | DS-01, DS-22, DS-23 | — | — | DOC06; FR-C043; OQ-C025 |
| Data governance (cross-cutting) | FR-024 | — | DS-09–DS-12, DS-21–DS-29 | — | — | DOC06; FR-C045 |
| PROGRAMME reconciliation | FR-019 | US-002 | DS-18 (`dim_campaign_attr`) | INT-004 | — | DOC03; FR-C032; **DEC-004** |
| Dual-clock attribution | FR-020 | US-008 (AC3) | DS-16 (`fact_enhanced_attribution`) | INT-005 | Attributed Sales (both clocks) | DOC03; FR-C034 |
| Walled-garden labeling | FR-021 | US-009 | DS-13, DS-14 | INT-005 | Reach, Exposure (modeled) | DOC03; NFR-EV-05 |

## Traceability by KPI Tier (cross-reference to `Data_Model_Design/13`)

| Tier | KPI Count | Traces to FR-### | Traces to US-### | Blocking Dependency |
|---|---|---|---|---|
| Tier 1 (Tlog + dimension only) | 25 | FR-006, FR-007 | US-006, US-008 | DS-29 (no atomic Tlog table confirmed) — RISK-003 |
| Tier 2 (Tlog + exposure/campaign) | 13 | FR-006, FR-007, FR-017 | US-006, US-007, US-008 | DS-13/DS-29; OQ-C020 (Core Dataset access tier) |
| Tier 3 (requires modeling) | 3 (F5, F6, F7) | FR-008, FR-022 | US-004, US-005 | DEC-001 (control-group architecture) — RISK-001 |

## Traceability by Open Decision

| Decision | Affects Requirements | Affects Stories | Affects KPIs | Register Entry |
|---|---|---|---|---|
| DEC-001 (control-group architecture) | FR-008, FR-022 | US-004, US-005 | F5, F6, F7 | [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md) §A |
| DEC-002 (Phase 1 vs. Phase 2, CF-008) | All FR-### (delivery sequencing) | All | All | Same, §A |
| DEC-003 (ROAS cost basis) | FR-007 | US-008 | ROAS | Same, §A |
| DEC-004 (PROGRAMME id adoption) | FR-019 | US-002 | Reconciliation (no direct KPI) | Same, §A |

## Traceability by Risk

| Risk | Affects Requirements/Datasets | Register Entry |
|---|---|---|
| RISK-001 (control-group undecided) | FR-008, FR-022, Tier 3 KPIs | §D |
| RISK-002 (Phase placement, CF-008) | All FR-### | §D |
| RISK-003 (no atomic Tlog table) | FR-006, FR-007, DS-29, Tier 1/2 KPIs | §D |
| RISK-004 (ghost-bid/PSA partner capability) | FR-022, DEC-001 Option C | §D |
| RISK-005 (join-rate floor breaches) | FR-018, DS-30 | §D |
| RISK-006 (Personalization knowledge continuity) | FR-C042 (not a formal FR-###) | §D |
| RISK-007 (single- vs. multi-portal architecture) | FR-009 (UI), CF-010 | §D |

## Coverage Check

- Every FR-### in [02_Retail_Media_Closed_Loop_PRD.md](02_Retail_Media_Closed_Loop_PRD.md) Section 9
  appears at least once in the Master Traceability Table above.
- Every US-### in [06_User_Stories_and_Acceptance_Criteria.md](06_User_Stories_and_Acceptance_Criteria.md)
  appears at least once.
- Every DEC-### and RISK-### in
  [07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md) is cross-referenced.
- KPIs are referenced by tier (per `Data_Model_Design/13`) rather than individually restating all 43,
  to avoid duplicating that authoritative source.
