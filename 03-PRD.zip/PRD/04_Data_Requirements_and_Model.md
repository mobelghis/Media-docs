# 04 — Data Requirements and Model

**Purpose:** Input/output data catalog and conceptual data model for the Retail Media Closed-Loop
Measurement capability. Grounded in DOC01 (9 TTD-template files), DOC03 (8 handshakes / BigQuery
objects), DOC02 (onboarding volumetrics), and the real physical schema work already completed in
`Data_Model_Design/` (03, 04, 11, 12, 13). **Fields marked "recommended" are proposed by this analysis,
not source-confirmed — clearly distinguished from source-provided fields.**

---

## 1. Dataset Catalog — Inbound (into the measurement platform)

| Dataset ID | Name | Purpose | Source System | Mechanism | Grain | Cadence | Status |
|---|---|---|---|---|---|---|---|
| DS-01 | Customer Mapping | Loyalty ID ↔ Retail Media ID, historized | Retailer / Identity Resolution | File (TTD template) | Customer | Daily | Confirmed concept (DOC01); Unlimitail field format not confirmed (AS-004) |
| DS-02 | Ad Interactions | Impression/View/Click/Conversion events, consented only | DSP / CDP | File | Event | Daily | Confirmed concept; ~35 fields, subset MVP-flagged (DOC01) |
| DS-03 | T-Log (Transactions) | Retailer purchase transactions | Retailer | Existing NIQ T-Log interface | Transaction line | Daily | Confirmed — reuses Insights Premium pipeline (AS-020) |
| DS-04 | Targeting | Who was targeted, which ad group, when | Retailer / DSP | File | Event | Daily | Confirmed concept (DOC01) |
| DS-05 | Campaign / Ad Group / Ad Metadata | Campaign hierarchy, current state only | DSP | File | Campaign/AdGroup/Ad | Daily | Confirmed concept; no history in MVP |
| DS-06 | Ad Products | Ad → Retailer Product/Brand/Category mapping | Retailer | File | Ad-Product | Daily/on-change | Confirmed concept; MVP = 1 primary category/brand per ad |
| DS-07 | Campaign Engagement | Aggregated cost/impressions/views/clicks | DSP | File | Campaign/Day | Daily | Confirmed concept; possible redundancy with DS-02 (OQ-C003) |
| DS-08 | Advertisers Mapping | Advertiser ↔ CPG ↔ Brand, for RLS | Retailer | File | Advertiser | Daily/on-change | Confirmed concept |
| DS-09 | Product Catalogue | UPC/GTIN, description, category hierarchy, brand | Unlimitail (Clean Data Hub) → Activation Partner | File (GCS/SFTP/HTTPS) | Product | Before any campaign, then on change (Handshake H1) | Confirmed (DOC03) |
| DS-10 | Shopper Dimensions | Universal-ID-ready key + audience-building attributes | Unlimitail → Activation Partner | File | Shopper | Initial load, then daily delta (Handshake H2) | Confirmed (DOC03) |
| DS-11 | Segment Membership | Segment ID, definition version, point-in-time membership snapshot | Unlimitail → Activation Partner | File | Shopper-Segment | On publication and on change (Handshake H3) | Confirmed (DOC03) |
| DS-12 | Orders & Customers | Retailer order data for reconciliation | Unlimitail → Activation Partner | File | Order | Per onboarding spec | Confirmed (DOC03) |

## 2. Dataset Catalog — Outbound / Inbound-from-Partner (BigQuery Core Dataset share, retailer tier)

| Dataset ID | Name | Grain | Contents | Notes | Status |
|---|---|---|---|---|---|
| DS-13 | `fact_realised_ad_agg_2` | Shopper | Customer-level exposure — **"the single most important table"** | Required for shopper-level measurement | Confirmed (DOC03); access at retailer tier not yet confirmed (OQ-C021, Blocking) |
| DS-14 | `fact_realised_ad` | Impression | Impressions, clicks, reach, frequency, placement | | Confirmed |
| DS-15 | `fact_ad_request` | Request | Fill rate, unsold inventory, unmet demand | | Confirmed |
| DS-16 | `fact_enhanced_attribution` | Campaign × SKU | Partner's own attributed outcome/ROAS | Stored as-is, **never recomputed** by Unlimitail (dual-clock policy) | Confirmed |
| DS-17 | `fact_ledger` + `fta_campaign_spend` | Transaction/Campaign | Media spend | Must be unioned or fixed placements are missed | Confirmed |
| DS-18 | `dim_campaign_attr` | Campaign | **Required** — where Unlimitail's PROGRAMME id lives; the reconciliation key | Handshake H4 — most easily missed | Confirmed as required; PROGRAMME-id write-back not yet confirmed adopted (OQ-C023) |
| DS-19 | `dim_product` / `dim_category` | Product | Partner's view of the catalogue Unlimitail sent | For mapping validation | Confirmed |
| DS-20 | `log_status` | Load | Load start/end/status | **Required** — Unlimitail's pipeline trigger | Confirmed |

**Critical access question (OQ-C020, Blocking):** Is the **Core Dataset** (full history) available to
Unlimitail at retailer tier, or only the **Reporting Datamart** (current-dimension-only, which would
push history-reconstruction onto Unlimitail)? This must be resolved before any of DS-13–DS-20 can be
relied upon for measurement.

## 3. Dataset Catalog — Physical/Reference Data (real schema, confirmed via direct DDL inspection)

| Dataset ID | Name | Physical Table(s) | Notes | Status |
|---|---|---|---|---|
| DS-21 | Store Master / Hierarchy | `CV_R_RTLR_POS_DESCRIPTION`, `CV_R_STORES_TREE`, `CV_R_STORE_PARENTS` | "POS" = Store in this schema's naming convention | Confirmed via real DDL |
| DS-22 | Shopper Master | `CV_R_SHPR_DESCRIPTION` (only 4 confirmed columns: `CV_SHOPPER_ID`, `RETAILER_LOYALTY_ID`, `ELIGABILITY_CHANNELS`, `SHOPPER_STATUS`) | Suspiciously sparse — flagged for re-verification; demographic fields (Household_ID, Join_Date, Year_of_Birth, Gender) not found on this table | Confirmed core columns; **Gap** — demographic fields unconfirmed (`Data_Model_Design/12` Gap #4) |
| DS-23 | Card ↔ Shopper Bridge | `CV_R_SHPR_IDENTIFYING_CARD` | Not historized (no Is_Current/Effective_From/To) | Confirmed; **Gap #5** |
| DS-24 | Shopper Custom Segments | `CV_R_SHPR_CUSTOM_SEGMENTS`, `CV_R_SHPR_BRAND_CUSTOM_SEGMENTS` | EAV-style segment assignment | Confirmed |
| DS-25 | Shopper GDPR Removal | `CV_R_SHPR_REMOVAL` | Removal/consent-adjacent table | Confirmed exists; content not fully read |
| DS-26 | Product Hierarchy | `CV_R_CATALOG_TREE`, `CV_R_CATALOG_PARENTS`, `CV_R_ALL_PARENTS` | Level-to-name mapping undefined; UPC/Private_Label_Flag location unconfirmed | Confirmed exists; **Gap #2/#3** |
| DS-27 | Brand Hierarchy | `CV_R_CPG_BRAND_CATALOG_TREE`, `CV_R_BRAND_CATALOG_FLAT` | Separate tree from product hierarchy | Confirmed exists |
| DS-28 | Control Groups (Personalization) | `CV_R_CMP_CONTROL_GROUPS` | `CONTROL_GROUP_ID`, `CV_WAVE_ID`, `DATE_CREATED/UPDATED`, `CV_TARGETING_GROUP_ID` | Confirmed full DDL read |
| DS-29 | **Atomic Transaction/Tlog** | **Not found in `CV_Retailer`, `CV_Campaigns`, or `CV_RetailerRprt`** | Confirmed absent via 2 targeted grep passes (regex for SALES/INVOICE/TLOG/TRANSACTION and PURCHASE/BASKET/RECEIPT/LOYALTY/CARD); the only match was a reporting rollup (`CV_R_RPT_OFFER_PERFORMANCE_REPURCHASE`), not atomic data | **Critical gap — Blocking** (`Data_Model_Design/12` §5); likely resides in an unsupplied SingleStore/Online schema (`Online_CV_Retailer`) |

## 4. Dataset Catalog — Output

| Dataset ID | Name | Purpose | Consumer | Grain | Status |
|---|---|---|---|---|---|
| DS-30 | Measurement Results / KPI Output | Computed KPI values (43-KPI catalog) | Reporting UI | Campaign/Audience/Product/Period | Proposed structure; depends on resolving DS-29 |
| DS-31 | Report Output | Rendered report artifact (dashboard/export) | Retailer, Advertiser/CPG | Report/Period | Proposed; UI/UX itself TBD (FR-C013) |
| DS-32 | Audit Events | Every load/reprocess/correction event | Operations, Data Onboarding | Event | Proposed — no source document defines an audit-log schema; recommended per PRD requirement (Section 22) |

## 5. Conceptual Data Model — Entity Summary

Full entity list, relationships, and business rules are documented in
[Knowledge_Base/Domain Model.md](../Knowledge_Base/Domain%20Model.md) and
[Data_Model_Design/03_Canonical_Data_Model.md](../Data_Model_Design/03_Canonical_Data_Model.md). Key
relationships relevant to closed-loop measurement:

- **Campaign (1) → Ad Group (N) → Ad/Creative (N)** — standard 3-level campaign hierarchy (DOC01).
- **Advertiser (1) → Campaign (N); Advertiser (N) → CPG (1)** via Advertisers Mapping (DOC01, RLS).
- **Loyalty ID (1) → Retail Media ID (N over time)**, historized via Effective_From/To (DOC01).
- **Ad Interaction (N) → Ad (1) → Retail Media ID (1)** — the exposure event.
- **T-Log Purchase (N) ↔ Ad Interaction (N)**, matched via Retail Media ID/Loyalty ID + Attribution
  Window — **the "closed loop" join itself.**
- **PROGRAMME (proposed, 1) → Campaign (N)** — a level-0 entity above Campaign, proposed by DOC03 to
  enable cross-channel reconciliation via `dim_campaign_attr`; **not yet confirmed adopted.**
- **Store (1) → Store Hierarchy (N levels)**; **Shopper (1) → Card (N, not historized)**; **Product
  (1) → Category Hierarchy (N levels)**; **Brand (1) → Brand Hierarchy (N levels)** — all confirmed
  via real physical DDL (`Data_Model_Design/12`).

## 6. Identity Resolution Approach

| Layer | Mechanism | Source | Status |
|---|---|---|---|
| Retailer-internal | Loyalty ID (`RETAILER_LOYALTY_ID`) ↔ `CV_SHOPPER_ID` via `CV_R_SHPR_IDENTIFYING_CARD` | Real DDL | Confirmed, not historized (Gap #5) |
| Ad-ecosystem (DSP-side, TTD example) | Retail Media ID (RampID / UID 2.0) | DOC01 | Confirmed for TTD; Unlimitail's actual DSP/ID scheme not confirmed (AS-001, AS-004) |
| Cross-party (Unlimitail ↔ Activation Partner) | Hashed loyalty ID resolved via CDP/CBP/CDI to the partner's customer ID | DOC03 | Confirmed as architecture; **exact resolved identifier and its stability across in-store/online is an open question (OQ-C025, Blocking)** |

## 7. Data Lineage / Source-to-Target Mapping (where evidence exists)

The most authoritative source-to-target mapping already built for this engagement is
[Data_Model_Design/12_Client_Feed_Onboarding_Mapping.md](../Data_Model_Design/12_Client_Feed_Onboarding_Mapping.md),
which maps every standard Activate client-onboarding feed (Store Master, Product Catalog, Shoppers,
Purchase Reference/Cards, Custom Segments, Attributes Metadata, Tlog Sales) to its real physical
landing table, with 6 explicit, severity-rated gaps. This PRD's Data Requirements section defers to
that mapping rather than re-deriving it.

## 8. Data-Quality Rules (confirmed, DOC03)

| Join | Keys | Floor | Consequence if broken |
|---|---|---|---|
| Product | upc ↔ gtin | 99% | Media exposure cannot be tied to sales |
| Shopper | hashed loyalty id ↔ customer id | 95% | All shopper-level measurement fails |
| Session | session key ↔ sessionId | 90% | Attribution cannot be reconciled between parties |
| Feed integrity | rows exported ↔ rows returned | 100% | Every rate metric has a wrong denominator |

**Business rule (confirmed):** a number built on a join below its floor is flagged, not reported.

## 9. Reconciliation Logic

- **PROGRAMME id reconciliation (proposed, DOC03):** Unlimitail's PROGRAMME id written to
  `dim_campaign_attr` at campaign setup is the proposed reconciliation key tying exposure, spend, and
  attributed outcome back to Unlimitail's own offers/audiences/sales — **not yet confirmed adopted by
  the activation partner** (OQ-C023).
- **Feed integrity reconciliation:** rows-exported vs. rows-returned counts (100% floor, above).
- **No reconciliation logic is documented for late-arriving/corrected transactions** in the media
  measurement context specifically (see Section 22 Gap Register in the PRD).

## 10. Retention and Deletion

No document in the corpus specifies data retention/deletion requirements specific to Retail Media
Measurement. DOC04's SLA note (monthly DB backup, DRP RTO 1–2 business days) is a platform-level
operational fact, not a data-retention policy. **This is a gap — flagged as a Security/Privacy
open question in Section 17 of the PRD** (no compliance claim is made here per the "do not state
compliance without evidence" instruction).

## 11. Recap

- **Entities/KPIs affected:** All 43 KPIs (dependent on DS-29's resolution); the full closed-loop
  identity/exposure/attribution chain.
- **Design decisions & rationale:** Dataset IDs are grouped by data-plane (DOC01 file-based ingestion
  vs. DOC03 BigQuery-share integration vs. real physical schema) rather than merged, since no document
  confirms these are the same physical pipeline (AS-012, open).
- **Data quality/privacy considerations:** Consented-only ingestion (DS-02); 4 join-rate floors (DS-30
  dependent on all upstream floors passing); GDPR/removal table exists (DS-25) but content unverified.
- **Confidence level:** High for DOC03's BigQuery object list and the real physical schema (both
  directly inspected); Medium for DOC01's file-based model (TTD-specific, portability unconfirmed);
  Low for how DOC01's and DOC03's data planes relate to each other (AS-012, open).
