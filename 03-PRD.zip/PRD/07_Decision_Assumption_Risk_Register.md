# 07 — Decision, Assumption, and Risk Register

**Purpose:** Consolidated register of decisions required, assumptions, constraints, and risks for the
Retail Media Closed-Loop Measurement capability. Reuses AS-### and OQ-C###/CF-### IDs directly from
[Knowledge_Base/Assumptions Log.md](../Knowledge_Base/Assumptions%20Log.md) and
[Knowledge_Base/Open Questions.md](../Knowledge_Base/Open%20Questions.md) as evidence; mints new
DEC-###, Q-###, ASM-###, CON-###, and RISK-### IDs for PRD-specific register entries.

---

## A. Decision Register (DEC-###)

### DEC-001 — Control-Group Architecture (the central open decision)

- **Decision required:** How should the test/control split be created and managed for incrementality
  measurement?
- **Options:**
  - **Option A — Platform withholds control before export.** Our platform defines and holds back the
    control group before sending the target audience to the activation platform. Corresponds to
    DOC03's candidate (A): "chosen at export — randomized when segment is published, held only on
    Unlimitail's side."
  - **Option B — Full audience sent; activation platform separates control.** The complete eligible
    audience is sent to the activation platform, which creates/separates the control group as part of
    its own campaign process. Corresponds to DOC03's candidate (B) ("built after the fact") if the
    partner uses simple unexposed-shopper differentiation, or candidate (C) ("ghost-bid/PSA") if the
    partner's ad server can withhold/serve a placebo to a random subset.
  - **Option C — Ghost-bid / PSA (hybrid, partner-side randomization).** DOC03's candidate (C):
    partner's ad server withholds or serves a placebo to a random subset of the reachable audience —
    keeps both reach and causal validity, but requires partner-side ad-server capability. This is
    explicitly Unlimitail's own stated preference in DOC03, **not a confirmed decision.**
- **Comparison (per DOC03's own "Where We Differ" framing):**

  | Dimension | Option A (withhold before export) | Option B (partner separates, post-hoc) | Option C (ghost-bid/PSA) |
  |---|---|---|---|
  | Methodological integrity | High — randomization controlled entirely by Unlimitail | Low — measures selection bias, not causal effect (DOC03 explicit) | High — randomization at the partner's serving layer |
  | Randomization control | Unlimitail owns it | Partner (uncontrolled/unconfirmed) | Partner-side, but to Unlimitail's spec |
  | Risk of control contamination | Low (held out before any exposure is possible) | High (post-hoc unexposed ≠ randomized) | Low (if implemented correctly) |
  | Reach impact | **Loses reach** (held-out group is never exposed, so is a real cost to the campaign) | No reach lost | No reach lost |
  | Activation-platform dependency | Low | Medium | **High — requires partner ad-server capability not yet confirmed to exist (OQ-C022)** |
  | Auditability | High (all control logic on Unlimitail's side) | Medium | Medium (depends on partner's own audit capability) |
  | Reporting accuracy / explainability to customers | High — clean causal story | Low — must be caveated as non-causal (per DOC03's own policy: never reported as causal lift) | High, if partner confirms the mechanism |
  | Operational complexity | Medium (must integrate holdout logic into segment publication) | Low (no extra Unlimitail-side logic) | High (depends entirely on partner's willingness/capability) |
  | Scalability / cross-market consistency | High (consistent regardless of partner) | Depends per-partner | Depends per-partner — may not be uniformly available across all activation channels/markets |
- **Benefits / Risks:** Option A trades reach for clean causal validity and full Unlimitail-side
  control; Option B avoids reach loss but produces a measurement DOC03 itself says is not statistically
  valid; Option C is the "best of both" on paper but is unconfirmed as technically available.
- **Dependencies:** Partner's ad-server / campaign-execution capability (OQ-C022); whether the same
  partner is used across all activation channels (Lane A retailer-owned channels vs. Lane B paid
  media, per DOC03) — Option C likely only applies to Lane B.
- **Information still needed:** Direct confirmation from the (currently unnamed) activation
  partner(s) on whether ghost-bid/PSA is technically supported, per campaign, across all relevant
  channels.
- **Recommended decision owners:** Unlimitail Product/Measurement leadership + the activation
  partner's technical integration team; NIQ Activate Product Owner (once assigned, per OQ-C037/FR-C037).
- **Decision deadline:** Not stated in source material — **TBD**, recommend setting a deadline tied to
  the Retail Media Measurement delivery-phase start once CF-008 (Phase 1 vs. Phase 2 placement) is
  resolved.
- **Impact of delaying:** Every incrementality-dependent KPI (F5 Incremental Revenue/Quantity/
  Shoppers/Buyer Rate, F6 ROAS-incremental, F7 P-Values — all Tier 3 in
  [05_Measurement_Methodology.md](05_Measurement_Methodology.md)) remains unimplementable; MVP scope
  would be limited to Tier 1/Tier 2 KPIs only.
- **Status:** **Open — no preferred option is selected per explicit instruction not to decide without
  source support.**

#### DEC-001 addendum (2026-09-13) — 3 new discovery-meeting transcripts (DOC16, DOC18, DOC19)

Three later, more detailed discovery-meeting transcripts materially deepen — but do not resolve —
DEC-001. Per this PRD's evidentiary discipline, this addendum documents what changed without
silently picking a preferred option.

- **Option-lettering inconsistency identified (see CF-011,
  [Knowledge_Base/Open Questions.md](../Knowledge_Base/Open%20Questions.md)):** DOC16/DOC18 letter
  their candidates differently from DOC03. DOC03's Option A/B map conceptually onto DOC16's Option
  A (upfront holdout) / Option B (post-exposure control), but DOC03's Option C (ghost-bid/PSA) is
  **not reintroduced by name** in any of the 3 new documents — those instead discuss only upfront
  holdout, post-exposure/natural-non-exposed control, and a 3rd non-method (aggregate-only/
  walled-garden channels, a data-availability constraint rather than a construction technique). This
  PRD does not assume ghost-bid/PSA has been dropped — see OQ-C047 — but flags that recent internal
  discussion has centered on the other two options.
- **DOC18 (Sep 8, 2026) provides the richest methodology detail seen to date for the upfront-holdout
  option specifically:**
  - New formal vocabulary: **addressable/intent-to-treat lift** (average effect across all matched
    treatment shoppers, including never-served ones) vs. **served lift** (addressable lift ÷
    delivery rate, i.e. rescaled to actually-exposed shoppers only) vs. **delivery rate** (exposed ÷
    matched treatment).
  - A worked numerical example (illustrative, not a production spec): 900/100 treatment/control
    split from 1,000 shoppers → 50% channel match → 300 treatment shoppers actually exposed (control
    suppressed) → $9,000 observed treatment spend vs. $800 control spend ($16/shopper control mean)
    → $7,200 counterfactual (450 × $16) → **$1,800 total incremental value** → $4 addressable
    lift/shopper (÷450) → 66.7% delivery rate → **$6 served lift/shopper** (÷66.7%) — the *total*
    incremental value is invariant to which per-shopper metric is reported, only the per-shopper
    figure changes.
  - New requirement IDs proposed in DOC18 (EXP-01–03, DATA-01–02, MET-01–03, GOV-01, COST-01) — these
    **elaborate, rather than replace,** this PRD's existing FR-008 guardrail and are tracked as new
    evidence rows FR-C062–FR-C071 in
    [03_Requirement_Evidence_Register.md](03_Requirement_Evidence_Register.md).
  - DOC18 itself explicitly states its own "Option B" was **not reviewed in this meeting** and
    requires a follow-up session — see OQ-C048. Do not assume the upfront-holdout option is the
    team's converged direction; it is simply the one most recently deep-dived.
- **DOC16 (Aug 13, 2026) and DOC19 (Sep 9, 2026) reconfirm the same 3-option framing** (upfront
  holdout / post-exposure control / aggregate-only channel) independently, and add: a client
  preference **for post-exposure control** where exposure-level data exists ("so small segments are
  not reduced upfront" — DOC16 §1.1), explicitly flagged as "not automatically valid" pending
  data-science review; concrete audience-scale figures (DOC19 §7.3: ~14M total shopper base, 5-6M
  typical large-brand audience, ~300K minimum-audience prerequisite, 10-20% typical holdout, 30-60%
  DSP match/drop range); and confirmation that **lookalike/control-store matching is explicitly out
  of current scope**, a separate unfunded data-science initiative, not a 4th DEC-001 option (AS-029).
- **This addendum does not change DEC-001's status.** It remains **Open**, now with 2 concretely
  detailed live candidates (upfront holdout, post-exposure control) plus the previously-documented
  aggregate-only/walled-garden constraint, and an unresolved question about whether ghost-bid/PSA
  remains a live 3rd candidate (OQ-C047, OQ-C048).

### DEC-002 — Phase Placement of Retail Media Measurement (CF-008)

- **Decision required:** Is Retail Media Measurement (this entire capability) part of the current
  contracted Phase 1, or a Phase 2/TBD deliverable?
- **Options:** (a) Phase 1 per DOC04's contract-phase table; (b) Phase 2 per DOC02/DOC06/DOC07/DOC09
  (4 independent documents, including a named "Phase 2 SOW" cited in DOC09).
- **Recommended decision owners:** NIQ PM (Jony Gurfinkel) + Customer PM (Richard Fercoq) + whoever
  holds the actual SOW document (OQ-C042).
- **Decision deadline:** Should precede any MVP delivery-timeline commitment.
- **Impact of delaying:** Blocks realistic sequencing/estimation for every other section of this PRD —
  this is the single highest-priority open item in the entire corpus.
- **Status:** Open, converging toward "Phase 2" per evidence weight, but **not resolved** — see CF-008
  in Knowledge_Base/Open Questions.md for full evidence trail.

### DEC-003 — Cost Basis for ROAS

- **Decision required:** Should ROAS be measured against retailer cost or advertiser cost?
- **Options:** Advertiser cost (DOC01 default) vs. Retailer cost (DOC01-documented alternative).
- **Recommended decision owners:** Advertiser/Brand stakeholders + Retailer finance/measurement team.
- **Status:** Open (OQ-C007).

### DEC-004 — PROGRAMME ID Adoption

- **Decision required:** Will the activation partner support writing Unlimitail's PROGRAMME id into
  `dim_campaign_attr` at campaign setup?
- **Options:** Adopt (enables cross-channel reconciliation) vs. manual per-campaign mapping (fallback).
- **Recommended decision owners:** Unlimitail integration team + activation partner technical team.
- **Status:** Open (OQ-C023, CF-006).

### DEC-005 — Indexes / Category-Benchmark Reporting Scope (new, 2026-09-13)

- **Decision required:** Is "Indexes" (brand/advertiser-vs.-category benchmark comparison reporting,
  discussed in a Sep 9, 2026 client discovery meeting) a formally scoped Phase 1/Phase 2 deliverable,
  or a not-yet-committed candidate capability still in discovery? Is it the same capability as the
  sample reports' undocumented `Indice CA`/`Indice UVC`/`Ecart vs Benchmark` KPIs
  ([Data_Model_Design/04_KPI_Lineage_and_Formulas.md](../Data_Model_Design/04_KPI_Lineage_and_Formulas.md)
  §C3/C4), or a distinct, net-new capability?
- **Options:** (a) Treat Indexes as the formula-resolution path for the existing UNVERIFIED §C3/C4
  KPIs (AS-027) and scope it accordingly; (b) treat Indexes as an entirely new, separately-scoped
  reporting capability, additive to the existing 6-report consolidation plan; (c) defer any Indexes
  work until the underlying formula and audience-eligibility questions (OQ-C050, OQ-C052, OQ-C053)
  are resolved.
- **Evidence:** DOC19 (Sep 9, 2026 discovery meeting) gives an illustrative, explicitly
  **not-finalized** candidate formula `Index = (Brand share / Category share) × 100` (with a
  point-difference alternative for less statistically sophisticated users), a full requirements
  register (RPT-01–14, MEA-01–04, UX-01–02, NFR-01–02), and reconfirms audience-scale figures (~14M
  total shopper base, ~300K minimum-audience prerequisite) relevant to when an Index can be reliably
  computed. DOC19 itself flags all of its own content as "proposed" or "open," requiring product/data
  validation before commitment (its own Appendix B).
- **Recommended decision owners:** Unlimitail Product/Measurement leadership (Richard Fercoq/Marina
  per DOC19) + NIQ Product Owner, jointly with whoever resolves DEC-001 (shared audience-eligibility
  dependencies).
- **Decision deadline:** Not stated in source material — **TBD**, recommend deciding before any
  Indexes-specific UI/report work begins (see `PRD/10_Report_Consolidation_Plan.md`).
- **Impact of delaying:** §C3/C4 of `Data_Model_Design/04_KPI_Lineage_and_Formulas.md` remain
  UNVERIFIED; no Indexes-labeled report component can be safely built without a confirmed formula and
  scope decision.
- **Status:** **Open, newly identified 2026-09-13 — no scope decision has been made; not previously
  represented in this PRD.**

### DEC-006 — Planning as a First-Class Product Stage (new, 2026-09-13)

- **Decision required:** Should "Planning" (pre-campaign opportunity discovery, standardized
  reporting-package generation, and a stored budget/channel/expected-outcome recommendation) be
  formally scoped as a distinct product capability alongside Activation and Measurement, or remain
  informally addressed only as ad hoc report exports?
- **Options:** (a) Add Planning as a named workstream/capability with its own requirements (PLN-01–07
  per DOC20) and roadmap placement; (b) treat Planning as out of scope for the current engagement and
  continue to address it only via existing use-case-oriented reporting; (c) defer the decision until
  the client's actual planning workflow (budget/forecast methodology) is discovered in more detail.
- **Evidence:** DOC20 (Aug 5, 2026, the earliest of the newly reviewed transcripts) frames the full
  commercial lifecycle as **planning → operations/activation → measurement**, with planning currently
  a highly manual process (multiple report exports, manual spreadsheet analysis, manual PowerPoint
  construction) that the client wants standardized. DOC20 explicitly flags that "the detailed
  budgeting and forecast methodology remains unknown and should be explicitly discovered" — this is
  not a fully specified capability, only a clearly identified gap and client pain point.
- **Recommended decision owners:** Unlimitail Product/Commercial leadership (sales/account-team
  representation) + NIQ Product Owner.
- **Decision deadline:** Not stated in source material — **TBD**, recommend deciding before any
  Planning-labeled report/UI work begins.
- **Impact of delaying:** No impact on already-scoped Activation/Measurement work; delaying only
  defers whether Planning becomes an explicit, funded capability or remains an informal, ad hoc use
  of existing reports.
- **Status:** **Open, newly identified 2026-09-13 — no scope decision has been made; not previously
  represented in this PRD.** See OQ-C055.

---

## B. Assumption Register (ASM-###, cross-referencing AS-### from the Knowledge Base)

| ASM ID | Assumption | Evidence (AS-###) | How it will be validated |
|---|---|---|---|
| ASM-001 | Unlimitail's actual DSP/activation partner may differ materially from TheTradeDesk (DOC01's example). | AS-001 | Confirm named partner(s) and re-validate field-level data model against their actual API/file spec. |
| ASM-002 | Unlimitail's identity-resolution mechanism may not be equivalent to TTD's UID 2.0 and may require a separate ID-resolution integration. | AS-002, AS-004 | Confirm with Unlimitail's CDP/CBP/CDI team (DOC03) what identifier the hashed loyalty ID resolves to. |
| ASM-003 | DOC01's file-based ingestion model (9 files) and DOC03's BigQuery-share model describe complementary, not conflicting, legs of the same architecture. | AS-012 | Obtain an explicit architecture document tying both legs together; until then, treat as two parallel, unreconciled data planes. |
| ASM-004 | The Insights Premium onboarded T-Log/customer data is the shared foundation reused for Retail Media Measurement (no separate onboarding pipeline). | AS-020 (**Confirmed by client**) | Already validated — no further action needed on the core principle; incremental fields for measurement-specific needs still TBD at onboarding-spec sign-off. |
| ASM-005 | The generic NIQ Activate Personalization platform epics (arm assignment, ghost log, control-group selection-logic fix, Advanced Lift Measurement Framework) are relevant to and will be consumed by Unlimitail's engagement. | AS-021 | Confirm with the NIQ product/platform team which of DOC10's 22 epics are actually committed for Unlimitail (OQ-C043). |
| ASM-006 | DOC11's RFQ-stage "Phase 1" scope (60 use cases, 8+ activation channels) was superseded/narrowed by the actual Phase 1 kickoff (DOC02). | AS-022 | Confirm with the client which (if any) DOC11 use cases remain live commitments (OQ-C044). |
| ASM-007 | DOC12/DOC13's single-portal architecture claim is a single, low-confidence data point (likely from the same generation process), not two independently corroborating sources. | AS-023 | Verify directly with the program team whether a single-portal architecture has been proposed/decided (OQ-C045). |
| ASM-008 | The 14-day post-exposure attribution lookback (DOC01, reconfirmed by DOC16) is the working default for shopper-level exposure-to-purchase matching, distinct from and not in conflict with DOC03's separately-cited 28-day window for Unlimitail's own randomized-holdout measurement (CF-005). | AS-026 | Confirm with the client which window applies to which reported metric, and resolve DOC16 §5.1's still-open boundary rules (day-zero inclusion, multi-touch, multi-purchase, time zone, returns). |
| ASM-009 | Lookalike/control-store matching is a separately-fundable, out-of-scope data-science initiative, not a 4th candidate option for DEC-001. | AS-029 | Confirmed as out of scope per DOC17; no further validation needed unless the client separately requests store-level lookalike measurement. |
| ASM-010 | The "Indexes" capability (DOC19) and the sample reports' undocumented `Indice CA`/`Indice UVC`/`Ecart vs Benchmark` KPIs are the same underlying capability, such that DOC19's discovery process is effectively the requirements-gathering path to resolving §C3/C4's UNVERIFIED status. | AS-027 | Validate directly with the client (Richard Fercoq/Marina/Samya) before treating DOC19's illustrative formula as authoritative; see DEC-005. |
| ASM-011 | "Media Rhythmics" and "OneDB" are the correct, confirmed proper names of the client's CDP/identity layer and future campaign-metadata system respectively. | AS-030 | Source document itself flags these as phonetically transcribed; validate directly with the client before use in any architecture diagram (OQ-C054). |
| ASM-012 | A `dim_campaign_group`/`advertiser_initiative` parent entity is a net-new, not-yet-scoped capability, not an existing part of any confirmed Phase 1 data model. | AS-031 | Confirm with the client/product team whether this is committed scope before building it (OQ-C058). |
| ASM-013 | Brazil's 3-banners-in-1-portal shopper-identity duplication is a distinct risk from CF-010's single-vs-multi-portal architecture debate — one concerns portal count, the other concerns shopper-ID uniqueness within a single portal. | AS-032 | Confirm the deduplication/identity-scope rule directly with the client before finalizing any Brazil-scoped reporting KPI (OQ-C059). |
| ASM-014 | The 4-week and 6-week windows mentioned in DOC20 are distinct from (not a replacement for) the confirmed 14-day attribution lookback, likely representing a separate repeat-purchase/persistence concept. | AS-033 | Confirm exact definition and purpose of these windows directly with the client (OQ-C060). |

## C. Constraint Register (CON-###)

| CON ID | Constraint | Source | Notes |
|---|---|---|---|
| CON-001 | Only consented Ad Interaction data may be ingested/processed — non-configurable. | DOC01 | Hard privacy constraint on every exposure-dependent KPI. |
| CON-002 | Phase 1 access is limited to ~100 internal Unlimitail users only; no external Advertiser/CPG access. | DOC02 | Directly limits which personas can be UAT'd/validated in the current delivery wave. |
| CON-003 | Adding any new transactional attribute requires a full historical reload — no incremental backfill supported. | DOC06 | Attribute scope must be finalized before onboarding-spec sign-off (BP-08). |
| CON-004 | Row-per-shopper-per-offer eligibility snapshots are explicitly "not viable at 15M shoppers." | DOC10 | Constrains any control-group/eligibility-tracking design to compact/aggregate snapshot forms. |
| CON-005 | No atomic Tlog/transaction table exists in any of the 3 real physical schemas reviewed (`CV_Retailer`, `CV_Campaigns`, `CV_RetailerRprt`). | Data_Model_Design/12 §5 | Blocks 25 of 43 KPIs (Tier 1) and several Tier 2 KPIs until resolved. |

## D. Risk Register (RISK-###)

| Risk ID | Description | Category | Probability | Impact | Severity | Mitigation | Contingency | Owner | Status |
|---|---|---|---|---|---|---|---|---|---|
| RISK-001 | Control-group methodology (DEC-001) remains undecided past the MVP delivery window, blocking all incrementality KPIs. | Methodology | Medium | High | **High** | Escalate DEC-001 to Unlimitail/activation-partner leadership now; scope MVP to Tier 1/2 KPIs only in the interim. | Ship Tier 1/2 KPIs first; defer incrementality to a clearly labeled Phase 2/3 release. | Product Owner | Open |
| RISK-002 | CF-008 (Phase 1 vs. Phase 2 placement) remains unresolved, causing delivery-timeline mismatch between what the contract implies and what discovery workshops describe. | Contractual / Program | Medium | High | **High** | Obtain the actual "Phase 2 SOW" document (OQ-C042) as the definitive artifact. | Plan two parallel timelines (contract-table view vs. workshop view) until resolved. | NIQ PM + Customer PM | Open |
| RISK-003 | No atomic Tlog table exists in the reviewed physical schemas — 25+ KPIs cannot be computed until this is resolved. | Data | High | High | **High** | Request the SingleStore/Online schema DDL explicitly, per `Data_Model_Design/12`'s own recommendation. | Scope initial delivery to whatever KPIs the Reporting Datamart/Core Dataset can support without atomic Tlog. | Data Engineering | Open |
| RISK-004 | Activation partner's ad-server may not support ghost-bid/PSA (Option C), forcing a fallback to a lower-validity control-group method. | Integration / Methodology | Medium | Medium | Medium | Confirm partner capability early (OQ-C022); design Option A as a documented fallback. | Adopt Option A (platform-side withhold) if Option C is unavailable, accepting the reach-loss tradeoff. | Integration / Measurement | Open |
| RISK-005 | Match/join rates fall below published floors (99%/95%/90%/100%), silently degrading every rate-based KPI. | Data Quality | Medium | High | Medium-High | Implement automated daily floor monitoring with flagging (already a confirmed business rule, DOC03). | Suppress affected KPIs rather than publish them below-floor. | Data Engineering / Operations | Open (monitoring not yet implemented) |
| RISK-006 | Personalization-domain knowledge (Sagit, Trevor) is lost before formal documentation, affecting future Personalization-adjacent measurement work. | Knowledge Continuity | Medium | Medium | Medium | Prioritize knowledge-transfer sessions before departure (FR-C042). | Reconstruct from Jira/backlog artifacts (DOC10) if knowledge is lost. | NIQ Delivery/CS | Open |
| RISK-007 | Single-portal vs. 3-country-portal architecture debate (CF-010) resolves late, causing rework in UI/reporting design. | Architecture | Low-Medium | Medium | Low-Medium | Verify directly with the program team rather than relying on secondary email summaries (OQ-C045). | Design report components to be portal-count-agnostic where feasible. | Architecture | Open |
| RISK-008 | Sample/exposure data delivery for the first onboarding country remains delayed past the point needed to validate Retail Media Measurement discovery (as of DOC17, Sep 1, 2026), pushing back downstream methodology/reporting work. | Data / Program | Medium | High | Medium-High | Escalate exposure-sample-data request (DATA-03 per DOC17) as a named, owned action rather than an ambient blocker. | Continue methodology and reporting-schema design against DOC16/DOC18/DOC19's conceptual descriptions, clearly labeled as unvalidated against real data, until sample data lands. | NIQ Delivery / Data Engineering | Open (OQ-C051) |
| RISK-009 | "Indexes" (DEC-005) reporting work proceeds without a finalized formula or confirmed linkage to the existing UNVERIFIED §C3/C4 KPIs, risking scope creep or duplicated effort against the report-consolidation plan. | Scope / Methodology | Medium | Medium | Medium | Resolve DEC-005 and OQ-C050 before starting any Indexes-labeled UI/report work; anchor any Indexes work explicitly to named user stories rather than open-ended exploration (per DOC19's own risk register). | Treat existing §C3/C4 KPIs as still UNVERIFIED/placeholder in any interim report mockup. | Product Owner | Open |
| RISK-010 | Planning (DEC-006) continues to be treated as "just existing reports" rather than a discovered, standardized workflow, leaving significant manual client effort (multi-report export, manual PowerPoint building) unaddressed. | Scope / Product | Medium | Medium | Medium | Explicitly discover the planning workflow (budget/forecast methodology) and scope a use-case-centered planning package (DOC20's own recommended mitigation). | Continue supporting Planning only via ad hoc existing-report exports until scoped. | Product Owner | Open |
| RISK-011 | No parent campaign-group entity exists, so cross-channel advertiser-initiative value cannot be summarized cleanly across channel-specific campaigns. | Data Architecture | Medium | Medium | Medium | Add the proposed `dim_campaign_group` entity (PROPOSED/NOT AVAILABLE, `Data_Model_Design/03_Canonical_Data_Model.md` §5) once DEC-006/OQ-C058 are resolved. | Report at the individual channel-campaign grain only until a parent entity is confirmed. | Product Owner / Data Engineering | Open |
| RISK-012 | Brazil's shopper-identity duplication across 3 banners in 1 portal is not resolved before audience/reporting KPIs are built, causing misleading audience-size or KPI counts. | Data Quality / Architecture | Medium | High | Medium-High | Expose identity scope and banner context explicitly (banner attribute on `dim_customer`, per DOC20's own mitigation); confirm dedup rule with the client (OQ-C059). | Flag any Brazil-scoped KPI as potentially inflated until the dedup rule is confirmed. | Data Engineering | Open |
| RISK-013 | Segment ID or equivalent lineage metadata is lost in the audience-export/exposure-return round trip, preventing exposure data from being linked back to the originating audience. | Integration / Measurement | Medium | High | Medium-High | Persist transfer- and campaign-audience lineage explicitly in the export/exposure file contracts (AUD-11 per DOC20). | Treat any exposure data without recoverable segment lineage as unusable for campaign-level measurement. | Integration / Measurement | Open |

## E. Open Question Register (Q-###, cross-referencing OQ-C### / CF-### from the Knowledge Base)

All 60 open questions (OQ-C001–OQ-C060) and 11 conflicts (CF-001–CF-011) are maintained in
[Knowledge_Base/Open Questions.md](../Knowledge_Base/Open%20Questions.md) and are **not re-numbered
here** to avoid ID drift. Grouped by PRD-relevant area for this register:

| Area | Question IDs | Blocking? |
|---|---|---|
| Methodology | OQ-C001, OQ-C006, OQ-C007, OQ-C010, OQ-C037, OQ-C047, OQ-C048, OQ-C049, OQ-C052, OQ-C060 | OQ-C006, OQ-C047, OQ-C048 Blocking |
| Data / Architecture | OQ-C003, OQ-C004, OQ-C009, OQ-C018, OQ-C020, OQ-C021, OQ-C025, OQ-C027, OQ-C036, OQ-C041, OQ-C051, OQ-C053, OQ-C058, OQ-C059 | OQ-C018, OQ-C020, OQ-C021, OQ-C025, OQ-C036, OQ-C041, OQ-C051, OQ-C059 Blocking |
| Activation Integration | OQ-C022, OQ-C023, OQ-C024, OQ-C026, OQ-C032, OQ-C054, OQ-C056, OQ-C057 | OQ-C022, OQ-C054, OQ-C056 Blocking |
| Contractual / Program Scope | OQ-C012, OQ-C014, OQ-C019, OQ-C042, OQ-C044, OQ-C045, OQ-C046 | OQ-C042, OQ-C044 Blocking |
| Reporting / UX | OQ-C002, OQ-C005 | Not blocking (design-level) |
| Indexes / Benchmarking (new, 2026-09-13) | OQ-C050 | Blocking (for DEC-005 / §C3-C4 formula resolution) |
| Planning (new, 2026-09-13) | OQ-C055 | Not blocking for Activation/Measurement (relevant to DEC-006) |
| Security / Access | OQ-C015 | Not blocking |
| Commercial / Governance | OQ-C028, OQ-C029, OQ-C030, OQ-C031 | Not blocking for product delivery |
| Product Gaps (Personalization) | OQ-C033, OQ-C034, OQ-C035 | Not blocking for Retail Media Measurement proper |
| Platform Roadmap | OQ-C043 | Not blocking (informational) |

## F. Recap

- **Entities/KPIs affected:** All incrementality KPIs (DEC-001), all 43 KPIs' delivery timeline
  (DEC-002), ROAS (DEC-003), cross-channel reconciliation (DEC-004), Ecart vs Benchmark/Indice CA/UVC
  KPIs and any new Indexes reporting scope (DEC-005), Planning as a candidate product stage and the
  proposed `dim_campaign_group`/Brazil-banner entities (DEC-006, added 2026-09-13).
- **Design decisions & rationale:** No option is recommended for DEC-001, DEC-002, DEC-005, or the
  newly added DEC-006 per explicit instruction; each decision brief documents tradeoffs and required
  owners instead. DEC-001's addendum incorporates 3 discovery-meeting transcripts (DOC16, DOC18,
  DOC19) that materially deepen candidate control-group methodology without resolving which option is
  adopted, and surface a terminology-only conflict (CF-011) in how options are lettered across
  documents. A 5th, chronologically earliest transcript (DOC20, Aug 5, 2026) broadens product scope
  further — introducing Planning as a candidate 3rd commercial stage, a proposed
  `dim_campaign_group` parent entity for cross-channel advertiser initiatives, and a concrete
  Brazil shopper-identity duplication risk — all logged as new assumptions/risks/open questions
  rather than committed scope.
- **Data quality/privacy considerations:** CON-001 (consent) and CON-005 (missing Tlog) are the two
  constraints most likely to block near-term delivery. The new documents reiterate pseudonymous-ID
  handling requirements (DOC17: masked IDs, client-side remapping, NIQ should not receive directly
  identifying IDs) consistent with existing CON-001/GOV-01 expectations — no new privacy constraint
  introduced, but reconfirmed. DOC20 additionally surfaces a shopper-identity-scope concern specific
  to Brazil (potential triple-counting of the same physical shopper across banners) — a data-quality
  risk (RISK-012), not itself a privacy/consent gap.
- **Confidence level:** High that these are the correct open items (all directly sourced from
  Knowledge_Base or Data_Model_Design); Low on resolution timelines, since no source document commits
  to dates for any of them. The DOC16/DOC18/DOC19 evidence is Medium confidence as candidate
  methodology (richly detailed, internally consistent) but explicitly not yet client-approved or
  NIQ-committed. DOC20 is Medium-Low confidence on its reconstructed architecture terms (Media
  Rhythmics, OneDB — the source document itself flags these as phonetically transcribed and
  unverified) and Medium confidence on its product-scope observations (planning pain points, campaign
  grouping gap, Brazil identity risk — directly stated, but not yet independently corroborated by a
  second source).
