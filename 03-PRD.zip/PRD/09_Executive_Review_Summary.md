# 09 — Executive Review Summary

**Audience:** Program/Product/Engineering leadership (Unlimitail + NIQ Activate).
**Purpose:** A concise, decision-oriented summary of the Retail Media Closed-Loop Measurement PRD
package. Full detail lives in files 01–08 of this folder.

---

## Product Objective

Give Unlimitail a governed, closed-loop measurement capability that ties retail-media ad exposure to
actual retailer sales — starting with attribution/ROAS reporting (MVP) and extending to statistically
valid incrementality once a control-group methodology is confirmed.

## Proposed MVP

Non-incremental closed-loop measurement: ingest exposure/spend/T-Log data, match ad interactions to
purchases within a 14-day attribution window ("last touch"), compute Impressions/Clicks/CTR/Conv.
Rate/Cost/Attributed Sales/ROAS/Reach/CPM/CPC, and expose them via a self-serve, RLS-enforced reporting
UI to ~100 internal Unlimitail users. This mirrors DOC01's own explicit MVP framing ("incremental ROAS
vs. control will not be part of the MVP").

## Top Confirmed Requirements

1. Consented-only ad-interaction ingestion (non-negotiable privacy constraint).
2. Daily T-Log ingestion via the existing NIQ interface (reuses onboarded Insights Premium data).
3. Row-Level Security: Retailer sees all data; Advertiser/CPG sees only its own.
4. Dual-clock attribution reporting: partner-measured and Unlimitail-measured values shown side by
   side, never blended.
5. Daily join/match-rate monitoring against four published floors (Product 99%, Shopper 95%, Session
   90%, Feed integrity 100%), with below-floor KPIs flagged rather than reported.

## Top 5 Decisions Required

1. **DEC-001 — Control-group architecture** (platform withholds control pre-export vs. partner
   separates control vs. ghost-bid/PSA hybrid). Blocks all incrementality KPIs (F5/F6/F7). No option
   is recommended here — evidence does not support choosing one.
2. **DEC-002 — Phase 1 vs. Phase 2 placement (CF-008).** Four documents place Retail Media Measurement
   in Phase 2 (one naming an actual "Phase 2 SOW"); one contract table places it in Phase 1. Blocks
   realistic delivery sequencing for the whole program.
3. **DEC-003 — ROAS cost basis** (advertiser cost vs. retailer cost).
4. **DEC-004 — PROGRAMME id adoption** by the activation partner, needed for cross-channel
   reconciliation.
5. **Activation/DSP partner identity** — no document names Unlimitail's actual partner; DOC01 uses
   TheTradeDesk only as an illustrative template. Every integration requirement (FR-016–FR-022) is
   provisional until this is confirmed.

## Top 5 Risks

1. **RISK-003 (High)** — No atomic transaction/Tlog table was found in any of the 3 real physical
   schemas reviewed; this blocks roughly 25 of 43 KPIs until a source table is confirmed or supplied.
2. **RISK-001 (High)** — Control-group methodology undecided; blocks all incrementality reporting.
3. **RISK-002 (High)** — Phase placement (CF-008) unresolved; blocks program-level sequencing/estimation.
4. **RISK-004 (Medium)** — Ghost-bid/PSA (the partner's preferred incrementality option, per DOC03) may
   not be technically supported by the activation partner's ad server.
5. **RISK-005 (Medium-High)** — Join/match rates falling below published floors could silently degrade
   every rate-based KPI if monitoring is not implemented before go-live.

## Major Dependencies

- Confirmation of the activation/DSP partner's identity and technical capabilities.
- Access-tier confirmation for the activation partner's BigQuery Core Dataset (vs. Reporting Datamart).
- NIQ Activate Product Owner assignment (unassigned at the time of the handover document).
- Physical confirmation/location of an atomic Tlog/transaction source table.

## Readiness Assessment

**Not ready to commit to a delivery date.** The requirements for the non-incremental MVP (Tier 1/2
KPIs, reporting UI, RLS, governance gates) are well evidenced and could proceed once the Tlog-table gap
(RISK-003) and partner identity (ASM-001) are resolved. Incrementality features (Tier 3 KPIs) cannot be
estimated at all until DEC-001 is resolved — this should be treated as a separate, later-sequenced
release, not folded into the MVP timeline.

## Recommended Next Steps

1. Obtain the "Phase 2 SOW" (or equivalent authoritative contract artifact) to resolve DEC-002/CF-008.
2. Request the physical DDL for whatever schema actually holds atomic transaction data (likely an
   unsupplied SingleStore/Online schema) to resolve RISK-003.
3. Confirm the activation/DSP partner's name and technical capabilities (ghost-bid/PSA support in
   particular) to unblock DEC-001 and DEC-004.
4. Assign a named NIQ Activate Product Owner for this engagement.
5. Once 1–4 are resolved, sequence delivery per [02_Retail_Media_Closed_Loop_PRD.md](02_Retail_Media_Closed_Loop_PRD.md)
   Section 24 (Foundation → Tier 1/2 MVP → Incrementality → External access).

---

*This summary is intentionally conservative: every "top" item above is drawn directly from the
Decision, Assumption, and Risk Register ([07_Decision_Assumption_Risk_Register.md](07_Decision_Assumption_Risk_Register.md))
and the Requirement Evidence Register ([03_Requirement_Evidence_Register.md](03_Requirement_Evidence_Register.md));
no new facts are introduced here.*
