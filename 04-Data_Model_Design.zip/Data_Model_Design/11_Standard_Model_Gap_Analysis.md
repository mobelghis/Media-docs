# 11 — Standard Activate Data Model vs. Canonical Model: Gap Analysis

**Purpose:** Map NIQ Activate's standard product data interface/schema (as sent by the user,
2026-09-13) against the canonical model proposed in [03_Canonical_Data_Model.md](03_Canonical_Data_Model.md),
which was built bottom-up from the 7 Unlimitail sample-report files. This closes several
PARTIAL/NOT AVAILABLE gaps with a real product schema, while surfacing new gaps and one
significant scope-relevant finding for CF-008/OQ01.

**Sources analyzed:**
- `Source files/Activate Data Interface v8.0.xlsx` — the standard, versioned client-onboarding data
  contract for Activate: 11 sheets (Modules Overview, Insights, Promo, Personalization, Supply
  Chain, Assortment, Activate Lite, Readme, Data Configs, Policies), covering every file/field a
  retailer can send into Activate across all modules (not Unlimitail-specific).
- `Source files/Activate DB Schema.xlsx` — internal physical table inventory (SingleStore `cv_r_*`
  tables + Online_CV_Retailer/Online_All/Promo schemas), with per-table module tagging and
  deprecated/legacy annotations.
- `Source files/cv-retailer-schema.sql`, `cv-campaigns-schema.sql`, `cv-retailerrprt-schema.sql` —
  **actual physical DDL** for the `CV_Retailer` (reference/master data), `CV_Campaigns`
  (Personalization waves/offers/coupons), and `CV_RetailerRprt` (pre-computed report tables)
  schemas. These are the ground-truth column-level definitions behind the `cv_r_*` names listed in
  the DB Schema workbook, added by the user specifically to correct/ground §2's store/shopper
  mapping (see §7).
- `Source files/offers-mgmt-entity-relationship.md` — entity-relationship documentation for the
  Personalization/Offers Management module (Wave/Offer/Coupon Bank/Control Group), authored by the
  user for a separate UI/UX migration effort.
- `Source files/nga-poc-all-table-ddls.md` — **staging tables for a different, unrelated
  proof-of-concept** (per user instruction). `nga_*`/`dh_*` tables are **excluded from this gap
  analysis and from the canonical model** — they are not part of Activate's core or Unlimitail's
  scope.

**Nature of these sources:** Unlike DOC01-15 (client-specific engagement documents), these files
describe the **generic, all-clients NIQ Activate product** — the target system Unlimitail's
data will actually be loaded into. They are the ground truth for "what fields does Activate
support," not "what Unlimitail has confirmed to send." Treat every mapping below as **schema
capability**, not confirmed Unlimitail data availability (that remains governed by
[02_Input_Data_Catalog.md](02_Input_Data_Catalog.md) and the Knowledge Base's onboarding-scope
findings).

---

## 1. Module Scope Relevant to Unlimitail

Per `Knowledge_Base/Data Model.md`, Unlimitail's confirmed Phase 1 is **Insights Premium** only
(Event Analyzer + Assortment Distribution reports, ~100 internal users). Cross-referencing against
"Modules Overview": Insights is the only module both **confirmed contracted** and **directly
relevant** to the 7 sample reports analyzed in this workspace. Personalization, Supply Chain,
Promo, and Assortment are documented below for completeness (they explain fields *referenced but
unused* in the sample reports, e.g. Coupon_Flag/Promo_Flag columns sitting unused in WB1/WB3/WB4/WB5)
but are **out of confirmed scope** — do not model them as active requirements without a
corresponding FR-C/contract confirmation.

---

## 2. Field-Level Mapping — Core Insights Files → Canonical Model

| Standard Interface File | Key Fields | Canonical Model Target | Status |
|---|---|---|---|
| Tlog Sales | Receipt_ID, Store_ID, Shopping_Datetime, Product_ID, Purchase_Ref_ID, Quantity, Sale_Price, Discount, Tax, Discount_Tax, Margin | `fact_transaction_line` (Tier 1, target-state) | **Resolves gap**: this is the exact atomic-grain schema our model proposed as NOT AVAILABLE (03 §9) — confirms the field list; population still depends on Unlimitail actually sending this file (still not seen in any of the 7 sample reports, which only show pre-aggregated exports). |
| Tlog Sales | Promo_Flag, Promo_Num, Promo_Name, Coupon_Flag, Coupon_Item_ID, Coupon_Name, Vendor, UPC, Channel, Attribute 1...30 | `fact_transaction_line` extension columns; `dim_promotion`, `dim_media_channel`(?) | **New** — confirms Promo/Coupon linkage happens at the transaction-line grain, not a separate join table as we'd tentatively modeled; also explains WB1/WB3/WB4/WB5's unused-looking Promo/Coupon columns as standard (but Unlimitail-unpopulated) schema fields. |
| Store Master | Store_ID, Store_Name, Store_Status, Store_Format_Level_1-4, Store_Banner_Level_1-4, Store_Channel_Level_1-4, Store_Geo_Level1-4 | `dim_store` (our abstraction) | **Confirms & extends, corrected in §7**: the *ingestion interface* exposes named 4-level hierarchies, but the *actual physical schema* (`CV_R_STORES_TREE`/`CV_R_STORE_PARENTS`) implements store hierarchy as a **generic, unnamed, up-to-6-level parent/child tree** per `HIERARCHY_TYPE`, not 4 fixed named levels. **Recommend modeling `dim_store` hierarchy the same way our `dim_product_hierarchy` already models product hierarchy (generic parent-child bridge), not as 4 flat columns.** See §7 for the full correction. |
| Product Catalog | Product_ID, Section/Subcategory/Category/Department (ID+Description each), CPG_Supplier_ID/Description, Brand_ID/Description, UPC, Private_Label_Flag | `dim_product`, `dim_product_hierarchy`, `dim_brand`, `dim_supplier` | **Confirms, refined in §7**: the interface shows a 4-level *product* hierarchy (Section→Subcategory→Category→Department), and the physical schema (`CV_R_CATALOG_TREE`/`CV_R_CATALOG_PARENTS`) confirms this is a **generic parent-child tree, levels 0-5** (0=Product/SKU up to 5=Catalog root) — separate and independent from a **distinct brand hierarchy tree** (`CV_R_CPG_BRAND_CATALOG_TREE`/`CV_R_BRAND_CATALOG_FLAT`: Brand→Sub-Brand→High-Brand→CPG, 4 levels). **Action: reconcile 03 §5 `dim_product_hierarchy` (currently modeled as 6-level from WB1/WB3 Lexique) against this — confirms two independent hierarchies (product tree + brand tree) rather than one 6-level tree; the extra levels seen in Unlimitail's sample reports are likely the brand tree's levels folded into the product Lexique, not a standard-schema conflict.** |
| Shoppers | Shopper_ID, Household_ID, Join_Date, Year_of_Birth, Gender, Accumulated_Points, Delivery_Channels | `dim_customer` (our abstraction) | **Resolves gap, corrected in §7**: exact ingestion-interface schema for our NOT AVAILABLE `dim_customer`. The physical schema splits this further: `CV_R_SHPR_DESCRIPTION` (shopper master, keyed by `RETAILER_LOYALTY_ID`) is separate from `CV_R_SHPR_IDENTIFYING_CARD` (card→shopper bridge) and from `CV_R_SHPR_CUSTOM_SEGMENTS`/`CV_R_SHPR_BRAND_CUSTOM_SEGMENTS` (Type-2-style attribute assignment tables). `Year_of_Birth` (not full DOB) and masked/tokenized IDs are **mandatory GDPR-driven field designs in the standard product itself**, not something we need to invent for Unlimitail. |
| Purchase Reference (Cards) | Purchase_Ref_ID, Shopper_ID, Is_Current, Effective_From/To, Status | Bridge between transaction-level identifier and `dim_customer` | **New, confirmed in §7** — `CV_R_SHPR_IDENTIFYING_CARD` is exactly this bridge in the physical schema (`IDENTIFYING_CARD_ID` ↔ `CV_SHOPPER_ID`, one shopper can have multiple cards). Our model had collapsed these into one `customer_key` — **recommend adding a `dim_card`/bridge table distinct from `dim_customer`**, consistent with both the ingestion interface and the physical schema. |
| Shopper Custom Segments | Shopper_ID, Segment_ID, Effective_From, Segment_Value_Code/Description | `bridge_customer_segment_assignment`, `dim_customer_segment` | **Resolves gap**: our bridge table's grain/columns are validated almost exactly; this closes the structural (not content) part of the NOT AVAILABLE status. |
| Attributes Metadata / Product-Store Attributes | Attribute_Type, Attribute_Code, Attribute_Value_Code/Description | Generic EAV-style attribute extension pattern | **New pattern** — the standard product uses a **generic attribute/metadata extension mechanism** (up to 30 custom `Attribute N` columns per file, described via a metadata table) rather than named columns per custom field. **Recommend documenting this as the standard mechanism for any "TBD/custom" dimension our model currently treats as a fixed column** (e.g. RFM/segment values, product attributes referenced in WB2/WB3 Lexique but never enumerated — OQ #8). |

---

## 3. Confirmed / Resolved Prior Gaps

- **`dim_promotion` (was NOT AVAILABLE)** — now fully specified via the Promo module's `Promo Event` /
  `Promo Product` / `Promo Store` files (Promo_Number, Promo_Type, Promo_Channel, Promo_Condition,
  Promo_Mechanism, Promo_Funding_Source, etc.). Schema gap is closed; **population gap remains**
  (Unlimitail has not confirmed sending Promo files — Phase 1 is Insights Premium only).
- **`dim_customer` (was NOT AVAILABLE)** — schema now known (see §2). Population still blocked
  pending Unlimitail's actual Shoppers/Cards file delivery (consistent with Knowledge Base's
  existing finding that no atomic customer file has been seen in any of the 15 Unlimitail
  documents either).
- **Loyalty Tier / RFM segmentation values (OQ #8, partially)** — the Readme sheet's "Activate
  Out-of-the-Box Segments" table defines a concrete, standard **Loyalty Tier** taxonomy (Platinum /
  Gold / Silver / Bronze / Occasional / Gone / None, computed via an RFM model) plus ~15 other
  standard segment dimensions (Discount Sensitivity, Same Store, Same Customer, Value Tier,
  Recency, Visits Frequency, Churn Propensity, Wallet Share, Marketing Tier, etc.). **This
  resolves part of OQ #8 for the standard/default segmentation** — but WB3's Lexique-named
  segment families (Lifestage, Structurelle, Consostyle, Promotion, RFM) do not exactly match
  these standard names, so **Unlimitail's segments may be custom, not out-of-the-box** — flag as a
  new sub-question (see §5 below).
- **GDPR/PII handling approach** — the Policies sheet **confirms, as a standard product design (not
  an assumption we made)**: Shopper_ID is masked/tokenized, DOB is sent as Year_of_Birth only, and
  there is a formal "Shopper Removal Policy" / Customer Removal Interface (`Removal_Policy`: A =
  history-only erasure keeping the entity for personalization, F = full erasure) for GDPR
  right-to-erasure compliance. **This directly satisfies the privacy/consent requirement flagged as
  a first-class concern in the Data Engineer agent's constraints — cite this file as the standard
  mechanism rather than proposing a bespoke one.**

## 4. New Entities Not Yet in Canonical Model (Out of Confirmed Phase 1 Scope)

The Personalization, Supply Chain, and Assortment modules introduce entities with no equivalent
anywhere in `03_Canonical_Data_Model.md`, because none of the 7 sample reports exercise them:
**Coupons, Coupon_Product, Coupon_Engagement, Allocation (Output)** (Personalization);
**Store/DC Inventory, Distribution Center, Purchase Order, Store Return, Demand/Order Forecast,
Store-DC Relation** (Supply Chain); **Product DTG, Product OOS, Planogram** (Assortment). **Do not
add these to the canonical model** unless a Knowledge Base requirement candidate (FR-C###)
explicitly calls for them — they are documented here only so future document intake can quickly
recognize these field names as standard-product (not Unlimitail-invented) terminology.

## 5. Critical Finding: No Campaign/Retail-Media Exposure Interface in the Standard Product

**This is the most significant finding from these two files for the overall engagement.** Neither
`Activate Data Interface v8.0.xlsx` (11 sheets, all modules) nor the DB Schema's active table list
contains a standard **campaign, media exposure, DSP-integration, or retail-media-measurement**
file/table — the kind of data underlying WB2 and deck7 (`agg_campaign_metric`, `dim_campaign`,
`dim_media_channel`, F1-F9 KPIs in [04](04_KPI_Lineage_and_Formulas.md)). The DB Schema sheet
explicitly tags the only two related tables as:
- `cv_r_campaign_interactions_all` — module: **"deprecated? | Retail Media - POC"**
- `cv_r_da_digital_activities_all`, `cv_r_da_domains_dim_all`, `cv_r_da_page_products_dim_all` —
  module: **"Retail Media Legacy | FreshDirect Only"**

**Implication:** Retail media / closed-loop campaign measurement (WB2, deck7, and the whole
Knowledge Base CF-008 "Phase 1 or Phase 2" debate) is **not a current, generally-available,
productized Activate module** — it exists only as a deprecated proof-of-concept and a legacy,
single-client (FreshDirect) implementation. This is independent, product-side corroboration for
the Phase 2 side of CF-008 (DOC02/DOC06/DOC07/DOC09's framing), and it also explains **why OQ01
(lift/matching methodology) and OQ #2 (ROAS formula) were never documented anywhere** — the
standard product itself has no shipped, general-purpose schema or methodology for this capability
yet. **Recommend elevating this as new evidence under CF-008 in `Knowledge_Base/Open Questions.md`
and flagging it to the Product Owner agent — it changes CF-008 from "ambiguous contract language"
to "the product doesn't have a general-availability feature for this yet regardless of contract
phase."**

## 6. Recommended Next Steps

Superseded — see §8.

## 7. Correction: Real Physical Schema (CV_Retailer / CV_Campaigns / CV_RetailerRprt)

**The ingestion-interface sheet (§2) describes what a retailer *sends*; it is not the physical
schema Activate stores data in.** The user supplied the actual DDL
(`cv-retailer-schema.sql`, `cv-campaigns-schema.sql`, `cv-retailerrprt-schema.sql`) plus
`offers-mgmt-entity-relationship.md`, correcting an error in §2/§3 above: **there is no `dim_store`
or `dim_shopper` table in the real product** — those were this document's own abstraction-layer
names, not the product's. The real, physical entities are:

| Concept | Real table(s) | Grain / structure |
|---|---|---|
| **Store master** | `CV_R_RTLR_POS_DESCRIPTION` | One row per POS (point-of-sale/store), PK `CV_POS_ID`. Carries address/geo, `CHANNEL`, `REGION`, `FORMAT`, and up to 8 generic `POS_DEMOGRAPHIC_n` columns — **not** the 4 named hierarchy levels shown in the ingestion interface. |
| **Store hierarchy** | `CV_R_STORES_TREE` + `CV_R_STORE_PARENTS`, queried via the flattened view `cv_r_store_parents_flat_view` | Generic, unnamed parent-child tree keyed by `HIERARCHY_TYPE` (a retailer can define multiple hierarchy *types* — e.g. Banner, Format, Channel — each with its own tree), **0-7 levels**, flattened in `CV_R_STORE_PARENTS` (child/parent + level pairs) for fast rollups. `cv_r_store_parents_flat_view` is the read-optimized flat view over this raw table, confirmed by the user as the store-side counterpart to `cv_r_product_parents_flat_view` (the LEGACY-REPLICA table in `nga-poc-all-table-ddls.md` that flattens `CV_R_CATALOG_PARENTS`/`CV_R_ALL_PARENTS` — note that doc's own Summary table omits the store equivalent, so this is user-supplied, not document-sourced). This is structurally identical to how product hierarchy works (see below), not 4 fixed named columns. |
| **Shopper master** | `CV_R_SHPR_DESCRIPTION` | One row per shopper, PK `RETAILER_LOYALTY_ID` (not `CV_SHOPPER_ID`, which is a secondary indexed column) — confirms shopper identity is retailer-loyalty-ID-anchored. |
| **Card ↔ Shopper bridge** | `CV_R_SHPR_IDENTIFYING_CARD` | `IDENTIFYING_CARD_ID` (unique) → `CV_SHOPPER_ID`, `STATUS`. Confirms §2's Purchase Reference (Card) finding at the physical-schema level: **one shopper can have multiple cards**, each independently active/inactive. |
| **Shopper segment/attribute assignment** | `CV_R_SHPR_CUSTOM_SEGMENTS`, `CV_R_SHPR_BRAND_CUSTOM_SEGMENTS` | EAV-style: `(CV_SHOPPER_ID, ATTRIBUTE_ID, ATTRIBUTE_VALUE_ID)` with `CREATION_TIMESTAMP`/`UPDATE_TIMESTAMP` — confirms the generic attribute-metadata mechanism found in §2 is implemented the same way physically, and that brand-level segments are a **separate** table from retailer-level segments (finer grain than our current `bridge_customer_segment_assignment` draft). |
| **Shopper GDPR removal** | `CV_R_SHPR_REMOVAL` | `RETAILER_LOYALTY_ID`, `STATUS` (R-running/I-ignored/C-completed) — the physical implementation of the Customer Removal Interface described in §3. |
| **Product hierarchy** | `CV_R_CATALOG_TREE` + `CV_R_CATALOG_PARENTS` (+ `CV_R_ALL_PARENTS` cross-hierarchy view) | Generic parent-child tree, `PRODUCT_TREE_LEVEL` 0 (SKU) through 5 (catalog root) — **independent from brand**. |
| **Brand hierarchy** | `CV_R_CPG_BRAND_CATALOG_TREE` / `CV_R_BRAND_CATALOG_FLAT` | **Separate tree**: Brand → Sub-Brand → High-Brand → CPG (4 levels), joined to products via `CV_R_BRAND_BENCHMARKS`/flat tables, not nested inside the product tree. |
| **Control groups (Personalization)** | `CV_R_CMP_CONTROL_GROUPS` (schema: `CONTROL_GROUP_ID`, `CV_WAVE_ID`, `CV_TARGETING_GROUP_ID`) | Confirms a **campaign/coupon-wave-scoped control-group mechanism exists today** — but it lives in `CV_Campaigns` (Personalization/offer allocation), not in a retail-media/ad-campaign schema. This is a different "control group" than the media-exposure lift control group implied by OQ01/OQ #2 — **do not conflate the two**; this table supports coupon holdout groups per allocation wave, not ad-exposure vs. non-exposure panels. |
| **Campaign/Offer/Coupon Bank model** | `CV_R_CMP_WAVES` (Campaign *and* Offer Bank — same table, differentiated by `waveType`), `CV_R_CMP_OFFERS`, `CV_R_CMP_COUPON_MASTER`, `CV_R_CMP_REF_COUPONS_BANK` | Per `offers-mgmt-entity-relationship.md`: Marketing Policy (`WaveTemplate`) → Campaign (`Wave`) → Offer → Coupon, with an "Offer Bank" being just a `Wave` flagged `waveType=offerBank`. This is Personalization-module architecture (out of Unlimitail's confirmed Phase 1 Insights-only scope) but is now documented ground truth if Personalization is ever scoped in. |

**Out of scope, explicitly excluded:** `nga_*`/`dh_*` tables in `nga-poc-all-table-ddls.md` are
**staging tables for a separate, unrelated proof-of-concept** (per user instruction) — not part of
Activate's product schema or Unlimitail's engagement. They are not referenced anywhere in this
gap analysis or the canonical model.

**Corrected recommendation (supersedes §2's store/product-hierarchy language):** Model `dim_store`
and `dim_product_hierarchy`/`dim_brand` the same way — a **generic parent-child hierarchy bridge
table per hierarchy type**, not fixed named-level columns — since that is how the real product
implements both store and product/brand hierarchies. Treat the Insights Data Interface's "Level
1-4" naming as a **display/labeling convention on top of** this generic tree, not the underlying
storage structure.

## 8. Recommended Next Steps

1. Update `03_Canonical_Data_Model.md` §5: model `dim_store` and `dim_product_hierarchy`/`dim_brand`
   as generic parent-child hierarchy bridges (per §7), not fixed named-level columns; split
   `dim_customer`/`dim_card` per §2/§7's Purchase Reference / Identifying Card finding; add a
   distinct brand-hierarchy bridge separate from the product hierarchy.
2. Update `07_Proposed_DDL.sql` and `09_Data_Quality_Rules.md` once the above structural changes
   are confirmed with the user (not yet applied — pending your go-ahead per the "chat about gaps"
   framing of this request).
3. Log the §5 finding into `Knowledge_Base/Open Questions.md` (CF-008) since it is genuinely new,
   product-side evidence, not just another Unlimitail document.
4. Treat §4's new entities as reference-only unless/until a requirement candidate calls for them.

---

## Recap

- **Entities/KPIs affected:** `dim_customer`/`dim_card`, `dim_promotion`, `dim_customer_segment`,
  `dim_store`, `dim_product_hierarchy`/`dim_brand` (all four now modeled as generic parent-child
  hierarchy/bridge structures per §7), plus a new implicit finding on `dim_campaign`/
  `agg_campaign_metric`'s product maturity (§5).
- **Design decisions & rationale:** Resolved 3 prior PARTIAL/NOT AVAILABLE schema gaps using the
  real product interface (§2/§3); corrected an initial over-simplification (named 4-level
  hierarchies) once the actual physical DDL was provided — store and product/brand hierarchies are
  both generic parent-child trees, not fixed columns (§7). Confirmed the Personalization module's
  control-group mechanism (`CV_R_CMP_CONTROL_GROUPS`) is unrelated to retail-media lift measurement
  — flagged so the two are not conflated in future OQ01 work.
- **Data quality / privacy considerations:** Standard product already implements GDPR-compliant
  tokenization, DOB minimization, and a formal erasure/removal interface (`CV_R_SHPR_REMOVAL`) — no
  new privacy gap introduced, existing assumptions were directionally correct.
- **Confidence:** High on schema-capability mappings for entities backed by the actual DDL (§7).
  Medium on the §5 campaign-maturity interpretation (inferred from table-comment annotations, not
  an explicit product roadmap statement) — recommend confirming with NIQ Activate product team
  before treating as final.
