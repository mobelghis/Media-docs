-- =============================================================================
-- 08_Sample_KPI_Queries.sql
--
-- Sample SQL implementing every CONFIRMED/INFERRED KPI from 04_KPI_Lineage_and_Formulas.md against
-- the schema in 07_Proposed_DDL.sql. Queries are written against the Tier-1 atomic facts
-- (fact_transaction_line / fact_transaction_header) where the KPI is in principle atomically
-- recomputable, with an equivalent Tier-2 landing-fact (agg_report_metric / agg_campaign_metric)
-- query shown alongside wherever the atomic tables are NOT AVAILABLE today, so the same KPI can be
-- read from what actually exists in the reviewed files right now.
--
-- Deliberately NOT included: any query for F5 (Incremental Revenue/Quantity/Shoppers/Buyer Rate),
-- F6 (ROAS), or F7 (P-values) — these remain UNVERIFIED/BLOCKING per 04_KPI_Lineage_and_Formulas.md
-- and 06_Open_Questions.md Blocking #2/#3/#4. No formula is invented for them here.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- A1. Revenue (CA) — atomic (Tier 1, NOT AVAILABLE) vs landing (Tier 2, AVAILABLE)
-- -----------------------------------------------------------------------------

-- Atomic (target state):
SELECT
    d.calendar_date,
    p.ean,
    SUM(f.line_revenue) AS revenue
FROM fact_transaction_line f
JOIN dim_date d ON d.date_key = f.date_key
JOIN dim_product p ON p.product_key = f.product_key
GROUP BY d.calendar_date, p.ean;

-- Landing / today:
SELECT
    m.report_run_id,
    p.ean,
    m.value_analyse AS revenue
FROM agg_report_metric m
JOIN cfg_kpi_definition k ON k.kpi_id = m.kpi_id AND k.kpi_code = 'A1'
LEFT JOIN dim_product p ON p.product_key = m.product_key
WHERE m.is_total_row = FALSE;   -- never sum a mix of detail + Total rows (03 §3)

-- -----------------------------------------------------------------------------
-- A2. Units (UVC)
-- -----------------------------------------------------------------------------

SELECT d.calendar_date, p.ean, SUM(f.quantity) AS units
FROM fact_transaction_line f
JOIN dim_date d ON d.date_key = f.date_key
JOIN dim_product p ON p.product_key = f.product_key
GROUP BY d.calendar_date, p.ean;

-- -----------------------------------------------------------------------------
-- A3. Transactions / Receipts (basket count)
-- -----------------------------------------------------------------------------

SELECT d.calendar_date, COUNT(DISTINCT f.transaction_id) AS transaction_count
FROM fact_transaction_header f
JOIN dim_date d ON d.date_key = f.date_key
GROUP BY d.calendar_date;

-- -----------------------------------------------------------------------------
-- A4. Customers / Shoppers (distinct purchasers)
-- -----------------------------------------------------------------------------

SELECT d.calendar_date, COUNT(DISTINCT f.customer_key) AS customer_count
FROM fact_transaction_header f
JOIN dim_date d ON d.date_key = f.date_key
WHERE f.customer_key IS NOT NULL
GROUP BY d.calendar_date;

-- -----------------------------------------------------------------------------
-- A5. Revenue per Customer  =  A1 / A4
-- -----------------------------------------------------------------------------

SELECT
    d.calendar_date,
    SUM(fh.total_revenue) / NULLIF(COUNT(DISTINCT fh.customer_key), 0) AS revenue_per_customer
FROM fact_transaction_header fh
JOIN dim_date d ON d.date_key = fh.date_key
GROUP BY d.calendar_date;

-- -----------------------------------------------------------------------------
-- A6. Frequency (Fréquence)  =  A3 / A4  (purchase visits per customer)
-- -----------------------------------------------------------------------------

SELECT
    d.calendar_date,
    COUNT(DISTINCT fh.transaction_id)::DECIMAL / NULLIF(COUNT(DISTINCT fh.customer_key), 0) AS frequency
FROM fact_transaction_header fh
JOIN dim_date d ON d.date_key = fh.date_key
GROUP BY d.calendar_date;

-- -----------------------------------------------------------------------------
-- A7. Average Basket (Panier moyen)  =  A1 / A3
-- -----------------------------------------------------------------------------

SELECT
    d.calendar_date,
    SUM(fh.total_revenue) / NULLIF(COUNT(DISTINCT fh.transaction_id), 0) AS avg_basket
FROM fact_transaction_header fh
JOIN dim_date d ON d.date_key = fh.date_key
GROUP BY d.calendar_date;

-- Independently recomputed sample verified in Report_Analysis_Catalog.md:
--   12,931,233.30 / 2,203,942 ~= 5.867  (Panier moyen, WB1)

-- -----------------------------------------------------------------------------
-- A8. Units per Basket (UVC par panier)  =  A2 / A3
-- -----------------------------------------------------------------------------

SELECT
    d.calendar_date,
    SUM(fl.quantity) / NULLIF(COUNT(DISTINCT fl.transaction_id), 0) AS units_per_basket
FROM fact_transaction_line fl
JOIN dim_date d ON d.date_key = fl.date_key
GROUP BY d.calendar_date;

-- -----------------------------------------------------------------------------
-- A9. Average Price (Prix moyen)  =  A1 / A2
-- -----------------------------------------------------------------------------

SELECT
    d.calendar_date,
    p.ean,
    SUM(fl.line_revenue) / NULLIF(SUM(fl.quantity), 0) AS avg_price
FROM fact_transaction_line fl
JOIN dim_date d ON d.date_key = fl.date_key
JOIN dim_product p ON p.product_key = fl.product_key
GROUP BY d.calendar_date, p.ean;

-- -----------------------------------------------------------------------------
-- B1. Promotion Revenue Share  =  SUM(revenue WHERE promotion_key IS NOT NULL) / A1
-- -----------------------------------------------------------------------------

SELECT
    d.calendar_date,
    SUM(CASE WHEN fl.promotion_key IS NOT NULL THEN fl.line_revenue ELSE 0 END)
        / NULLIF(SUM(fl.line_revenue), 0) AS promo_revenue_share
FROM fact_transaction_line fl
JOIN dim_date d ON d.date_key = fl.date_key
GROUP BY d.calendar_date;

-- -----------------------------------------------------------------------------
-- B2. Numeric Distribution (DN)  =  Selling Stores / Total Stores
-- -----------------------------------------------------------------------------

-- Atomic (target state):
SELECT
    p.ean,
    COUNT(DISTINCT CASE WHEN a.is_ranged_flag THEN a.store_key END)::DECIMAL
        / NULLIF(COUNT(DISTINCT a.store_key), 0) AS numeric_distribution
FROM fact_product_store_availability a
JOIN dim_product p ON p.product_key = a.product_key
GROUP BY p.ean;

-- Independently recomputed sample verified in Report_Analysis_Catalog.md: 1373 / 4255 = 0.3227

-- -----------------------------------------------------------------------------
-- C1. Evolution %  =  (analyse - comparaison) / comparaison
-- -----------------------------------------------------------------------------

SELECT
    m.report_run_id,
    k.kpi_code,
    m.value_analyse,
    m.value_comparaison,
    (m.value_analyse - m.value_comparaison) / NULLIF(m.value_comparaison, 0) AS evolution_pct
FROM agg_report_metric m
JOIN cfg_kpi_definition k ON k.kpi_id = m.kpi_id
WHERE m.is_total_row = FALSE;

-- Independently recomputed sample verified in Report_Analysis_Catalog.md:
--   (12,931,233.30 - 11,884,336.71) / 11,884,336.71 = 0.08809

-- -----------------------------------------------------------------------------
-- C2. Evolution (pts)  =  (ratio1 - ratio2) * 100   -- percentage-point delta, NOT a relative %
-- -----------------------------------------------------------------------------

SELECT
    m.report_run_id,
    (m.value_analyse - m.value_comparaison) * 100 AS evolution_pts
FROM agg_report_metric m
JOIN cfg_kpi_definition k ON k.kpi_id = m.kpi_id AND k.kpi_code = 'C2';

-- Independently recomputed sample verified in Report_Analysis_Catalog.md:
--   (0.99953 - 1.00171) * 100 = -0.218 pts  (DN Evolution)

-- -----------------------------------------------------------------------------
-- E1. Customer Movement Classification (Constants / Gagné / Perdu)
-- -----------------------------------------------------------------------------

-- Atomic (target state) — classification is READ from the pre-computed fact, not re-derived here,
-- since the exact eligibility rule for "Constants" (customer purchased in both periods, WB1 sense)
-- vs. "store had no material format change" (WB3 sense) must never be conflated (review_findings.md §1.3):
SELECT
    c.customer_id,
    pl.product_list_name,
    s.movement_status
FROM fact_customer_period_status s
JOIN dim_customer c ON c.customer_key = s.customer_key
JOIN dim_product_list pl ON pl.product_list_id = s.product_list_id
WHERE s.period_pair_id = :period_pair_id;

-- -----------------------------------------------------------------------------
-- F1. Conversion Rate  =  Shoppers / Exposable group   (Business Equation, deck7 slide 9, CONFIRMED)
-- -----------------------------------------------------------------------------

SELECT
    m.campaign_key,
    SUM(CASE WHEN k.kpi_code = 'A4' THEN m.value END)
        / NULLIF(SUM(CASE WHEN k.kpi_code = 'F_EXPOSABLE_GROUP' THEN m.value END), 0) AS conversion_rate
FROM agg_campaign_metric m
JOIN cfg_kpi_definition k ON k.kpi_id = m.kpi_id
WHERE m.is_total_row = FALSE
GROUP BY m.campaign_key;

-- -----------------------------------------------------------------------------
-- F2. Reach / Reach Rate
-- -----------------------------------------------------------------------------

SELECT
    m.campaign_key,
    m.media_channel_key,
    m.value AS reach
FROM agg_campaign_metric m
JOIN cfg_kpi_definition k ON k.kpi_id = m.kpi_id AND k.kpi_code = 'F2'
WHERE m.is_total_row = FALSE;

-- -----------------------------------------------------------------------------
-- F8. Loyal Shopper Rate  -- NOTE: two discrepant rule variants preserved side by side (06 Important #11)
-- -----------------------------------------------------------------------------

SELECT
    customer_key,
    product_list_id,
    period_id,
    rule_source,           -- 'WB2_gt2' (>2 receipts, i.e. >=3) vs 'deck6_gte2' (>=2 receipts)
    is_loyal_shopper_flag
FROM fact_loyal_shopper
WHERE product_list_id = :product_list_id
  AND period_id = :period_id;

-- -----------------------------------------------------------------------------
-- F9. New vs Returning Shoppers  =  Total Shoppers = New Shoppers + Returning Shoppers (CONFIRMED)
-- -----------------------------------------------------------------------------

SELECT
    f.campaign_key,
    COUNT(*) FILTER (WHERE f.is_new_shopper_flag)       AS new_shoppers,
    COUNT(*) FILTER (WHERE NOT f.is_new_shopper_flag)    AS returning_shoppers,
    COUNT(*)                                              AS total_shoppers
FROM fact_new_shopper_flag f
GROUP BY f.campaign_key;

-- -----------------------------------------------------------------------------
-- Campaign lift INPUTS ONLY (no lift formula) — feeds an external/manual methodology, per 06 Blocking #2
-- -----------------------------------------------------------------------------

SELECT
    m.campaign_key,
    m.period,
    m.group_assignment,   -- Control / Exposed
    k.kpi_code,
    m.value
FROM agg_campaign_metric m
JOIN cfg_kpi_definition k ON k.kpi_id = m.kpi_id
WHERE m.is_total_row = FALSE
  AND k.kpi_code IN ('A1', 'A2', 'A4')   -- Revenue/Units/Shoppers by Control vs Exposed, no incremental calc applied
ORDER BY m.campaign_key, m.period, m.group_assignment;
