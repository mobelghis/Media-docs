# 01 — Executive Summary

**Prepared as:** a senior data architect / analytics engineer's canonical data model design for a
future rebuild of the retail-performance and retail-media-measurement reporting currently produced
via Memory 360 (Excel) and Unlimitail (PowerPoint) exports for Carrefour.

**Scope of this deliverable set:** documentation and design artifacts only — no application code, no
implementation of any live pipeline, and critically, **no invented business formula for any
BLOCKING/UNVERIFIED KPI** (lift/incrementality, ROAS, p-values, Ecart vs Benchmark, Indice, VMH, DV).

---

## 1. What Was Reviewed

Seven files across two report families, fully cataloged in `Report_Analysis_Catalog.md` (1699 lines)
and audited for internal consistency in [review_findings.md](review_findings.md):

- **Family A — Retail/customer performance** (French vocabulary: CA, UVC, Panier, Client, Encarté):
  `NIQ_Customer Loyalty analysis.xlsx` (WB1), `NIQ_Performance analysis.xlsx` (WB3),
  `NIQ_Product_Extraction.xlsx` (WB4), `NIQ_Temporal_evolution.xlsx` (WB5), and the
  "Presales Insights" deck.
- **Family B — Campaign/retail-media measurement** (English vocabulary: Exposed/Control/Reach/
  Shoppers/Incremental): `NIQ_Datasheet_Liftcampaign.xlsx` (WB2, 37 sheets) and the
  "Measurement Report" deck (15 slides).

---

## 2. Central Finding

**All 7 files are fully static, pre-aggregated exports.** Zero atomic transaction-line, receipt-
header, or customer-event data exists anywhere in the reviewed set (0 formula cells, 0 named ranges,
0 pivots/Power Query/Data Model/VBA/connections confirmed across all 5 workbooks — see
Report_Analysis_Catalog.md §1.1–§5.1). This single fact governs the entire model design: the
canonical model is deliberately split into a **Tier 2 landing/aggregate layer** (populatable today,
directly from these files) and a **Tier 1 atomic layer** (target-state, requires net-new source
integration) — see [03_Canonical_Data_Model.md](03_Canonical_Data_Model.md) §1.

---

## 3. Deliverables in This Package

| # | File | Contents |
|---|---|---|
| 01 | `01_Executive_Summary.md` | This document |
| 02 | [02_Input_Data_Catalog.md](02_Input_Data_Catalog.md) | 35 upstream datasets across 6 categories, each fully profiled (grain, keys, DQ checks, availability, open questions) |
| 03 | [03_Canonical_Data_Model.md](03_Canonical_Data_Model.md) | Layered logical model — 35 tables (15 dims, 4 bridges, 4 config, 2 aggregate facts, 10 atomic facts) |
| 04 | [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md) | 31 KPIs, each with formula, lineage, status (CONFIRMED/INFERRED/UNVERIFIED/UNKNOWN) |
| 05 | [05_Report_Traceability_Matrix.md](05_Report_Traceability_Matrix.md) | All 22 named report sections mapped to model entities, 6-way reproducibility classification |
| 06 | [06_Open_Questions.md](06_Open_Questions.md) | 23 prioritized open items (10 Blocking / 9 Important / 4 Nice to have) |
| 07 | [07_Proposed_DDL.sql](07_Proposed_DDL.sql) | Full SQL DDL for all 35 tables |
| 08 | [08_Sample_KPI_Queries.sql](08_Sample_KPI_Queries.sql) | Sample queries for every CONFIRMED/INFERRED KPI; deliberately none for lift/ROAS/p-values |
| 09 | [09_Data_Quality_Rules.md](09_Data_Quality_Rules.md) | 11 categories of consistency/DQ rules |
| 10 | [10_Model_Assumptions_and_Decisions.md](10_Model_Assumptions_and_Decisions.md) | 32-item assumption/decision log with evidentiary status tags |
| — | [data_model.mmd](data_model.mmd) | Mermaid ER diagram of the full 34-table model |
| — | [review_findings.md](review_findings.md) | Independent audit of the source catalog for contradictions/naming collisions |

---

## 4. Canonical Model at a Glance

- **15 dimensions:** date, customer, customer_segment, product, brand, supplier, product_hierarchy,
  product_list, store, geography, store_banner, media_channel, promotion, campaign, audience.
- **4 bridges:** product_list↔product, customer↔segment (point-in-time), campaign↔audience,
  customer↔audience (point-in-time).
- **4 configuration tables:** report_definition, nielsen_period_calendar, kpi_definition,
  currency_tax_treatment.
- **2 landing/aggregate facts (AVAILABLE today):** `agg_report_metric` (Family A),
  `agg_campaign_metric` (Family B) — universal "one row = one KPI value at one dimensional cut"
  design, carrying an `is_total_row` flag so Total dimension-member rows are never double-counted.
- **10 atomic target-state facts (mostly NOT AVAILABLE):** transaction_header, transaction_line,
  product_store_availability, store_lifecycle_event, customer_period_status, new_shopper_flag,
  loyal_shopper, media_exposure, campaign_group_assignment, campaign_cost.

Two dimensions that look similar were deliberately **not merged**:
`dim_store_banner` (HYPER/EXPRESS/CONTACT/CITY/MARKET) and `dim_media_channel`
(HYPERMARKET/SUPERMARKET/E-COMMERCE/PROXIMITY-CONVENIENCE/CASH & CARRY) — their value sets differ and
no source file states an equivalence.

---

## 5. Confirmed Formulas (safe to build on)

$$\text{CA (Revenue)} = \text{Clients} \times \text{Fréquence} \times \text{Panier moyen}$$
$$\text{Panier moyen} = \text{UVC par panier} \times \text{Prix moyen}, \quad \text{Prix moyen} = \frac{\text{CA}}{\text{UVC}}$$
$$\text{Evolution \%} = \frac{\text{analyse} - \text{comparaison}}{\text{comparaison}}, \quad \text{DN} = \frac{\text{Selling Stores}}{\text{Total Stores}}$$
$$\text{DN Evolution (pts)} = (\text{ratio}_1 - \text{ratio}_2) \times 100 \quad \text{(percentage points, not relative \%)}$$
$$\text{Conversion Rate} = \frac{\text{Shoppers}}{\text{Exposable Group}}, \quad \text{Total Shoppers} = \text{New Shoppers} + \text{Returning Shoppers}$$

All independently recomputed against exact sample values in `Report_Analysis_Catalog.md` (e.g.
Panier moyen = 12,931,233.30/2,203,942 ≈ 5.867; DN = 1373/4255 = 0.3227).

---

## 6. Biggest Risks (see [06_Open_Questions.md](06_Open_Questions.md) for the full list)

1. Zero atomic transaction/customer data anywhere — every "reproducible" report is only reproducible
   at the pre-aggregated grain the source already provides.
2. Control/Exposed matching methodology, ROAS formula, and p-value test type are all undocumented —
   **Sales Uplift cannot be rebuilt without new methodology input from the client.**
3. Benchmark product lists (e.g. "BARRES CHOCOLATEES") are referenced by name only, never enumerated.
4. Customer/loyalty master data and segmentation-assignment logic do not exist in any reviewed file.
5. Loyal-shopper threshold is genuinely discrepant between sources (WB2 ">2" vs. deck6 "≥2") — both
   variants are preserved rather than silently resolved.
6. It is unproven whether "Client" (Family A) and "Shopper" (Family B) share the same identity space.

---

## 7. Recommended Next Steps

1. Validate this model with the client/retailer, prioritizing the 10 **Blocking** items in
   [06_Open_Questions.md](06_Open_Questions.md).
2. Stand up the Tier 2 landing layer (`agg_report_metric`, `agg_campaign_metric`) first — it requires
   no new source integration and immediately supports 8 of 22 report sections as "Fully reproducible."
3. Scope a net-new atomic data feed (POS transaction line + loyalty customer master) as the highest-
   value Tier 1 investment — it would resolve 6 of the 10 Blocking items in one integration effort.
4. Do not attempt to reverse-engineer or approximate the lift/ROAS/p-value methodology internally;
   request it directly from Unlimitail/Memory 360's measurement team.

---

## 8. Terminology Crosswalk

Full bilingual crosswalk of every term-pair identified across the 7 files, consolidating
[review_findings.md](review_findings.md) §2 and the KPI-level detail in
[04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md).

| French / Family A term | English / Family B term | Evidence | Equivalence confidence |
|---|---|---|---|
| CA | Revenue | WB1 Bilan; WB3 Performance; WB2 "Revenue"; deck7 slide 9 | High (currency/tax treatment unconfirmed — 06 Important #16) |
| UVC | Units / Quantity | WB1/WB3 "UVC"; WB2 "Quantity"; deck7 "Item/basket" | High |
| Client | Shopper | WB1 "Clients"; WB2/deck7 "Shoppers" | Medium — identity-resolution equivalence unproven (06 Blocking #10) |
| Panier | Basket / Transaction / Receipt | WB1/WB3 "Panier"; WB2 "Receipts"; deck7 "Transactions" | High |
| Encarté | Cardholder | WB1/WB3 "Encartés"/"Non encartés"; deck6/7 footers | High |
| Bannière | Banner | WB1 Lexique; WB3/WB4/WB5 `Bannière` column | High (label set differs from WB2's `Channel` — 06 Important #12) |
| Marque | Brand | Universal | High (subject to alias normalization, e.g. COCA COLA/COCA-COLA — 06 Important #19) |
| Magasin | Store | WB3/WB4/WB5 | High |
| Poids promo | Promotional Share | WB1 Lexique; WB3/WB4 | High for the ratio; Low for whether promotion-eligibility rules match across workbooks |
| Evolution | Period-over-Period Change | Universal; formula verified | High (CONFIRMED by recomputation) |
| DN | Numeric Distribution / Numeric Detention | WB3 "Numeric Detention"; WB2 "Numeric Distribution by SKU" | Medium — same ratio, different translation of one French term |
| Fréquence | Frequency | WB1 "average visits per cardholder, fixed period"; WB2 "implicitly Transactions ÷ Shoppers, per-campaign" | Medium — same formula shape, different period-scoping (kept as separate KPI rows, 04 §A6 vs §F3) |
| Constants (WB1) | — | Customer purchased in both periods | Not equivalent to WB3's "Constants" (see next row) |
| Constants (WB3, "Magasins constants") | — | Store with no material format change | Deliberately never merged with WB1's customer-grain "Constants" |
| Gagné / Perdu | New / Returning Shopper | WB1/WB3 3-way gain/loss cohort logic; WB2/deck binary new/returning flag | Low — structurally different classification logic, not merged |
| Lifestage / Structurelle / Consostyle / Promotion | LIFESTAGE / CONSOSTYLE / PROMO / RFM | WB1/WB3 Lexique vs. WB2 `Hierarchy 1`; deck7 slides 12–13 | Medium — name-level match only; segmentation *computation* equivalence unconfirmed (06 Blocking #8) |
| RFM | RFM | WB2 `Hierarchy 1` only | Not Available — zero definition anywhere |
| Indice CA/UVC | Index | WB1/WB3 | Unverified — baseline population per report unconfirmed (06 Blocking #6) |
| Ecart vs Benchmark | Gap vs Benchmark | WB3 | Unverified (06 Blocking #6) |
| VMH (Vente Moyenne Hebdomadaire) | Average Weekly Sale | WB3 Lexique (name only) | Unverified (06 Blocking #6 equivalent — see 04 §C5) |
| — | Incremental Revenue/Quantity/Shoppers, ROAS | WB2/deck7 | Unverified/Blocking — no formula stated anywhere (06 Blocking #2/#3) |
| — | Reach / Reach Rate | WB2/deck7 | High for the concept; underlying exposable-population denominator partially undocumented |
| — | Conversion Rate | deck7 slide 9 "Business equation" | High — explicitly stated formula |

---

*End of Executive Summary. This document, together with the 11 companion files listed in §3, is the
complete data-architecture deliverable requested. All conclusions are traceable to
`Report_Analysis_Catalog.md` and tagged per the evidentiary scale defined in
[10_Model_Assumptions_and_Decisions.md](10_Model_Assumptions_and_Decisions.md).*
