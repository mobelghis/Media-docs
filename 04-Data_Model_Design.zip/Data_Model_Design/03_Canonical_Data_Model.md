# 03 — Canonical Data Model

**Purpose:** Define the proposed canonical logical data model that could ultimately replace the 7
reviewed files, built strictly from what [02_Input_Data_Catalog.md](02_Input_Data_Catalog.md) and
[04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md) established. Per the task's critical
modeling rule, every table below is explicitly classified as one of: **Atomic source input /
Reference-master data / Configuration-parameter / Derived row-level attribute / Calculated KPI /
Pre-aggregated source output / Presentation-only value / Unknown-requires clarification**, and tagged
with its **availability status**: **AVAILABLE** (seedable today from the 7 reviewed files),
**PARTIAL** (structure known, data scope-limited or degenerate), or **NOT AVAILABLE** (requires
net-new source integration).

---

## 1. Design Principles

1. **Two-tier model.** Because zero atomic transaction/customer-event data exists anywhere in the 7
   reviewed files (Report_Analysis_Catalog.md, all §1.1/§2.1/§3.1/§4.1/§5.1: "0 formula cells... fully
   static export"), the model is split into:
   - **Tier 1 — Atomic layer** (`fact_*`, `dim_*`, `bridge_*`): the target-state, from-scratch
     recomputable design, assuming Carrefour/Memory 360/Unlimitail can eventually supply atomic
     sources. Nearly all Tier 1 fact tables are **NOT AVAILABLE** today.
   - **Tier 2 — Landing/aggregate layer** (`agg_*`, `cfg_*`): a pragmatic design that can be populated
     **today**, directly from the 7 reviewed files, preserving them as pre-aggregated source output
     rather than pretending they are atomic.
   A rebuild can start on Tier 2 immediately and migrate individual KPIs to Tier 1 only as underlying
   atomic sources become available — see [10_Model_Assumptions_and_Decisions.md](10_Model_Assumptions_and_Decisions.md).

2. **Never assume a reported column is an atomic input.** Every table below states its row-fact
   classification explicitly; pre-aggregated KPI values (e.g. CA, UVC, Evolution %) are always
   **Calculated KPI** or **Pre-aggregated source output**, never **Atomic source input**, even where
   they appear as plain numeric columns in the source spreadsheets.

3. **"Total" is a dimension member, not a computed sum.** Confirmed independently in WB1, WB2, WB3,
   WB4, WB5 (review_findings.md §1.3 — the single most important cross-file finding). Every `agg_*`
   fact table therefore carries an explicit `is_total_row` boolean and a `grain_level` text
   discriminator, so consumers never silently double-count by summing detail rows that already have a
   sibling Total row.

4. **Two distinct report families are modeled as two distinct landing facts** (not one shared table),
   because their dimensionality, vocabulary, and even shared-looking dimensions (e.g. "Channel") do
   not provably align (review_findings.md §1.1, §1.4): **(A)** retail/customer performance
   (French vocabulary: CA, UVC, Panier, Client, Encarté) and **(B)** campaign/retail-media measurement
   (English vocabulary: Exposed/Control/Reach/Shoppers/Incremental).

5. **Segment/audience/customer assignments are always point-in-time.** Every bridge involving
   `customer_id` carries an `as_of_date` or `effective_from/effective_to` pair — segmentation,
   audience membership, and customer status are all confirmed or strongly implied to drift over time
   (02_Input_Data_Catalog.md #16, #22, #23).

6. **No lift/p-value/matching formula is implemented.** Per explicit task instruction and per
   [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md)'s F5/F6/F7 UNVERIFIED/BLOCKING
   status, `fact_campaign_lift_result` stores the **inputs** to lift calculations (Exposed/Control
   group KPI values) but does **not** encode a formula for `Incremental X`, ROAS, or p-values.

---

## 2. Layered Architecture

```mermaid
flowchart LR
    A["Layer 0: Source Systems<br/>(Carrefour POS/loyalty, Memory 360,<br/>Unlimitail ad platform — mostly NOT<br/>directly accessible; 7 reviewed files<br/>are this layer's only visible output)"]
    B["Layer 1: Raw Landing<br/>(agg_report_metric, agg_campaign_metric —<br/>1:1 ingestion of every reviewed sheet/slide,<br/>untransformed, is_total_row preserved)"]
    C["Layer 2: Conformed / Dimensional<br/>(dim_*, bridge_*, cfg_* —<br/>deduplicated, SCD-managed, effective-dated<br/>reference data: product, store, customer,<br/>segment, campaign, audience, geography)"]
    D["Layer 3: Atomic Business Facts<br/>(fact_transaction_line, fact_media_exposure,<br/>fact_campaign_group_assignment, etc. —<br/>TARGET STATE, NOT AVAILABLE today)"]
    E["Layer 4: Semantic / Analytics<br/>(cfg_kpi_definition-driven views recomputing<br/>every KPI in 04_KPI_Lineage_and_Formulas.md<br/>from Layer 3 where available, else Layer 1)"]
    F["Layer 5: Report / Presentation Output<br/>(report-specific views matching the 22 sections<br/>in 05_Report_Traceability_Matrix.md)"]
    A --> B
    A -.future direct feed, not available today.-> D
    B --> C
    C --> D
    C --> E
    D --> E
    B --> E
    E --> F
```

- **Today**, only Layers 1 (partially), 2 (partially), and 5 (as literal source files) are
  populatable. Layer 3 and most of Layer 2's `dim_customer`/`dim_promotion` are **PROPOSED** designs
  awaiting net-new data.
- Layer 4 (semantic views) is designed to be **source-agnostic per KPI**: each KPI's view definition
  checks whether Layer 3 atomic facts exist for its inputs; if not, it falls back to Layer 1's
  pre-aggregated value. This lets the model be adopted incrementally rather than requiring all atomic
  sources at once.

---

## 3. Grain & "Total Row" Handling Policy

Every `agg_*` fact table includes:
- `is_total_row BOOLEAN` — `TRUE` when the row represents a pre-computed aggregate/"Total" dimension
  member (e.g. `Product List = 'Total'`, `Channel = 'Total'`, `Marque = 'Total'`) rather than a leaf
  detail row.
- `grain_level VARCHAR` — a short descriptor of which dimensions are "rolled up to Total" vs. "at
  detail" for this specific row (e.g. `'product:detail|store:total|period:detail'`), since a single
  sheet can mix rollup levels across different dimensions in the same table (confirmed pattern across
  WB1 `Profil`, WB2's 37 sheets, WB3's `Quoi`/`Où`/`Qui`).

**Rule enforced by this design:** consumers must **never** `SUM()` an `agg_*` fact table's `value`
column across rows that include an `is_total_row = TRUE` row alongside its own constituent detail
rows. Aggregation queries must either filter to `is_total_row = FALSE` and re-derive totals, or trust
the `is_total_row = TRUE` row directly — never both combined.

---

## 4. Naming Conventions (recap)

snake_case; `dim_` = conformed dimension; `fact_` = atomic-grain business fact (Tier 1); `agg_` =
pre-aggregated/landing fact (Tier 2); `bridge_` = many-to-many/point-in-time association;
`cfg_` = configuration/reference/parameter table. Surrogate keys: `<entity>_key` (int/bigint,
warehouse-generated). Natural/business keys: `<entity>_id` or `<entity>_code` (as sourced). Every
`fact_`/`agg_` table carries `source_system`, `load_ts`, and (where methodology-sensitive, e.g. any
campaign/lift table) `methodology_version`.

---

## 5. Dimension Tables (Layer 2 — Conformed)

| Table | Description | Grain | PK | Key FKs | SCD strategy | Classification | Source dataset(s) | Availability |
|---|---|---|---|---|---|---|---|---|
| `dim_date` | Calendar date reference incl. Nielsen period mapping | 1 row / calendar date | `date_key` | `nielsen_period_key` → cfg_nielsen_period_calendar | N/A (static, generated) | Reference-master data | Generated + #34 | PARTIAL (Nielsen mapping concept only, no calendar table) |
| `dim_customer` | Loyalty customer identity & status | 1 row / customer / effective period | `customer_key` | — | Type 2 | Reference-master data | #15 | NOT AVAILABLE — **note (2026-09-13, DOC20):** for Brazil, a `banner_id`/`banner_name` attribute is proposed as a required disambiguator (3 banners share one portal; the same physical shopper may otherwise appear as 3 distinct customer records) — this is a **proposed, unconfirmed** attribute, not yet added as a column (AS-032, OQ-C059). |
| `dim_customer_segment` | Segment taxonomy (family, macro/micro value, definition) | 1 row / (family, detail_level, value) | `segment_key` | — | Type 1 (or Type 2 if taxonomy versions) | Reference-master data | #17 | AVAILABLE (as glossary text — needs structuring) |
| `dim_product` | Product/EAN master incl. master-EAN chaining | 1 row / EAN / effective period | `product_key` | `ean_maitre_key` (self), `brand_key`, `supplier_key`, `hierarchy_key` | Type 2 | Reference-master data | #5, #6 | PARTIAL (scope-limited to reviewed categories) |
| `dim_brand` | Brand identity & type (Triptyque: MN/MDD/PP) | 1 row / brand | `brand_key` | — | Type 1 (Type 2 recommended, see #7) | Reference-master data | #7 | PARTIAL (embedded in #5, not standalone; normalization gap) |
| `dim_supplier` | Supplier identity | 1 row / supplier | `supplier_key` | — | Type 1 | Reference-master data | #7 | PARTIAL (embedded in #5) |
| `dim_product_hierarchy` | 6-level category tree | 1 row / distinct (niveau_1..6) combination | `hierarchy_key` | — | Type 2 (rare changes) | Reference-master data | #8 | PARTIAL (flattened in #5, not normalized) |
| `dim_product_list` | Named product scope (target/benchmark/additional) | 1 row / list | `product_list_id` | — | Type 2 | Configuration-parameter | #9 | PARTIAL (target lists enumerable; most benchmark lists are name-only) |
| `dim_store` | Store master (code, name, region, banner, surface) | 1 row / store / effective period | `store_key` | `region_key` | Type 2 | Reference-master data | #11 | PARTIAL (scope-limited per extraction) |
| `dim_geography` | Region reference | 1 row / region | `region_key` | — | Type 1 | Reference-master data | #14 | AVAILABLE (8-region list, high confidence) |
| `dim_store_banner` | Retail store format/banner reference (HYPER/EXPRESS/CONTACT/CITY/MARKET) | 1 row / banner | `banner_key` | — | Type 1 | Reference-master data | Embedded in #11 | AVAILABLE |
| `dim_media_channel` | Campaign-measurement channel reference (HYPERMARKET/SUPERMARKET/E-COMMERCE/PROXIMITY-CONVENIENCE/CASH & CARRY) | 1 row / channel | `media_channel_key` | — | Type 1 | Reference-master data | Embedded in WB2 §2.3 | AVAILABLE — **kept deliberately separate from `dim_store_banner`; label sets do not match 1:1 and equivalence is UNVERIFIED (see §9 modeling decision below)** |
| `dim_promotion` | Promotion/mechanic master | 1 row / promotion | `promotion_key` | `product_list_id`, `store_key` (nullable) | Type 2 (start/end inherent) | Reference-master data | #10 | NOT AVAILABLE |
| `dim_campaign` | Campaign/study master | 1 row / campaign | `campaign_key` | `campaign_group_key` (nullable) | Type 1 | Reference-master data / Configuration-parameter | #21, #32 | PARTIAL (GUID only; most attributes narrative-only) |
| `dim_campaign_group` (proposed, new 2026-09-13) | Advertiser-initiative parent that rolls up multiple channel-specific campaigns into one business program (e.g., one Coca-Cola initiative spanning 5 channels, each currently a separate `dim_campaign` row) | 1 row / advertiser initiative | `campaign_group_key` | — | Type 1 | Reference-master data | DOC20 §6.1 | **PROPOSED, NOT AVAILABLE** — DOC20 itself frames this as "a future product opportunity," not a delivered capability (AS-031, OQ-C058); no parent entity currently exists in any confirmed data source. |
| `dim_audience` | Named targeting audience & (unstructured) membership rule | 1 row / audience / version | `audience_key` | `campaign_key` (if campaign-scoped) | Type 2 (naming implies versioning, e.g. "V3") | Reference-master data | #22 | PARTIAL (names only, no rule text) |

---

## 6. Bridge Tables

| Table | Description | Grain | PK | FKs | Classification | Source dataset(s) | Availability |
|---|---|---|---|---|---|---|---|
| `bridge_product_list_product` | Membership of an EAN in a named product list, point-in-time | 1 row / (list, ean, effective period) | (`product_list_id`, `ean`, `effective_from`) | `product_list_id` → dim_product_list; `ean` → dim_product | Configuration-parameter | #9 | PARTIAL |
| `bridge_customer_segment_assignment` | Which customer belongs to which segment, as of a date | 1 row / (customer, segment_family, as_of_date) | (`customer_key`, `segment_key`, `as_of_date`) | `customer_key` → dim_customer; `segment_key` → dim_customer_segment | Derived row-level attribute | #16 | NOT AVAILABLE |
| `bridge_campaign_audience` | Which audiences are in scope for a campaign | 1 row / (campaign, audience) | (`campaign_key`, `audience_key`) | `campaign_key` → dim_campaign; `audience_key` → dim_audience | Configuration-parameter | #21 (WB2 `Scope - audiences`) | PARTIAL |
| `bridge_customer_audience_membership` | Per-customer audience membership | 1 row / (customer, audience, as_of_date) | (`customer_key`, `audience_key`, `as_of_date`) | `customer_key` → dim_customer; `audience_key` → dim_audience | Derived row-level attribute | #23 | NOT AVAILABLE |

---

## 7. Configuration Tables

| Table | Description | Grain | PK | Classification | Source dataset(s) | Availability |
|---|---|---|---|---|---|---|
| `cfg_report_definition` | Exact parameters used to generate a report run (retailer, scope, period type, dates, selected KPIs) | 1 row / report run | `report_run_id` | Configuration-parameter | #33 | AVAILABLE (best-structured config data in the whole file set) |
| `cfg_nielsen_period_calendar` | Nielsen 13-period/year calendar, period ↔ date range | 1 row / (nielsen_year, period_number) | (`nielsen_year`, `period_number`) | Reference-master data | #34 | PARTIAL (concept defined, table itself not sourced) |
| `cfg_kpi_definition` | Operationalizes [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md) as queryable metadata: kpi_id, name, formula_text, aggregation_behavior, additivity_class, confirmation_status | 1 row / KPI | `kpi_id` | Configuration-parameter | Derived from 04 | AVAILABLE (authored as part of this deliverable set) |
| `cfg_currency_tax_treatment` | Currency code and gross/net-of-VAT convention | 1 row (global) | `currency_config_id` | Configuration-parameter | #35 | NOT AVAILABLE (undocumented in any file — flagged, not assumed) |

---

## 8. Fact Tables — Tier 2: Landing / Aggregate Layer (AVAILABLE today)

### 8.1 `agg_report_metric` (retail/customer performance family — WB1, WB3, WB4, WB5, deck 6)

- **Description:** Universal landing fact for every pre-aggregated KPI value found in the
  retail-performance report family. One row = one KPI value at one dimensional cut, exactly as
  exported (no re-aggregation performed at load time).
- **Grain:** (`report_run_id` × whatever dimension keys are populated for that sheet/block ×
  `kpi_id` × `measurement_basis` × `is_total_row`).
- **PK:** `agg_report_metric_id` (surrogate, since the natural grain varies per sheet).
- **Key columns:** `report_run_id` → cfg_report_definition; `kpi_id` → cfg_kpi_definition;
  `measurement_basis` (CA/UVC, nullable for KPIs not CA/UVC-split); `product_key` (nullable);
  `brand_key` (nullable); `store_key` (nullable); `region_key` (nullable); `store_banner_key`
  (nullable); `segment_key` (nullable); `date_key`/`period_grain` (nullable — week/month/quarter);
  `value_analyse`; `value_comparaison` (nullable); `evolution_value`; `evolution_pct`;
  `ecart_vs_benchmark` (nullable, UNVERIFIED formula per 04 §C3); `is_total_row`; `grain_level`;
  `source_sheet_name` (traceability back to the exact reviewed-file sheet); `source_system`;
  `load_ts`.
- **Classification:** Pre-aggregated source output.
- **Reports supported:** Customer Loyalty Bilan/Profile, Performance, Quoi, Quand, Où, Qui, Top EAN,
  Top Brands, Customer Segmentations, Geographic Distribution, Product Extraction Indicators,
  Temporal Evolution, Presales Insights slides — i.e. every section in
  [05_Report_Traceability_Matrix.md](05_Report_Traceability_Matrix.md) tagged report family (A).
- **Availability:** AVAILABLE — directly loadable from the reviewed files today; this is the primary
  near-term deliverable of any rebuild effort.

### 8.2 `agg_campaign_metric` (campaign/retail-media measurement family — WB2, deck 7)

- **Description:** Universal landing fact for every pre-aggregated KPI value found in the
  campaign/lift-measurement report family.
- **Grain:** (`campaign_id` × `period` [Pre Campaign/Campaign] × `product_list_id` × `group`
  [Control/Exposed, nullable] × `audience_key` (nullable) × `media_channel_key` (nullable) ×
  `kpi_id` × `is_total_row`).
- **PK:** `agg_campaign_metric_id` (surrogate).
- **Key columns:** `campaign_id` → dim_campaign; `kpi_id` → cfg_kpi_definition; `period`;
  `product_list_id` → dim_product_list; `group_assignment` (Control/Exposed, nullable);
  `audience_key` (nullable); `media_channel_key` (nullable); `is_new_shopper` (nullable);
  `value`; `is_multisegment_resampled` (flag, meaning `[UNVERIFIED]` per 04 §F7); `is_total_row`;
  `grain_level`; `source_sheet_name`; `source_system`; `load_ts`; `methodology_version`
  (**deliberately left NULL/unresolved** — see design principle 6).
- **Classification:** Pre-aggregated source output; sub-rows corresponding to lift/p-value KPIs are
  additionally tagged **Unknown-requires clarification** at the KPI level via `cfg_kpi_definition`.
- **Reports supported:** All WB2 sheets, Measurement Report slides — report family (B) sections in
  [05_Report_Traceability_Matrix.md](05_Report_Traceability_Matrix.md).
- **Availability:** AVAILABLE for descriptive/observed values; **NOT AVAILABLE** for independently
  re-deriving any lift/lift-significance value (those remain pass-through from source, never
  recomputed by this model).

---

## 9. Fact Tables — Tier 1: Atomic Business Layer (target-state, NOT AVAILABLE unless noted)

| Table | Description | Grain | PK | Key FKs | Classification | Source dataset(s) | Availability |
|---|---|---|---|---|---|---|---|
| `fact_transaction_line` | Atomic basket-line sale | 1 row / (transaction, EAN, line) | `transaction_line_id` | `product_key`, `store_key`, `customer_key` (nullable), `date_key`, `promotion_key` (nullable) | Atomic source input | #1 | NOT AVAILABLE |
| `fact_transaction_header` | Basket/receipt-level reconciliation record (optional — derivable from `fact_transaction_line` if header attributes aren't needed independently) | 1 row / transaction | `transaction_id` | `customer_key` (nullable), `store_key`, `date_key` | Atomic source input | #2 | NOT AVAILABLE |
| `fact_product_store_availability` | Per-store-per-product ranging/selling status, point-in-time | 1 row / (store, EAN, as_of_date) | (`store_key`, `product_key`, `as_of_date`) | `store_key`, `product_key` | Atomic source input | #12 | NOT AVAILABLE |
| `fact_store_lifecycle_event` | Store open/close/remodel event log | 1 row / (store, event, date) | (`store_key`, `event_date`, `event_type`) | `store_key` | Atomic source input | #13 | NOT AVAILABLE |
| `fact_customer_period_status` | Customer Constants/Gagné/Perdu classification per period pair | 1 row / (customer, product_list, period_pair) | (`customer_key`, `product_list_id`, `period_pair_id`) | `customer_key`, `product_list_id` | Derived row-level attribute | #18 | NOT AVAILABLE (rule is CONFIRMED, data is not) |
| `fact_new_shopper_flag` | New/returning shopper classification per campaign | 1 row / (customer, campaign) | (`customer_key`, `campaign_key`) | `customer_key`, `campaign_key` | Derived row-level attribute | #19 | NOT AVAILABLE |
| `fact_loyal_shopper` | Loyal-shopper (≥2 purchases) classification per period | 1 row / (customer, product_list, period) | (`customer_key`, `product_list_id`, `period_id`) | `customer_key`, `product_list_id` | Derived row-level attribute (directly derivable from `fact_transaction_header` once available) | #20 | NOT AVAILABLE (rule CONFIRMED; base data not) |
| `fact_media_exposure` | Impression-level ad-serving log | 1 row / impression | `impression_id` | `campaign_key`, `customer_key` (nullable), `media_channel_key` | Atomic source input | #24 | NOT AVAILABLE |
| `fact_campaign_group_assignment` | Per-shopper Control/Exposed group assignment | 1 row / (customer, campaign) | (`customer_key`, `campaign_key`) | `customer_key`, `campaign_key` | Atomic source input / Configuration-parameter (methodology-dependent) | #29, #30 | NOT AVAILABLE |
| `fact_campaign_cost` | Campaign media spend, ideally by channel/day | 1 row / (campaign, channel, date) | (`campaign_key`, `media_channel_key`, `date_key`) | `campaign_key`, `media_channel_key` | Atomic source input | #31 | PARTIAL (totals only, via `agg_campaign_metric`) |

---

## 10. Full Entity Inventory (for DDL/ER-diagram cross-check)

`dim_date`, `dim_customer`, `dim_customer_segment`, `dim_product`, `dim_brand`, `dim_supplier`,
`dim_product_hierarchy`, `dim_product_list`, `dim_store`, `dim_geography`, `dim_store_banner`,
`dim_media_channel`, `dim_promotion`, `dim_campaign`, `dim_audience`, `bridge_product_list_product`,
`bridge_customer_segment_assignment`, `bridge_campaign_audience`,
`bridge_customer_audience_membership`, `cfg_report_definition`, `cfg_nielsen_period_calendar`,
`cfg_kpi_definition`, `cfg_currency_tax_treatment`, `agg_report_metric`, `agg_campaign_metric`,
`fact_transaction_line`, `fact_transaction_header`, `fact_product_store_availability`,
`fact_store_lifecycle_event`, `fact_customer_period_status`, `fact_new_shopper_flag`,
`fact_loyal_shopper`, `fact_media_exposure`, `fact_campaign_group_assignment`, `fact_campaign_cost`.

**Total: 36 tables** (16 dims, 4 bridges, 4 config, 2 aggregate/landing facts, 10 atomic facts). This
exact list is what [data_model.mmd](data_model.mmd) diagrams and what
[07_Proposed_DDL.sql](07_Proposed_DDL.sql) must implement table-for-table (verification checkpoint).
**Note (2026-09-13):** `dim_campaign_group` is newly added as a PROPOSED/NOT AVAILABLE entity (see
§5, Modeling Decision 6 below) and is not yet reflected in `data_model.mmd`/`07_Proposed_DDL.sql`.

---

## 11. Key Modeling Decisions Made in This Layer (see also [10_Model_Assumptions_and_Decisions.md](10_Model_Assumptions_and_Decisions.md))

1. **`dim_store_banner` and `dim_media_channel` are kept separate**, not merged into one `dim_channel`,
   because their observed value sets differ (`HYPER/EXPRESS/CONTACT/CITY/MARKET` in WB3/WB4's store
   data vs. `HYPERMARKET/SUPERMARKET/E-COMMERCE/PROXIMITY-CONVENIENCE/CASH & CARRY` in WB2) and no
   file in the reviewed set states an explicit crosswalk between them — merging would be an
   unsupported assumption. **[PROPOSED — revisit if client confirms a 1:1 mapping.]**
2. **`agg_report_metric` and `agg_campaign_metric` are two separate landing facts**, not one, mirroring
   review_findings.md's finding that the two report families' shared-looking vocabulary (e.g.
   "Constants", "Total") resolves to different grains/meanings per family.
3. **No `fact_lift_result` with a computed `incremental_x` column exists.** `agg_campaign_metric`
   stores the Exposed/Control KPI values exactly as reported, but the model does not compute or store
   a derived "Incremental Revenue" value anywhere — per 04 §F5, that formula is UNVERIFIED/BLOCKING.
4. **Customer identity is not assumed shared between report families.** `dim_customer` is a single
   conformed dimension in principle, but `bridge_customer_audience_membership` and
   `bridge_customer_segment_assignment` are populated independently per family until the client
   confirms (or denies) that "Clients" (family A) and "Shoppers" (family B) resolve to the same
   underlying identity space (review_findings.md §1.2).
5. **SCD Type 2 is recommended (not yet confirmed necessary) for `dim_product`, `dim_store`, and
   `dim_audience`**, based on naming/versioning evidence (EAN reclassification, store remodels,
   audience "V1/V2/V3" naming) rather than direct proof of historical change events in the reviewed
   files.
6. **`dim_campaign_group` and a proposed `banner_id`/`banner_name` attribute on `dim_customer` are
   newly added as PROPOSED/NOT AVAILABLE (2026-09-13, DOC20).** Neither is confirmed as scoped or
   funded — `dim_campaign_group` addresses a genuine gap DOC20 identifies (no parent entity today
   aggregates a multi-channel advertiser initiative's separate channel campaigns), and the banner
   attribute addresses Brazil's 3-banners-in-1-portal shopper-identity duplication risk. Both require
   client/product confirmation before being treated as committed scope (AS-031, AS-032, OQ-C058,
   OQ-C059).
