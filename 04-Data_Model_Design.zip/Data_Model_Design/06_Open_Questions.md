# 06 — Open Questions

**Purpose:** Consolidated, prioritized list of every unresolved item surfaced across
[02_Input_Data_Catalog.md](02_Input_Data_Catalog.md), [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md),
[03_Canonical_Data_Model.md](03_Canonical_Data_Model.md), and
[05_Report_Traceability_Matrix.md](05_Report_Traceability_Matrix.md). Each item states what is known,
what is missing, and what a resolution would unblock. Priority levels: **Blocking** (prevents a
faithful rebuild of at least one report section), **Important** (affects confidence/precision but a
reasonable interim assumption exists), **Nice to have** (documentation/completeness gap only).

---

## Blocking

1. **Atomic transaction-line data does not exist anywhere in the reviewed files.** (02 #1, #2) —
   Without it, `fact_transaction_line`/`fact_transaction_header` cannot be populated, and every
   "Fully reproducible" classification in 05 is really "reproducible only at the pre-aggregated
   grain the source already provides." *Unblocks: true atomic rebuild of report families A and B.*
2. **Control/Exposed group matching methodology is undocumented.** (02 #30, 04 F5/F6/F7) — No file
   states how Control and Exposed shopper groups are matched/balanced, what statistical test
   produces significance values, or the exact lift formula. *Unblocks: 05 row 21 "Sales Uplift",
   the single largest reproducibility gap in the campaign family.* **Update 2026-09-13:** the client
   Knowledge Base (`Knowledge_Base/Open Questions.md` CF-003/CF-011) now documents a much richer
   candidate methodology (upfront holdout vs. post-exposure control, worked numerical example,
   addressable/served-lift vocabulary) from 3 new discovery-meeting transcripts. This is **candidate
   methodology under active discussion, not a client-confirmed or NIQ-approved formula** — still
   Blocking for this deliverable's purposes until DEC-001 (`PRD/07_Decision_Assumption_Risk_Register.md`)
   is formally resolved.
3. **ROAS formula is never stated.** (04 F6) — Revenue-per-media-dollar logic, cost basis (gross
   vs net media spend), and attribution window are all unconfirmed. *Unblocks: any spend-efficiency
   reporting in the Measurement Report family.*
4. **P-value/significance-test type is unstated.** (04 F7) — The `multisegment resampled` label
   appears in WB2 with no methodology note. *Unblocks: any claim of statistical significance in
   campaign reporting.*
5. **Benchmark product lists are named but never enumerated.** (02 #9) — E.g. "BARRES CHOCOLATEES"
   in WB3 is referenced by name only; its member EAN list is not in any reviewed file.
   *Unblocks: 05 row 7 "Performance" and any Ecart-vs-Benchmark KPI (04 C3).*
6. **Ecart vs Benchmark and Indice CA/UVC formulas/index bases are unconfirmed.** (04 C3, C4) —
   Numerically plausible candidate formulas exist but were not independently verified against a
   recomputed sample in Report_Analysis_Catalog.md. *Unblocks: full trust in WB3's comparative KPIs.*
   **Update 2026-09-13:** a new client discovery-meeting transcript (`Knowledge_Base/Open Questions.md`
   OQ-C050, sourced from a Sep 9, 2026 "Indexes and Reporting" discussion) gives an illustrative
   candidate formula, `Index = (Brand share / Category share) × 100`, for what appears to be the same
   underlying "Indexes" capability — but that same meeting **explicitly did not finalize a formal
   formula specification** ("must be validated before implementation"). This narrows but does **not
   close** this blocking gap; still requires direct client confirmation before implementation.
6b. **Index-type KPIs (C4) may need a UX alternative for some client segments.** (04 C4, client call
    transcript) — Client-side PM Richard Fercoq (Unlimitail/Carrefour) indicated base-100 indices are
    hard for statistically-less-sophisticated clients to interpret and prefers percentage-point change
    (C2) framing instead. This corroborates the base-100 convention assumption but adds a **product
    decision**, not a data question: should Index KPIs be shown at all, hidden by default, or always
    paired with a plain percentage-point-change equivalent? *Unblocks: report-template design decision
    for any rebuilt WB3 Où/Qui sections (05 rows 10-11).*
7. **Customer/loyalty master data does not exist.** (02 #15) — No file contains a durable customer
   identity table; every customer-level KPI (Constants, Gagné/Perdu, loyal shopper, new/returning
   shopper) is only visible as a pre-aggregated count. *Unblocks: `dim_customer`,
   `fact_customer_period_status`, `fact_loyal_shopper`, `fact_new_shopper_flag`.*
8. **Customer-segmentation engine and assignment rules are undocumented.** (02 #16) — WB3's Lexique
   defines segment *names* (Lifestage, Structurelle, Consostyle, Promotion, RFM) but no file states
   the assignment logic, and it's unconfirmed whether the same engine is shared between Memory 360
   and Unlimitail. *Unblocks: `bridge_customer_segment_assignment`, all "Qui"/segment cuts.*
9. **New-shopper lookback window is unstated.** (02 #19) — "New" vs "Returning" shopper
   classification logic is referenced but the exact prior-period window is never given.
   *Unblocks: 05 row 18 "New Shopper Acquisition."*
10. **Whether "Client" (family A) and "Shopper" (family B) are the same identity space is unproven.**
    (review_findings.md §1.2) — No shared customer key or cross-reference exists between the retail
    and campaign report families. *Unblocks: any decision to model `dim_customer` as a single
    conformed dimension vs. two independent ones.*

## Important

11. **Loyal-shopper threshold is discrepant between sources.** (04 F8) — WB2 uses ">2 Receipts"
    (i.e. ≥3) while deck6 says "at least twice" (i.e. ≥2). *Interim assumption: model both as
    distinct, explicitly-labeled variants (`loyal_shopper_wb2_rule`, `loyal_shopper_deck6_rule`)
    rather than silently picking one.*
12. **`dim_store_banner` vs `dim_media_channel` equivalence is unconfirmed.** (03 §11.1) — Value
    sets differ across WB3/WB4 (HYPER/EXPRESS/CONTACT/CITY/MARKET) and WB2 (HYPERMARKET/SUPERMARKET/
    E-COMMERCE/PROXIMITY-CONVENIENCE/CASH & CARRY). *Interim assumption: kept as two separate
    dimensions; revisit if retailer confirms a crosswalk.*
13. **RFM segment definitions are entirely absent.** (02 #17) — The term appears in the Lexique
    taxonomy list with zero supporting definition anywhere. *Interim assumption: model as a segment
    family placeholder in `dim_customer_segment` with `definition_text = NULL`, not invent an
    R/F/M scoring rule.*
14. **EAN-maître (master EAN) chaining rules are only partially observable.** (02 #6) — The
    self-referencing FK exists in the product master extract but the business rule for *why* a
    child EAN maps to a master is not documented. *Interim assumption: preserve the raw mapping,
    do not infer a rule.*
15. **Store availability data (`fact_product_store_availability`) is only visible as an aggregate
    ratio (DN), never as atomic store-by-store ranging flags.** (02 #12) — *Interim assumption:
    `agg_report_metric` stores the ratio; the atomic fact table remains a target-state placeholder.*
16. **Currency and tax-treatment conventions are undocumented.** (02 #35) — No file states whether
    reported CA values are gross or net of VAT, or confirms currency (assumed EUR from context).
    *Interim assumption: EUR, gross-of-VAT unless corrected — flagged, not silently assumed
    elsewhere.*
17. **Nielsen period calendar table itself is not sourced**, only the concept of period-based
    reporting (CAM/CAD) is confirmed. (02 #34) — *Interim assumption: `cfg_nielsen_period_calendar`
    ships empty; report runs reference period labels as free text until the calendar is supplied.*
18. **Cardholder identification method is unconfirmed.** (04 B3) — Whether "Cardholder Rate" is
    derived from a loyalty-card flag at transaction time or from a separate registration table is
    not stated. *Interim assumption: model as a transaction-line flag pending confirmation.*
19. **Brand-name normalization is required before any Temporal Evolution rebuild.** (05 row 13) —
    `COCA COLA` vs `COCA-COLA` inconsistency confirmed in WB5; without normalization, `dim_brand`
    joins would silently split one brand into two. *Interim assumption: normalize at ingestion via
    a documented alias table, do not silently merge without a rule.*

## Nice to Have

20. **Product-list precedence when an EAN appears in multiple named lists is undocumented.** (02 #9)
    — Interim assumption: `bridge_product_list_product` allows multi-membership; no precedence rule
    enforced.
21. **Promotion eligibility/exclusion rules (e.g. loyalty-card-only promotions) are not stated.**
    (02 #10) — Interim assumption: `dim_promotion` models mechanic type and dates only.
22. **Zero-denominator and rounding-display conventions are inferred, not confirmed, for several
    KPIs** (04, various "null handling"/"rounding" fields) — e.g. whether a 0-shopper Exposed group
    displays as `0%`, blank, or `N/A`. Interim assumption documented per-KPI in 04; no universal
    override applied.
23. **Whether campaign cost (`fact_campaign_cost`) is ever available at daily/channel grain, or
    only as a campaign-level total, is unconfirmed** — only totals were observed. (02 #31)

## New Items (2026-09-13, sourced from DOC20)

24. **No parent entity aggregates multi-channel advertiser initiatives.** A single advertiser
    campaign (e.g., one brand's initiative across 5 channels) currently arrives as 5 separate
    `dim_campaign` rows with no rollup entity. *Unblocks: any cross-channel program-level KPI or
    report.* Proposed `dim_campaign_group` added to `03_Canonical_Data_Model.md` §5 as
    PROPOSED/NOT AVAILABLE — not yet confirmed as scoped (`Knowledge_Base/Open Questions.md`
    OQ-C058).
25. **Brazil shopper-identity duplication across 3 banners sharing 1 portal is unresolved.** A
    physical shopper active in all 3 banners may be represented as 3 distinct `dim_customer` rows,
    risking double-counted audience/reporting KPIs. *Blocking for any Brazil-scoped KPI until a
    deduplication rule is confirmed.* (`Knowledge_Base/Open Questions.md` OQ-C059, AS-032)
26. **4-week and 6-week post-campaign windows are mentioned but not defined**, and their
    relationship to the already-confirmed 14-day attribution lookback is unclear (a distinct
    "post-campaign persistence/repeat-purchase" concept is suspected, not confirmed).
    (`Knowledge_Base/Open Questions.md` OQ-C060, AS-033)

---

## Cross-Reference to KPI Confirmation Status

All items tagged UNVERIFIED/BLOCKING in [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md)
(C3 Ecart vs Benchmark, C4 Indice CA/UVC, C5 VMH, F5 Incremental measures, F6 ROAS, F7 P-values) are
represented above as Blocking items 3, 4, 6. F8's Loyal Shopper Rate discrepancy is Important item 11.
