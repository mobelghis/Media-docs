# 10 — Model Assumptions and Decisions

**Purpose:** A single consolidated log of every material assumption or design decision made across
this deliverable set, each tagged with its evidentiary status and cross-referenced to where it was
made. Status legend: **OBSERVED** (directly seen in a reviewed file), **INFERRED** (reasonably
concluded from patterns, not explicitly stated), **PROPOSED** (a design choice made where no source
evidence exists either way), **UNVERIFIED** (a plausible claim that could not be independently
confirmed), **NOT AVAILABLE** (the underlying fact/data plainly does not exist in the reviewed set).

---

| # | Assumption / Decision | Status | Where Made | Rationale |
|---|---|---|---|---|
| 1 | All 5 Excel workbooks and both PowerPoint decks are fully static, pre-aggregated exports with zero atomic transaction/customer-event data | OBSERVED | Report_Analysis_Catalog.md §1.1-§5.1 (0 formula cells, 0 named ranges, 0 pivots/Power Query/VBA across all 5 workbooks) | Directly inspected via `_analysis/*.py` dump scripts |
| 2 | Carrefour is the retailer for WB2 and both decks | OBSERVED | Deck footers "Base encartés Carrefour" | Explicit text string in source files |
| 3 | Carrefour is the retailer for WB1, WB3, WB4, WB5 | INFERRED | Banner/region taxonomy match (HYPER/MARKET/CITY/CONTACT/EXPRESS, 8 French regions) | No explicit retailer name string found in these 5 workbooks |
| 4 | Memory 360 and Unlimitail are the same underlying Carrefour/Publicis retail-media JV | INFERRED | Cross-referencing deck branding + shared banner taxonomy | Never explicitly stated as one entity in any single file |
| 5 | CA = Clients × Fréquence × Panier moyen; Panier moyen = UVC par panier × Prix moyen; Prix moyen = CA/UVC | CONFIRMED (independently recomputed) | 04 §A1-A9; sample recomputation 12,931,233.30/2,203,942≈5.867 | Matched to 2+ decimal places against Report_Analysis_Catalog.md sample values |
| 6 | Evolution % = (analyse − comparaison)/comparaison | CONFIRMED | 04 §C1; recomputed (12,931,233.30−11,884,336.71)/11,884,336.71=0.08809 | Matched exactly |
| 7 | DN Evolution is expressed in percentage points, not relative % | CONFIRMED | 04 §C2; recomputed (0.99953−1.00171)×100=−0.218 | Matched exactly; distinguishes pts from % |
| 8 | Ecart vs Benchmark formula | UNVERIFIED | 04 §C3, 06 Blocking #6; candidate formula referenced in `Knowledge_Base/Open Questions.md` OQ-C050 (2026-09-13, unconfirmed) | No recomputable sample found; candidate formulas plausible but unconfirmed |
| 9 | Indice CA/UVC index base | UNVERIFIED | 04 §C4, 06 Blocking #6; candidate illustrative formula `(Brand share / Category share) × 100` surfaced in a Sep 9, 2026 client discovery meeting (`Knowledge_Base/Open Questions.md` OQ-C050) but explicitly not finalized by that meeting | Index base (100 = what?) never stated in the original sample-report corpus; new candidate formula is unconfirmed/pending client validation |
| 10 | VMH (Vente Moyenne Hebdomadaire) formula | UNVERIFIED | 04 §C5 | Term defined in Lexique name only, no formula |
| 11 | Conversion rate = Shoppers / Exposable group | CONFIRMED | Explicitly stated, deck7 slide 9 "Business equation" | Direct source quote |
| 12 | Total Shoppers = New Shoppers + Returning Shoppers | CONFIRMED | Explicit deck7/WB2 statement | Direct source quote |
| 13 | Lift/incrementality methodology (Control/Exposed matching, resampling, p-value test) | UNVERIFIED / BLOCKING | 04 §F5-F7, 06 Blocking #2-4; richer candidate methodology (upfront holdout vs. post-exposure control, worked example, addressable/served-lift vocabulary) now documented in `Knowledge_Base/Open Questions.md` CF-003/CF-011 (2026-09-13), still not client/NIQ-approved | No methodology text anywhere in WB2 or decks; new discovery-meeting evidence is candidate/under-discussion, not a finalized formula |
| 14 | ROAS formula | UNVERIFIED / BLOCKING | 04 §F6, 06 Blocking #3 | Term used without formula |
| 15 | "Total" is always a literal pre-computed row, never re-derivable by summing | OBSERVED | review_findings.md §1.3; confirmed across WB1/WB2/WB3/WB4/WB5 | Consistent structural pattern across all 5 workbooks |
| 16 | "Constants" means customer-grain (WB1) vs store-grain (WB3) — two different concepts | OBSERVED | review_findings.md §1.3 direct text comparison | Explicit definitions differ in each workbook's glossary |
| 17 | RFM segmentation has zero definitions anywhere | NOT AVAILABLE | 02 #17, 06 Important #13 | Term appears in Lexique list only, no supporting text |
| 18 | "Benchmark produits" gagné/perdu customer category is defined but has zero data rows | NOT AVAILABLE | Report_Analysis_Catalog.md §1 Lexique review | Definition present, no populated example anywhere |
| 19 | WB2's `Exposure Overview - frequency`/`Frequency Impact` sheets are empty (headers only) | OBSERVED | Report_Analysis_Catalog.md §2 sheet inventory | Directly inspected via dump scripts |
| 20 | `Exposure Evolutions` is all-zero for 50 days | OBSERVED | Report_Analysis_Catalog.md §2 | Directly inspected |
| 21 | `Performance by Audience` has anomalous near-0/near-1 values, likely an export bug | INFERRED | Report_Analysis_Catalog.md §2/§7, review_findings.md | Values are implausible as literal KPIs but no confirmation of the underlying cause |
| 22 | Loyal-shopper threshold: WB2 ">2 Receipts" (≥3) vs deck6 "at least twice" (≥2) — genuine discrepancy | OBSERVED | 04 §F8, 06 Important #11 | Two literal source statements conflict; both preserved rather than reconciled |
| 23 | Whether "Client" (family A) and "Shopper" (family B) are the same identity space | UNVERIFIED | review_findings.md §1.2, 06 Blocking #10 | No shared key/cross-reference exists in the 7 files |
| 24 | `dim_store_banner` (HYPER/EXPRESS/CONTACT/CITY/MARKET) and `dim_media_channel` (HYPERMARKET/SUPERMARKET/E-COMMERCE/PROXIMITY-CONVENIENCE/CASH & CARRY) are kept as two separate dimensions | PROPOSED | 03 §11.1, 06 Important #12 | Value sets differ; no source crosswalk found — merging would be an unsupported assumption |
| 25 | `agg_report_metric` and `agg_campaign_metric` are two separate landing facts rather than one unified table | PROPOSED | 03 §11.2 | Two report families' vocabularies and grains do not provably align |
| 26 | SCD Type 2 is used for `dim_product`, `dim_store`, `dim_audience` | PROPOSED | 03 §11.5 | Naming/versioning evidence (EAN reclassification, store remodels, audience "V1/V2/V3") suggests change-over-time, though no explicit historized record was observed |
| 27 | `bridge_customer_segment_assignment`/`bridge_customer_audience_membership` use point-in-time `as_of_date`, not effective ranges | PROPOSED | 09 Rule DQ-7.1 | Segment/audience assignment appears re-evaluated per period rather than continuously tracked; revisit if disproven |
| 28 | No PII columns (name/address/email/phone) are modeled anywhere | NOT AVAILABLE | 09 Rule DQ-8.1 | None observed in any reviewed file; adding them would be speculative |
| 29 | Currency is EUR and revenue figures are gross-of-VAT | UNVERIFIED / PROPOSED | 02 #35, 06 Important #16 | Inferred from French/Carrefour context only; never explicitly stated |
| 30 | Two atomic reference datasets (product master, store master) are genuinely recoverable at near-full fidelity from WB4/WB5 | OBSERVED | 02 #5, #11 | `Informations produits`/`Informations magasins` sheets contain true one-row-per-entity reference data, unlike every other sheet in the 7 files |
| 31 | Brand-name inconsistency `COCA COLA` vs `COCA-COLA` requires alias normalization before `dim_brand` load | OBSERVED | 02 WB5 review, 06 Important #19, 09 Rule DQ-11.1 | Both spellings found referring to the same product line in WB5's daily series |
| 32 | No formula is invented anywhere in this deliverable set for Ecart vs Benchmark, Indice, VMH, DV, lift/incrementality, ROAS, or p-values | PROPOSED (governance decision) | Applies across 04, 07, 08, 09 | Explicit task instruction: never invent a definitive formula for a BLOCKING/UNVERIFIED item |
| 33 | `dim_campaign_group` (advertiser-initiative parent entity) and a `banner_id`/`banner_name` attribute on `dim_customer` (Brazil identity disambiguation) are added as new PROPOSED/NOT AVAILABLE entities | PROPOSED | 03 §5, §11.6 (2026-09-13); sourced from DOC20 §6.1, §8 | DOC20 identifies both gaps directly (no campaign-grouping parent exists; Brazil's 3 banners share one portal without unified shopper IDs) but frames them as not-yet-scoped/confirmed (AS-031, AS-032) |

---

## Summary by Status

| Status | Count |
|---|---|
| OBSERVED | 12 |
| INFERRED | 4 |
| PROPOSED | 9 |
| UNVERIFIED | 6 |
| NOT AVAILABLE | 3 |
| CONFIRMED (independently recomputed, treated as a strong sub-class of OBSERVED) | 4 |

*(Some rows are dual-tagged, e.g. "UNVERIFIED / BLOCKING", "UNVERIFIED / PROPOSED" — counted under
their primary evidentiary status above.)*
