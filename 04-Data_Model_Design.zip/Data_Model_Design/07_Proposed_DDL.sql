-- =============================================================================
-- 07_Proposed_DDL.sql
--
-- PROPOSED, implementation-neutral SQL DDL for the canonical data model defined in
-- 03_Canonical_Data_Model.md. This is a DESIGN PROPOSAL, not a reflection of any existing
-- physical system (Memory 360 / Unlimitail internals were never observed). Written in
-- ANSI-SQL-leaning / PostgreSQL-compatible syntax for portability; adapt types per target platform.
--
-- Table count: 34 (15 dim_, 4 bridge_, 4 cfg_, 2 agg_ landing facts, 9 fact_ atomic facts) —
-- must match the Full Entity Inventory in 03_Canonical_Data_Model.md §10 exactly (verification
-- checkpoint).
--
-- Conventions:
--   - Surrogate keys: <entity>_key BIGINT GENERATED ALWAYS AS IDENTITY (or platform equivalent)
--   - Natural/business keys: <entity>_id / _code, UNIQUE where applicable
--   - Every fact_/agg_ table carries: source_system, load_ts, and (campaign/lift tables only)
--     methodology_version
--   - SCD Type 2 dimensions carry: effective_from, effective_to, is_current
--   - Tables tagged "-- NOT AVAILABLE" or "-- PARTIAL" in comments reflect 02_Input_Data_Catalog.md
--     availability status; the DDL is still proposed so the target schema is ready when/if source
--     data arrives.
-- =============================================================================

-- =============================================================================
-- SECTION 1: DIMENSIONS (Layer 2 — Conformed)
-- =============================================================================

CREATE TABLE dim_date (
    date_key                INTEGER PRIMARY KEY,          -- YYYYMMDD
    calendar_date            DATE NOT NULL UNIQUE,
    iso_week                 SMALLINT NOT NULL,
    iso_year                 SMALLINT NOT NULL,
    month_number              SMALLINT NOT NULL,
    quarter_number             SMALLINT NOT NULL,
    year_number               SMALLINT NOT NULL,
    nielsen_year              SMALLINT,                    -- PARTIAL: concept only, see cfg_nielsen_period_calendar
    nielsen_period_number       SMALLINT
);

CREATE TABLE dim_geography (                              -- AVAILABLE
    region_key    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    region_name   VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE dim_store_banner (                           -- AVAILABLE
    banner_key    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    banner_name   VARCHAR(50) NOT NULL UNIQUE               -- HYPER/EXPRESS/CONTACT/CITY/MARKET
);

CREATE TABLE dim_media_channel (                          -- AVAILABLE (kept separate from dim_store_banner, see 03 §11.1)
    media_channel_key   BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    channel_name        VARCHAR(50) NOT NULL UNIQUE          -- HYPERMARKET/SUPERMARKET/E-COMMERCE/PROXIMITY-CONVENIENCE/CASH & CARRY
);

CREATE TABLE dim_store (                                  -- PARTIAL (scope-limited extractions)
    store_key       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    store_code       VARCHAR(50) NOT NULL,                   -- natural key
    store_name       VARCHAR(200),
    region_key       BIGINT REFERENCES dim_geography(region_key),
    banner_key       BIGINT REFERENCES dim_store_banner(banner_key),
    superficie_bracket VARCHAR(50),
    effective_from    DATE NOT NULL,
    effective_to      DATE,
    is_current       BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT uq_store_natural UNIQUE (store_code, effective_from)
);

CREATE TABLE dim_customer (                               -- NOT AVAILABLE
    customer_key   BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    customer_id     VARCHAR(100) NOT NULL,                  -- natural key / loyalty card id
    card_status     VARCHAR(30),
    enrollment_date  DATE,
    effective_from   DATE NOT NULL,
    effective_to     DATE,
    is_current      BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT uq_customer_natural UNIQUE (customer_id, effective_from)
);

CREATE TABLE dim_customer_segment (                       -- AVAILABLE as glossary text; needs structuring
    segment_key    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    segment_family  VARCHAR(50) NOT NULL,                   -- Lifestage/Structurelle/Consostyle/Promotion/RFM
    detail_level    VARCHAR(20) NOT NULL,                   -- Macro/Micro
    segment_value   VARCHAR(200) NOT NULL,
    definition_text TEXT,                                  -- NULL where undocumented (e.g. RFM — see 06 Important #13)
    CONSTRAINT uq_segment_natural UNIQUE (segment_family, detail_level, segment_value)
);

CREATE TABLE dim_brand (                                  -- PARTIAL (embedded in product master, not standalone)
    brand_key    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    brand_name    VARCHAR(200) NOT NULL UNIQUE,
    brand_type    VARCHAR(10) CHECK (brand_type IN ('MN', 'MDD', 'PP'))
);

CREATE TABLE dim_supplier (                               -- PARTIAL (embedded in product master)
    supplier_key   BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    supplier_name   VARCHAR(200) NOT NULL UNIQUE
);

CREATE TABLE dim_product_hierarchy (                      -- PARTIAL (flattened in source, not normalized)
    hierarchy_key   BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    niveau_1        VARCHAR(200),
    niveau_2        VARCHAR(200),
    niveau_3        VARCHAR(200),
    niveau_4        VARCHAR(200),
    niveau_5        VARCHAR(200),
    niveau_6        VARCHAR(200),
    CONSTRAINT uq_hierarchy_levels UNIQUE (niveau_1, niveau_2, niveau_3, niveau_4, niveau_5, niveau_6)
);

CREATE TABLE dim_product (                                -- PARTIAL (scope-limited to reviewed categories)
    product_key    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    ean            VARCHAR(20) NOT NULL,                    -- natural key
    ean_libelle     VARCHAR(300),
    ean_maitre_key  BIGINT REFERENCES dim_product(product_key),  -- self-reference chaining, rule undocumented (06 Important #14)
    brand_key       BIGINT REFERENCES dim_brand(brand_key),
    supplier_key    BIGINT REFERENCES dim_supplier(supplier_key),
    hierarchy_key   BIGINT REFERENCES dim_product_hierarchy(hierarchy_key),
    triptyque       VARCHAR(10),
    effective_from   DATE NOT NULL,
    effective_to     DATE,
    is_current      BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT uq_product_natural UNIQUE (ean, effective_from)
);

CREATE TABLE dim_product_list (                           -- PARTIAL (target lists enumerable; most benchmark lists name-only)
    product_list_id  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    product_list_name VARCHAR(200) NOT NULL UNIQUE,
    list_type        VARCHAR(20) CHECK (list_type IN ('target', 'benchmark', 'additional'))
);

CREATE TABLE dim_promotion (                              -- NOT AVAILABLE
    promotion_key   BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    mechanic_type    VARCHAR(50),
    discount_value_or_pct DECIMAL(10,4),
    start_date       DATE NOT NULL,
    end_date         DATE,
    CONSTRAINT chk_promotion_dates CHECK (end_date IS NULL OR end_date >= start_date)
);

CREATE TABLE dim_campaign (                               -- PARTIAL (GUID only; most attributes narrative-only)
    campaign_key    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    campaign_id      VARCHAR(100) NOT NULL UNIQUE,           -- Study Id GUID
    campaign_name    VARCHAR(300),
    campaign_type    VARCHAR(100),
    campaign_start_date DATE,
    campaign_end_date   DATE,
    attribution_window_start DATE,
    attribution_window_end   DATE
);

CREATE TABLE dim_audience (                               -- PARTIAL (names only, no rule text)
    audience_key   BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    audience_name   VARCHAR(300) NOT NULL,
    campaign_key    BIGINT REFERENCES dim_campaign(campaign_key),
    version         VARCHAR(20),                            -- e.g. V1/V2/V3
    CONSTRAINT uq_audience_natural UNIQUE (audience_name, campaign_key, version)
);

-- =============================================================================
-- SECTION 2: BRIDGES
-- =============================================================================

CREATE TABLE bridge_product_list_product (                -- PARTIAL
    product_list_id  BIGINT NOT NULL REFERENCES dim_product_list(product_list_id),
    product_key      BIGINT NOT NULL REFERENCES dim_product(product_key),
    effective_from    DATE NOT NULL,
    effective_to      DATE,
    PRIMARY KEY (product_list_id, product_key, effective_from)
);

CREATE TABLE bridge_customer_segment_assignment (         -- NOT AVAILABLE
    customer_key   BIGINT NOT NULL REFERENCES dim_customer(customer_key),
    segment_key    BIGINT NOT NULL REFERENCES dim_customer_segment(segment_key),
    as_of_date     DATE NOT NULL,
    PRIMARY KEY (customer_key, segment_key, as_of_date)
);

CREATE TABLE bridge_campaign_audience (                   -- PARTIAL
    campaign_key   BIGINT NOT NULL REFERENCES dim_campaign(campaign_key),
    audience_key   BIGINT NOT NULL REFERENCES dim_audience(audience_key),
    PRIMARY KEY (campaign_key, audience_key)
);

CREATE TABLE bridge_customer_audience_membership (        -- NOT AVAILABLE
    customer_key   BIGINT NOT NULL REFERENCES dim_customer(customer_key),
    audience_key   BIGINT NOT NULL REFERENCES dim_audience(audience_key),
    as_of_date     DATE NOT NULL,
    PRIMARY KEY (customer_key, audience_key, as_of_date)
);

-- =============================================================================
-- SECTION 3: CONFIGURATION
-- =============================================================================

CREATE TABLE cfg_report_definition (                      -- AVAILABLE
    report_run_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    report_name          VARCHAR(200) NOT NULL,
    retailer             VARCHAR(100) NOT NULL,
    category             VARCHAR(30) CHECK (category IN ('Analyser', 'Extraction')),
    period_type          VARCHAR(30) CHECK (period_type IN ('CAM', 'CAD', 'Personnalisee')),
    analysis_period_start   DATE NOT NULL,
    analysis_period_end     DATE NOT NULL,
    comparison_period_start  DATE,
    comparison_period_end    DATE,
    product_list_id       BIGINT REFERENCES dim_product_list(product_list_id),
    load_ts               TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cfg_nielsen_period_calendar (                -- PARTIAL (concept defined, table not sourced)
    nielsen_year    SMALLINT NOT NULL,
    period_number    SMALLINT NOT NULL CHECK (period_number BETWEEN 1 AND 13),
    period_start_date DATE NOT NULL,
    period_end_date   DATE NOT NULL,
    PRIMARY KEY (nielsen_year, period_number),
    CONSTRAINT chk_nielsen_period_dates CHECK (period_end_date >= period_start_date)
);

CREATE TABLE cfg_kpi_definition (                         -- AVAILABLE (authored as part of this deliverable set)
    kpi_id                BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    kpi_code               VARCHAR(20) NOT NULL UNIQUE,       -- e.g. 'A1', 'F5' matching 04_KPI_Lineage_and_Formulas.md
    kpi_name                VARCHAR(200) NOT NULL,
    formula_text             TEXT,
    aggregation_behavior      VARCHAR(50),
    additivity_class          VARCHAR(30),
    confirmation_status       VARCHAR(20) NOT NULL
        CHECK (confirmation_status IN ('CONFIRMED', 'INFERRED', 'UNVERIFIED', 'UNKNOWN'))
);

CREATE TABLE cfg_currency_tax_treatment (                 -- NOT AVAILABLE
    currency_config_id  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    currency_code        CHAR(3) NOT NULL,
    tax_treatment         VARCHAR(30)                         -- undocumented in any reviewed file
);

-- =============================================================================
-- SECTION 4: TIER 2 — LANDING / AGGREGATE FACTS (AVAILABLE today)
-- =============================================================================

CREATE TABLE agg_report_metric (                          -- AVAILABLE — retail/customer performance family (WB1, WB3, WB4, WB5, deck6)
    agg_report_metric_id  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    report_run_id           BIGINT NOT NULL REFERENCES cfg_report_definition(report_run_id),
    kpi_id                  BIGINT NOT NULL REFERENCES cfg_kpi_definition(kpi_id),
    measurement_basis        VARCHAR(10) CHECK (measurement_basis IN ('CA', 'UVC') OR measurement_basis IS NULL),
    product_key             BIGINT REFERENCES dim_product(product_key),
    brand_key                BIGINT REFERENCES dim_brand(brand_key),
    store_key                BIGINT REFERENCES dim_store(store_key),
    region_key                BIGINT REFERENCES dim_geography(region_key),
    segment_key               BIGINT REFERENCES dim_customer_segment(segment_key),
    date_key                  INTEGER REFERENCES dim_date(date_key),
    value_analyse             DECIMAL(20,4),
    value_comparaison          DECIMAL(20,4),
    evolution_value            DECIMAL(20,4),
    evolution_pct              DECIMAL(10,6),
    ecart_vs_benchmark          DECIMAL(10,6),                -- UNVERIFIED formula, see 04 §C3 / 06 Blocking #6
    is_total_row               BOOLEAN NOT NULL DEFAULT FALSE, -- see 03 §3 grain policy — never SUM() across a TRUE row + its details
    grain_level                VARCHAR(200),
    source_sheet_name           VARCHAR(200) NOT NULL,
    source_system               VARCHAR(50) NOT NULL,
    load_ts                     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_agg_report_metric_run_kpi ON agg_report_metric (report_run_id, kpi_id);

CREATE TABLE agg_campaign_metric (                        -- AVAILABLE (descriptive values) — campaign/lift family (WB2, deck7)
    agg_campaign_metric_id  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    campaign_key              BIGINT NOT NULL REFERENCES dim_campaign(campaign_key),
    kpi_id                     BIGINT NOT NULL REFERENCES cfg_kpi_definition(kpi_id),
    period                     VARCHAR(30) CHECK (period IN ('Pre Campaign', 'Campaign')),
    product_list_id             BIGINT REFERENCES dim_product_list(product_list_id),
    group_assignment            VARCHAR(20) CHECK (group_assignment IN ('Control', 'Exposed') OR group_assignment IS NULL),
    audience_key                BIGINT REFERENCES dim_audience(audience_key),
    media_channel_key            BIGINT REFERENCES dim_media_channel(media_channel_key),
    value                       DECIMAL(20,4),
    is_multisegment_resampled     BOOLEAN,                    -- meaning UNVERIFIED, see 04 §F7 / 06 Blocking #4
    is_total_row                 BOOLEAN NOT NULL DEFAULT FALSE,
    grain_level                  VARCHAR(200),
    source_sheet_name             VARCHAR(200) NOT NULL,
    source_system                 VARCHAR(50) NOT NULL,
    load_ts                       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    methodology_version            VARCHAR(30)                 -- deliberately nullable/unresolved, see 03 design principle 6
);

CREATE INDEX idx_agg_campaign_metric_campaign_kpi ON agg_campaign_metric (campaign_key, kpi_id);

-- =============================================================================
-- SECTION 5: TIER 1 — ATOMIC BUSINESS FACTS (target-state; mostly NOT AVAILABLE)
-- =============================================================================

CREATE TABLE fact_transaction_header (                    -- NOT AVAILABLE
    transaction_id   VARCHAR(100) PRIMARY KEY,
    customer_key      BIGINT REFERENCES dim_customer(customer_key),
    store_key         BIGINT NOT NULL REFERENCES dim_store(store_key),
    date_key          INTEGER NOT NULL REFERENCES dim_date(date_key),
    total_revenue      DECIMAL(20,4) NOT NULL,
    is_cardholder_flag  BOOLEAN,
    source_system      VARCHAR(50) NOT NULL,
    load_ts            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE fact_transaction_line (                      -- NOT AVAILABLE
    transaction_line_id  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    transaction_id         VARCHAR(100) NOT NULL REFERENCES fact_transaction_header(transaction_id),
    line_number             INTEGER NOT NULL,
    product_key             BIGINT NOT NULL REFERENCES dim_product(product_key),
    store_key                BIGINT NOT NULL REFERENCES dim_store(store_key),
    customer_key             BIGINT REFERENCES dim_customer(customer_key),
    date_key                 INTEGER NOT NULL REFERENCES dim_date(date_key),
    promotion_key             BIGINT REFERENCES dim_promotion(promotion_key),
    quantity                 DECIMAL(12,3) NOT NULL,
    unit_price                DECIMAL(12,4) NOT NULL,
    line_revenue               DECIMAL(20,4) NOT NULL,
    source_system              VARCHAR(50) NOT NULL,
    load_ts                    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_transaction_line UNIQUE (transaction_id, line_number)
);

CREATE INDEX idx_fact_transaction_line_product ON fact_transaction_line (product_key);
CREATE INDEX idx_fact_transaction_line_store_date ON fact_transaction_line (store_key, date_key);
CREATE INDEX idx_fact_transaction_line_customer ON fact_transaction_line (customer_key);

CREATE TABLE fact_product_store_availability (            -- NOT AVAILABLE
    store_key      BIGINT NOT NULL REFERENCES dim_store(store_key),
    product_key    BIGINT NOT NULL REFERENCES dim_product(product_key),
    as_of_date      DATE NOT NULL,
    is_ranged_flag   BOOLEAN NOT NULL,
    source_system    VARCHAR(50) NOT NULL,
    load_ts          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (store_key, product_key, as_of_date)
);

CREATE TABLE fact_store_lifecycle_event (                 -- NOT AVAILABLE
    store_key    BIGINT NOT NULL REFERENCES dim_store(store_key),
    event_date    DATE NOT NULL,
    event_type    VARCHAR(30) NOT NULL CHECK (event_type IN ('open', 'close', 'remodel')),
    source_system  VARCHAR(50) NOT NULL,
    load_ts        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (store_key, event_date, event_type)
);

CREATE TABLE fact_customer_period_status (                -- NOT AVAILABLE (rule CONFIRMED, data is not)
    customer_key      BIGINT NOT NULL REFERENCES dim_customer(customer_key),
    product_list_id     BIGINT NOT NULL REFERENCES dim_product_list(product_list_id),
    period_pair_id      VARCHAR(50) NOT NULL,
    movement_status     VARCHAR(20) NOT NULL CHECK (movement_status IN ('Constants', 'Gagne', 'Perdu')),
    source_system        VARCHAR(50) NOT NULL,
    load_ts               TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (customer_key, product_list_id, period_pair_id)
);

CREATE TABLE fact_new_shopper_flag (                      -- NOT AVAILABLE
    customer_key       BIGINT NOT NULL REFERENCES dim_customer(customer_key),
    campaign_key        BIGINT NOT NULL REFERENCES dim_campaign(campaign_key),
    is_new_shopper_flag   BOOLEAN NOT NULL,
    lookback_window_days   INTEGER,                          -- UNVERIFIED, see 06 Blocking #9
    source_system         VARCHAR(50) NOT NULL,
    load_ts                TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (customer_key, campaign_key)
);

CREATE TABLE fact_loyal_shopper (                         -- NOT AVAILABLE (rule CONFIRMED but discrepant; base data not)
    customer_key           BIGINT NOT NULL REFERENCES dim_customer(customer_key),
    product_list_id          BIGINT NOT NULL REFERENCES dim_product_list(product_list_id),
    period_id                VARCHAR(50) NOT NULL,
    purchase_count_in_period   INTEGER NOT NULL,
    is_loyal_shopper_flag       BOOLEAN NOT NULL,
    rule_source                VARCHAR(20) CHECK (rule_source IN ('WB2_gt2', 'deck6_gte2')),  -- see 06 Important #11
    source_system              VARCHAR(50) NOT NULL,
    load_ts                     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (customer_key, product_list_id, period_id, rule_source)
);

CREATE TABLE fact_media_exposure (                        -- NOT AVAILABLE
    impression_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    campaign_key          BIGINT NOT NULL REFERENCES dim_campaign(campaign_key),
    customer_key          BIGINT REFERENCES dim_customer(customer_key),
    media_channel_key      BIGINT NOT NULL REFERENCES dim_media_channel(media_channel_key),
    impression_timestamp   TIMESTAMP NOT NULL,
    source_system          VARCHAR(50) NOT NULL,
    load_ts                 TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_fact_media_exposure_campaign ON fact_media_exposure (campaign_key);
CREATE INDEX idx_fact_media_exposure_customer ON fact_media_exposure (customer_key);

CREATE TABLE fact_campaign_group_assignment (             -- NOT AVAILABLE
    customer_key       BIGINT NOT NULL REFERENCES dim_customer(customer_key),
    campaign_key        BIGINT NOT NULL REFERENCES dim_campaign(campaign_key),
    group_assignment     VARCHAR(20) NOT NULL CHECK (group_assignment IN ('Control', 'Exposed')),
    assignment_method     VARCHAR(100),                       -- NOT AVAILABLE, see 06 Blocking #2
    methodology_version    VARCHAR(30),
    source_system          VARCHAR(50) NOT NULL,
    load_ts                 TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (customer_key, campaign_key)
);

CREATE TABLE fact_campaign_cost (                         -- PARTIAL (totals only observed)
    campaign_key       BIGINT NOT NULL REFERENCES dim_campaign(campaign_key),
    media_channel_key    BIGINT NOT NULL REFERENCES dim_media_channel(media_channel_key),
    date_key             INTEGER NOT NULL REFERENCES dim_date(date_key),
    cost                 DECIMAL(20,4) NOT NULL,
    source_system         VARCHAR(50) NOT NULL,
    load_ts                TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (campaign_key, media_channel_key, date_key)
);

-- =============================================================================
-- END OF DDL — 35 tables total (verification checkpoint against 03_Canonical_Data_Model.md §10):
--   Dimensions (15): dim_date, dim_customer, dim_customer_segment, dim_product, dim_brand,
--     dim_supplier, dim_product_hierarchy, dim_product_list, dim_store, dim_geography,
--     dim_store_banner, dim_media_channel, dim_promotion, dim_campaign, dim_audience
--   Bridges (4): bridge_product_list_product, bridge_customer_segment_assignment,
--     bridge_campaign_audience, bridge_customer_audience_membership
--   Configuration (4): cfg_report_definition, cfg_nielsen_period_calendar, cfg_kpi_definition,
--     cfg_currency_tax_treatment
--   Landing/Aggregate facts (2): agg_report_metric, agg_campaign_metric
--   Atomic facts (10): fact_transaction_header, fact_transaction_line,
--     fact_product_store_availability, fact_store_lifecycle_event, fact_customer_period_status,
--     fact_new_shopper_flag, fact_loyal_shopper, fact_media_exposure,
--     fact_campaign_group_assignment, fact_campaign_cost
-- =============================================================================
