# 09 — Data Quality Rules

**Purpose:** Consistency and data-quality rules that must hold across the canonical model in
[03_Canonical_Data_Model.md](03_Canonical_Data_Model.md), grounded in the specific structural risks
found in [02_Input_Data_Catalog.md](02_Input_Data_Catalog.md) and `review_findings.md`. Organized per
the task's required consistency-check categories.

---

## 1. Every KPI has documented source fields, or is explicitly marked unsupported

- **Rule DQ-1.1:** Every row in `cfg_kpi_definition` must have a non-null `formula_text` OR a
  `confirmation_status` of `UNVERIFIED`/`UNKNOWN` with an explanatory note — never a null formula
  silently paired with `CONFIRMED` status.
- **Rule DQ-1.2:** Every `kpi_code` referenced in `agg_report_metric`/`agg_campaign_metric` must
  exist in `cfg_kpi_definition` (referential integrity via FK; enforced at the database level).
- **Rule DQ-1.3:** KPIs tagged UNVERIFIED/BLOCKING in
  [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md) (C3, C4, C5, F5, F6, F7) must
  **never** appear in [08_Sample_KPI_Queries.sql](08_Sample_KPI_Queries.sql) with a computed formula
  — verified: they do not (08 only reads pass-through input values for these).

## 2. Fact-table grains do not conflict

- **Rule DQ-2.1:** `fact_transaction_line` grain is (transaction_id, line_number) — enforced by
  `UNIQUE (transaction_id, line_number)`. No aggregation query may join this table to
  `fact_transaction_header` and then re-aggregate `total_revenue` alongside `SUM(line_revenue)`
  without reconciling the two (both should match; a mismatch is a DQ alert, not a modeling choice).
- **Rule DQ-2.2:** `agg_report_metric` and `agg_campaign_metric` grains vary per source sheet (see
  `grain_level` column, 03 §3). Any consumer query must filter/group consistently with the
  `grain_level` value actually present in the rows being read — never assume a fixed grain across
  the whole table.
- **Rule DQ-2.3:** `fact_loyal_shopper` intentionally carries **two** grain-compatible but
  rule-distinct rows per (customer, product_list, period) — one per `rule_source` value (`WB2_gt2`,
  `deck6_gte2`) — because 06 Important #11 documents a genuine source discrepancy. Consumers must
  always filter on `rule_source` explicitly; a query that omits this filter will double-count loyal
  shoppers.

## 3. No hidden many-to-many relationships via direct dimension joins

- **Rule DQ-3.1:** `dim_product.ean_maitre_key` is a self-referencing FK, not a many-to-many
  relationship — enforced by keeping it a single nullable FK column (one master per product per
  effective period), not a bridge table, since no evidence of multi-master mapping was found.
- **Rule DQ-3.2:** Product-list membership (`bridge_product_list_product`), segment assignment
  (`bridge_customer_segment_assignment`), campaign audience (`bridge_campaign_audience`), and
  customer audience membership (`bridge_customer_audience_membership`) are **always** modeled via
  bridge tables, never as a direct FK on the dimension row, precisely because all four relationships
  are confirmed or strongly implied to be many-to-many and time-varying.
- **Rule DQ-3.3:** Joining `dim_product` directly to `dim_product_list` (skipping the bridge) is
  disallowed by design — no such FK column exists on either table.

## 4. Totals are never double-counted

- **Rule DQ-4.1 (single most important rule in this file):** Any query aggregating
  `agg_report_metric` or `agg_campaign_metric` must filter `is_total_row = FALSE` before applying
  `SUM()`/`COUNT()` across detail rows, OR must select the `is_total_row = TRUE` row directly and
  perform no further aggregation. Combining both in one aggregate is a defect
  (review_findings.md §1.3, 03 §3).
- **Rule DQ-4.2:** ETL load jobs populating `agg_report_metric`/`agg_campaign_metric` must tag
  `is_total_row` at ingestion time by detecting the literal `"Total"` dimension-member label in the
  source sheet — never inferred after the fact by checking whether a row's value equals the sum of
  its siblings (siblings may not even be present in a given extract).

## 5. Total rows are never mixed with atomic records in the same result set without a flag

- **Rule DQ-5.1:** Any report-output view (Layer 5) that blends `agg_report_metric` detail rows with
  a `fact_transaction_line`-derived recomputation (once available) must carry a `row_origin` column
  (`'landing_aggregate'` vs `'atomic_recomputed'`) so downstream consumers can distinguish
  provenance and never treat the two as interchangeable without disclosure.

## 6. Bridge tables exist for every overlapping product list / audience / segment relationship

- **Rule DQ-6.1:** Confirmed via 03 §6 — `bridge_product_list_product`, `bridge_campaign_audience`,
  `bridge_customer_audience_membership`, `bridge_customer_segment_assignment` cover all four
  known overlapping relationships identified in 02 (#9, #16, #22, #23). No additional bridge is
  known to be missing at this time; revisit if new overlapping relationships are discovered.

## 7. Effective dates exist for products, stores, and segment assignments

- **Rule DQ-7.1:** `dim_product`, `dim_store`, and `dim_audience` all carry `effective_from` /
  `effective_to` (+ `is_current` where Type 2) columns. `bridge_customer_segment_assignment` and
  `bridge_customer_audience_membership` use point-in-time `as_of_date` rather than a range, since
  segment/audience assignment is expected to be re-evaluated per period rather than continuously
  versioned — **[PROPOSED, revisit if the client confirms continuous-range assignment instead]**.
- **Rule DQ-7.2:** Any join to `dim_product`/`dim_store` for a historical fact row must match on
  `effective_from <= fact_date AND (effective_to IS NULL OR effective_to > fact_date)`, never on the
  natural key alone, to avoid silently attributing historical facts to the current version of a
  changed product/store record.

## 8. PII handling

- **Rule DQ-8.1:** `dim_customer.customer_id` is a natural/business key that may itself be
  sensitive (loyalty card identifier). No name, address, email, or phone column is modeled anywhere
  in this design, because none was observed in any of the 7 reviewed files — adding such columns
  would be an unsupported assumption, not a documented requirement.
- **Rule DQ-8.2:** If a future atomic customer source does supply PII fields, they must be added to
  `dim_customer` behind an access-controlled view/column-level security policy, not exposed directly
  in `agg_report_metric`/`agg_campaign_metric`, which are intended for broad analytical access.

## 9. Source-vs-recommendation separation

- **Rule DQ-9.1:** Every table/column in this deliverable set that is **NOT AVAILABLE** or
  **PARTIAL** is explicitly commented as such in [07_Proposed_DDL.sql](07_Proposed_DDL.sql) and
  tagged in [03_Canonical_Data_Model.md](03_Canonical_Data_Model.md) — no proposed/target-state
  design is presented as if it already reflects an existing system.
- **Rule DQ-9.2:** No KPI formula in [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md)
  or query in [08_Sample_KPI_Queries.sql](08_Sample_KPI_Queries.sql) is stated as CONFIRMED unless it
  was either (a) explicitly stated in a reviewed source file, or (b) independently recomputed against
  a sample value already present in `Report_Analysis_Catalog.md` and matched. All others remain
  INFERRED, UNVERIFIED, or UNKNOWN.

## 10. Cross-family terminology collisions do not silently merge

- **Rule DQ-10.1:** "Frequency" (A6, purchase-visit frequency) and "Frequency"/"Impressions" (F3,
  media-exposure frequency) are never modeled as the same `kpi_code` or the same fact column — they
  are `A6` and `F3` respectively in `cfg_kpi_definition`, with distinct `agg_report_metric` vs
  `agg_campaign_metric` homes.
- **Rule DQ-10.2:** "Constants" is never modeled as a single shared table/column across the retail
  family (customer-grain, WB1) and the performance family (store-grain, WB3). `fact_customer_period_status`
  is customer-grain only; any store-grain "no material format change" concept, if modeled in future,
  must be a distinct `fact_store_lifecycle_event`-derived attribute, never unioned with customer
  `movement_status` values.

## 11. Brand-name and identifier normalization

- **Rule DQ-11.1:** ETL loading `dim_brand` must apply a documented alias-normalization step (e.g.
  `COCA COLA` → `COCA-COLA`) before generating a surrogate `brand_key`, per 06 Important #19 — never
  silently create two brand rows for what is evidently one brand without recording the applied alias
  rule in an audit column.
