# Review Findings — Issues & Inconsistencies in `Report_Analysis_Catalog.md`

**Purpose:** Independent re-review of the full catalog (§0–§7 + summary) performed before designing
the canonical data model. This document records contradictions, naming collisions, unverifiable
claims, and places where the catalog's own `[INFERRED]`/`[UNVERIFIED]`/`[GAP]` labels needed to be
preserved or sharpened. It does **not** re-derive new business facts — it only audits the existing
document for internal consistency and modeling risk.

Status labels used below: **OBSERVED** (directly stated in the catalog and traceable to a cell/slide),
**INFERRED** (the catalog's own inference, carried forward), **RISK** (a modeling risk this
inconsistency creates if not handled carefully).

---

## 1. Contradictions between files

### 1.1 "Constants" means three different things depending on file
- WB1 `Bilan`/`Profil`: **`Constants`** = a *customer* who bought the product scope in both periods
  (§1.5 of catalog).
- WB3 `Où (CA)/(UVC)`: **`Constants`** (as `Magasins constants`) = a *store* that has not opened/
  closed/changed surface between the two periods (§3.2/§3.3), explicitly distinguished in the
  Lexique from `Magasins courants` (stores that sold at least once in both periods).
- **RISK:** The same label "Constants" is overloaded across a **customer-grain** concept and a
  **store-grain** concept. Any canonical model must never store these in the same table/column;
  they must be modeled as `fact_customer_period_status.status = 'Constant'` (customer grain) vs. a
  `dim_store.is_constant_flag` (store grain) — fully separate entities. See
  [03_Canonical_Data_Model.md](03_Canonical_Data_Model.md).

### 1.2 "Shoppers"/"Clients" are not proven to be the same population definition across report families
- WB1/WB3 (French, retail performance family): `Clients`/`Nb de clients` = counted at the **loyalty
  card (encarté)** level primarily, with an explicit `Non encartés` counterpart tracked separately
  (§1.2 Bilan).
- WB2/deck6/deck7 (campaign/lift family): `Shoppers` = anyone who purchased during the campaign,
  attributed via the **loyalty card database** per deck7's footer ("Carrefour loyalty card holders
  database") — this suggests campaign "Shoppers" **are** loyalty-card-identified, similar to WB1's
  `Encartés`, but the catalog **never confirms these are the same identity-resolution pipeline or the
  same customer ID space**. **RISK:** Do not assume `dim_customer` keys are shared/joinable between
  the two report families without client confirmation. Flagged as `[UNVERIFIED — cross-file]` in
  [06_Open_Questions.md](06_Open_Questions.md).

### 1.3 "Total" as a dimension member vs. a computed grand total
- Nearly every workbook (§1.2, §2.2, §4.2, §5.2) stores **`Total` as a literal data row** (a
  pre-aggregated dimension member), not as a spreadsheet-computed SUM. This is consistent across
  files, but it creates a **real risk of double-counting** if a future model's fact table mixes
  `Total` rows with the detail rows they summarize and someone naively `SUM()`s the whole table.
  **This is the single most important cross-file consistency finding** for physical model design —
  addressed explicitly via the `is_total_row` / `aggregation_level` convention in
  [03_Canonical_Data_Model.md](03_Canonical_Data_Model.md) and checked in
  [09_Data_Quality_Rules.md](09_Data_Quality_Rules.md).

### 1.4 Segmentation taxonomy names are similar but not proven identical across files
- WB1 Lexique defines: `Lifestage`, `Structurelle`, `Consostyle`, `Promotion` (French names, with
  full Macro/Micro segment lists).
- WB3 Lexique redefines the **same four family names** more completely (catalog treats WB3's Lexique
  as authoritative/master — §3.9 item 3).
- WB2 uses **`LIFESTAGE`, `CONSOSTYLE`, `PROMO`, `RFM`** (English/uppercase, via `Hierarchy 1`), of
  which `RFM` has **no definition anywhere** in the file set (§2.9 item 5).
- Deck7 slides 12–13 use "Lifestage" and "Consostyle" segment labels (`Deal seekers, Budget, Gourmet,
  Nutrition, Convenience`) that the catalog treats as a "cross-file confirmation" of WB3's Lexique
  (§7.2 slide 13, §7.9 not flagged as risk). **RISK — sharpened here:** the catalog calls this a
  "confirmation," but it is still only a **name match**, not a proof that the segment *computation
  logic* (which customer lands in "Gourmet" vs. "Nutrition") is identical between the retail
  performance platform (Memory 360) and the retail-media platform behind WB2/decks. Two systems can
  use the same label for a segment with different derivation rules. This should be downgraded from
  "confirmed" to `[INFERRED — name-level match only]` until the client confirms it's the same
  segmentation engine/output. See [06_Open_Questions.md](06_Open_Questions.md) Q on segmentation
  consistency.

### 1.5 Two different vendor/platform names, never directly reconciled
- "Memory 360" (all 5 Excel workbooks) vs. "Unlimitail" (both decks). The catalog's closing summary
  labels the JV relationship `[INFERRED]` — correctly hedged — but earlier per-file sections (e.g.
  §7.1) state Unlimitail "explicitly named" without re-flagging that the *connection* to Memory 360 is
  still inferred. Carried forward here as: **OBSERVED** — two distinct names appear; **INFERRED** —
  they represent the same vendor/JV.

---

## 2. Concepts that appear under different names (terminology crosswalk)

See the full bilingual crosswalk table in
[01_Executive_Summary.md](01_Executive_Summary.md#terminology-crosswalk). Summary of the pairs
explicitly required by the task, with an evidence pointer and an equivalence-confidence flag:

| French term | English term | Evidence (workbook/sheet/slide) | Equivalence confidence |
|---|---|---|---|
| CA | Revenue | WB1 Bilan; WB3 Performance; WB2 "Revenue"; deck7 slide 9 | **High** — same concept, both = gross sales value; currency/tax treatment unconfirmed (see Open Questions) |
| UVC | Units / Quantity | WB1/WB3 "UVC"; WB2 "Quantity"; deck7 "Item/basket" | **High** — both = unit count sold |
| Client | Shopper | WB1 "Clients"; WB2/deck7 "Shoppers" | **Medium** — same conceptual role (a buying person) but population/identity-resolution rules not proven identical (§1.2 above) |
| Panier | Basket / Transaction / Receipt | WB1/WB3 "Panier"; WB2 "Receipts"; deck7 "Transactions" | **High** — all = one checkout/purchase event; WB2 additionally uses "Receipts" as a count noun distinct from "Basket" as a value noun |
| Encarté | Cardholder | WB1/WB3 "Encartés"/"Non encartés"; deck6/7 footers "loyalty card holders" | **High** — explicit definition present (Lexique) |
| Bannière | Banner | WB1 Lexique ("format du magasin"); WB3/WB4/WB5 `Bannière` column | **High** |
| Marque | Brand | Universal across all files | **High** |
| Magasin | Store | WB3/WB4/WB5 | **High** |
| Poids promo | Promotional Share | WB1 Lexique; WB3 "Poids CA/UVC promo"; WB4 "CA promo" | **High** for the CA/UVC-share concept; **Low** for whether the *promotion eligibility rule* is identical across workbooks (see Open Questions) |
| Evolution | Period-over-Period Change | Universal; formula verified in WB1/3/4 | **High** (formula independently verified by recomputation) |
| DN | Numeric Distribution / Numeric Detention | WB3 labels it "Numeric Detention" (own translation); WB2 sheet is literally named "Numeric Distribution by SKU" | **Medium** — same underlying ratio (Selling Stores/Total Stores, verified in WB2) but the two workbooks use **different English translations of the same French term**, which is itself a terminology risk worth flagging to the client (is "Détention" or "Distribution" the client's preferred English term?) |

**Explicit non-merge decision:** Per the task's instruction, the following are **not** merged despite
surface-level naming similarity, because the catalog does not provide evidence of an identical
definition:
- WB1 "Constants" (customer) vs. WB3 "Magasins constants" (store) — see §1.1 above.
- WB1/WB3 `Gagné`/`Perdu` (customer gain/loss, retailer-scope cohort logic) vs. WB2/deck
  `New`/`Returning Shopper` (simple first-purchase-in-period flag) — structurally different
  classification logic (3-way "gagné" sub-decomposition vs. binary new/returning), even though both
  are period-over-period customer-movement concepts.
- WB2/WB3's "Consostyle"/"Lifestage" labels vs. deck7's same labels — name match only, not proven
  identical computation (§1.4 above).

---

## 3. Unverifiable / weakly-evidenced claims carried over from the catalog

These are not new problems, but this document explicitly re-flags them so they are not silently
treated as confirmed while building the model:

1. **`Ecart vs Benchmark`, `VMH`, `DV`, exact base of `Indice CA/UVC`** — catalog marks all four
   `[INFERRED]`/not in any Lexique (§1.4/§3.9). No formula has been independently verified for these
   four (unlike Evolution %, Panier moyen, DN, which *were* verified by recomputation). Treated as
   **UNVERIFIED formula** in [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md).
2. **Lift/incrementality methodology (WB2 §2.5, deck7 §7.5)** — the catalog is careful to label the
   *existence* of a Control-vs-Exposed structure as OBSERVED, but the *statistical method*
   (matching/weighting/resampling, p-value test type) as `[GAP]`. This is carried forward as a
   **BLOCKING** open question — see [06_Open_Questions.md](06_Open_Questions.md).
3. **WB2 "Performance by Audience" anomalous values** (§2.2 data quality note) — near-zero/near-one
   values inconsistent with the rest of the workbook's KPI scale. The catalog correctly declines to
   treat these as literal KPI values. Carried forward as a **data-quality flag**, not as a modeling
   input, in [09_Data_Quality_Rules.md](09_Data_Quality_Rules.md).
4. **Retailer identity for WB4/WB5** — `[INFERRED, unconfirmed]` in the catalog (§4.9/§5.9) via
   banner/region taxonomy match only, never an explicit "Retailer = Carrefour" field like WB3's
   `Paramètres`. Still `[INFERRED]` here — not upgraded to confirmed, even though decks 6/7
   independently confirm Carrefour as *a* retailer in this file set (that confirmation applies to
   WB1/WB3's explicit "Carrefour" label and to the decks themselves, not automatically to WB4/WB5's
   unlabeled scope).
5. **"Benchmark produits" gain/loss categories** (WB1 §1.5 item 3) — defined in the glossary but with
   **zero corresponding data rows** in the reviewed export. Treated as a **defined-but-unobserved**
   category — do not assume it is unused in general, only that it happened to be empty in this sample
   export.

---

## 4. Structural/grain risks worth flagging before modeling

1. **Every reviewed KPI table is already aggregated.** No file in the set contains transaction-line,
   receipt-header, or atomic customer-event data. This is the single most consequential finding for
   the whole exercise (explicitly instructed by the task: "Do not treat pre-calculated KPI tables as
   proof that the underlying atomic data is available"). Every fact table proposed in
   [03_Canonical_Data_Model.md](03_Canonical_Data_Model.md) that requires atomic grain is explicitly
   marked `NOT AVAILABLE — required as new input` rather than inferred to exist.
2. **Column-count/range inflation artifact** (empty-string cells) noted repeatedly by the catalog
   (WB1, WB3) is a **file-format quirk**, not a data-modeling concern — confirmed not to affect any
   KPI value, only `ws.dimensions` metadata. No further action needed beyond what the catalog already
   recorded.
3. **Two workbooks (WB4/WB5) share a near-identical schema** (`Paramètres` / `Indicateurs` /
   `Informations produits` / `Informations magasins`) but represent **two different extraction
   "modes"** of the same underlying tool (category snapshot vs. daily time series). This is good
   evidence for a single, mode-parameterized `cfg_report_definition` design rather than two separate
   config tables.

---

## 5. Concepts sharing a name but with unclear/possibly different definitions

| Concept | File A definition | File B definition | Resolution applied |
|---|---|---|---|
| DN (Numeric Detention/Distribution) | WB3: "Share of stores stocking the product(s) under study" (own translation label) | WB2: `Numeric Distribution = Selling Stores / Total Stores` (verified formula) | Treated as the **same ratio**, different translation of the French term — see crosswalk table above; formula from WB2 applied as the working definition since it was independently verified |
| Indice CA / UVC | WB1: "Over/under-representation vs. total CA share; 100 = neutral" | WB3: same label, base not re-confirmed | Treated as the same metric family (index vs. a 100 baseline), but the **baseline population** (total store, total category, total benchmark?) is `[UNVERIFIED]` per-workbook and must be confirmed per report before implementation |
| Fréquence | WB1: "Average number of visits by cardholders" | WB2: no explicit definition, `[INFERRED]` "Transactions ÷ Shoppers" | Kept as **two separate KPI lineage rows** in [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md) since WB1's is over a fixed calendar period while WB2's is implicitly per-campaign — same formula shape, different period-scoping rules |

---

## 6. Summary of resulting modeling decisions

- No fact table in the proposed model is allowed to mix `Total`/aggregate rows with detail rows
  without an explicit `is_total_row` / `grain_level` discriminator column.
- Customer-grain "Constants"/"Gagné"/"Perdu" and store-grain "Constants" are modeled as attributes of
  entirely different entities (`fact_customer_period_status` vs. `dim_store.is_constant_flag`).
- No shared `dim_customer` key is assumed between the retail-performance family and the
  campaign/lift family unless/until the client confirms identity resolution is common — the model
  keeps `dim_customer` single but flags this join as `[UNVERIFIED]` in
  [10_Model_Assumptions_and_Decisions.md](10_Model_Assumptions_and_Decisions.md).
- All four segmentation families (`Lifestage`, `Structurelle`, `Consostyle`, `Promotion`/`Promo`) are
  modeled as one conformed `dim_customer_segment` reference table seeded from WB3's Lexique (the
  richest source), with `RFM` added as a fifth family with `definition = NULL` pending client input.
- Every KPI without an independently verified formula (`Ecart vs Benchmark`, `VMH`, `DV`, `Indice`
  baseline, lift/p-value methodology) is marked **UNKNOWN/UNVERIFIED** in the KPI lineage matrix, not
  guessed.
