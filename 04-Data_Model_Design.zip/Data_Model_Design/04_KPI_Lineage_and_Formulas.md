# 04 — KPI Lineage & Formulas

**Purpose:** For every KPI observed (or explicitly required by the task spec) across the 7 reviewed
files, document its full lineage — definition, source, required base fields, formula, aggregation
behavior, edge-case handling, and confirmation status — so that the canonical model
([03_Canonical_Data_Model.md](03_Canonical_Data_Model.md)) and DDL/sample queries can be built without
re-guessing business logic. Cross-referenced against `Report_Analysis_Catalog.md` (all §0–§7) and
`02_Input_Data_Catalog.md`.

**Status legend:**
- **CONFIRMED** — independently recomputed and matched against a sampled source value
  (Report_Analysis_Catalog.md verification), or explicitly stated as a formula/definition in a source
  file (Lexique / Paramètres / deck narrative).
- **INFERRED** — plausible from column co-occurrence, naming convention, or standard domain
  vocabulary, but not independently recomputed or explicitly stated.
- **UNVERIFIED** — a term/value exists in source but its exact calculation cannot be determined from
  any reviewed file; must not be treated as a known formula until confirmed by the client.
- **UNKNOWN** — no source evidence at all beyond the KPI's name.

Every KPI below is tagged against the task's 8 required categories in the **Row-fact classification**
field: *Atomic source input / Reference-master data / Configuration-parameter / Derived row-level
attribute / Calculated KPI / Pre-aggregated source output / Presentation-only value / Unknown-requires
clarification*. All KPIs catalogued here are **Calculated KPI** and/or **Pre-aggregated source
output** (never atomic inputs) — this is itself a key modeling finding, restated per-KPI for
traceability.

---

## A. Core Business Equation KPIs (Revenue–Volume–Basket family)

### A1. Revenue (CA)
- **Alt/translated names:** Chiffre d'Affaires, CA total, CA encartés/non encartés, Revenue.
- **Definition:** Total monetary sales value realized over the selected scope (product × store ×
  period × customer-type), gross incl. tax, cardholders and non-cardholders combined unless split.
- **Reports using it:** Customer Loyalty Bilan/Profile (WB1 §1.2), Performance/Quoi/Quand/Où/Qui (WB3
  §3.2–§3.4), Product Extraction Indicators (WB4 §4.4), Temporal Evolution (WB5 §5.4), Presales
  Insights slides 1–3 (§6.4), Measurement Report slide 9 "Revenue" (§7.4).
- **Required base fields:** Transaction line revenue (dataset #1, not available) or the
  pre-aggregated export itself (dataset #3, available).
- **Dimensions supported:** product/brand/category, store/banner/region, customer segment,
  cardholder status, period, channel.
- **Formula:** `CA = Σ(line_revenue)` over the scope, or (verified decomposition) `CA = Nb clients ×
  Fréquence × Panier moyen`.
- **Aggregation behavior:** Additive across product, store, and customer dimensions; **not** additive
  across overlapping "Total" rows (Total is a separate pre-computed row, not a SUM of the detail rows
  shown alongside it — review_findings.md §1.3).
- **Period logic:** CAM (rolling 13-Nielsen-period) or CAD (year-to-date) or custom, per report
  `Paramètres` (dataset #33).
- **Filters:** Product scope, store scope (constants/courants), transaction type (e-commerce vs.
  magasin), customer type (encartés/non encartés).
- **Null handling:** A scope with zero qualifying transactions should report CA = 0, not null.
- **Zero-denominator behavior:** N/A (CA is a numerator, not a ratio).
- **Rounding/display:** Currency, 2 decimals as observed in all sampled exports.
- **Additivity:** Fully additive (across product/store/customer, excluding pre-computed Total rows).
- **Status:** **CONFIRMED** (independently recomputed via the `CA = Clients × Fréquence × Panier
  moyen` identity in WB1, WB3, WB4, and confirmed narratively in deck 7 slide 9).
- **Row-fact classification:** Calculated KPI / Pre-aggregated source output (as observed in all 7
  files — never seen at atomic grain).
- **Test cases needed:** Verify CA(Total) ≠ SUM(CA of detail rows) is expected, not a bug; verify
  CA(encartés) + CA(non encartés) = CA(total) for the same scope.

### A2. Units (UVC)
- **Alt/translated names:** Unité de Vente Consommateur, UVC encartés, Quantity, Units.
- **Definition:** Count of individual product units sold over the selected scope.
- **Reports using it:** Same report set as A1 (UVC is CA's unit-count counterpart throughout WB1/3/4/5
  and both decks).
- **Required base fields:** Transaction line quantity (dataset #1, unavailable) or pre-aggregated
  export (#3).
- **Dimensions supported:** Same as A1.
- **Formula:** `UVC = Σ(quantity)` over the scope.
- **Aggregation behavior:** Additive, same caveats as A1 re: Total rows.
- **Period logic:** Same as A1.
- **Filters:** Same as A1.
- **Null handling:** Zero, not null, for a scope with no sales.
- **Zero-denominator behavior:** N/A.
- **Rounding/display:** Integer count.
- **Additivity:** Fully additive (excluding Total rows).
- **Status:** **CONFIRMED** (used directly in the verified `Panier moyen = UVC/panier × Prix moyen`
  and `Prix moyen = CA/UVC` identities, WB3 §3.5, WB4 §4.5).
- **Row-fact classification:** Calculated KPI / Pre-aggregated source output.
- **Test cases needed:** UVC(encartés) + UVC(non encartés) = UVC(total) for the same scope.

### A3. Transactions / Receipts (Nb de paniers)
- **Alt/translated names:** Nombre de paniers, Paniers, Receipts, Transactions.
- **Definition:** Count of distinct checkout/basket events in the scope.
- **Reports using it:** Performance (WB3 §3.4, "Formule de vente"), Product Extraction Indicators
  (Panier moyen denominator, WB4 §4.4), Measurement Report slide 9 "Transactions" (§7.4), WB2 "Sales
  Overview - trade" Receipts (§2.4).
- **Required base fields:** Transaction/receipt header (dataset #2, unavailable) or pre-aggregated
  export (#3).
- **Dimensions supported:** Store, period, customer type, channel.
- **Formula:** `Nb de paniers = COUNT(DISTINCT transaction_id)` over the scope.
- **Aggregation behavior:** Additive across store/period; not directly additive across customer type
  splits if a single transaction could span both (unlikely given cardholder identification is per
  card, but `[UNVERIFIED]`).
- **Period logic:** Same as A1.
- **Filters:** Same as A1, plus is_cardholder_flag.
- **Null handling:** Zero, not null.
- **Zero-denominator behavior:** N/A (numerator for A7's denominator).
- **Rounding/display:** Integer count.
- **Additivity:** Additive (transaction counts sum across independent scopes).
- **Status:** **CONFIRMED** (recomputed as the denominator of `Panier moyen = CA / Nb de paniers` —
  WB3 §3.5 row 37: 12,931,233.30 / 2,203,942 ≈ 5.867 ✓ matches source exactly).
- **Row-fact classification:** Calculated KPI / Pre-aggregated source output.
- **Test cases needed:** Confirm no double-counting of split-tender or multi-session baskets.

### A4. Customers / Shoppers (Nb de clients)
- **Alt/translated names:** Nombre de clients (encartés), Clients, Shoppers.
- **Definition:** Count of distinct customers/loyalty-card holders who purchased in the scope. In the
  campaign/measurement family ("Shoppers"), this is the count of unique buyers within a targeted
  audience during a period, not necessarily loyalty-card-scoped in the same way.
- **Reports using it:** Customer Loyalty Bilan (WB1 §1.2), Performance (WB3 §3.4), Business Equation
  vs Control (WB2 §2.4), Measurement Report slides 7–9 (§7.4).
- **Required base fields:** Customer/loyalty-card master (dataset #15, unavailable) or pre-aggregated
  export (#3).
- **Dimensions supported:** Customer segment, period, product scope, audience (campaign family).
- **Formula:** `Nb de clients = COUNT(DISTINCT customer_id)` with a qualifying purchase in the scope.
- **Aggregation behavior:** **Non-additive across overlapping scopes** — a customer buying in two
  product categories is counted once in each category's total but should not be summed across
  categories to get a "total customer count" without deduplication.
- **Period logic:** Same as A1.
- **Filters:** Product scope, cardholder status.
- **Null handling:** Zero if no qualifying customers.
- **Zero-denominator behavior:** N/A (denominator for A5, A6).
- **Rounding/display:** Integer count.
- **Additivity:** **Semi-additive** — additive across mutually exclusive segments only; not additive
  across overlapping dimensions (e.g. brand × category) due to distinct-count semantics.
- **Status:** **CONFIRMED** for the retail family (used in verified `CA = Clients × Fréquence ×
  Panier moyen`); the retail-media family's "Shoppers" population identity vs. "Clients" is
  **UNVERIFIED** as the same underlying customer population (review_findings.md §1.2).
- **Row-fact classification:** Calculated KPI / Pre-aggregated source output.
- **Test cases needed:** Confirm distinct-count semantics are preserved when rolling up from
  segment-level to total-level counts (should not simply SUM segment counts).

### A5. Revenue per Customer (CA par client)
- **Alt/translated names:** CA/client, Revenue per Shopper, Revenue/client.
- **Definition:** Average revenue generated per purchasing customer in the scope.
- **Reports using it:** deck6 Presales Insights slide 1 (§6.4), WB2 Business Equation* (§2.4), deck7
  slide 9 (§7.4).
- **Required base fields:** A1 (Revenue), A4 (Customers).
- **Dimensions supported:** Same as A1/A4 intersected.
- **Formula:** `CA par client = CA / Nb de clients`.
- **Aggregation behavior:** Non-additive (a ratio); must be recomputed at each rollup level from its
  components, never summed directly.
- **Period logic:** Same as A1.
- **Filters:** Same as A1/A4.
- **Null handling:** N/A unless Nb de clients = 0 (see zero-denominator).
- **Zero-denominator behavior:** Undefined/null when Nb de clients = 0 — must not render as 0 or ∞;
  display as "n/a" or suppress the row.
- **Rounding/display:** Currency, 2 decimals.
- **Additivity:** Non-additive (ratio KPI).
- **Status:** **CONFIRMED** (component of the verified business-equation identity).
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Confirm ratio is recomputed (not averaged) when aggregating multiple periods.

### A6. Frequency (Fréquence)
- **Alt/translated names:** Fréquence d'achat, Frequency, Purchase Frequency.
- **Definition:** Average number of visits/transactions per (cardholding) customer over the selected
  period.
- **Reports using it:** Performance (WB3 §3.4), Product Extraction Indicators (WB4 §4.4), Measurement
  Report slide 9 (§7.4).
- **Required base fields:** A3 (Transactions), A4 (Customers).
- **Dimensions supported:** Same as A3/A4 intersected.
- **Formula:** `Fréquence = Nb de paniers / Nb de clients` (component of `CA = Clients × Fréquence ×
  Panier moyen`).
- **Aggregation behavior:** Non-additive (ratio).
- **Period logic:** Same as A1; explicitly period-length-dependent (a longer period yields a higher
  raw frequency value — comparisons must hold period length constant, which the CAM convention
  already enforces).
- **Filters:** Cardholder status (defined specifically for encartés per WB4 §4.4's verbatim
  definition).
- **Null handling:** N/A unless Nb de clients = 0.
- **Zero-denominator behavior:** Undefined/null when Nb de clients = 0.
- **Rounding/display:** Decimal, typically 1–2 places (e.g. "1.1" in deck7 slide 9).
- **Additivity:** Non-additive (ratio KPI).
- **Status:** **CONFIRMED** (component of the verified business-equation identity; also explicitly
  defined verbatim in WB4 `Paramètres`, §4.4: "Nombre de visites moyennes réalisées par les clients
  encartés sur la période sélectionnée").
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Confirm frequency recomputes correctly when the analysis window changes
  length (e.g. CAM vs. CAD).

### A7. Avg Basket (Panier moyen)
- **Alt/translated names:** Average Basket, Avg. Basket Value, Panier moyen encartés/non encartés.
- **Definition:** Average revenue per checkout visit/receipt.
- **Reports using it:** All retail-performance reports (WB1/3/4) plus WB2/deck7's "Avg. Basket Value"
  KPI in the campaign family.
- **Required base fields:** A1 (Revenue), A3 (Transactions).
- **Dimensions supported:** Same as A1/A3 intersected.
- **Formula:** `Panier moyen = CA / Nb de paniers` (**verified**, WB3 §3.5 row 37).
- **Aggregation behavior:** Non-additive (ratio); further decomposes to `Panier moyen = UVC par panier
  × Prix moyen` (also verified).
- **Period logic:** Same as A1.
- **Filters:** Cardholder status, product scope.
- **Null handling:** N/A unless Nb de paniers = 0.
- **Zero-denominator behavior:** Undefined/null when Nb de paniers = 0.
- **Rounding/display:** Currency, 2–3 decimals as sampled.
- **Additivity:** Non-additive (ratio KPI).
- **Status:** **CONFIRMED** (independently recomputed and matched exactly in WB3 §3.5).
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Confirm `Panier moyen = UVC par panier × Prix moyen` reconciles at every
  sampled row, not just the ones already checked.

### A8. Units per Basket (UVC par panier)
- **Alt/translated names:** Nombre UVC par panier, Volume per basket, Item/basket, Avg. Items per
  Basket.
- **Definition:** Average unit quantity per checkout visit/receipt.
- **Reports using it:** Same set as A7.
- **Required base fields:** A2 (Units), A3 (Transactions).
- **Dimensions supported:** Same as A2/A3 intersected.
- **Formula:** `UVC par panier = UVC / Nb de paniers` (**verified** per WB3 §3.5's analogous
  derivation for Panier moyen; explicitly defined verbatim in WB4 §4.4).
- **Aggregation behavior:** Non-additive (ratio).
- **Period logic:** Same as A1.
- **Filters:** Same as A7.
- **Null handling:** N/A unless Nb de paniers = 0.
- **Zero-denominator behavior:** Undefined/null when Nb de paniers = 0.
- **Rounding/display:** Decimal, 1–2 places.
- **Additivity:** Non-additive (ratio KPI).
- **Status:** **CONFIRMED** (defined verbatim in source: "Nombre de produits vendus par passage en
  caisse pour l'ensemble des clients", WB4 §4.4; formula consistent with sampled ratios).
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Same reconciliation check as A7.

### A9. Avg Price (Prix moyen)
- **Alt/translated names:** Average price per unit, Price/product, Avg. Price per Product.
- **Definition:** Average selling price per unit sold.
- **Reports using it:** Performance (WB3 §3.4), Appendix SKU Validation (WB2 §2.4), deck7 slide 9/11
  (§7.4).
- **Required base fields:** A1 (Revenue), A2 (Units).
- **Dimensions supported:** Same as A1/A2 intersected, plus per-SKU (WB2 Appendix SKU Validation
  tracks min/max unit price for QA purposes).
- **Formula:** `Prix moyen = CA / UVC` (**verified**, consistent component of the Panier moyen
  decomposition, WB3 §3.5).
- **Aggregation behavior:** Non-additive (ratio); a weighted average of unit prices across products
  when aggregated above SKU level, not a simple average of per-SKU prices.
- **Period logic:** Same as A1.
- **Filters:** Product scope, SKU.
- **Null handling:** N/A unless UVC = 0.
- **Zero-denominator behavior:** Undefined/null when UVC = 0.
- **Rounding/display:** Currency, 2 decimals.
- **Additivity:** Non-additive (ratio KPI; revenue-weighted, not simple average, when rolled up).
- **Status:** **CONFIRMED** (component of verified Panier moyen decomposition).
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Verify per-SKU min/max price validation (WB2 Appendix SKU Validation) does
  not silently exclude outlier prices from the main Prix moyen calculation without a documented rule.

---

## B. Promotion & Distribution KPIs

### B1. Promotion Revenue/Unit Share (Poids CA/UVC promo, CA promo)
- **Alt/translated names:** Poids promo, CA promo, Promotion Revenue Share, Fond de rayon (inverse
  concept — non-promo baseline).
- **Definition:** Share of CA/UVC realized through catalog/flyer promotional pricing, excluding
  variable-weight products (per WB1 Lexique's `Poids promo` definition).
- **Reports using it:** Performance (WB3 §3.4), Product Extraction Indicators (WB4 §4.4), Quoi "Fond
  de rayon vs Promotion" block (WB3 §3.2).
- **Required base fields:** CA/UVC (A1/A2), promotion flag at line grain (dataset #4/#10,
  unavailable).
- **Dimensions supported:** Product, period, store.
- **Formula:** `Poids CA promo = CA promo / CA total`.
- **Aggregation behavior:** Non-additive (ratio); CA promo itself is additive, but the ratio is not.
- **Period logic:** Same as A1.
- **Filters:** Excludes "poids variables" (variable-weight/scale items) per source definition.
- **Null handling:** N/A unless CA total = 0.
- **Zero-denominator behavior:** Undefined/null when CA total = 0.
- **Rounding/display:** Percentage, 1 decimal.
- **Additivity:** Non-additive (ratio KPI); underlying CA promo is additive.
- **Status:** **INFERRED** for the exact eligibility rule (what counts as "promotional"); **CONFIRMED**
  for the ratio structure itself (consistently observed CA promo ≤ CA total in sampled rows).
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Confirm CA promo + CA fond de rayon = CA total for the same scope.

### B2. Numeric Distribution (DN) / Value Distribution (DV)
- **Alt/translated names:** DN (Numeric Detention), Distribution Numérique, DV (Distribution Valeur,
  `[INFERRED]` name), Numeric Distribution.
- **Definition:** Share of stores stocking the product(s) under study (DN, **defined verbatim in
  source**, WB3/WB4 Paramètres/Lexique). DV is paired alongside DN in WB3's `Quoi` distribution block
  but never separately defined — `[INFERRED]` as "value distribution" (share of category value sold
  in DN-qualifying stores), **not confirmed**.
- **Reports using it:** Numeric Distribution by SKU / Business Equation by SKU (WB2 §2.4), Performance/
  Quoi (WB3 §3.4), Product Extraction Indicators (WB4 §4.4).
- **Required base fields:** Store availability/ranging (dataset #12, unavailable atomically) or
  pre-aggregated ratio (#3).
- **Dimensions supported:** Product/SKU, period.
- **Formula:** `DN = Selling Stores / Total Stores` (**verified by recomputation**: 1373/4255 =
  0.3227 ✓, WB2 §2.5; WB4 §4.5).
- **Aggregation behavior:** Non-additive (ratio); `Selling Stores`/`Total Stores` counts themselves
  are additive across products only if store sets don't overlap (they typically do, so **do not
  sum** Selling Stores across multiple SKUs).
- **Period logic:** Point-in-time or period-average, `[UNVERIFIED]` which convention is used.
- **Filters:** Product scope, store scope (constants/courants).
- **Null handling:** N/A unless Total Stores = 0.
- **Zero-denominator behavior:** Undefined/null when Total Stores = 0.
- **Rounding/display:** Percentage, 1–2 decimals, or ratio 0–1.
- **Additivity:** Non-additive (ratio KPI).
- **Status:** **CONFIRMED** for DN's formula (independently verified twice, in WB2 and WB4);
  **UNVERIFIED** for DV (never defined in any Lexique).
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Clarify with client whether "Selling Stores" means *ranged* or *actually sold
  ≥1 unit* (open question in 02_Input_Data_Catalog.md #12).

### B3. Cardholder Rate (Taux d'encartés)
- **Alt/translated names:** Taux d'encartés, Cardholder Rate.
- **Definition:** Share of total revenue attributable to cardholding customers.
- **Reports using it:** Performance (WB3 §3.4 KPIs block).
- **Required base fields:** CA encartés, CA total (both A1 variants).
- **Dimensions supported:** Store, period, product scope.
- **Formula:** `Taux d'encartés = CA encartés / CA total` (`[INFERRED]`, consistent with naming and
  standard retail-loyalty KPI convention; not independently recomputed from raw values in this pass).
- **Aggregation behavior:** Non-additive (ratio).
- **Period logic:** Same as A1.
- **Filters:** Product scope.
- **Null handling:** N/A unless CA total = 0.
- **Zero-denominator behavior:** Undefined/null when CA total = 0.
- **Rounding/display:** Percentage, 1 decimal.
- **Additivity:** Non-additive (ratio KPI).
- **Status:** **INFERRED** (formula not independently recomputed against sampled source values in
  this pass, though structurally consistent).
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Recompute against a sampled Performance (CA) row to confirm exact formula.

---

## C. Evolution & Comparison KPIs

### C1. Evolution % (Period-over-Period Change)
- **Alt/translated names:** Evolution (%), PoP Change, Evol. CA/UVC encartés.
- **Definition:** Relative change between the analysis period value and the comparison period value
  for any KPI.
- **Reports using it:** Universally — every report family/sheet with a two-period comparison (WB1,
  WB3, WB4, deck6 slides 1–2).
- **Required base fields:** Any KPI's analysis-period and comparison-period values.
- **Dimensions supported:** Applies orthogonally to every KPI/dimension combination.
- **Formula:** `Evolution % = (Valeur analyse − Valeur comparaison) / Valeur comparaison`
  (**verified by recomputation** multiple times: WB3 §3.5 CA row 17: (12,931,233.30 −
  11,884,336.71)/11,884,336.71 = 0.08809 ✓; WB4 §4.5 CA row 8: (1,618,216,346.88 −
  1,514,330,289.94)/1,514,330,289.94 = 0.068602 ✓).
- **Aggregation behavior:** Non-additive; must be recomputed from the underlying period values at
  each rollup level, never averaged directly.
- **Period logic:** Depends entirely on the report's configured analysis/comparison period pair
  (dataset #33); **must not be assumed comparable across reports with different period-pair
  definitions** (e.g. CAM vs. CAD vs. custom).
- **Filters:** N/A (structural, applies to whatever scope the base KPI has).
- **Null handling:** N/A unless comparison value = 0.
- **Zero-denominator behavior:** **Undefined when Valeur comparaison = 0** — must render as "n/a" or
  "new" rather than a literal ∞ or 0.
- **Rounding/display:** Percentage, 1–2 decimals; sign convention (+/−) preserved.
- **Additivity:** Non-additive.
- **Status:** **CONFIRMED** (independently recomputed and exactly matched at least twice across two
  different workbooks).
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Verify zero-comparison-value edge case is handled gracefully in any rebuilt
  calculation engine (matches the "Constants" Top-EAN CA=0/Evolution=−1 edge case noted in WB1 §1.9).

### C2. Evolution (pts) / Percentage-Point Change
- **Alt/translated names:** Evolution (pts), pp Change, DN Evolution (pts), Indice CA (evol %) [note:
  labeled "evol %" in source but behaves as pts per C2's formula in the DN case — inconsistent
  labeling flagged].
- **Definition:** Absolute (percentage-point) difference between two already-percentage/ratio KPI
  values, as opposed to their relative % change.
- **Reports using it:** Product Extraction Indicators (DN Evolution, WB4 §4.5), possibly Où (Where)
  Top/Flop `Indice CA (evol %)` column (WB3 §3.9 item 2, `[UNVERIFIED]` whether pts or relative %).
- **Required base fields:** Two ratio-type KPI values (e.g. DN analysis, DN comparison).
- **Dimensions supported:** Same as whatever ratio KPI it applies to.
- **Formula:** `Evolution (pts) = (ratio_analyse − ratio_comparaison) × 100` (**verified by
  recomputation**: WB4 §4.5 DN row 8: (0.99953 − 1.00171) × 100 = −0.218 ✓ matches source exactly).
- **Aggregation behavior:** Non-additive.
- **Period logic:** Same as C1.
- **Filters:** N/A.
- **Null handling:** N/A.
- **Zero-denominator behavior:** N/A (this is a difference, not a ratio).
- **Rounding/display:** Percentage points, 2–3 decimals.
- **Additivity:** Non-additive.
- **Status:** **CONFIRMED** for the DN case (independently recomputed and matched exactly).
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Confirm whether WB3's `Indice CA (evol %)` Top/Flop column uses this pts
  formula or the relative-% formula (C1) — the two are easily confused and the column name itself
  ("evol %") suggests relative %, contradicting the "always 0" anomaly noted in WB3 §3.9 item 2.

### C3. Ecart vs Benchmark [UNVERIFIED]
- **Alt/translated names:** Ecart vs Benchmark, Gap vs. Category.
- **Definition:** Gap between an item's own Evolution % and its benchmark category's Evolution % over
  the same period (`[INFERRED]` structurally from context; category defined in `Paramètres`).
- **Reports using it:** Performance, Quoi, Quand, Où (all WB3 theme sheets, §3.4).
- **Required base fields:** Item's own Evolution % (C1), benchmark category's Evolution % (C1
  computed on the benchmark product-list scope, dataset #9).
- **Dimensions supported:** Same as C1, intersected with a defined benchmark scope.
- **Formula:** **UNVERIFIED** — plausibly `Ecart = Evolution%(item) − Evolution%(benchmark)` (simple
  pp difference) but not confirmed by any recomputation in the reviewed data; the exact scaling/units
  are not fully verifiable from visible values alone (WB3 §3.5).
- **Aggregation behavior:** Non-additive.
- **Period logic:** Same as C1.
- **Filters:** Requires an enumerated benchmark product list, which is itself a gap (see
  02_Input_Data_Catalog.md #9).
- **Null handling:** Undefined until formula is confirmed.
- **Zero-denominator behavior:** N/A (assumed difference, not ratio) — pending confirmation.
- **Rounding/display:** Percentage or percentage points — pending confirmation.
- **Additivity:** Non-additive (assumed).
- **Status:** **UNVERIFIED.** Do not implement a definitive formula without client confirmation.
- **Row-fact classification:** Calculated KPI (formula unconfirmed) — flagged **Unknown/requires
  clarification** for exact calculation logic.
- **Test cases needed:** Obtain client confirmation of exact formula and units before any
  implementation; see [06_Open_Questions.md](06_Open_Questions.md).
- **Candidate formula (unconfirmed, 2026-09-13):** A Sep 9, 2026 client discovery meeting on "Indexes"
  (`Knowledge_Base/Open Questions.md` OQ-C050) discussed a point-difference alternative,
  `Point difference = Brand share − Category share`, as an easier-to-interpret companion to an
  index value — conceptually consistent with this KPI's assumed simple-pp-difference structure, but
  that meeting explicitly did not finalize a formal specification. Does not close this UNVERIFIED status.

### C4. Indice (CA/UVC) [UNVERIFIED baseline]
- **Alt/translated names:** Indice CA, Indice UVC, Index.
- **Definition:** An indexed comparison value (conventionally base 100 = some reference point), used
  in Où/Qui sheets (WB3 §3.4).
- **Reports using it:** Où — Performance des régions/Top-Flop magasins (WB3 §3.2); Qui — Segmentations
  clients table (WB3 §3.2).
- **Required base fields:** The KPI being indexed (e.g. CA) plus an undefined reference/base value.
- **Dimensions supported:** Region, store, customer segment.
- **Formula:** **UNVERIFIED** — exact base/reference value not specified in any Lexique seen so far
  (WB3 §3.9 item 1).
- **Aggregation behavior:** Non-additive (assumed index KPI).
- **Period logic:** `[UNVERIFIED]`.
- **Filters:** `[UNVERIFIED]`.
- **Null handling:** `[UNVERIFIED]`.
- **Zero-denominator behavior:** `[UNVERIFIED]`.
- **Rounding/display:** Numeric index, base unknown (commonly 100 in retail indices, **not
  confirmed** here).
- **Additivity:** Non-additive (assumed).
- **Status:** **UNVERIFIED.**
- **Row-fact classification:** Unknown/requires clarification.
- **Test cases needed:** Client confirmation of index base and formula required before
  implementation.
- **Client feedback (client call transcript, weekly Business Stream sync):** Unlimitail/Carrefour PM Richard Fercoq stated a base-~100 over/under-representation reading is indeed the intended interpretation of these indices (corroborates the assumed base-100 convention), but flagged that index-type KPIs are hard for less statistically sophisticated clients to interpret, and suggested percentage-point change (see C2) as a clearer alternative presentation for at least some client segments. **Product/UX consideration, not a formula resolution** — does not close the UNVERIFIED status above.
- **Candidate formula (unconfirmed, 2026-09-13):** A Sep 9, 2026 "Indexes and Reporting" client
  discovery meeting (`Knowledge_Base/Open Questions.md` OQ-C050, AS-027) is assumed to be the same
  underlying capability as this KPI, and gives an illustrative formula
  `Index = (Brand share / Category share) × 100`, with the benchmark resolved to the "relevant
  category" for the selected brand/advertiser rather than the total retailer. That meeting itself
  states "the meeting did not finalize a formal formula specification" — this remains a **candidate,
  not a confirmed formula**, and must be validated directly with the client before implementation.

### C5. VMH (Vente Moyenne Hebdomadaire) [UNVERIFIED]
- **Alt/translated names:** Average Weekly Sale.
- **Definition:** `[INFERRED]` Average weekly sale (CA or UVC per store per week) — term appears only
  as a column label in Performance (WB3 §3.2), never defined in any Lexique (WB3 §3.9 item 1).
- **Reports using it:** Performance (CA)/(UVC) KPIs block (WB3 §3.2).
- **Required base fields:** CA or UVC (A1/A2), store count, week count — exact denominator
  unconfirmed.
- **Dimensions supported:** Store, period.
- **Formula:** **UNVERIFIED** — plausibly `CA / (selling stores × weeks in period)` but not confirmed.
- **Aggregation behavior:** Non-additive (assumed).
- **Period logic:** `[UNVERIFIED]`.
- **Filters:** `[UNVERIFIED]`.
- **Null handling:** `[UNVERIFIED]`.
- **Zero-denominator behavior:** `[UNVERIFIED]`.
- **Rounding/display:** Currency or unit count, weekly basis (assumed).
- **Additivity:** Non-additive (assumed).
- **Status:** **UNVERIFIED.**
- **Row-fact classification:** Unknown/requires clarification.
- **Test cases needed:** Client confirmation of exact formula required.

---

## D. Market & Assortment KPIs

### D1. Market Share (Part de marché)
- **Alt/translated names:** Part de marché, Market Share.
- **Definition:** Brand's share of total category CA/UVC.
- **Reports using it:** Quoi — Performance des marques (WB3 §3.4).
- **Required base fields:** Brand-level CA/UVC (A1/A2), category-level CA/UVC (same KPI, wider
  product-list scope, dataset #9).
- **Dimensions supported:** Brand, category, period.
- **Formula:** `Part de marché = CA(brand) / CA(category)` (`[INFERRED]`, standard retail market-share
  convention; consistent with column co-occurrence but not independently recomputed against sampled
  values in this pass).
- **Aggregation behavior:** Non-additive (ratio); shares across all brands in a category should sum
  to ≤100% (validation check).
- **Period logic:** Same as A1.
- **Filters:** Category/benchmark scope (dataset #9, partially enumerable only).
- **Null handling:** N/A unless CA(category) = 0.
- **Zero-denominator behavior:** Undefined/null when CA(category) = 0.
- **Rounding/display:** Percentage, 1 decimal.
- **Additivity:** Non-additive (ratio KPI).
- **Status:** **INFERRED.**
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Recompute against a sampled Quoi row once benchmark product-list membership
  (dataset #9) is available.

### D2. Share of Assortment (Part d'offre)
- **Alt/translated names:** Part d'offre.
- **Definition:** Ratio of number of products at a given level (brand/supplier/etc.) to total
  products sold — **defined in source** (WB3 Lexique, §3.4).
- **Reports using it:** Quoi — Performance des marques/type de marque (WB3 §3.2).
- **Required base fields:** Distinct product count at brand level, distinct product count at total
  level (both derivable from dataset #5, product master).
- **Dimensions supported:** Brand, supplier, category.
- **Formula:** `Part d'offre = COUNT(DISTINCT ean WHERE brand=X) / COUNT(DISTINCT ean WHERE
  category scope)` (**DEFINED IN SOURCE**, WB3 Lexique).
- **Aggregation behavior:** Non-additive (ratio).
- **Period logic:** Point-in-time (assortment composition as of the report's run date, not
  period-averaged — `[UNVERIFIED]` exact convention).
- **Filters:** Category/benchmark scope.
- **Null handling:** N/A unless total product count = 0.
- **Zero-denominator behavior:** Undefined/null when total product count = 0.
- **Rounding/display:** Percentage, 1 decimal.
- **Additivity:** Non-additive (ratio KPI).
- **Status:** **CONFIRMED** (definition transcribed verbatim from WB3 Lexique).
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Confirm point-in-time vs. period-average convention for "assortment" as of
  which date.

### D3. Growth Contribution (Contribution à la croissance)
- **Alt/translated names:** Contribution à la croissance (%).
- **Definition:** Share of total category/scope growth attributable to a specific
  brand/segment/product.
- **Reports using it:** Quoi — Performance des marques (WB3 §3.2/§3.4).
- **Required base fields:** Brand-level CA delta (analysis − comparison), category-level CA delta.
- **Dimensions supported:** Brand, category, period.
- **Formula:** `Contribution = (CA(brand, analyse) − CA(brand, comparaison)) / (CA(category, analyse)
  − CA(category, comparaison))` (`[INFERRED]`, standard growth-contribution/waterfall convention; not
  independently recomputed against sampled values).
- **Aggregation behavior:** Non-additive; contributions across all brands in a category should sum to
  ≈100% (validation check) if the category grew, or behave asymmetrically if the category declined.
- **Period logic:** Same as A1/C1.
- **Filters:** Category/benchmark scope.
- **Null handling:** Undefined if category delta = 0 (no growth or decline to attribute).
- **Zero-denominator behavior:** Undefined/null when category CA delta = 0.
- **Rounding/display:** Percentage, 1 decimal.
- **Additivity:** Non-additive (ratio KPI); should reconcile to ~100% across all constituent brands.
- **Status:** **INFERRED.**
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Confirm sign convention when category declined (negative denominator) —
  contribution % can behave counterintuitively in that case.

---

## E. Customer Movement & Purchase-Pattern KPIs

### E1. Customer gain/loss/constant populations (Constants / Gagné / Perdu)
- **Alt/translated names:** Constants, Gagnés (tous/périmètre produits/enseigne/benchmark produits),
  Perdus (same 4 sub-types).
- **Definition:** Classifies each customer's relationship to a product scope between two periods —
  **fully defined via decision-tree logic in WB1's Lexique** (Report_Analysis_Catalog.md §1.5).
- **Reports using it:** Customer Loyalty Bilan, Customer Loyalty Profile (WB1 §1.2).
- **Required base fields:** Per-customer purchase history in both periods for the defined product
  scope (dataset #18, unavailable atomically).
- **Dimensions supported:** Product scope, period pair.
- **Formula:** Classification rule (not a numeric formula) — a customer is: **Constants** if they
  purchased in both periods; **Gagné** if they purchased only in the analysis period (sub-typed by
  whether they were new-to-enseigne, new-to-product-scope, or new-to-benchmark-category); **Perdu**
  if they purchased only in the comparison period (same 4 sub-types, inverse direction).
- **Aggregation behavior:** Mutually exclusive categories; `Total ≈ Constants + Gagnés(tous) +
  Perdus(tous)` is expected to reconcile but is **not spreadsheet-formula-verified in source** (only
  glossary-logic-verified).
- **Period logic:** Requires an explicit two-period comparison; not meaningful for a single period.
- **Filters:** Product scope (the classification is always relative to a specific product list).
- **Null handling:** Every customer must resolve to exactly one category — no null/unclassified state
  expected.
- **Zero-denominator behavior:** N/A (a count-based classification, not a ratio).
- **Rounding/display:** Integer counts, plus CA/UVC value per category.
- **Additivity:** The 4 top-level categories (Constants, Gagnés[tous], Perdus[tous], and implicitly
  "never purchased") should be mutually exclusive and collectively exhaustive of the customer base
  observed in either period.
- **Status:** **CONFIRMED** for the *classification rule* (transcribed precisely from source Lexique);
  **UNVERIFIED** for whether the totals actually reconcile (never independently recomputed since no
  atomic customer data is available).
- **Row-fact classification:** Calculated KPI (row-level attribute is Derived, since it results from
  applying business logic to atomic history that itself is unavailable).
- **Test cases needed:** Investigate why the "benchmark produits" gagné/perdu sub-type has zero data
  rows in the reviewed export (WB1 §1.9) before assuming the classification always populates all 4
  sub-types.

### E2. Délai Interachat (Time between Purchases)
- **Alt/translated names:** Délai Interachat, Time between Purchases.
- **Definition:** **Defined verbatim in source** (WB4 §4.4): average number of days between two
  purchase acts by cardholding customers over the selected period.
- **Reports using it:** Performance (WB3 §3.4), Product Extraction Indicators (WB4 §4.4).
- **Required base fields:** Per-customer purchase dates (dataset #2, unavailable atomically) or
  pre-aggregated value (#3).
- **Dimensions supported:** Product scope, period, cardholder status.
- **Formula:** `Délai interachat = AVG(days between consecutive purchases)` per cardholding customer,
  averaged across all cardholding customers in scope (**DEFINED IN SOURCE**, exact averaging method —
  e.g. mean of per-customer means vs. pooled — not specified).
- **Aggregation behavior:** Non-additive (an average of intervals).
- **Period logic:** Same as A1.
- **Filters:** Cardholder status (encartés only, per definition).
- **Null handling:** Undefined for customers with only a single purchase in the period (no interval to
  measure) — exclusion/inclusion rule not specified.
- **Zero-denominator behavior:** N/A (not a simple ratio, but an average of a derived quantity).
- **Rounding/display:** Days, 1 decimal.
- **Additivity:** Non-additive.
- **Status:** **CONFIRMED** for the definition text; **UNVERIFIED** for the exact averaging
  methodology (per-customer-then-overall vs. pooled).
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Clarify averaging method and single-purchase-customer treatment with client.

---

## F. Campaign / Retail-Media KPIs

### F1. Conversion Rate
- **Alt/translated names:** Conversion rate, Buyer Rate.
- **Definition:** Share of an exposable/reachable audience that purchased at least once during the
  campaign.
- **Reports using it:** Conversion overview/funnel (deck7 slides 7–8, §7.4), Business Equation* (WB2
  §2.4).
- **Required base fields:** Shoppers count (A4 variant), Exposable group size (dataset #22/#28).
- **Dimensions supported:** Audience/segment, period, product list.
- **Formula:** `Conversion rate = Shoppers / Exposable group` (**CONFIRMED**, explicitly stated as
  part of deck7 slide 9's self-labeled "Business equation" narrative, §7.5).
- **Aggregation behavior:** Non-additive (ratio); Exposable group sizes across overlapping segments
  should not be summed without deduplication (segments in deck7 slide 8 are nested/overlapping by
  construction — "w/o summer", "w/o summer & winter" naming implies deliberate mutual exclusivity,
  `[INFERRED]`).
- **Period logic:** Fixed to the campaign period + attribution window (dataset #21/#32).
- **Filters:** Audience/segment.
- **Null handling:** N/A unless Exposable group = 0.
- **Zero-denominator behavior:** Undefined/null when Exposable group = 0.
- **Rounding/display:** Percentage, 1 decimal (e.g. "0.2%", deck7 slide 7).
- **Additivity:** Non-additive (ratio KPI).
- **Status:** **CONFIRMED** for the formula; segment mutual-exclusivity is **INFERRED** from naming
  convention, not explicitly stated.
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Confirm the 4 named segments (deck7 slide 8) are indeed built to be mutually
  exclusive ("w/o summer", "w/o summer & winter", etc.) before summing Shoppers across them.

### F2. Reach / Reach Rate
- **Alt/translated names:** Analysed Reach, Reachable, Reach Rate.
- **Definition:** Count of unique individuals actually reached by the campaign's media (Reach), and
  the share of the addressable/reachable population actually reached (Reach Rate).
- **Reports using it:** Exposure Overview (WB2 §2.4), Campaign KPIs (deck7 slide 4, §7.4), Sales
  Overview - reach_vs_buyers (WB2 §2.2).
- **Required base fields:** Media exposure/impression log (dataset #24, unavailable atomically) or
  pre-aggregated totals (dataset #28).
- **Dimensions supported:** Audience, channel, period.
- **Formula:** `Reach Rate = Analysed Reach / Reachable` (**INFERRED**, standard media-math
  convention; not independently recomputed against sampled values since Reachable is not directly
  shown alongside Reach Rate in the same sampled row).
- **Aggregation behavior:** Non-additive (ratio); Reach itself (numerator) should be de-duplicated
  across channels — summing per-channel Reach would double-count individuals reached on multiple
  channels (`[INFERRED]` risk, not explicitly confirmed in source).
- **Period logic:** Campaign period.
- **Filters:** Channel, audience.
- **Null handling:** N/A unless Reachable = 0.
- **Zero-denominator behavior:** Undefined/null when Reachable = 0.
- **Rounding/display:** Reach as integer count; Reach Rate as percentage.
- **Additivity:** Reach is non-additive across channels (dedup risk); Reach Rate is non-additive
  (ratio).
- **Status:** **INFERRED.**
- **Row-fact classification:** Calculated KPI / Pre-aggregated source output.
- **Test cases needed:** Confirm whether Reach is already deduplicated across channels in the source
  platform before assuming any cross-channel rollup is safe.

### F3. Impressions / Frequency (media)
- **Alt/translated names:** Paid Impressions, Analysed Impressions, Number of Impressions, Frequency
  (Buyers Frequency — average exposures per person/buyer; distinct from A6's purchase Frequency).
- **Definition:** Count of ad impressions served, and the average number of exposures per reached
  individual.
- **Reports using it:** Exposure Overview (WB2 §2.4), Campaign KPIs (deck7 slide 4).
- **Required base fields:** Media exposure log (dataset #24, unavailable) or pre-aggregated totals.
- **Dimensions supported:** Audience, channel, period.
- **Formula:** `Frequency (media) = Impressions / Reach` (**INFERRED**, standard media math; not
  independently recomputed here — note this is a **different KPI from A6's purchase Frequency**
  despite the shared English name, a cross-family terminology collision worth flagging explicitly in
  any glossary).
- **Aggregation behavior:** Impressions additive across channels/dates (subject to double-counting
  caveats noted in F2); Frequency (media) itself non-additive.
- **Period logic:** Campaign period.
- **Filters:** Channel, audience.
- **Null handling:** N/A unless Reach = 0.
- **Zero-denominator behavior:** Undefined/null when Reach = 0.
- **Rounding/display:** Impressions as integer (often displayed in K/M, e.g. "14M", deck7 slide 4);
  Frequency as decimal.
- **Additivity:** Impressions additive (with caveats); Frequency (media) non-additive.
- **Status:** **INFERRED.**
- **Row-fact classification:** Calculated KPI / Pre-aggregated source output.
- **Test cases needed:** Explicitly disambiguate "Frequency" (media, F3) from "Fréquence" (purchase,
  A6) in any glossary/UI to prevent business-user confusion — same English word, unrelated formulas.

### F4. CPM (Cost per 1000 Exposed)
- **Alt/translated names:** Cost per 1000 Exposed, CPM.
- **Definition:** Standard media cost-efficiency metric — cost per thousand impressions/exposures.
- **Reports using it:** Exposure Overview (WB2 §2.4), Campaign KPIs (deck7 slide 4, actual 2.4€ vs.
  estimated 4.3€).
- **Required base fields:** Campaign cost (dataset #31), Impressions (F3).
- **Dimensions supported:** Campaign, channel, period.
- **Formula:** `CPM = (Campaign Cost / Impressions) × 1000` (**INFERRED**, standard media-industry
  formula; consistent with the actual-vs-estimated framing in deck7 but not independently recomputed
  from underlying cost/impression totals in this pass).
- **Aggregation behavior:** Non-additive (ratio); numerator/denominator both additive independently.
- **Period logic:** Campaign period.
- **Filters:** Channel.
- **Null handling:** N/A unless Impressions = 0.
- **Zero-denominator behavior:** Undefined/null when Impressions = 0.
- **Rounding/display:** Currency, 1–2 decimals.
- **Additivity:** Non-additive (ratio KPI).
- **Status:** **INFERRED.**
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Recompute CPM against WB2's Campaign Cost + Impressions fields once both are
  available in the same sampled row to confirm the formula exactly.

### F5. Incremental Revenue / Quantity / Shoppers / Buyer Rate (Lift)
- **Alt/translated names:** Incremental Revenue, Incremental Quantity, Incremental Shoppers,
  Incremental Buyer Rate, Sales Uplift.
- **Definition:** The portion of a KPI attributable to the campaign — Exposed-group value minus what
  it would have been absent exposure (estimated via the Control group).
- **Reports using it:** Sales Uplift, Sales Uplift by Audience (WB2 §2.4).
- **Required base fields:** Exposed-group KPI values, Control-group KPI values (dataset #29 —
  unavailable atomically), plus the (unknown) statistical adjustment method (dataset #30).
- **Dimensions supported:** Audience, product list, period.
- **Formula:** `Incremental X = Exposed_X − Adjusted_Control_X` (**INFERRED structurally** from the
  presence of matching Control/Exposed rows plus a single Incremental result — WB2 §2.5); **the exact
  statistical adjustment (propensity weighting, matching) is NOT documented in any file** — treat as
  **UNVERIFIED/BLOCKING**.
- **Aggregation behavior:** Non-additive across audiences without re-running the underlying
  methodology per audience (cannot simply sum per-audience incremental values without knowing the
  matching approach).
- **Period logic:** Pre-Campaign (baseline) vs. Campaign period comparison.
- **Filters:** Audience, product list (Target Products vs. Total).
- **Null handling:** `[UNVERIFIED]`.
- **Zero-denominator behavior:** N/A (a difference, not a ratio, at the top level).
- **Rounding/display:** Currency/units/counts as appropriate; percentages for Incremental Buyer Rate.
- **Additivity:** **UNVERIFIED** — do not assume additive across audiences/channels.
- **Status:** **UNVERIFIED/BLOCKING** for the exact statistical methodology; the existence of a
  test-vs-control lift design is **CONFIRMED** structurally.
- **Row-fact classification:** Calculated KPI (formula unconfirmed) — flagged **Unknown/requires
  clarification**.
- **Test cases needed:** Obtain the exact matching/weighting methodology and significance-test type
  from the client before implementing any Incremental-X calculation — see
  [06_Open_Questions.md](06_Open_Questions.md), top-priority item.

### F6. ROAS (Return on Ad Spend)
- **Alt/translated names:** Return on Ad Spend, ROAS.
- **Definition:** Incremental revenue generated per unit of campaign spend.
- **Reports using it:** Sales Uplift (WB2 §2.4).
- **Required base fields:** Incremental Revenue (F5), Campaign Cost (dataset #31).
- **Dimensions supported:** Campaign, audience.
- **Formula:** `ROAS = Incremental Revenue / Campaign Cost` (**INFERRED**, exact formula not shown in
  source, WB2 §2.4) — inherits F5's methodology uncertainty, so **doubly unverified**.
- **Aggregation behavior:** Non-additive (ratio); depends entirely on F5's unresolved methodology.
- **Period logic:** Campaign period.
- **Filters:** Audience.
- **Null handling:** N/A unless Campaign Cost = 0.
- **Zero-denominator behavior:** Undefined/null when Campaign Cost = 0.
- **Rounding/display:** Ratio or currency-per-currency (e.g. "3.2x").
- **Additivity:** Non-additive (ratio KPI).
- **Status:** **UNVERIFIED/BLOCKING** (inherits F5's blocking status).
- **Row-fact classification:** Unknown/requires clarification.
- **Test cases needed:** Same as F5 — cannot be implemented until the lift methodology is confirmed.

### F7. P-Values (Statistical Significance)
- **Alt/translated names:** P-Value (Buyer Rate / Revenue per Shopper / Quantity per Shopper / Avg.
  Basket Value / Avg. Price per Product).
- **Definition:** Statistical significance test result for each KPI's observed lift.
- **Reports using it:** Appendix Pvalues, Sales Uplift (WB2 §2.4).
- **Required base fields:** Exposed and Control group distributions (dataset #29), significance test
  type (dataset #30 — unavailable).
- **Dimensions supported:** Audience, product list, KPI.
- **Formula:** **UNVERIFIED** — test type (t-test, bootstrap, etc.) never documented in any file.
- **Aggregation behavior:** Non-additive (p-values cannot be meaningfully summed or averaged across
  segments — multiple-comparisons correction would be needed if aggregating, itself unconfirmed).
- **Period logic:** Campaign period.
- **Filters:** Audience, product list.
- **Null handling:** `[UNVERIFIED]`.
- **Zero-denominator behavior:** N/A.
- **Rounding/display:** Decimal, typically 2–4 places.
- **Additivity:** Non-additive; **must never be aggregated/averaged across segments**.
- **Status:** **UNVERIFIED/BLOCKING.**
- **Row-fact classification:** Unknown/requires clarification.
- **Test cases needed:** Confirm test type and whether `Is Multisegment Resampled` flag (WB2 §2.4)
  affects the p-value calculation for multi-segment audiences.

### F8. Loyal Shopper Rate
- **Alt/translated names:** Number/Percentage of Loyal Shoppers - more than 2 Receipts, Loyal shopper
  %.
- **Definition:** Share of shoppers with ≥2 (WB2: ">2", i.e. ≥3 — see discrepancy) purchases in the
  period. Deck6 slide 10 states the rule as "at least twice" (≥2).
- **Reports using it:** Sales Overview - trade (WB2 §2.4), Measurement Report slide 10 (§7.4).
- **Required base fields:** Loyal shopper flag (dataset #20), total Shoppers (A4 variant).
- **Dimensions supported:** Audience, period.
- **Formula:** `Loyal Shopper Rate = COUNT(loyal shoppers) / COUNT(total shoppers)`.
- **Aggregation behavior:** Non-additive (ratio).
- **Period logic:** Campaign period.
- **Filters:** Audience.
- **Null handling:** N/A unless total Shoppers = 0.
- **Zero-denominator behavior:** Undefined/null when total Shoppers = 0.
- **Rounding/display:** Percentage, 1 decimal (e.g. "9%", deck7 slide 10).
- **Additivity:** Non-additive (ratio KPI).
- **Status:** **CONFIRMED** for the general concept; **discrepant** on the exact threshold (">2
  Receipts" in WB2 vs. "at least twice"/≥2 in deck6 — these are not the same threshold, see
  02_Input_Data_Catalog.md #20).
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Reconcile the ">2" vs. "≥2" threshold discrepancy with the client before
  implementation — **[IMPORTANT]**.

### F9. New / Returning Shopper Measures
- **Alt/translated names:** New Shoppers, Returning Shoppers, New Shopper Acquisition Rate.
- **Definition:** Split of shoppers (and their spend) between first-time buyers in the period vs.
  previously-existing buyers.
- **Reports using it:** New Shoppers Acquisition, Loyalty Profiles* (WB2 §2.4).
- **Required base fields:** New/Returning shopper flag (dataset #19).
- **Dimensions supported:** Audience, channel, period.
- **Formula:** `Total Shoppers = New Shoppers + Returning Shoppers` (**verified consistent** in
  sampled WB2 rows, §2.5); `New Shopper Rate = New Shoppers / Total Shoppers` (`[INFERRED]`).
- **Aggregation behavior:** New/Returning are additive to Total Shoppers within a single audience;
  non-additive as a rate.
- **Period logic:** Campaign period; requires an unconfirmed lookback window to define "new" (see
  dataset #19).
- **Filters:** Audience, channel.
- **Null handling:** N/A unless Total Shoppers = 0.
- **Zero-denominator behavior:** Undefined/null when Total Shoppers = 0 (for the rate).
- **Rounding/display:** Counts as integers; rate as percentage.
- **Additivity:** New + Returning = Total (additive identity, verified); the rate itself is
  non-additive.
- **Status:** **CONFIRMED** for the additive identity; **UNVERIFIED/BLOCKING** for the exact lookback
  window defining "new".
- **Row-fact classification:** Calculated KPI.
- **Test cases needed:** Obtain the exact lookback period from the client — see
  [06_Open_Questions.md](06_Open_Questions.md).

---

## Cross-Family Terminology Collisions (flagged for the glossary)

| Term | Family A meaning | Family B meaning | Risk |
|---|---|---|---|
| Frequency | A6 — average purchase visits per customer (Fréquence d'achat) | F3 — average ad exposures per reached individual (media frequency) | High — identical English word, unrelated formulas and units; must be disambiguated in any unified glossary/UI. |
| Constants | WB1 — a **customer** who purchased in both periods (E1) | WB3 — a **store** with no material format change between periods (dataset #13) | Already flagged in review_findings.md §1.1 — never the same grain, must not be merged into one column/concept. |
| Total (as a value) | Every report family — a literal pre-computed dimension-member row | N/A | Universal — never sum detail rows to "recreate" a Total; always trust (or independently recompute) the Total row directly. |

---

## Summary: KPIs by confirmation status

| Status | Count | KPIs |
|---|---|---|
| CONFIRMED | 15 | A1, A2, A3, A6 (rule text), A7, A8, A9, B2 (DN only), C1, C2, D2, E1 (rule only), E2 (definition only), F1, F9 (identity only) |
| INFERRED | 9 | A4 (retail side only), A5, B1, B3, D1, D3, F2, F3, F4 |
| UNVERIFIED / BLOCKING | 8 | A4 (Shopper=Client identity), B2 (DV only), C3, C4, C5, F5, F6, F7 |
| Discrepant (needs reconciliation, not simply unverified) | 1 | F8 (>2 vs ≥2 threshold) |

This distribution directly informs [06_Open_Questions.md](06_Open_Questions.md) (all UNVERIFIED/
BLOCKING items above are carried forward there) and the DDL/sample-query scope in
[07_Proposed_DDL.sql](07_Proposed_DDL.sql) / [08_Sample_KPI_Queries.sql](08_Sample_KPI_Queries.sql)
(no sample query will be written for F5/F6/F7's exact lift/p-value formulas — inputs only, per the
task's explicit instruction not to invent statistical methodology).
