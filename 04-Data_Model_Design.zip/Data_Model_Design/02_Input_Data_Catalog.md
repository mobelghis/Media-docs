# 02 — Input Data Catalog

**Purpose:** Honest inventory of every candidate input dataset a rebuilt reporting/data-model
solution would need, cross-checked against what the 7 reviewed files (`Report_Analysis_Catalog.md`)
actually contain. Per the task's critical modeling rule: **pre-aggregated KPI tables are not treated
as proof that the underlying atomic data exists or is available.** Each row states what is actually
present, at what grain, and what would have to be newly sourced.

Presence legend: **Yes** (atomic/master data genuinely present), **Partial** (only pre-aggregated
summaries present, or present for a narrow report-specific scope only), **No** (not present in any
reviewed file — would need to be newly sourced from an operational system).

---

## 1. Transactional / Sales Data

#### 1. Transaction line items (basket detail)
- **Business purpose:** Atomic record of every product sold on every receipt — the foundational fact
  from which nearly all CA/UVC/Panier/Fréquence/DN KPIs in every report family would be recomputed.
- **Presence in reviewed files:** **No.** Never present in any of the 5 workbooks — all are
  pre-aggregated exports (Report_Analysis_Catalog.md §1.1, §2.1, §3.1: "0 formula cells... fully
  static export"). Per the task's critical modeling rule, the existence of pre-aggregated CA/UVC
  tables (dataset #3) must **not** be read as proof this line-level data is accessible to us.
- **Expected grain:** One row per (transaction_id × EAN × line sequence).
- **Primary key (proposed):** `transaction_line_id` (surrogate) or composite (`transaction_id`, `line_number`).
- **Foreign keys (proposed):** `transaction_id` → transaction header (#2); `ean` → dim_product; `store_code` → dim_store.
- **Required fields:** transaction_id, ean, quantity, unit_price, line_revenue, promo_flag, transaction_date, store_code.
- **Optional fields:** discount_amount, tax_amount, loyalty_card_id (may live on header instead), promotion_id, currency_code.
- **Source-system owner:** `[UNKNOWN — likely Carrefour POS/checkout system, not Memory 360/Unlimitail, which only consumes it]`.
- **Update frequency:** `[UNKNOWN]` — presumed daily/near-real-time at POS, batch-loaded into the analytics platform; not observed.
- **Historical retention requirement:** `[UNKNOWN]` — at minimum enough history to support the longest observed comparison window (CAM = 13 Nielsen periods × 2 = ~24 months, per WB1/WB3 `Paramètres`); WB5 uses an 18-month trend window (deck 6 slide 3).
- **Effective-dating requirement:** Must join to product/store dimensions **as they existed on transaction_date** (see SCD requirements in [03_Canonical_Data_Model.md](03_Canonical_Data_Model.md)).
- **Data-quality checks:** line_revenue = quantity × unit_price (± discount); no negative quantity unless flagged as a return; every ean/store_code resolves in dimension tables as of transaction_date.
- **Reports supported (if available):** All — this is the base fact every report in the catalog ultimately depends on.
- **Confidence level:** N/A (not observed) — this entire card is **PROPOSED**, not derived from any file.
- **Open questions:** Is this data obtainable from Carrefour directly, or only via Memory 360/Unlimitail's own pre-aggregation pipeline? Does "non encartés" (non-cardholder) traffic have a resolvable transaction record at all, or only an aggregate count? **[BLOCKING]**

#### 2. Transaction / receipt header
- **Business purpose:** One row per checkout/basket event — required to compute Panier moyen (avg
  basket), Nb de paniers/Receipts, Fréquence, and to link line items to a customer and channel.
- **Presence in reviewed files:** **No.** Only aggregate **counts** of receipts appear (e.g. WB3
  `Performance (CA)` "Nb de paniers"; WB2 "Receipts"/"Receipts per Shopper"), never receipt-level rows.
- **Expected grain:** One row per transaction/receipt.
- **Primary key (proposed):** `transaction_id`.
- **Foreign keys (proposed):** `customer_id` (nullable for non-cardholders) → dim_customer; `store_code` → dim_store; `channel` → dim_channel.
- **Required fields:** transaction_id, transaction_datetime, store_code, channel, total_revenue, is_cardholder_flag.
- **Optional fields:** customer_id (null if non-cardholder or unresolved), device/basket_type, e-commerce order reference.
- **Source-system owner:** `[UNKNOWN — POS/e-commerce order system]`.
- **Update frequency:** `[UNKNOWN]`, presumed daily.
- **Historical retention requirement:** Same as #1 (≥24 months to support CAM comparisons).
- **Effective-dating requirement:** N/A (transactional event, not a dimension) — but customer_id linkage must respect the loyalty-card enrollment status *at the time of the transaction*.
- **Data-quality checks:** total_revenue = SUM(line_revenue) from #1 for the same transaction_id; one store_code per transaction; is_cardholder_flag consistent with customer_id being non-null.
- **Reports supported (if available):** Customer Loyalty Bilan/Profile, Performance, Business Equation (all families) — anything using Panier moyen, Fréquence, Nb de clients.
- **Confidence level:** N/A (not observed) — **PROPOSED**.
- **Open questions:** How is a "customer" identified for **non-cardholder** transactions, if at all (WB1 tracks `Non encartés` CA/UVC but the catalog never shows a non-cardholder identifier)? **[BLOCKING]**

#### 3. Pre-aggregated CA/UVC/Panier/Client KPI exports
- **Business purpose:** The actual output layer the client currently uses for reporting — CA, UVC,
  Panier moyen, Clients, Fréquence, Evolution %, Indice, etc., pre-aggregated by the Memory 360
  platform at various cuts.
- **Presence in reviewed files:** **Yes.** This is what most of the 7 reviewed files *are*: WB1
  `Bilan`/`Profil` (Report_Analysis_Catalog.md §1.2); WB3 all `Performance`/`Quoi`/`Quand`/`Où`/`Qui`
  sheets (§3.2); WB4/WB5 `Indicateurs` (§4.2, §5.2); WB2's 37 sheets (§2.2); decks 6/7 slide tables.
- **Expected grain:** Varies per sheet — e.g. (customer-type × period) in WB1 `Bilan`; (product-scope ×
  period × store-format) in WB3; (brand × day) in WB5; (audience × period × group × channel) in WB2.
  **Never atomic** — always already grouped by at least one dimension combination.
- **Primary key (as landed):** Composite of whatever dimension columns are present on the given sheet
  (e.g. WB1 Bilan: customer_type + period; WB5 Indicateurs: marque + date).
- **Foreign keys:** None enforced in source (flat spreadsheet export); would resolve conceptually to
  dim_product/dim_store/dim_customer_segment/dim_date once loaded into a landing table.
- **Required fields:** whatever columns exist per sheet (see Report_Analysis_Catalog.md §1.2–§7.2 for
  full per-sheet column lists) — not standardized across files.
- **Optional fields:** N/A — treat entire row as required once landed (nothing to make optional in a
  pre-aggregated export).
- **Source-system owner:** Memory 360 (Excel exports) / Unlimitail (decks) — the export tool itself,
  not the original transactional source system.
- **Update frequency:** Ad hoc / per report run — each file is a **point-in-time export**, not a
  refreshing feed; no evidence of a recurring extract schedule.
- **Historical retention requirement:** N/A for the export files themselves (they are snapshots); if
  landed as a staging layer, retain indefinitely for audit/lineage purposes.
- **Effective-dating requirement:** Each export already carries its own analysis/comparison period
  (see dataset #33) — no additional effective-dating needed at landing time.
- **Data-quality checks:** `Total`-labeled rows must not be summed together with the detail rows they
  aggregate (see review_findings.md §1.3 — the single most important cross-file DQ risk found);
  Evolution % must reconcile to `(analyse − comparaison) / comparaison` (verified formula).
- **Reports supported:** All 22 report sections in [05_Report_Traceability_Matrix.md](05_Report_Traceability_Matrix.md) — this is the
  primary landing-layer input for the whole model's "Reproducible with assumptions" tier.
- **Confidence level:** High (directly observed, extensively sampled and recomputation-verified per
  the catalog).
- **Open questions:** None regarding presence; open question is whether the client can also expose
  atomic data (#1/#2) rather than only these exports — **[IMPORTANT]**.

#### 4. Promotion-flagged revenue/units
- **Business purpose:** Share of CA/UVC attributable to promotional (flyer/catalog) mechanics —
  feeds `CA promo`, `Poids promo CA/UVC` KPIs.
- **Presence in reviewed files:** **Partial.** Only the resulting **share metric** is present (WB1
  `Lexique` definition only; WB3 `Poids CA/UVC promo`, §3.4; WB4 `CA promo` KPI, §4.4). No
  promotion-flag exists at line-item grain and no promotion master/calendar exists anywhere (see
  dataset #10).
- **Expected grain (if atomic source existed):** Per transaction line, a boolean/ID indicating
  promotional pricing was applied.
- **Primary key (as observed):** N/A — only a scalar % per (product scope × period) row.
- **Foreign keys:** N/A as observed; would be `promotion_id` → dim_promotion if atomic data existed.
- **Required fields (as observed):** CA promo value, Poids promo % (share of total CA/UVC).
- **Optional fields:** N/A.
- **Source-system owner:** Memory 360 (pre-computed); ultimate atomic source `[UNKNOWN]`.
- **Update frequency:** Same as parent export (#3) — snapshot per report run.
- **Historical retention requirement:** Same as #3.
- **Effective-dating requirement:** N/A at this grain; would apply to promotion master (#10) if sourced.
- **Data-quality checks:** `Poids promo CA` ∈ [0, 1]; `CA promo` ≤ `CA total` for the same scope/period.
- **Reports supported:** Performance (§3), Product Extraction Indicators (§4), Customer Loyalty
  Profile promo-related columns.
- **Confidence level:** Medium — the % metric itself is observed and plausible, but promotion
  **eligibility rules** ("hors poids variables" = excluding variable-weight products, per WB1 Lexique)
  are only partially documented.
- **Open questions:** What defines promotion eligibility exactly (mechanic types, discount thresholds)?
  **[IMPORTANT]** — see [06_Open_Questions.md](06_Open_Questions.md).


## 2. Product Reference Data

#### 5. Product master
- **Business purpose:** Core product dimension — EAN, label, brand, supplier, hierarchy, master-EAN
  chaining. The single richest genuinely atomic reference dataset in the whole file set.
- **Presence in reviewed files:** **Yes, but scope-limited.** WB4 `Informations produits` (5,369 rows,
  §4.2); WB5 `Informations produits` (131 rows, narrower "Groupe" scope, §5.2). Each extract is scoped
  to the report's own category/brand list — **not a full universal catalog**.
- **Expected grain:** One row per EAN.
- **Primary key (proposed):** `ean` (natural key) → `product_key` (surrogate) in dim_product.
- **Foreign keys (proposed):** `ean_maitre` → self-referencing (master EAN); `marque` → dim_brand;
  `fournisseur` → dim_supplier; `niveau_hierarchique_1..6` → dim_product_hierarchy.
- **Required fields (as observed):** EAN, EAN libellé, EAN maître, EAN maître libellé, Marque,
  Triptyque, Fournisseur, Niveau hiérarchique 1–6.
- **Optional fields:** Nutriscore, Bio flag (referenced as filter options in WB1 `Paramètres` but not
  present as columns in WB4/WB5's product master — `[GAP]`).
- **Source-system owner:** Memory 360 product nomenclature engine (per WB1 Lexique: "Nomenclature
  Client" = Carrefour Hyper nomenclature + UR/UBC vision + chaining); ultimate owner likely Carrefour
  merchandising master data.
- **Update frequency:** `[UNKNOWN]` — presumed to change as products are ranged/delisted; not observed
  in any file (no as-of date on the product master sheets).
- **Historical retention requirement:** Must retain point-in-time hierarchy/brand assignment history if
  products are reclassified, to keep historical KPI cuts reproducible.
- **Effective-dating requirement:** **Yes — SCD Type 2 recommended.** Hierarchy/brand/supplier
  assignment can change over a product's life; no effective-dating columns observed in any source file.
- **Data-quality checks:** EAN uniqueness; `ean_maitre` resolves to a valid EAN in the same table;
  brand-name normalization (WB5 found `COCA COLA` vs `COCA-COLA` inconsistency — see
  [09_Data_Quality_Rules.md](09_Data_Quality_Rules.md)); hierarchy level 1–6 always non-null together.
- **Reports supported:** Top EAN, Top Brands, Product Extraction Indicators, Temporal Evolution, Quoi
  (What), and any report needing brand/hierarchy rollups.
- **Confidence level:** High for structure/columns (directly observed); Medium for completeness
  (scope-limited, not proven universal).
- **Open questions:** Is a **full, unscoped** product master obtainable from Carrefour/Memory 360, or
  only ever available pre-filtered per report? **[BLOCKING]** for any cross-category rebuild.

#### 6. EAN → EAN maître (master product) mapping
- **Business purpose:** Consolidates "slave" EANs (variants/special editions) under a principal
  reference EAN for higher-level reporting ("chainage", per WB1/WB3 Lexique `EAN maître` definition).
- **Presence in reviewed files:** **Yes**, embedded in dataset #5 (not a separate table) — confirmed
  real EAN≠EAN maître rows exist in WB4's `Informations produits` (§4.2 data-quality note).
- **Expected grain:** One row per EAN (same as #5).
- **Primary key (proposed):** `ean`.
- **Foreign keys (proposed):** `ean_maitre` → `ean` (self-referencing, same table).
- **Required fields:** ean, ean_maitre, ean_maitre_libelle.
- **Optional fields:** chaining reason/type code (not observed — `[GAP]`, would clarify *why* an EAN
  was chained, e.g. "limited edition", "pack size change").
- **Source-system owner:** Same as #5 (Memory 360 nomenclature engine).
- **Update frequency:** `[UNKNOWN]`.
- **Historical retention requirement:** Chaining relationships should be versioned — a slave EAN's
  master could change over time; not observed whether this happens.
- **Effective-dating requirement:** Yes, if chaining relationships are not permanent — `[UNVERIFIED]`.
- **Data-quality checks:** No circular chaining (A→B→A); every `ean_maitre` value also exists as an
  `ean` row (self-consistency).
- **Reports supported:** Any KPI aggregated "by master product" rather than raw EAN — not explicitly
  seen as a distinct report cut in the catalog, but implied by the concept's existence.
- **Confidence level:** Medium — concept and column presence confirmed; usage in actual KPI rollups
  not directly demonstrated by a sampled calculation.
- **Open questions:** Are any of the reviewed reports' EAN-level KPIs (e.g. WB1 Top EAN) already
  rolled up to master EAN, or still at raw/slave EAN grain? `[UNVERIFIED]` **[IMPORTANT]**.

#### 7. Brand / supplier master
- **Business purpose:** Brand and supplier identity and attributes (e.g. brand type/Triptyque:
  MN/MDD/PP) used for brand-level KPI rollups (Top Brands, Part de marché).
- **Presence in reviewed files:** **Yes**, embedded in #5 only (no standalone brand/supplier table).
- **Expected grain:** One row per distinct `Marque` / `Fournisseur` value (would need to be derived by
  DISTINCT-ing dataset #5, not sourced as its own table).
- **Primary key (proposed):** `brand_key` (surrogate) for dim_brand; `supplier_key` for dim_supplier.
- **Foreign keys:** None inbound; outbound referenced by dim_product.
- **Required fields:** brand_name, brand_type (Triptyque: national/MN, MDD, PP).
- **Optional fields:** supplier_name, supplier_group/parent company (not observed).
- **Source-system owner:** Same as #5.
- **Update frequency:** `[UNKNOWN]`.
- **Historical retention requirement:** Brand renames/mergers should be tracked (relevant given the
  WB5 `COCA COLA`/`COCA-COLA` inconsistency, which may in fact be a brand-master data-quality defect
  rather than a genuine second brand).
- **Effective-dating requirement:** Recommended (SCD2) if brand ownership/type changes over time.
- **Data-quality checks:** Brand-name normalization/deduplication (see [09_Data_Quality_Rules.md](09_Data_Quality_Rules.md));
  Triptyque value constrained to a known set (national/MDD/PP per WB3 Lexique).
- **Reports supported:** Top Brands, Performance (Quoi — Performance des marques, Performance par type
  de marque), Market Share / Share of Assortment KPIs.
- **Confidence level:** Medium — brand/supplier values are directly observed, but no dedicated brand
  master table exists to guarantee a single canonical spelling per brand.
- **Open questions:** Does Memory 360 maintain a canonical brand master that would resolve the
  `COCA COLA`/`COCA-COLA` ambiguity, or is normalization the client's responsibility? **[IMPORTANT]**.

#### 8. Product hierarchy / classification tree (Niveau 1–6)
- **Business purpose:** Category rollup structure (e.g. `PGC → BOISSONS → SOFTS DRINKS → GAZEIFIES →
  COLAS → BRSA COLA STD PET 2L`) used for all category-level aggregation and benchmark scoping.
- **Presence in reviewed files:** **Yes**, embedded as 6 flattened columns per product in dataset #5
  (WB4/WB5 `Informations produits`) — **not** a separate parent-child hierarchy/tree table.
- **Expected grain:** One row per EAN with 6 level columns (as observed); a normalized hierarchy table
  would instead have one row per distinct level-combination.
- **Primary key (proposed, normalized form):** `hierarchy_key` (surrogate) over distinct
  (niveau_1..niveau_6) combinations.
- **Foreign keys:** None inbound in flattened form; dim_product would reference `hierarchy_key`.
- **Required fields:** niveau_hierarchique_1 through 6 (all 6 always populated together per
  observation).
- **Optional fields:** None observed beyond the 6 levels.
- **Source-system owner:** Carrefour nomenclature ("Nomenclature Hyper"/"Nomenclature Proxi"/
  "Nomenclature Super" per WB1 Lexique — **three different Carrefour-format-specific nomenclatures
  exist**, plus a Memory-specific "Nomenclature Client" that blends them with UR/UBC vision).
- **Update frequency:** `[UNKNOWN]`.
- **Historical retention requirement:** Hierarchy reclassification history should be retained (a
  product can move category over time) — not evidenced in any file.
- **Effective-dating requirement:** Recommended (SCD2), tied to dataset #5's effective-dating.
- **Data-quality checks:** No orphan levels (e.g. level 3 populated but level 2 null); consistent
  level-6 → level-1 rollup for all EANs sharing the same level-1..5 combination.
- **Reports supported:** Product Extraction Indicators (Niveau hiérarchique 4 grain, WB4 §4.2),
  Performance/Quoi benchmark scoping (WB3's "BARRES CHOCOLATEES" benchmark).
- **Confidence level:** Medium — structure is clearly observed, but **three-plus distinct nomenclature
  systems are referenced across the glossary** (Hyper/Proxi/Super/Client) and the catalog never
  confirms which one applies to which report — `[UNVERIFIED]` per-report.
- **Open questions:** Which of the 4 named nomenclatures (Hyper/Proxi/Super/Client) applies to each
  report family, and are they mutually consistent for the same EAN? **[IMPORTANT]**.

#### 9. Named product-scope lists (target / benchmark)
- **Business purpose:** The exact EAN membership of a report's "target" product scope and its
  "benchmark" comparison scope — required to reproduce any report's filtering exactly.
- **Presence in reviewed files:** **Partial.** Target-list membership is fully enumerated only in WB2
  (`Scope - targets products`, 1,096 SKUs, §2.2) and, less formally, as a semicolon-delimited EAN/label
  list embedded in WB1's `Paramètres` row 19 (~100+ Herta SKUs) and WB5's `Paramètres` ("Niveaux" list
  of ~135 EANs, §5.2). WB3's benchmark scope ("BARRES CHOCOLATEES") is given **only as a category
  label**, never as an enumerated EAN list — the same is true for WB2's implicit "Total" product list.
- **Expected grain:** One row per (list_name × member_ean).
- **Primary key (proposed):** composite (`product_list_id`, `ean`) — see `bridge_product_list_product`
  in [03_Canonical_Data_Model.md](03_Canonical_Data_Model.md).
- **Foreign keys:** `ean` → dim_product; `product_list_id` → dim_product_list.
- **Required fields:** product_list_id, product_list_name, ean, effective_from.
- **Optional fields:** effective_to, list_type (target/benchmark/additional), source_report.
- **Source-system owner:** Configured per-report in Memory 360 at export time (client- or
  analyst-defined selection), not a persistent master list per the evidence available.
- **Update frequency:** Per report configuration — `[UNKNOWN]` whether lists persist/are reused across
  report runs or are recreated ad hoc each time.
- **Historical retention requirement:** Must retain the exact list membership **as of each report's
  run date**, since evolving list membership between two report runs would break comparability.
- **Effective-dating requirement:** Yes — list membership must be point-in-time versioned.
- **Data-quality checks:** No duplicate (list_id, ean) pairs; every ean resolves in dim_product;
  benchmark lists (where enumerable) should not silently overlap 100% with target lists.
- **Reports supported:** All reports that filter to a named product scope — Performance, Quoi/Quand/
  Où/Qui, Product Extraction Indicators, Temporal Evolution, Sales Overview, Numeric Distribution.
- **Confidence level:** Low-Medium — confirmed to exist and matter, but **most reports' benchmark
  lists are never enumerated in the source files**, only named.
- **Open questions:** Can the client supply the enumerated EAN membership of every named
  category/benchmark (e.g. "BARRES CHOCOLATEES") as of each report's run date? **[BLOCKING]** for
  exact reproducibility of any benchmark-comparison KPI (Ecart vs Benchmark, Indice CA/UVC).

#### 10. Promotion master / calendar
- **Business purpose:** Would define individual promotions (mechanic, discount, start/end date,
  eligible products/stores) — the atomic source needed to independently verify `Poids promo`/`CA
  promo` rather than trust the pre-aggregated share.
- **Presence in reviewed files:** **No.** Never present in any of the 7 files; only the resulting
  revenue-share KPI (dataset #4) exists.
- **Expected grain:** One row per promotion (or per promotion × store × date range, if
  store-specific).
- **Primary key (proposed):** `promotion_id`.
- **Foreign keys (proposed):** `ean` (or `product_list_id`) → dim_product/dim_product_list;
  `store_code` → dim_store (if store-specific).
- **Required fields:** promotion_id, mechanic_type, discount_value_or_pct, start_date, end_date.
- **Optional fields:** minimum_purchase_qty, flyer/catalog reference, exclusions (e.g. "hors poids
  variables" per WB1 Lexique's `Poids promo` definition).
- **Source-system owner:** `[UNKNOWN]` — presumed a Carrefour merchandising/pricing system.
- **Update frequency:** `[UNKNOWN]`, presumed per promotional campaign/flyer cycle (weekly/biweekly is
  typical for grocery retail but not confirmed).
- **Historical retention requirement:** `[UNKNOWN]` — needed for as-far-back as any Poids-promo KPI
  comparison period (≥24 months per CAM logic).
- **Effective-dating requirement:** Inherent (start_date/end_date define the effective window).
- **Data-quality checks:** No overlapping active promotions for the same EAN without a defined
  precedence rule; discount value within plausible bounds.
- **Reports supported (if available):** Performance (Poids promo CA/UVC), Product Extraction
  Indicators (CA promo), Quoi (Fond de rayon vs Promotion split).
- **Confidence level:** N/A (not observed) — **PROPOSED**.
- **Open questions:** Does a structured promotion calendar exist at Carrefour/Memory 360 at all, or is
  "promo" purely a POS-level flag with no calendar/mechanic metadata? **[BLOCKING]**.


## 3. Store / Retailer Reference Data

#### 11. Store master
- **Business purpose:** Core store dimension — code, name, region, banner, surface bracket. Second
  genuinely atomic reference dataset (alongside product master) recovered from the file set.
- **Presence in reviewed files:** **Yes, scope-limited.** WB4 `Informations magasins` (4,299 rows,
  §4.2); WB5 (4,234 rows, §5.2). Same caveat as product master — scoped to stores that sold the
  report's product during its period, not guaranteed to be the full network.
- **Expected grain:** One row per store.
- **Primary key (proposed):** `store_code` (natural key, e.g. `H00016`, `S01703`, `750100`) →
  `store_key` (surrogate).
- **Foreign keys (proposed):** `region` → dim_geography; `banniere` → dim_channel/banner reference.
- **Required fields:** store_code, store_name, region, banniere, superficie_bracket.
- **Optional fields:** exact surface area (sq. m — only a bracket is observed, e.g. "[HYPER] 8000 -
  12000", not an exact figure); open_date/close_date (not observed, needed for #13).
- **Source-system owner:** `[INFERRED]` Carrefour store master, surfaced via Memory 360.
- **Update frequency:** `[UNKNOWN]` — store network changes (openings/closures/remodels) presumably
  update this periodically; no update-frequency evidence in any file.
- **Historical retention requirement:** Needed to support "Magasins constants" vs. "non constants"
  classification (WB3 §3.2) across the full CAM comparison window (≥24 months).
- **Effective-dating requirement:** **Yes — SCD Type 2 recommended.** Store banner/surface can change
  (remodel/rebrand); the store code prefix-letter-to-banner mapping is itself only `[INFERRED]` from a
  small sample (WB4 §4.9 open question #3), reinforcing the need for an explicit, dated banner field
  rather than inferring it from the code.
- **Data-quality checks:** store_code uniqueness; banniere ∈ {HYPER, MARKET, CITY, CONTACT, EXPRESS};
  region ∈ the 8 named French regions observed across WB1/WB3/WB4/WB5.
- **Reports supported:** Geographic Distribution, Où (Where), Top/Flop magasins, Numeric Distribution,
  Sales Overview by channel.
- **Confidence level:** High for structure; Medium for completeness (scope-limited per extraction).
- **Open questions:** Can a full, unscoped store master be supplied, independent of any single
  report's product scope? **[BLOCKING]** for a from-scratch rebuild.

#### 12. Store availability / ranging (numeric distribution source data)
- **Business purpose:** Per-store-per-product "is this EAN sellable here" flag — the atomic input
  that would let `DN`/Numeric Distribution be recomputed at any cut, rather than only trusted as a
  pre-aggregated ratio.
- **Presence in reviewed files:** **Partial.** Only the resulting ratio (`Selling Stores / Total
  Stores`) is present — WB2 `Numeric Distribution by SKU` (§2.4, verified formula:
  1373/4255=0.3227 ✓); WB3/WB4 `DN` KPI (§3.5, §4.5, both independently recomputation-verified). No
  atomic per-store-per-product ranging flag exists anywhere.
- **Expected grain:** One row per (store_code × ean × as_of_date).
- **Primary key (proposed):** composite (`store_code`, `ean`, `as_of_date`).
- **Foreign keys (proposed):** `store_code` → dim_store; `ean` → dim_product.
- **Required fields:** store_code, ean, as_of_date, is_ranged_flag (or is_selling — note WB2's field
  is literally "Selling Stores", which conflates *ranged* with *actually sold at least once* —
  see open question below).
- **Optional fields:** ranging_reason, planogram/assortment_id.
- **Source-system owner:** `[UNKNOWN]` — presumed Carrefour assortment/ranging system.
- **Update frequency:** `[UNKNOWN]`, presumed to change as assortments are updated (periodic
  planogram resets).
- **Historical retention requirement:** Needed for any period-over-period DN Evolution (pts)
  calculation (verified formula: `(ratio1 − ratio2) × 100`, WB4 §4.5).
- **Effective-dating requirement:** Yes — ranging status is inherently point-in-time.
- **Data-quality checks:** `Selling Stores` ≤ `Total Stores` for the same scope; DN ∈ [0, 1].
- **Reports supported (if available, at atomic grain):** Numeric Distribution by SKU, Business
  Equation by SKU (DN column), Performance/Quoi (DN/DV KPIs), Product Extraction Indicators (DN KPI).
- **Confidence level:** Medium — the ratio itself is well-verified; the atomic source is not observed
  and "Selling Stores" is ambiguous (ranged vs. actually-sold, see below).
- **Open questions:** Does "Selling Stores" mean *ranged* (assortment-listed) or *actually sold ≥1 unit
  in the period*? These are different populations and the catalog cannot distinguish them from the
  observed ratio alone. **[IMPORTANT]**.

#### 13. Store open/close/remodel history
- **Business purpose:** Event log needed to classify a store as "constant" (no material change) vs.
  "non constant" between the comparison and analysis periods — a filter used in WB3's `Où` sheets.
- **Presence in reviewed files:** **No.** Only the *result* of applying this history (the
  Constants/Non-constants store classification) appears as a filter/segmentation label in WB3 §3.2 —
  the underlying open/close/remodel event log itself is absent from every file.
- **Expected grain:** One row per (store_code × event_type × event_date).
- **Primary key (proposed):** composite (`store_code`, `event_date`, `event_type`).
- **Foreign keys (proposed):** `store_code` → dim_store.
- **Required fields:** store_code, event_type (open/close/remodel/surface_change), event_date.
- **Optional fields:** old_surface_bracket, new_surface_bracket (for remodel events), reason.
- **Source-system owner:** `[UNKNOWN]` — presumed Carrefour store-operations system.
- **Update frequency:** `[UNKNOWN]`, event-driven (as changes occur).
- **Historical retention requirement:** Full history needed to correctly classify "constant" status
  for any arbitrary two-period comparison, not just the specific periods seen in the reviewed files.
- **Effective-dating requirement:** Inherent (event_date defines the point-in-time change).
- **Data-quality checks:** No two conflicting events on the same store/date; open_date always precedes
  any subsequent close_date for the same store.
- **Reports supported (if available):** Où (Where) — "Performance selon le type de magasins" block
  (Constants vs. Non constants), any like-for-like store comparison.
- **Confidence level:** N/A (not observed) — **PROPOSED**.
- **Open questions:** What exactly qualifies a store as "non constant" — any surface change, or only
  changes above some threshold? WB1 Lexique distinguishes `Magasins constants` from `Magasins
  courants` (sold ≥once in both periods) but doesn't state the constants threshold precisely.
  **[IMPORTANT]**.

#### 14. Geography reference
- **Business purpose:** Region-level grouping above individual stores, used for the Geographic
  Distribution report and regional benchmarking.
- **Presence in reviewed files:** **Yes**, but only embedded as a store attribute (`Région` column in
  dataset #11) plus a fixed list of 8 region labels repeated in WB1 `Profil` ("Répartition
  géographique" block, §1.2) and WB3/WB4/WB5. No independent geography master with codes, boundaries,
  or a hierarchy *above* "region" (e.g. no zone/country level) exists.
- **Expected grain:** One row per region (8 rows observed: Sud Est, Ouest, Paris/Région Parisienne,
  Nord, Centre Ouest, Centre Est, Sud Ouest, Est).
- **Primary key (proposed):** `region_code` (needs to be assigned — only region *names* are observed,
  no numeric/alpha codes).
- **Foreign keys:** None inbound; dim_store references `region_code`.
- **Required fields:** region_code, region_name.
- **Optional fields:** parent geography level (zone/country — not observed, presumed single-country
  France-only scope given all observed data).
- **Source-system owner:** `[INFERRED]` Carrefour regional structure.
- **Update frequency:** Low — regional definitions rarely change, but not confirmed.
- **Historical retention requirement:** Low priority unless region boundaries are redefined over time
  (`[UNKNOWN]` whether this has happened).
- **Effective-dating requirement:** Only if region boundaries change over time — `[UNVERIFIED]`, no
  evidence either way.
- **Data-quality checks:** Exactly 8 distinct region values across all files (consistency check — the
  same 8 names recur in WB1/WB3/WB4/WB5, a good cross-file consistency signal already noted in
  review_findings.md).
- **Reports supported:** Geographic Distribution (Répartition géographique), Où (Where) — Performance
  des régions.
- **Confidence level:** High — the 8-region list is consistent and repeated across 4 independent
  files, a strong signal it's a stable reference set.
- **Open questions:** Is there a formal region code (not just name) used internally, and is there any
  level of geography above "region" (e.g. zone) relevant to reporting? **[NICE TO HAVE]**.


## 4. Customer / Loyalty Data

#### 15. Customer / loyalty-card master
- **Business purpose:** Individual customer/loyalty-card identity — card status, enrollment date,
  demographic attributes — needed to compute any customer-level KPI from scratch (Clients, CA/Client,
  Fréquence) rather than trust pre-aggregated counts.
- **Presence in reviewed files:** **No.** Never present as atomic records anywhere in the 7 files;
  only aggregated counts (`Nombre de clients encartés`, `Shoppers`, etc.) ever appear.
- **Expected grain:** One row per customer/loyalty card.
- **Primary key (proposed):** `customer_id` (loyalty card ID or resolved customer identity).
- **Foreign keys:** None inbound; referenced by transaction header (#2), segment assignment (#16),
  audience membership (#23).
- **Required fields:** customer_id, card_status (active/inactive), enrollment_date, is_cardholder_flag.
- **Optional fields:** demographic attributes (age band, household composition — these may only exist
  derived via Lifestage segment assignment rather than as raw demographic fields; `[UNVERIFIED]`),
  opt-in/consent flags for data usage.
- **Source-system owner:** `[UNKNOWN]` — presumed Carrefour loyalty program system ("Carrefour loyalty
  card holders database", per deck 6/7 footers, which is cited as *a* source but never exposed at
  customer grain in any reviewed file).
- **Update frequency:** `[UNKNOWN]`.
- **Historical retention requirement:** Needed at least as far back as the earliest comparison period
  observed (≥24 months for CAM logic) plus enough lookback for "new shopper" determination (see #19).
- **Effective-dating requirement:** Yes — card_status and demographic attributes can change over time;
  no evidence of how this is currently handled.
- **Data-quality checks:** customer_id uniqueness; one active card per customer at a time (unless
  multi-card households are explicitly supported).
- **Reports supported (if available):** Customer Loyalty Bilan/Profile, all "Clients"/"Shoppers" count
  KPIs across both report families.
- **Confidence level:** N/A (not observed) — **PROPOSED**. This is the single most significant
  customer-data gap in the whole file set.
- **Open questions:** Is customer-grain data obtainable at all given privacy/PII constraints, or must
  the model always consume pre-aggregated counts from Memory 360/Unlimitail? **[BLOCKING]** — see PII
  handling in [09_Data_Quality_Rules.md](09_Data_Quality_Rules.md).

#### 16. Customer-to-segment assignment
- **Business purpose:** Which customer belongs to which Lifestage/Consostyle/Structurelle/Promotion/
  RFM segment — needed to recompute segment-level KPIs (counts, Part de CA, Indice) from scratch.
- **Presence in reviewed files:** **No.** Only pre-aggregated **counts and KPI values per segment**
  exist (WB1 `Profil` Segmentations block §1.2; WB2 `Loyalty Profiles`/`Shoppers Profiles` §2.2; decks
  6/7 profiling slides §6.2/§7.2). The individual customer→segment mapping and its membership rule are
  both absent everywhere.
- **Expected grain:** One row per (customer_id × segment_family × as_of_date).
- **Primary key (proposed):** composite (`customer_id`, `segment_family_id`, `as_of_date`).
- **Foreign keys (proposed):** `customer_id` → dim_customer; `segment_id` → dim_customer_segment.
- **Required fields:** customer_id, segment_family (Lifestage/Structurelle/Consostyle/Promotion/RFM),
  segment_value (macro/micro), as_of_date.
- **Optional fields:** assignment_confidence_score, model_version (if segments are model-derived
  rather than rule-based).
- **Source-system owner:** `[UNKNOWN]` — presumed a Memory 360 customer-segmentation engine (or a
  broader NIQ-wide segmentation model, given the same taxonomy names recur with different exact
  wording across WB1/WB3/WB2/decks — see review_findings.md §1.4).
- **Update frequency:** `[UNKNOWN]` — segments like `Segmentation Structurelle - Nouveau` ("client
  depuis <3 mois") are inherently time-dependent, implying at least periodic (monthly?) recomputation.
- **Historical retention requirement:** Full history needed to reproduce any historical report's
  segment cuts, since segment membership is expected to drift over time (e.g. a customer moves from
  `Nouveau` to `Actifs`).
- **Effective-dating requirement:** **Yes — mandatory.** Segment assignment is inherently point-in-time;
  this is flagged explicitly in the consistency-check requirements of the task spec.
- **Data-quality checks:** A customer should have exactly one Macro and one Micro value per family per
  as_of_date (no duplicate/conflicting assignments); every segment_value resolves in dataset #17.
- **Reports supported (if available):** Customer Segmentations, Loyalty Profiles, Shopper Profiles,
  Measurement Report profiling slides.
- **Confidence level:** N/A (not observed) — **PROPOSED**.
- **Open questions:** Is the segmentation engine shared identically between the retail-performance
  platform (Memory 360) and the retail-media platform (behind WB2/decks), or are these two separately
  computed segmentations that merely share label names? **[BLOCKING]** — see review_findings.md §1.4
  and [06_Open_Questions.md](06_Open_Questions.md).

#### 17. Segment taxonomy / definitions
- **Business purpose:** Master reference defining every segmentation family, its Macro/Micro segment
  values, and their business meaning.
- **Presence in reviewed files:** **Yes.** WB1 `Lexique` (68 terms, §1.2); WB3 `Lexique` (79 terms,
  most complete — treated as master per catalog §3.9 item 3 and review_findings.md). Genuinely
  reusable as seed data, but exists only as prose glossary text, not a structured/queryable table.
- **Expected grain:** One row per (segment_family × segment_value).
- **Primary key (proposed):** `segment_id` (surrogate) or composite (`segment_family`, `detail_level`
  [Macro/Micro], `segment_value`).
- **Foreign keys:** None inbound; referenced by dataset #16 and by fact tables' segment columns.
- **Required fields:** segment_family (Lifestage/Structurelle/Consostyle/Promotion/RFM),
  detail_level (Macro/Micro), segment_value, definition_text.
- **Optional fields:** approx_population_share (WB1 Lexique gives rough %s for some Promo/Structurelle
  segments, e.g. "~28%" for "Petit % CA promo, Petit régul" — informative but not authoritative).
- **Source-system owner:** Memory 360 (glossary content is platform-authored, per the "Lexique" sheets
  themselves).
- **Update frequency:** Low — glossary/taxonomy definitions change infrequently, but WB1 vs. WB3's
  differing completeness for the *same* family names suggests the taxonomy has evolved over time or
  across product configurations `[UNVERIFIED]`.
- **Historical retention requirement:** Should version the taxonomy itself if segment definitions
  change, to keep old reports' segment meanings interpretable.
- **Effective-dating requirement:** Recommended if the taxonomy evolves (`[UNVERIFIED]` whether it
  does).
- **Data-quality checks:** No duplicate (family, detail_level, value) combinations; `RFM` family
  currently has **zero definitions** (gap, see below) and should not be silently treated as fully
  defined.
- **Reports supported:** Customer Segmentations, Loyalty/Shopper Profiles, Measurement Report
  profiling slides — this table underlies every segment label shown anywhere.
- **Confidence level:** High for the 4 named families (Lifestage/Structurelle/Consostyle/Promotion,
  fully transcribed from WB3's Lexique); **Low** for RFM (no definition anywhere).
- **Open questions:** Can the client supply an authoritative `RFM` segment definition list (used in
  WB2's Hierarchy 1/2 values, e.g. "RFM 5 - Panier Très Fréquent")? **[BLOCKING]** for that one family;
  otherwise **[IMPORTANT]** to confirm WB3's Lexique is indeed the canonical/current version.

#### 18. Customer period-over-period movement classification
- **Business purpose:** Classifies each customer as Constants/Gagné(sub-types)/Perdu(sub-types)
  between the comparison and analysis periods — feeds the Customer Loyalty Bilan report directly.
- **Presence in reviewed files:** **Partial.** Only pre-aggregated **counts** per movement category
  exist (WB1 `Bilan`, §1.2/§1.5). The underlying per-customer classification (which specific customer
  is "Gagné (périmètre produits)" vs. "Gagné (enseigne)") is not present. The "benchmark produits"
  gagné/perdu variant is **defined in the glossary but has zero data rows** in this export — a
  defined-but-unobserved category (review_findings.md §3 item 5).
- **Expected grain:** One row per (customer_id × comparison_period × analysis_period).
- **Primary key (proposed):** composite (`customer_id`, `period_pair_id`).
- **Foreign keys (proposed):** `customer_id` → dim_customer; `product_list_id` → dim_product_list (the
  classification is always relative to a specific product scope, per WB1 Lexique's definitions).
- **Required fields:** customer_id, product_list_id, comparison_period_start/end, analysis_period_
  start/end, movement_status (Constants / Gagné [tous|périmètre produits|enseigne|benchmark produits] /
  Perdu [same 4 sub-types]).
- **Optional fields:** None beyond the classification itself.
- **Source-system owner:** `[UNKNOWN]` — Memory 360's customer-loyalty analysis engine, per WB1's
  reported platform origin.
- **Update frequency:** Per report run (each `Paramètres` sheet fixes its own comparison/analysis
  period pair) — not a continuously-updated table, but recomputed per report configuration.
- **Historical retention requirement:** Needed for every historical report's exact period-pair
  definitions to be reproducible.
- **Effective-dating requirement:** Inherent — classification is only meaningful relative to a
  specific period pair, which is itself a form of effective-dating.
- **Data-quality checks:** Every customer_id classified into exactly one of Constants/Gagné(*)/Perdu(*)
  per period pair (mutually exclusive, per the exact decision-tree logic transcribed in
  Report_Analysis_Catalog.md §1.5); `Total ≈ Constants + Gagnés(tous) + Perdus(tous)` should
  reconcile, but is **not spreadsheet-formula-verified in source** (only glossary-logic-verified).
- **Reports supported (if available):** Customer Loyalty Bilan, Customer Loyalty Profile (product-
  scope and total-enseigne value tables).
- **Confidence level:** Medium — the classification *rule* is fully and precisely documented (a rare
  case where prose glossary text is precise enough to be an executable spec), but no atomic
  per-customer data or verifying spreadsheet formula exists.
- **Open questions:** Why does the "benchmark produits" variant have zero data rows in this export —
  is it simply unused for this specific product scope, or not populated for this report type at all?
  **[IMPORTANT]**.

#### 19. New / Returning shopper flag (campaign context)
- **Business purpose:** Distinguishes first-time buyers in a campaign period from previously-existing
  buyers — feeds New Shopper Acquisition and Loyalty Profile KPIs in the campaign/lift report family.
- **Presence in reviewed files:** **Partial.** Only pre-aggregated counts of New/Returning shoppers per
  audience/period exist (WB2 `New Shoppers Acquisition`, `Loyalty Profiles *`, §2.2). No per-shopper
  flag/atomic data.
- **Expected grain:** One row per (customer_id × campaign_id × period).
- **Primary key (proposed):** composite (`customer_id`, `campaign_id`).
- **Foreign keys (proposed):** `customer_id` → dim_customer; `campaign_id` → dim_campaign.
- **Required fields:** customer_id, campaign_id, is_new_shopper_flag, lookback_window_days (the
  lookback period used to determine "new" — **never stated in any file**, see open question).
- **Optional fields:** first_purchase_date_in_lookback (for returning shoppers), first_ever_purchase
  date (for genuinely new-to-category shoppers).
- **Source-system owner:** `[UNKNOWN]` — the retail-media/lift-measurement platform behind WB2
  (distinct from Memory 360 per catalog §2.5, though possibly the same NIQ product suite).
- **Update frequency:** Per campaign/study — WB2 is scoped to a single `Study Id`.
- **Historical retention requirement:** Must retain at least the lookback window's worth of prior
  purchase history per customer to determine new/returning status correctly.
- **Effective-dating requirement:** Inherent to the campaign period definition.
- **Data-quality checks:** `Total Shoppers = New Shoppers + Returning Shoppers` (verified consistent in
  sampled WB2 rows, §2.5); is_new_shopper_flag consistent with dataset #16/#18's broader customer
  movement classification where the same customer appears in both report families (`[UNVERIFIED]`
  whether this cross-check is even possible given the identity-resolution question in review_findings.md
  §1.2).
- **Reports supported (if available):** New Shopper Acquisition, Loyalty Profiles (Per Audience/
  Channel/Total/Number of Products/Distribution).
- **Confidence level:** Low-Medium — the binary flag and its resulting counts are well-observed;
  the exact lookback rule that defines "new" is completely undocumented.
- **Open questions:** What is the exact lookback period used to classify a shopper as "new" (e.g. no
  purchase in the prior 12/24 months)? **[BLOCKING]** for reproducing this KPI from scratch.

#### 20. Loyal shopper definition & flag
- **Business purpose:** Flags shoppers who purchased ≥2 times in a period — feeds "Loyal Shopper
  Rate"/"Number of Loyal Shoppers" KPIs.
- **Presence in reviewed files:** **Partial.** The **rule itself is stated inline** — a rare case in
  this file set — in deck 6 slide 10: *"A loyal shopper is a customer who has bought the product at
  least twice during the campaign"* (§7.2); WB2 `Sales Overview - trade` has a related "Number/
  Percentage of Loyal Shoppers - more than 2 Receipts" column (§2.4). No atomic per-shopper flag exists.
- **Expected grain:** One row per (customer_id × product_scope × period).
- **Primary key (proposed):** composite (`customer_id`, `product_list_id`, `period_id`).
- **Foreign keys (proposed):** `customer_id` → dim_customer; `product_list_id` → dim_product_list.
- **Required fields:** customer_id, product_list_id, period_id, purchase_count_in_period,
  is_loyal_shopper_flag (derived: purchase_count_in_period ≥ 2).
- **Optional fields:** None beyond the count itself (the rule is a simple threshold, per the observed
  definition — no additional required fields anticipated).
- **Source-system owner:** Same as #2 (transaction/receipt header) — this is directly derivable from
  receipt-level data, unlike most other customer-classification datasets in this catalog.
- **Update frequency:** Per report/campaign period.
- **Historical retention requirement:** Same as #2.
- **Effective-dating requirement:** Inherent to the period definition.
- **Data-quality checks:** purchase_count_in_period ≥ 0; is_loyal_shopper_flag = (count ≥ 2) exactly
  (simple, fully specified rule — the cleanest KPI-support rule in this entire catalog since both the
  *definition* and the *required base data* (#2) are unambiguous, even though #2 itself is unavailable).
- **Reports supported (if available):** Measurement Report "Shopper breakdown: loyalty" slide, Sales
  Overview - trade (loyal shopper %).
- **Confidence level:** High for the *rule* (explicitly stated in-file — a genuine
  `[DEFINED IN SOURCE]` case); N/A for atomic data availability.
- **Open questions:** Is the ">2 Receipts" loyalty threshold (WB2) identical to the "at least twice"
  threshold (deck 6) — i.e. is "more than 2" (>2, meaning ≥3) actually consistent with "at least twice"
  (≥2)? These two stated thresholds are **subtly different** and should be reconciled with the client.
  **[IMPORTANT]**.


## 5. Campaign / Retail-Media Data

#### 21. Campaign master
- **Business purpose:** One record per media campaign/study — name, type, period, attribution window,
  objective. Needed to scope and join every campaign-measurement fact.
- **Presence in reviewed files:** **Partial.** WB2 carries one `Study Id` GUID per workbook
  (`2b178f13-2fff-4333-b4c6-28e7a1d76e83`, §2.1) but no name/objective/type fields; campaign
  type/period/attribution window appear only as **narrative text** in decks 6/7 (deck6 slide 1/3,
  deck7 slide 3) — no structured campaign catalog exists anywhere across the file set.
- **Expected grain:** One row per campaign/study.
- **Primary key (proposed):** `campaign_id` (natural key = Study Id GUID where available).
- **Foreign keys:** None inbound; referenced by nearly every fact table in the campaign/retail-media
  family.
- **Required fields:** campaign_id, campaign_name, campaign_type (e.g. Social), campaign_start_date,
  campaign_end_date, attribution_window_start, attribution_window_end, retailer (Carrefour).
- **Optional fields:** objective/brief text, redirection_url ("Link to Carrefour.fr", deck7 slide 3),
  social_media_used (blank/redacted in the observed example, per §7.9).
- **Source-system owner:** `[UNKNOWN]` — a retail-media/lift-measurement platform, distinct from
  Memory 360 per Report_Analysis_Catalog.md §2.5 ("possibly the same NIQ product suite",
  `[UNVERIFIED]`).
- **Update frequency:** Per campaign — one record created per campaign booking.
- **Historical retention requirement:** Indefinite; every historical measurement report must remain
  traceable to its exact campaign definition.
- **Effective-dating requirement:** Not applicable to the campaign record itself (it's a fixed
  historical event), but attribution-window dates must be stored precisely, not inferred.
- **Data-quality checks:** campaign_end_date > campaign_start_date; attribution_window_start ≥
  campaign_end_date (or per whatever attribution model the client confirms).
- **Reports supported (if available):** All of WB2's 37 sheets, both measurement-family decks.
- **Confidence level:** Low — only a bare GUID is confirmed structured data; every other attribute is
  narrative-only and scoped to a single example.
- **Open questions:** Does a queryable, multi-campaign catalog exist at the source platform (i.e., can
  multiple `Study Id`s be listed/joined), or is each WB2-style export always single-campaign?
  **[IMPORTANT]**.

#### 22. Audience definitions
- **Business purpose:** Defines each named audience/targeting segment and its membership rule — needed
  to reproduce or QA audience sizing.
- **Presence in reviewed files:** **Partial.** Only audience **names** are present (e.g.
  `Acheteurs_ProduitsDuMonde_24M_V3_Dedup`, `Acheteurs_Reghalal_24M_V3` in WB2 §2.2/§2.3; "Summer
  liquor buyers", "Prosecco/white wine buyers" etc. in deck7 §7.3) — the underlying membership rule is
  only `[INFERRED]` from the name string (e.g. "24M" plausibly = 24-month lookback), never stated
  explicitly anywhere.
- **Expected grain:** One row per named audience.
- **Primary key (proposed):** `audience_id`.
- **Foreign keys (proposed):** `campaign_id` → dim_campaign (audiences appear to be campaign-scoped,
  not a shared global library, though this is `[UNVERIFIED]`).
- **Required fields:** audience_id, audience_name, membership_rule_text, lookback_window_days.
- **Optional fields:** dedup_flag (the "Dedup" suffix in one WB2 audience name suggests
  deduplication logic exists — `[UNVERIFIED]` what exactly is deduplicated), version (the "V3" suffix
  suggests audience definitions are versioned over time).
- **Source-system owner:** Same as #21.
- **Update frequency:** `[UNKNOWN]`, presumed refreshed per campaign or on a versioned cadence ("V3"
  naming convention implies iterative updates).
- **Historical retention requirement:** Should retain the exact audience definition version used for
  each historical campaign to keep measurement reproducible.
- **Effective-dating requirement:** Yes, if audience definitions are versioned/refreshed over time as
  the naming convention suggests.
- **Data-quality checks:** audience_id uniqueness within a campaign; membership_rule_text non-null
  (currently would fail this check universally, since no rule text exists in any source file).
- **Reports supported (if available):** Audience Affinity, Business Equation by Audience, Sales Uplift
  by Audience, all Measurement Report segment-targeting slides.
- **Confidence level:** Low — names and their use are well observed; the actual construction rule is
  never documented.
- **Open questions:** What exact behavioral/purchase criteria define each named audience (e.g. what
  counts as a "summer liquor buyer")? **[BLOCKING]** for independently validating audience sizing.

#### 23. Customer-to-audience membership (atomic)
- **Business purpose:** Per-customer flag of audience membership — needed to independently verify
  `Exposable group` sizes and to join audience membership to actual purchase behavior.
- **Presence in reviewed files:** **No.** Only aggregate audience/segment sizes ("Exposable group"
  counts, e.g. 4.8M in deck7 slide 7) are ever shown; no atomic membership list exists in any file.
- **Expected grain:** One row per (customer_id × audience_id).
- **Primary key (proposed):** composite (`customer_id`, `audience_id`).
- **Foreign keys (proposed):** `customer_id` → dim_customer; `audience_id` → dim_audience.
- **Required fields:** customer_id, audience_id, membership_as_of_date.
- **Optional fields:** membership_score/rank (if audiences are propensity-ranked rather than binary).
- **Source-system owner:** Same as #21/#22.
- **Update frequency:** `[UNKNOWN]`, presumed to be built once per campaign at audience-activation time
  (per deck7 slide 6's "Audience building" methodology step).
- **Historical retention requirement:** Needed for the life of any campaign that references the
  audience, to support post-hoc audit of who was actually targeted.
- **Effective-dating requirement:** Yes — membership is built as of a specific activation date.
- **Data-quality checks:** COUNT(DISTINCT customer_id) per audience_id reconciles to the reported
  "Exposable group" total (e.g. 4.8M, deck7 slide 7/8).
- **Reports supported (if available):** Any audience-level KPI, cross-checking Conversion Rate
  (Shoppers ÷ Exposable group) at the atomic level.
- **Confidence level:** N/A (not observed) — **PROPOSED**.
- **Open questions:** Is this data ever exportable, or does it stay entirely internal to the
  media-activation platform for privacy/scale reasons? **[BLOCKING]**.

#### 24. Media exposure / impressions (atomic, impression-level log)
- **Business purpose:** Raw ad-serving log (who was served an impression, when, on what
  channel/placement) — the base fact behind Reach, Frequency, and Reach Rate KPIs.
- **Presence in reviewed files:** **No.** Only pre-aggregated totals exist: WB2 `Exposure Overview -
  exposure` (Reachable, Paid/Analysed Impressions, §2.2/§2.4); deck7 slide 4 (single headline
  "Impressions = 14M", actual vs. estimated 7.8M).
- **Expected grain:** One row per ad impression served (customer/device × timestamp × placement).
- **Primary key (proposed):** `impression_id` (surrogate).
- **Foreign keys (proposed):** `customer_id`/`device_id` → dim_customer (if resolvable); `campaign_id`
  → dim_campaign; `channel`/`placement` → dim_media_channel.
- **Required fields:** impression_id, campaign_id, impression_timestamp, channel/placement.
- **Optional fields:** device_id, cost_attributed (if cost is allocated per-impression rather than only
  at campaign level).
- **Source-system owner:** `[UNKNOWN]` — an ad-serving/media platform (e.g. Meta, per deck7 slide 15's
  "test Meta Social Retail format" recommendation, suggesting Meta is at least one media partner).
- **Update frequency:** `[UNKNOWN]`, presumed near-real-time at the ad platform, batch-aggregated
  downstream.
- **Historical retention requirement:** For the campaign's active period plus attribution window.
- **Effective-dating requirement:** N/A (immutable event log).
- **Data-quality checks:** SUM(impressions) reconciles to the reported aggregate total; impression
  timestamps fall within the campaign period.
- **Reports supported (if available):** Exposure Overview, Sales Impact Evolution, Campaign KPIs
  (deck7 slide 4).
- **Confidence level:** N/A (not observed) — **PROPOSED**.
- **Open questions:** Is impression-level (or even daily-aggregate) exposure data obtainable from the
  media partner, given that WB2's own `Exposure Overview - frequency` and `Exposure Evolutions` sheets
  are empty/all-zero in the reviewed export? **[BLOCKING]**.

#### 25. Media exposure by frequency bucket
- **Business purpose:** Would show how ad frequency (number of exposures per person) relates to buyer
  rate/revenue — needed for frequency-capping and media-efficiency analysis.
- **Presence in reviewed files:** **Partial — structure only, no data.** WB2 `Exposure Overview -
  frequency` and `Frequency Impact` sheets exist with header rows but **zero populated data rows**
  (§2.2, §2.9 item 3).
- **Expected grain:** One row per (audience_id × frequency_bucket).
- **Primary key (proposed):** composite (`audience_id`, `frequency_bucket`).
- **Foreign keys (proposed):** `audience_id` → dim_audience.
- **Required fields:** audience_id, frequency_bucket, impressions, exposed_count, buyer_rate, revenue.
- **Optional fields:** None beyond the above.
- **Source-system owner:** Same as #24.
- **Update frequency:** `[UNKNOWN]` — the sheet's existence with headers suggests this is a
  routinely-supported cut, just not populated for this particular study.
- **Historical retention requirement:** Same as #24.
- **Effective-dating requirement:** N/A.
- **Data-quality checks:** N/A until real data is observed.
- **Reports supported (if available):** Would support frequency-based media optimization
  recommendations; no current report in the catalog consumes this.
- **Confidence level:** Low — the schema is anticipated by the source tool, but its actual population
  rate/reliability is unverified (this specific export shows it empty).
- **Open questions:** Is this sheet ever populated for other campaigns, or structurally unused for
  this study's channel mix? **[NICE TO HAVE]** to confirm before relying on it.

#### 26. Media exposure evolution over time (daily/weekly trend)
- **Business purpose:** Daily/weekly time series of impressions/reach/new-reached — needed for
  Sales Impact Evolution-style trend reporting.
- **Presence in reviewed files:** **Partial — present but degenerate.** WB2 `Exposure Evolutions` has
  50 real data rows spanning 2025‑02‑10 to 2025‑03‑23, but **every metric value is exactly 0** for the
  whole window (§2.2, §2.9 item 4) — structurally present, not usable as real evidence of the
  underlying data's typical quality.
- **Expected grain:** One row per (audience_id × date).
- **Primary key (proposed):** composite (`audience_id`, `date`).
- **Foreign keys (proposed):** `audience_id` → dim_audience.
- **Required fields:** audience_id, date, impressions, reach, new_reached.
- **Optional fields:** None beyond the above.
- **Source-system owner:** Same as #24.
- **Update frequency:** Daily (per the observed date grain).
- **Historical retention requirement:** Campaign period + attribution window.
- **Effective-dating requirement:** N/A (event-dated fact).
- **Data-quality checks:** Not all values should be exactly 0 for an active campaign — an all-zero
  window should trigger a DQ alert (see [09_Data_Quality_Rules.md](09_Data_Quality_Rules.md)).
- **Reports supported (if available):** Sales Impact Evolution, any trend-based media dashboard.
- **Confidence level:** Low — real structure observed, but the only sampled instance is a known data
  quality failure (all-zero), so reliability cannot be assessed from this file set.
- **Open questions:** Was exposure/reach tracking simply not enabled for this study's media channels,
  or is this an export pipeline bug? **[IMPORTANT]** per catalog §2.9 item 4.

#### 27. Clicks
- **Business purpose:** Ad click-through counts — a standard media-funnel KPI, alongside impressions
  and reach.
- **Presence in reviewed files:** **Partial — single number only.** One headline total ("Clics =
  38.7K", deck7 slide 4). No structured clicks dataset/sheet exists anywhere in WB2's 37 sheets.
- **Expected grain:** One row per click event (or, minimally, per campaign × day aggregate).
- **Primary key (proposed):** `click_id` (if atomic) or composite (`campaign_id`, `date`) if only
  daily aggregates are obtainable.
- **Foreign keys (proposed):** `campaign_id` → dim_campaign; `customer_id`/`device_id` if resolvable.
- **Required fields:** campaign_id, click_count (or click_id + timestamp at atomic grain).
- **Optional fields:** click-through destination URL, device/channel.
- **Source-system owner:** Same as #24 (ad-serving platform).
- **Update frequency:** `[UNKNOWN]`.
- **Historical retention requirement:** Campaign period + attribution window.
- **Effective-dating requirement:** N/A.
- **Data-quality checks:** click_count ≤ impressions for the same scope (CTR ≤ 100%).
- **Reports supported (if available):** Campaign KPIs (deck7 slide 4) — currently the only report
  section that surfaces this metric at all.
- **Confidence level:** Low — a single scalar total is the only evidence this metric is tracked;
  no time series or per-channel breakdown observed.
- **Open questions:** Is a clicks-by-day or clicks-by-channel breakdown available from the media
  partner? **[NICE TO HAVE]**.

#### 28. Reach / reachable audience size
- **Business purpose:** Size of the addressable audience and how much of it was actually reached by
  media — denominator/numerator for Reach Rate.
- **Presence in reviewed files:** **Partial.** Pre-aggregated totals only: WB2 `Exposure Overview -
  exposure` (Reachable, Analysed Reach, §2.4); deck7 slide 4 ("Reach = 1.5M").
- **Expected grain:** One row per (audience_id × period).
- **Primary key (proposed):** composite (`audience_id`, `period_id`).
- **Foreign keys (proposed):** `audience_id` → dim_audience; `campaign_id` → dim_campaign.
- **Required fields:** audience_id, reachable_count, analysed_reach_count.
- **Optional fields:** reach_rate (derivable: analysed_reach / reachable).
- **Source-system owner:** Same as #24.
- **Update frequency:** Per campaign/study, snapshot at reporting time.
- **Historical retention requirement:** Campaign period + attribution window.
- **Effective-dating requirement:** N/A.
- **Data-quality checks:** analysed_reach_count ≤ reachable_count.
- **Reports supported:** Exposure Overview, Campaign KPIs, Sales Overview - reach_vs_buyers.
- **Confidence level:** Medium — aggregate values are consistently observed across both WB2 and deck7,
  a reasonable cross-file consistency signal.
- **Open questions:** None blocking; would benefit from atomic impression log (#24) to independently
  verify.

#### 29. Exposed/Control group assignment (atomic, per-shopper)
- **Business purpose:** Per-shopper flag of Exposed vs. Control group membership — the atomic input
  needed to independently recompute or audit the lift/incrementality methodology.
- **Presence in reviewed files:** **No.** The `Group`/`Is Control` dimension exists only at the
  **aggregate KPI-row level** (e.g. "Business Equation vs Control", WB2 §2.2/§2.3) — no shopper-level
  assignment table exists anywhere.
- **Expected grain:** One row per (customer_id × campaign_id).
- **Primary key (proposed):** composite (`customer_id`, `campaign_id`).
- **Foreign keys (proposed):** `customer_id` → dim_customer; `campaign_id` → dim_campaign.
- **Required fields:** customer_id, campaign_id, group_assignment (Control/Exposed), assignment_method
  (random/matched/propensity — never documented, see #30).
- **Optional fields:** matching_weight (if propensity-weighted).
- **Source-system owner:** Same as #21 — the lift-measurement platform's internal experiment design.
- **Update frequency:** Once per campaign, at study design time.
- **Historical retention requirement:** Full retention for the life of the campaign, for auditability.
- **Effective-dating requirement:** N/A (fixed assignment for the study's duration).
- **Data-quality checks:** No customer in both groups simultaneously; group sizes reconcile to
  reported aggregate counts.
- **Reports supported (if available):** Business Equation vs Control, Sales Uplift, all lift KPIs.
- **Confidence level:** N/A (not observed) — **PROPOSED**.
- **Open questions:** Can per-shopper group assignment ever be exported, or does the measurement
  vendor keep this strictly internal (common for lift-study IP protection)? **[BLOCKING]**.

#### 30. Control-group construction / matching methodology
- **Business purpose:** Documents *how* the Control group is built (random holdout vs. propensity
  matching vs. lookalike) and the statistical test used for p-values — required to trust or audit any
  lift/incrementality number.
- **Presence in reviewed files:** **No.** Not documented anywhere in any of the 7 files. Deck7 slide 6
  gives only a high-level 3-step narrative ("Audience building → Exposable group → Sales measure", §7.2)
  with no statistical detail. Report_Analysis_Catalog.md §2.5/§2.9 explicitly flags this as unresolved.
- **Expected grain:** One record per campaign (methodology can vary per study).
- **Primary key (proposed):** `campaign_id` (1:1 with #21).
- **Foreign keys:** `campaign_id` → dim_campaign.
- **Required fields:** matching_method (e.g. propensity score matching, random holdout),
  significance_test_type (for the p-values seen in WB2 `Appendix Pvalues`), is_multisegment_resampled
  (flag already observed in source, meaning unclear — §2.4).
- **Optional fields:** matching_covariates (what variables the match was balanced on), sample_size
  calculation method.
- **Source-system owner:** `[UNKNOWN]`.
- **Update frequency:** N/A — a methodology description, not a refreshing data feed.
- **Historical retention requirement:** Should be versioned if methodology changes between studies,
  to avoid comparing incompatible lift numbers across campaigns.
- **Effective-dating requirement:** N/A.
- **Data-quality checks:** N/A (documentation, not data).
- **Reports supported (if available):** Underpins the validity of every lift/incrementality/p-value
  KPI in WB2 and deck7 — currently **none of these can be independently audited**.
- **Confidence level:** N/A (not observed) — **PROPOSED**, and flagged as the single most significant
  methodological gap in the whole file set.
- **Open questions:** What exact statistical method builds the Control group and computes p-values?
  **[BLOCKING]** — see [06_Open_Questions.md](06_Open_Questions.md), top priority item.

#### 31. Campaign cost data
- **Business purpose:** Media spend, needed for CPM, Cost per Shopper/Receipt, and ROAS KPIs.
- **Presence in reviewed files:** **Partial.** Aggregate totals only: WB2 `Exposure Overview -
  exposure` (Campaign Cost, Analysed Cost, §2.4); deck7 slide 4 ("CPM = 2.4€", actual vs. estimated
  4.3€). No daily/channel-level cost breakdown beyond WB2's `Performance by Channel` aggregate view.
- **Expected grain:** One row per (campaign_id × channel × date), ideally; only totals observed.
- **Primary key (proposed):** composite (`campaign_id`, `channel`, `date`).
- **Foreign keys (proposed):** `campaign_id` → dim_campaign; `channel` → dim_media_channel.
- **Required fields:** campaign_id, total_cost, analysed_cost.
- **Optional fields:** cost_by_channel, cost_by_date, estimated_cost (for actual-vs-estimated
  comparisons as shown on deck7 slide 4).
- **Source-system owner:** Same as #24 (ad platform / media buying system).
- **Update frequency:** Per campaign, snapshot at reporting time.
- **Historical retention requirement:** Campaign period retention, for ROAS trend analysis across
  campaigns.
- **Effective-dating requirement:** N/A.
- **Data-quality checks:** analysed_cost ≤ total_cost; CPM = (cost / impressions) × 1000 reconciles.
- **Reports supported:** Exposure Overview, Sales Overview - trade (Cost per Receipt/Shopper), Sales
  Uplift (ROAS), Campaign KPIs.
- **Confidence level:** Medium — headline totals are consistently observed; no granular breakdown to
  verify beyond that.
- **Open questions:** Can cost be broken out by channel/day to support more granular ROAS analysis?
  **[NICE TO HAVE]**.

#### 32. Attribution window configuration
- **Business purpose:** Defines the post-campaign period during which a sale can still be attributed
  to campaign exposure — a critical, currently unstructured parameter.
- **Presence in reviewed files:** **Partial.** Stated only as narrative text: deck7 slide 1/3 ("30-day
  attribution window, from June 1 to June 30, 2026"); not present as a structured/configurable field
  inside WB2 itself (no `attribution_window` column found in the §2.2 sheet inventory).
- **Expected grain:** One row per campaign.
- **Primary key (proposed):** `campaign_id` (1:1 with #21).
- **Foreign keys:** `campaign_id` → dim_campaign.
- **Required fields:** campaign_id, attribution_window_start, attribution_window_end,
  attribution_window_days (30, as observed).
- **Optional fields:** attribution_model (last-touch/multi-touch — not documented).
- **Source-system owner:** Same as #21.
- **Update frequency:** Set once per campaign at design time.
- **Historical retention requirement:** Permanent, for reproducibility of historical lift numbers.
- **Effective-dating requirement:** N/A (fixed per campaign).
- **Data-quality checks:** attribution_window_start = campaign_end_date + 1 day (per the observed
  pattern: campaign ends 31/05/2026, attribution window starts 01/06/2026).
- **Reports supported (if available, as structured data):** All lift/incrementality KPIs in WB2 and
  deck7 implicitly depend on this window but it is never exposed as queryable data alongside the KPI
  values themselves.
- **Confidence level:** Low — the concept and one example value are clear; there is no evidence this
  is captured as structured, joinable configuration data in the source platform.
- **Open questions:** Is the attribution window ever varied per campaign (i.e., is 30 days a fixed
  platform default or a per-study choice)? **[IMPORTANT]**.

## 6. Configuration / Report-Parameter Data

#### 33. Report parameter records
- **Business purpose:** Captures the exact configuration (retailer, banner/region/surface scope,
  product scope, period type, analysis vs. comparison dates, selected KPI list) used to generate a
  given report export — essential for reproducibility and for parameterizing a future self-service
  report-generation layer.
- **Presence in reviewed files:** **Yes.** Every `Paramètres` sheet (WB1 §1.2, WB3 §3.2, WB4 §4.2, WB5
  §5.2) — the best-structured, most directly reusable configuration data in the whole file set.
- **Expected grain:** One row per report run/export.
- **Primary key (proposed):** `report_run_id` (surrogate).
- **Foreign keys (proposed):** `product_list_id` → dim_product_list; `store_scope_id` → a store-scope
  filter definition; references dataset #34 for period-type resolution.
- **Required fields:** report_run_id, report_name, retailer, category (Analyser/Extraction),
  product_nomenclature, product_scope_value, store_format_scope, region_scope, surface_scope,
  constants_courants_flag, transaction_type_scope, period_type (CAM/CAD/Personnalisée),
  analysis_period_start/end, comparison_period_start/end (nullable — WB5 explicitly has none),
  analysis_level, selected_kpi_list.
- **Optional fields:** benchmark_nomenclature, benchmark_scope_value (only present when a benchmark is
  configured, e.g. WB3's "BARRES CHOCOLATEES").
- **Source-system owner:** Memory 360 (the report-generation/export tool itself).
- **Update frequency:** One record created per report export/run — not a slowly-changing master, but
  an append-only log of configurations used.
- **Historical retention requirement:** Permanent — required to interpret every historical export
  correctly (this is the record that defines what "période d'analyse" even means for that export).
- **Effective-dating requirement:** N/A (each record is inherently a point-in-time configuration
  snapshot).
- **Data-quality checks:** analysis_period_start/end always populated; comparison fields populated
  unless period_type = "Personnalisée" with explicit no-comparison flag (as in WB5).
- **Reports supported:** All — this is the config record underlying every report in the catalog.
- **Confidence level:** High — directly observed, consistent structure across 4 independent workbooks.
- **Open questions:** None blocking; recommend formalizing this as `cfg_report_definition` in the
  canonical model (see [03_Canonical_Data_Model.md](03_Canonical_Data_Model.md)).

#### 34. Nielsen period calendar
- **Business purpose:** Maps Nielsen/NIQ period numbers to calendar start/end dates (13 periods per
  year, ~28 days each) — required to operationalize `CAM` (Cumul Annuel Mobile) and `CAD` (Cumul A
  Date) period-type logic in a `dim_date` table.
- **Presence in reviewed files:** **Partial.** The *concept* is defined in glossary text only (WB3
  `Lexique`, §3.4: "CAM = rolling 13-Nielsen-period cumulative window"; "CAD = year-to-date cumulative
  from the start of the current Nielsen year") — the actual period-number-to-date mapping table is
  **not present** in any file.
- **Expected grain:** One row per Nielsen period per year.
- **Primary key (proposed):** composite (`nielsen_year`, `period_number`).
- **Foreign keys:** None inbound; referenced by dim_date and by dataset #33's period_type resolution.
- **Required fields:** nielsen_year, period_number (1–13), period_start_date, period_end_date.
- **Optional fields:** None anticipated.
- **Source-system owner:** `[EXTERNAL]` — Nielsen/NIQ's standard retail calendar, not generated by
  Carrefour or Unlimitail.
- **Update frequency:** Annual (a new year's 13-period calendar is published once per year).
- **Historical retention requirement:** Full history back to the earliest period any report might
  reference (≥24 months minimum, likely longer for trend analysis).
- **Effective-dating requirement:** N/A (each period is a fixed historical date range once published).
- **Data-quality checks:** Exactly 13 periods per Nielsen year; no gaps/overlaps between consecutive
  period_end_date and the next period_start_date.
- **Reports supported (if available):** Enables independent recomputation of any CAM/CAD-period-typed
  KPI; currently every such KPI must be trusted as pre-computed by Memory 360.
- **Confidence level:** Low — concept is well-defined in glossary text, but the actual calendar table
  is entirely absent and would need to be sourced from Nielsen/NIQ directly.
- **Open questions:** Can the Nielsen period calendar be licensed/obtained directly, or must all
  period-typed date logic continue to be delegated to Memory 360's own internal calendar?
  **[IMPORTANT]**.

#### 35. Currency / tax treatment metadata
- **Business purpose:** Confirms currency (implicitly € throughout) and whether revenue figures are
  gross or net of VAT — required for any financial reconciliation against Carrefour's own general
  ledger or external benchmarks.
- **Presence in reviewed files:** **No.** Not addressed in any file; all monetary values are
  implicitly in € (consistent formatting observed throughout WB1/WB3/WB4/WB5 and both decks) but no
  explicit currency code field exists, and no statement of gross-vs-net-of-VAT treatment is present
  anywhere in the catalog.
- **Expected grain:** Single global configuration record (or one per retailer/country if
  multi-currency were ever in scope, though nothing in the file set suggests that).
- **Primary key (proposed):** `currency_config_id` (likely a single row given single-country,
  single-currency evidence).
- **Foreign keys:** None.
- **Required fields:** currency_code (presumed EUR), tax_treatment (gross/net of VAT — `[UNKNOWN]`).
- **Optional fields:** None anticipated.
- **Source-system owner:** `[UNKNOWN]`.
- **Update frequency:** Effectively static (currency/tax regime changes are rare, exceptional events).
- **Historical retention requirement:** Low priority, but should be recorded once for the life of the
  model to avoid silent misinterpretation of monetary figures.
- **Effective-dating requirement:** Only relevant if a VAT-rate change occurred within the reporting
  history window — `[UNVERIFIED]`.
- **Data-quality checks:** N/A (single reference value).
- **Reports supported:** All monetary KPIs implicitly depend on this being correctly understood, even
  though it is never explicitly stated.
- **Confidence level:** N/A (not observed) — **PROPOSED**, flagged purely as a documentation gap since
  all sampled figures are internally consistent with a single implied currency/tax convention.
- **Open questions:** Confirm with the client: are all CA/Revenue figures gross of VAT, net of VAT, or
  does it vary by report? **[IMPORTANT]**.

---

## Summary Assessment

| Category | Genuinely atomic & available | Available only pre-aggregated | Not available at all |
|---|---|---|---|
| Transactional/sales | 0 of 4 | 2 of 4 (#3, #4) | 2 of 4 (#1, #2) |
| Product reference | 3 of 6 (#5–8 combined = 3 distinct datasets) | 1 of 6 (#9) | 1 of 6 (#10) |
| Store/retailer reference | 2 of 4 (#11, #14) | 1 of 4 (#12) | 1 of 4 (#13) |
| Customer/loyalty | 1 of 6 (#17) | 3 of 6 (#18–20) | 2 of 6 (#15, #16) |
| Campaign/retail-media | 0 of 12 | 8 of 12 | 4 of 12 (#23, #24, #29, #30) |
| Config | 1 of 3 (#33) | 1 of 3 (#34) | 1 of 3 (#35) |

**Bottom line:** The 7 reviewed files collectively behave as a **presentation/output layer**, not a
source layer. The only genuinely atomic, reusable reference data recovered is the **product master**
and **store master** embedded in WB4/WB5, plus the **report-parameter (`Paramètres`) records**. Every
KPI, segment, and campaign-measurement number in the whole file set is a pre-aggregated result of
upstream systems (POS/loyalty transactions, ad-platform exposure logs, a statistical lift-measurement
service) that are **not included** in this file set and would need to be sourced directly from Carrefour/
Memory 360/Unlimitail to build a from-scratch, recomputable data model. This finding directly shapes the
two-tier design in [03_Canonical_Data_Model.md](03_Canonical_Data_Model.md) (a "required new inputs"
tier vs. a "derivable from reviewed files" tier).
