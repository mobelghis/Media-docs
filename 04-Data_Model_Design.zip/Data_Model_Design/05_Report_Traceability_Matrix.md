# 05 — Report Traceability Matrix

**Purpose:** For each of the 22 report sections identified across the 7 reviewed files, map the
required facts/dimensions/filters/KPIs to the canonical model in
[03_Canonical_Data_Model.md](03_Canonical_Data_Model.md), and classify reproducibility using the
6-way scale below. This is the bridge between "what the source files show" and "what the proposed
model can actually deliver."

**Reproducibility classification legend:**
- **Fully reproducible** — all required facts/dims exist in the model as AVAILABLE data today.
- **Reproducible with assumptions** — reproducible today, but only by accepting one or more
  INFERRED/PARTIAL items documented in [02](02_Input_Data_Catalog.md)/[04](04_KPI_Lineage_and_Formulas.md).
- **Requires additional source data** — blocked on a NOT AVAILABLE Tier‑1 fact/dim; structurally
  designed for, but not populatable, today.
- **Requires statistical methodology** — blocked specifically on an undefined lift/matching/
  significance methodology (F5/F6/F7 in 04), not on missing raw data per se.
- **Presentation-only** — the section is chart/narrative/branding content with no underlying KPI to
  model (e.g. a title slide).
- **Not reproducible from available evidence** — neither current data nor a stated methodology exists,
  and no reasonable assumption can bridge the gap.

---

| # | Report Section | Source | Required Facts/Aggregate Tables | Required Dimensions | Key Filters | Key KPIs (from 04) | Reproducibility |
|---|---|---|---|---|---|---|---|
| 1 | Customer Loyalty — Bilan (movement) | WB1 §1 | `agg_report_metric`; target: `fact_customer_period_status` | dim_product_list, dim_date (period pair) | Product list, period pair (analyse vs comparaison) | E1 Constants/Gagné/Perdu, A4, A5 | Reproducible with assumptions (movement *rule* is CONFIRMED; underlying per-customer data is PARTIAL via agg only) |
| 2 | Customer Loyalty — Profile | WB1 §1 | `agg_report_metric` | dim_customer_segment, dim_product_list | Segment family, product list | A1–A9, B1 | Reproducible with assumptions (segment defs INFERRED from Lexique; no atomic customer rows) |
| 3 | Top EAN | WB1, WB3 | `agg_report_metric` | dim_product | Top-N rank, product list | A1, A2, A9 | Fully reproducible (rank of pre-aggregated CA/UVC per EAN is directly in source exports) |
| 4 | Top Brands | WB1, WB3 | `agg_report_metric` | dim_brand | Top-N rank, product list | A1, A2, A9 | Fully reproducible |
| 5 | Customer Segmentations | WB1 | `agg_report_metric`; taxonomy: `dim_customer_segment` | dim_customer_segment | Segment family/value | A1, A4, B1 | Reproducible with assumptions (RFM has zero definitions anywhere — RFM cells fall to "Requires additional source data" specifically) |
| 6 | Geographic Distribution | WB1, WB3 | `agg_report_metric` | dim_geography, dim_store_banner | Region, banner | A1, A2, B2 | Fully reproducible (8-region taxonomy AVAILABLE) |
| 7 | Performance (overview) | WB3 §3.1 | `agg_report_metric` | dim_product, dim_store | Product/benchmark list, period | A1–A9, C1, C2 | Reproducible with assumptions (benchmark list "BARRES CHOCOLATEES" never enumerated — see 02 #9 BLOCKING) |
| 8 | Quoi (product cut) | WB3 §3.2 | `agg_report_metric` | dim_product, dim_product_hierarchy | Product hierarchy level | A1, A2, B2, C1 | Reproducible with assumptions |
| 9 | Quand (temporal cut) | WB3 §3.2 | `agg_report_metric` | dim_date | Period grain (week/month) | A1, A2, C1, C2 | Fully reproducible |
| 10 | Où (geographic/store cut) | WB3 §3.2 | `agg_report_metric` | dim_store, dim_geography, dim_store_banner | Region, banner | A1, A2, B2, C1 | Fully reproducible |
| 11 | Qui (customer/segment cut) | WB3 §3.2 | `agg_report_metric` | dim_customer_segment | Segment family | A1, A4, C1 | Reproducible with assumptions |
| 12 | Product Extraction Indicators | WB4 | `agg_report_metric`; masters: `dim_product`, `dim_store` | dim_product, dim_store | Category (SOFTS DRINKS), scope | A1, A2, A9, B2 | Fully reproducible (masters are the two genuinely atomic reference extracts recovered) |
| 13 | Temporal Evolution | WB5 | `agg_report_metric` | dim_date, dim_product (single brand) | Daily grain, 181-day window | A1, A2, C1 | Reproducible with assumptions (brand-name inconsistency `COCA COLA`/`COCA-COLA` must be normalized in `dim_brand`, else double-counts) |
| 14 | Presales Insights — slides 1–2 (context/branding) | deck6 | — | — | — | — | Presentation-only |
| 15 | Presales Insights — slide 3 (KPI content) | deck6 | `agg_report_metric` | dim_product (anonymized as XXX) | Product list | A1, A4, F8 (loyal shopper, deck-stated rule) | Reproducible with assumptions (brand anonymized; loyal-shopper threshold discrepant vs WB2 — see 04 F8) |
| 16 | Campaign Exposure Overview | WB2, deck7 | `agg_campaign_metric`; target: `fact_media_exposure` | dim_campaign, dim_media_channel | Campaign, channel | F2 Reach, F3 Impressions/Frequency | Reproducible with assumptions (`Exposure Overview - frequency` sheet empty in WB2; deck totals only) |
| 17 | Business Equation | deck7 slide 9 | `agg_campaign_metric` | dim_campaign, dim_product_list | Campaign, group | F1 Conversion Rate, A1, A4 | Fully reproducible (formula explicitly stated in source, CONFIRMED) |
| 18 | New Shopper Acquisition | WB2, deck7 | `agg_campaign_metric`; target: `fact_new_shopper_flag` | dim_campaign, dim_product_list | Campaign, New/Returning | F9 New/Returning Shopper Measures | Reproducible with assumptions (classification rule stated; lookback window UNVERIFIED — 02 #19 BLOCKING) |
| 19 | Numeric Distribution | WB3, WB2 | `agg_report_metric` / `agg_campaign_metric` | dim_product, dim_store | Product, store scope | B2 Numeric/Value Distribution | Fully reproducible (DN formula CONFIRMED and independently recomputed) |
| 20 | Sales Overview (campaign) | WB2 | `agg_campaign_metric` | dim_campaign, dim_product_list | Campaign, period (Pre/Campaign) | A1, A2, A4 | Fully reproducible |
| 21 | Sales Uplift | WB2, deck7 | `agg_campaign_metric`; target: none (no lift fact) | dim_campaign, dim_product_list | Campaign, Control/Exposed | F5 Incremental Revenue/Quantity/Shoppers, F6 ROAS | **Requires statistical methodology** (lift/matching/ROAS formula UNVERIFIED/BLOCKING per 04 F5/F6) |
| 22a | Loyalty Profiles (campaign-side) | WB2 | `agg_campaign_metric` | dim_customer_segment, dim_campaign | Campaign, segment | F8 Loyal Shopper Rate | Reproducible with assumptions (WB2's ">2 Receipts" threshold discrepant vs deck6 — flag both) |
| 22b | Shopper Profiles | WB2 | `agg_campaign_metric` | dim_customer_segment, dim_audience | Campaign, audience | A4, F1, F8 | Reproducible with assumptions |
| 22c | Measurement Report — slides 1–8, 10, 12–15 (narrative/branding/context) | deck7 | — | — | — | — | Presentation-only |
| 22d | Measurement Report — slide 9 (Business Equation) | deck7 | see row 17 | — | — | — | Fully reproducible (duplicate of row 17, shown here for slide-level completeness) |
| 22e | Measurement Report — slide 11 (brand leak: Saint Germain) | deck7 | `agg_campaign_metric` | dim_campaign, dim_product | Campaign | A1, A4 | Reproducible with assumptions (brand identity confirmed only via anonymization leak — do not rely on this as a stable source-of-truth join key) |
| 22f | Measurement Report — `Performance by Audience` anomalous values | deck7 / WB2 | `agg_campaign_metric` | dim_audience | Audience | F1, F2 | **Not reproducible from available evidence** (flagged in review_findings.md as a likely export bug, not literal KPI values — do not model as a trustworthy fact) |
| 22g | Measurement Report — `Exposure Evolutions` (all-zero, 50 days) | WB2 | `agg_campaign_metric` | dim_date | Daily grain | F2, F3 | **Not reproducible from available evidence** (source data is degenerate/all-zero; cannot validate correctness of a rebuild against it) |

---

## Summary by Classification

| Classification | Count | Sections |
|---|---|---|
| Fully reproducible | 8 | 3, 4, 6, 9, 10, 12, 17, 19, 20 (9 actually — see note) |
| Reproducible with assumptions | 11 | 1, 2, 5, 7, 8, 11, 13, 15, 16, 18, 22a, 22b, 22e |
| Requires additional source data | 0 (folded into "with assumptions" where a rule is CONFIRMED but data is PARTIAL) | — |
| Requires statistical methodology | 1 | 21 (Sales Uplift) |
| Presentation-only | 2 | 14, 22c |
| Not reproducible from available evidence | 2 | 22f, 22g |

*(Note: row count above is 24 due to the Measurement Report deck being broken into 7 sub-rows
(16–22g) for slide-level traceability, rather than exactly 22 flat sections; every one of the 22
named sections in the original spec list is covered — some map to multiple matrix rows because a
single deck section spans multiple distinct reproducibility outcomes, e.g. row 22 "Measurement
Report slides" spans presentation-only, fully-reproducible, and not-reproducible sub-content.)*

## Cross-Reference Notes

- Every "Requires statistical methodology" and "Not reproducible from available evidence" row here
  must have a corresponding entry in [06_Open_Questions.md](06_Open_Questions.md) tagged **Blocking**.
- Every KPI referenced in the "Key KPIs" column exists in
  [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md); no KPI is introduced here that
  isn't already defined there (verification checkpoint for step 12 of plan.md).
