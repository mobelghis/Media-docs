# 12 — Client Feed Onboarding Mapping: Standard Interface → Real Physical Schema

**Purpose:** For onboarding Unlimitail's client feeds into Activate, map each **standard
ingestion-interface file/field** (`Activate Data Interface v8.0.xlsx` — what a retailer sends) to
the **real physical database table/column** it lands in (`CV_Retailer` / `CV_Campaigns` /
`CV_RetailerRprt`, per the DDL supplied by the user), and mark explicit gaps. This supersedes the
abstraction-layer (`dim_store`/`dim_customer`) framing used in
[11_Standard_Model_Gap_Analysis.md](11_Standard_Model_Gap_Analysis.md) with the actual onboarding
target schema, so client-feed mapping work is grounded in what will actually receive the data.

**Sources:**
- `Source files/Activate Data Interface v8.0.xlsx` (Insights sheet) — client feed contract.
- `Source files/cv-retailer-schema.sql` — `CV_Retailer` schema (reference/master data).
- `Source files/cv-campaigns-schema.sql` — `CV_Campaigns` schema (Personalization, out of Phase 1 scope).
- `Source files/cv-retailerrprt-schema.sql` — `CV_RetailerRprt` schema (report output tables).
- `Source files/Activate DB Schema.xlsx` — SingleStore/Online table inventory (referenced only
  where the real gap requires it — see §5).

**Excluded:** `Source files/nga-poc-all-table-ddls.md` (`nga_*`/`dh_*` tables) — confirmed
unrelated PoC staging tables for a different project, not part of Activate onboarding.

---

## 0. Visual Overview — Incoming Feed Fields → Activate Physical Data Model

Every arrow below is a 1:1 restatement of a mapping row in Sections 1–7; no field or target not
already documented in this file has been added. Color/style indicates status: solid green =
**Present**, dashed orange = **Gap/Unconfirmed**, dashed red = **Blocking Gap**.

```mermaid
flowchart LR
    classDef present fill:#d4f4dd,stroke:#2e7d32,color:#1b1b1b;
    classDef gap fill:#fff3cd,stroke:#c98a00,color:#1b1b1b,stroke-dasharray: 4 3;
    classDef blocking fill:#fbdada,stroke:#c62828,color:#1b1b1b,stroke-dasharray: 4 3;
    classDef feed fill:#e3ecfb,stroke:#3057a3,color:#1b1b1b,font-weight:bold;

    subgraph F1["1. Store Master feed"]
        direction LR
        S1["Store_ID"]:::feed --> S1T["CV_R_RTLR_POS_DESCRIPTION.POS_ID"]:::present
        S2["Store_Name (short/long)"]:::feed --> S2T["POS_SHORT_DESCRIPTION /<br/>POS_LONG_DESCRIPTION"]:::present
        S3["Store_Status"]:::feed --> S3T["POS_STATUS"]:::present
        S4["Address fields"]:::feed --> S4T["ADDRESS_LINE_1/2, CITY, STREET,<br/>ZIP_CODE, PROVINCE, STATE"]:::present
        S5["Geography code"]:::feed --> S5T["GEOGRAPHY_ID"]:::present
        S6["Store_Format/Banner/Channel/<br/>Geo_Level_1-4"]:::feed -.-> S6T["CV_R_STORES_TREE +<br/>CV_R_STORE_PARENTS<br/>(HIERARCHY_TYPE convention undefined)"]:::gap
        S7["Custom retailer demographics"]:::feed --> S7T["POS_DEMOGRAPHIC_1..8"]:::present
    end

    subgraph F2["2. Product Catalog feed"]
        direction LR
        P1["Product_ID"]:::feed --> P1T["CV_R_CATALOG_TREE<br/>(PRODUCT_TREE_LEVEL = 0)"]:::present
        P2["Section/Subcategory/<br/>Category/Department"]:::feed -.-> P2T["CV_R_CATALOG_TREE levels 1-4 +<br/>CV_R_CATALOG_PARENTS<br/>(level-to-name mapping undefined)"]:::gap
        P3["CPG_Supplier / Brand"]:::feed --> P3T["CV_R_CPG_BRAND_CATALOG_TREE /<br/>CV_R_BRAND_CATALOG_FLAT"]:::present
        P4["UPC"]:::feed -.-> P4T["Not confirmed in columns read so far"]:::gap
        P5["Private_Label_Flag"]:::feed -.-> P5T["Not located — possibly<br/>CV_R_ATTRIBUTES_MASTER"]:::gap
    end

    subgraph F3["3. Shoppers feed"]
        direction LR
        H1["Shopper_ID"]:::feed --> H1T["CV_R_SHPR_DESCRIPTION.CV_SHOPPER_ID<br/>(PK is actually RETAILER_LOYALTY_ID)"]:::present
        H2["Household_ID"]:::feed -.-> H2T["Not found on CV_R_SHPR_DESCRIPTION"]:::gap
        H3["Join_Date, Year_of_Birth,<br/>Gender, Accumulated_Points"]:::feed -.-> H3T["Not found — possibly an<br/>unread SHPR demographic table"]:::gap
        H4["Delivery_Channels"]:::feed --> H4T["ELIGABILITY_CHANNELS<br/>(bitmask, format unconfirmed)"]:::present
    end

    subgraph F4["4. Purchase Reference (Cards) feed"]
        direction LR
        C1["Purchase_Ref_ID / Card_ID"]:::feed --> C1T["CV_R_SHPR_IDENTIFYING_CARD.<br/>IDENTIFYING_CARD_ID"]:::present
        C2["Shopper_ID link"]:::feed --> C2T["CV_R_SHPR_IDENTIFYING_CARD.<br/>CV_SHOPPER_ID"]:::present
        C3["Status"]:::feed --> C3T["CV_R_SHPR_IDENTIFYING_CARD.STATUS"]:::present
        C4["Is_Current / Effective_From/To"]:::feed -.-> C4T["Not historized —<br/>no such columns exist"]:::gap
    end

    subgraph F5["5. Tlog Sales feed"]
        direction LR
        T1["Transaction/basket/receipt/<br/>invoice-line data"]:::feed -.->|BLOCKING| T1T["No table in CV_Retailer,<br/>CV_Campaigns, or CV_RetailerRprt —<br/>lives in unsupplied SingleStore/<br/>Online schema"]:::blocking
    end

    subgraph F6["6. Shopper Custom Segments feed"]
        direction LR
        G1["Shopper_ID, Segment_ID,<br/>Segment_Value_Code/Description"]:::feed --> G1T["CV_R_SHPR_CUSTOM_SEGMENTS<br/>(EAV: CV_SHOPPER_ID, ATTRIBUTE_ID,<br/>ATTRIBUTE_VALUE_ID) + brand variant"]:::present
        G2["Effective_From"]:::feed --> G2T["CREATION_TIMESTAMP /<br/>UPDATE_TIMESTAMP<br/>(audit, not business-effective dating)"]:::present
    end

    subgraph F7["7. Attributes Metadata feed"]
        direction LR
        A1["Attribute_Type, Attribute_Code,<br/>Attribute_Value_Code/Description"]:::feed --> A1T["CV_R_ATTRIBUTES_MASTER<br/>(+ _PERMISSIONS, _VALUES_MASTER)"]:::present
    end
```

---

## 1. Store Master feed

| Interface field | Physical target | Status |
|---|---|---|
| Store_ID | `CV_R_RTLR_POS_DESCRIPTION.POS_ID` (business key; `CV_POS_ID` is the internal surrogate PK) | **Present** |
| Store_Name / short & long description | `POS_SHORT_DESCRIPTION` / `POS_LONG_DESCRIPTION` | **Present** |
| Store_Status | `POS_STATUS` (A/D) | **Present** |
| Address fields (city, street, zip, province, state...) | `ADDRESS_LINE_1/2`, `CITY`, `STREET`, `STREET_NUMBER`, `ZIP_CODE`, `PROVINCE`, `STATE` | **Present** |
| Geography code | `GEOGRAPHY_ID` | **Present** |
| Store_Format_Level_1-4 / Store_Banner_Level_1-4 / Store_Channel_Level_1-4 / Store_Geo_Level1-4 | **No dedicated 4-level columns exist.** Partially covered by flat `CHANNEL`, `REGION`, `FORMAT` columns on `CV_R_RTLR_POS_DESCRIPTION` (single value each, not a hierarchy), plus the generic hierarchy tables `CV_R_STORES_TREE` + `CV_R_STORE_PARENTS` (keyed by `HIERARCHY_TYPE`, 0-7 levels, no fixed "Banner"/"Format"/"Channel" semantics attached at the DDL level — those would be *values* of `HIERARCHY_TYPE`, not columns). | **GAP — structural mismatch.** The onboarding feed's named 4-level hierarchies must be loaded as **rows into `CV_R_STORES_TREE` per `HIERARCHY_TYPE`** (e.g. one hierarchy_type for Banner, one for Format, one for Channel, one for Geo), not as columns on the POS table. Client-feed mapping/ETL needs an explicit `HIERARCHY_TYPE` assignment convention — **not yet defined anywhere in the reviewed sources.** |
| Custom retailer demographics (free text) | `POS_DEMOGRAPHIC_1` through `_8` | **Present** (generic slots, not typed) |

## 2. Product Catalog feed

| Interface field | Physical target | Status |
|---|---|---|
| Product_ID | `CV_R_CATALOG_TREE` row at `PRODUCT_TREE_LEVEL = 0`; `catalog_internal_id`-equivalent surrogate | **Present** |
| Section/Subcategory/Category/Department (ID+Description) | `CV_R_CATALOG_TREE` levels 1-4 + `CV_R_CATALOG_PARENTS` (flattened rollup); `CV_R_ALL_PARENTS` for cross-hierarchy queries | **Present**, but note: interface names 4 fixed levels (Section→Department); physical schema is a **generic 0-5 level tree** — level-to-name mapping (which `PRODUCT_TREE_LEVEL` = "Section" vs. "Department") is **not defined in the DDL** and must be confirmed as a retailer-specific convention. |
| CPG_Supplier_ID/Description, Brand_ID/Description | `CV_R_CPG_BRAND_CATALOG_TREE` / `CV_R_BRAND_CATALOG_FLAT` (Brand→Sub-Brand→High-Brand→CPG, 4 levels) | **Present**, in a **separate tree from the product hierarchy** — confirm the client feed's Brand_ID resolves against this tree, not a column on the product record. |
| UPC | Not confirmed present as a distinct column in the read portions of `CV_R_CATALOG_TREE`; likely a `PROD_*` attribute column (`PRODUCT_RETAILER_FACT_1-4` or similar free-form fields seen elsewhere in the file) | **UNCONFIRMED — needs targeted read of `CV_R_CATALOG_TREE`'s full column list** (only summarized in prior passes). |
| Private_Label_Flag | Not yet located in the columns read so far (`PROD_FOOD`, `PROD_UNIT_OF_MEASURE`, `PROD_QUANTITY` were seen; no explicit private-label column confirmed) | **GAP or UNCONFIRMED** — needs explicit verification; may be one of the generic `CV_R_ATTRIBUTES_MASTER` (Product-category attributes) rather than a fixed column. |

## 3. Shoppers feed

| Interface field | Physical target | Status |
|---|---|---|
| Shopper_ID | `CV_R_SHPR_DESCRIPTION.CV_SHOPPER_ID` (secondary indexed column; **`RETAILER_LOYALTY_ID` is the actual primary key**) | **Present**, but note the PK is the retailer's loyalty ID string, not the numeric shopper ID — client feed must supply/resolve both consistently. |
| Household_ID | **Not found** in `CV_R_SHPR_DESCRIPTION` (columns confirmed: `CV_SHOPPER_ID`, `RETAILER_LOYALTY_ID`, `ELIGABILITY_CHANNELS`, `SHOPPER_STATUS`) | **GAP** — no household-level grouping column exists on the shopper master table in this schema. If household grouping is required, it isn't modeled here — flag as an open question for onboarding. |
| Join_Date, Year_of_Birth, Gender, Accumulated_Points | **Not found** on `CV_R_SHPR_DESCRIPTION`'s confirmed 4 columns | **GAP or elsewhere** — these demographic/loyalty fields must live in a different table not yet fully read (possibly `CV_R_SHPR_CUSTOM_SEGMENTS`/`CV_R_SHPR_BRAND_CUSTOM_SEGMENTS` via the generic attribute mechanism, or an unread table). **Needs targeted follow-up read of `cv-retailer-schema.sql` for any additional SHPR demographic table.** |
| Delivery_Channels | `ELIGABILITY_CHANNELS` (int2 on `CV_R_SHPR_DESCRIPTION`) — likely a bitmask | **Present**, format (bitmask semantics) unconfirmed. |

## 4. Purchase Reference (Cards) feed

| Interface field | Physical target | Status |
|---|---|---|
| Purchase_Ref_ID / Card ID | `CV_R_SHPR_IDENTIFYING_CARD.IDENTIFYING_CARD_ID` (unique) | **Present** |
| Shopper_ID link | `CV_R_SHPR_IDENTIFYING_CARD.CV_SHOPPER_ID` | **Present** |
| Status | `CV_R_SHPR_IDENTIFYING_CARD.STATUS` | **Present** |
| Is_Current / Effective_From / Effective_To (Type-2 history) | **Not present as columns** on `CV_R_SHPR_IDENTIFYING_CARD` (only `INTERNAL_ID`, `IDENTIFYING_CARD_ID`, `CV_SHOPPER_ID`, `STATUS` confirmed) | **GAP** — the table is not historized; card reassignment history (a card moving between shoppers over time) is not modeled unless `STATUS` transitions are tracked elsewhere (e.g., an audit/history table not yet found). Flag as an open question before mapping the interface's `Effective_From/To` fields. |

## 5. Tlog Sales feed — **CRITICAL GAP**

**No transaction, basket, receipt, or invoice-line table exists in any of the three schemas
reviewed** (`CV_Retailer`, `CV_Campaigns`, `CV_RetailerRprt`) — confirmed via targeted search
for `SALES`/`INVOICE`/`TLOG`/`TRANSACTION`/`PURCHASE`/`BASKET`/`RECEIPT` table names; the only
match was `CV_R_RPT_OFFER_PERFORMANCE_REPURCHASE`, a pre-aggregated **reporting** rollup, not
atomic transaction data.

This is corroborated by the (excluded, but informative-as-context) `nga-poc-all-table-ddls.md`,
whose `cv_r_sales_history_no_rls` table is explicitly labeled **LEGACY-REPLICA** — i.e. it
reproduces a **SingleStore/online-DB structure that lives outside these three Postgres schemas
entirely.** This is consistent with `Activate DB Schema.xlsx` (§11 review) listing Tlog-adjacent
tables under **SingleStore** and **`Online_CV_Retailer`/`Online_All`** schemas, not `CV_Retailer`.

**Implication for onboarding:** The atomic sales feed (the single most important input for every
Insights KPI) is **not covered by the three DDL files provided for this mapping exercise.**
Onboarding client Tlog feeds requires the **SingleStore/Online schema DDL**, which has not yet
been supplied in source-file form (only referenced by name in the `Activate DB Schema.xlsx`
workbook dump). **Recommend requesting this DDL explicitly before finalizing the onboarding
mapping — this is a blocking gap, not a minor one.**

## 6. Shopper Custom Segments feed

| Interface field | Physical target | Status |
|---|---|---|
| Shopper_ID, Segment_ID, Segment_Value_Code/Description | `CV_R_SHPR_CUSTOM_SEGMENTS` (`CV_SHOPPER_ID`, `ATTRIBUTE_ID`, `ATTRIBUTE_VALUE_ID`) + brand-scoped variant `CV_R_SHPR_BRAND_CUSTOM_SEGMENTS` | **Present**, EAV-style — confirms the ingestion interface's named columns collapse into a generic `(shopper, attribute, value)` triple physically; onboarding ETL must resolve `Segment_ID`/`Segment_Value_Code` against `CV_R_ATTRIBUTES_MASTER` (attribute master) rather than loading them as literal columns. |
| Effective_From | `CV_R_SHPR_CUSTOM_SEGMENTS.CREATION_TIMESTAMP` / `UPDATE_TIMESTAMP` | **Present**, but semantics differ — these are audit timestamps, not business-effective-dating fields; confirm whether "Effective_From" in the feed should map here or is a distinct requirement. |

## 7. Attributes Metadata feed

| Interface field | Physical target | Status |
|---|---|---|
| Attribute_Type, Attribute_Code, Attribute_Value_Code/Description | `CV_R_ATTRIBUTES_MASTER` (+ `_PERMISSIONS`, `_VALUES_MASTER` family) — `ATTRIBUTE_CATEGORY` (S=Shopper/P=Product), `ATTRIBUTE_SUB_CATEGORY` (D/G/L/B/F), `ATTRIBUTE_TYPE` (N/O/I), `ATTRIBUTE_VALUES_TYPE` (U/M) | **Present** — confirms the generic attribute-metadata mechanism is real and shared across Shopper and Product attribute types. |

---

## Summary of Gaps

| # | Gap | Severity |
|---|---|---|
| 1 | Store hierarchy: no Banner/Format/Channel/Geo-named columns; must be loaded as `HIERARCHY_TYPE` rows in `CV_R_STORES_TREE` with an undefined type-to-name convention. | Medium — blocks store-feed ETL design until convention is confirmed. |
| 2 | Product hierarchy level-to-name mapping (which tree level = Section vs. Department) not defined in DDL. | Medium |
| 3 | UPC and Private_Label_Flag not confirmed present on the product table as read so far. | Low/Unconfirmed — needs a follow-up targeted read. |
| 4 | No Household_ID, Join_Date, Year_of_Birth, Gender, or Accumulated_Points column found on `CV_R_SHPR_DESCRIPTION`. | Medium/High — needs a follow-up targeted read before ruling this a true gap vs. an unread table. |
| 5 | `CV_R_SHPR_IDENTIFYING_CARD` is not historized (no Effective_From/To) — card-reassignment history not modeled. | Medium |
| 6 | **No atomic Tlog/sales/transaction table in any of the 3 schemas reviewed** — lives in an unsupplied SingleStore/Online schema. | **Blocking** — this is the core Insights fact feed. |

## Recap

- **Entities/KPIs affected:** Store hierarchy (`dim_store`), Product/Brand hierarchy
  (`dim_product_hierarchy`/`dim_brand`), Shopper master (`dim_customer`), Card bridge
  (`dim_card`), and the entire transaction-line fact (`fact_transaction_line`) underlying nearly
  every KPI in [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md).
- **Design decisions & rationale:** Mapped each onboarding-interface file to its real physical
  landing table rather than to the canonical model's abstraction names, so onboarding ETL design
  is grounded in what actually exists; flagged 6 explicit gaps rather than assuming coverage.
- **Data quality / privacy considerations:** No PII-specific new gap found beyond what's already
  logged in [11_Standard_Model_Gap_Analysis.md](11_Standard_Model_Gap_Analysis.md) §3; the
  missing Tlog table (gap #6) means no PII/consent posture can be assessed for that feed until
  its real schema is supplied.
- **Confidence:** High for gaps #1, #5, #6 (directly confirmed by grep/read against the provided
  DDL). Medium for #2, #4 (plausible gaps, but based on partial reads — recommend a follow-up
  pass reading the remainder of `cv-retailer-schema.sql` before treating as final). Low/Unconfirmed
  for #3 (flagged for verification, not yet ruled a gap).
