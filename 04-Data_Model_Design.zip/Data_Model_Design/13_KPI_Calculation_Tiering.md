# 13 — KPI Calculation Tiering (Tlog+Dim / Tlog+Exposure / Requires Modeling)

**Purpose:** Group every KPI catalogued in [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md)
**and** in the client-attached `Report_KPI_Dimension_Analysis.xlsx` KPI Catalog sheet (43 KPIs total —
04's 31 KPIs A1–F9, plus an additional G1–G11 "Campaign Media & Supporting" series not yet present in
04) into 3 build tiers, based strictly on what data class is *sufficient* to compute it:

> **Correction note (added after initial publication):** the first version of this file only covered
> the 31 KPIs in 04_KPI_Lineage_and_Formulas.md and omitted the G1–G11 series that exists in the
> client-supplied `Report_KPI_Dimension_Analysis.xlsx` (companion to
> [Report_KPI_Dimension_Analysis_Summary.md](../Report_KPI_Dimension_Analysis_Summary.md), which
> explicitly flags the "43 vs 31" KPI-count gap in its §5/Next-Steps section). G1–G11 are added below
> and should also be back-filled into 04 as a follow-up (see Recap).

- **Tier 1 — Tlog + Dimension/Reference-master data only.** Pure retail-performance arithmetic:
  transaction-line facts (revenue, quantity, promo flag, store, product, date) joined only to
  reference-master dimensions (store hierarchy, product/brand hierarchy, shopper master, calendar).
  No campaign/media/exposure data of any kind is required.
- **Tier 2 — Tlog + Exposure/Campaign-audience data, straightforward arithmetic.** Requires an
  exposure/audience artifact (impression log, reachable/exposed audience roster, campaign cost) in
  addition to (or, for pure media metrics, instead of) Tlog — but the calculation itself is a direct
  ratio/sum, not a statistical model.
- **Tier 3 — Requires modeling/statistical methodology from our side.** Cannot be computed by any
  direct formula from source data alone; requires us to design and implement a control-group/matching
  methodology, a significance test, or resolve a genuinely undefined formula before any number can be
  produced.

This tiering is a **build-sequencing and dependency-risk view**, not a replacement for
[04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md)'s per-KPI lineage — every row below
cites its source KPI ID and confirmation status from that file. **Note the current, critical blocker
from [12_Client_Feed_Onboarding_Mapping.md](12_Client_Feed_Onboarding_Mapping.md) §5: no atomic Tlog
table has actually been supplied in any of the 3 reviewed physical schemas** (`CV_Retailer` /
`CV_Campaigns` / `CV_RetailerRprt`). Every Tier 1 and Tier 2 KPI below is therefore **blocked on that
same missing dependency**, independent of its own formula-confirmation status — this is flagged once
here rather than repeated per row.

---

## Tier 1 — Tlog + Dimension data only (no exposure/campaign data required)

| KPI ID | KPI | Formula (per 04) | Base data required | Formula status |
|---|---|---|---|---|
| A1 | Revenue (CA) | `Σ(line_revenue)` | Tlog line + store/product/shopper/calendar dims | CONFIRMED |
| A2 | Units (UVC) | `Σ(quantity)` | Tlog line + dims | CONFIRMED |
| A3 | Transactions (Nb de paniers) | `COUNT(DISTINCT transaction_id)` | Tlog header + dims | CONFIRMED |
| A4 | Customers (Nb de clients) — retail variant | `COUNT(DISTINCT customer_id)` w/ qualifying purchase | Tlog + shopper master | CONFIRMED (concept); non-additive across scopes |
| A5 | Revenue per Customer | `CA / Nb de clients` | A1 + A4 | CONFIRMED |
| A6 | Frequency (Fréquence) | `Nb de paniers / Nb de clients` | A3 + A4 | CONFIRMED |
| A7 | Avg Basket (Panier moyen) | `CA / Nb de paniers` | A1 + A3 | CONFIRMED |
| A8 | Units per Basket | `UVC / Nb de paniers` | A2 + A3 | CONFIRMED |
| A9 | Avg Price (Prix moyen) | `CA / UVC` | A1 + A2 | CONFIRMED |
| B1 | Promo Revenue/Unit Share | `CA promo / CA total` | Tlog line promo flag + product dim | INFERRED (eligibility rule) |
| B2 | Numeric/Value Distribution (DN/DV) | `Selling Stores / Total Stores` | Tlog (selling stores) + store dim (total stores) | CONFIRMED (DN); UNVERIFIED (DV, never defined) |
| B3 | Cardholder Rate | `CA encartés / CA total` | A1 variants + shopper dim (card flag) | INFERRED |
| C1 | Evolution % | Period-over-period delta of any base KPI | Any Tier-1 KPI, 2 periods | CONFIRMED |
| C2 | Evolution (pts) | Percentage-point delta | Any Tier-1 ratio KPI, 2 periods | CONFIRMED |
| C3 | Ecart vs Benchmark | `Evolution%(item) − Evolution%(benchmark)` | C1 + benchmark product-list scope | **UNVERIFIED formula** — Tier-1 data sufficiency, not Tier-3; only the exact math needs client confirmation |
| C4 | Indice (CA/UVC) | Indexed value vs. undefined base | A1/A2 + undefined reference value | **UNVERIFIED formula/base** — client confirmed base-~100 concept in principle (see 04 §C4), exact base still open |
| C5 | VMH (Vente Moyenne Hebdomadaire) | `CA / (selling stores × weeks)` (assumed) | A1 + store/calendar dims | **UNVERIFIED formula** |
| D1 | Market Share | `CA(brand) / CA(category)` | A1 at brand + category product-hierarchy dim | INFERRED |
| D2 | Share of Assortment | `COUNT(DISTINCT ean, brand) / COUNT(DISTINCT ean, category)` | Product master dim only — **no Tlog required at all** | CONFIRMED (defined in source) |
| D3 | Growth Contribution | `ΔCA(brand) / ΔCA(category)` | A1 deltas, 2 periods, brand/category dim | INFERRED |
| E1 | Customer gain/loss/constant | Classification rule over per-customer purchase history, 2 periods | Tlog (per-customer, per-period) + shopper dim + product scope | CONFIRMED (rule); UNVERIFIED (reconciliation) |
| E2 | Délai Interachat | `AVG(days between consecutive purchases)` per cardholder | Tlog (per-customer purchase dates) + shopper dim | CONFIRMED (definition); UNVERIFIED (averaging method) |
| G3 | E-commerce Share of Turnover | `Revenue(e-commerce)/Revenue(total)`, brand vs. category, +pts | A1 filtered by channel dim, brand vs. benchmark category product dim | DERIVED_AND_VALIDATED |
| G6 | Unit Price Validation (Min/Max Unit Price QA) | `MIN/MAX(unit_price)` per SKU | Tlog line (per-transaction unit price) + product/SKU dim — QA/supporting measure, not client-facing | NOT_APPLICABLE (QA, not a KPI formula) |
| G8 | Segment Population Share % — *retail variant only* | `COUNT(DISTINCT customer WHERE segment=X) / COUNT(DISTINCT customer)` | Shopper dim + segment-assignment dim (no exposure group filter) | INFERRED |
| G10 | Ecart vs Constants | `segment_value − constants_value` for same metric/period | A5/B1 (Tier-1 KPIs) + customer-movement-type dim, single-period snapshot | INFERRED |
| G11 | Revenue/Unit Share by Segment, Region or Channel | `A1/A2 (cut) / A1/A2 (total scope)`, plus period-over-period `(evol.)` variant | A1/A2 + segment/region/channel dim | INFERRED |

**Tier 1 dependency note:** All 25 KPIs above need only the atomic Tlog fact plus reference-master
dimensions (store, product/brand, shopper, calendar, segment assignment) — **no exposure, audience, or
campaign-cost data of any kind.** This is the largest tier (~58% of the full 43-KPI catalogue) and is
the correct build priority once the Tlog gap (12_Client_Feed_Onboarding_Mapping.md §5) is resolved,
since none of these require any new statistical methodology from us.

---

## Tier 2 — Tlog + Exposure/Campaign-audience data (direct arithmetic, no lift modeling)

| KPI ID | KPI | Formula (per 04) | Base data required | Formula status |
|---|---|---|---|---|
| F1 | Conversion Rate | `Shoppers / Exposable group` | Tlog (Shoppers = A4 variant, purchased) + exposure/audience roster (Exposable group) | CONFIRMED |
| F2 | Reach / Reach Rate | `Analysed Reach / Reachable` | Exposure/impression log only — **no Tlog required** | INFERRED |
| F3 | Impressions / Frequency (media) | `Impressions / Reach` | Exposure/impression log only — **no Tlog required** | INFERRED |
| F4 | CPM | `(Campaign Cost / Impressions) × 1000` | Campaign cost + Impressions (F3) — **no Tlog required** | INFERRED |
| F8 | Loyal Shopper Rate | `COUNT(loyal shoppers ≥2/>2 receipts) / COUNT(total shoppers)` | Tlog (receipt count per shopper) + campaign audience roster | CONFIRMED (concept); **discrepant threshold** (">2" vs "≥2", see 04 §F8) |
| F9 | New/Returning Shopper | `Total = New + Returning`; `New Rate = New / Total` | Tlog (purchase history, lookback) + campaign audience roster | CONFIRMED (identity); **UNVERIFIED/BLOCKING lookback window** |
| G1 | Clicks | `SUM(click_count)` | Ad-platform click log only — **no Tlog required** | NOT_APPLICABLE (atomic ad-platform metric; NOT AVAILABLE as a datasheet, deck-slide value only) |
| G2 | Exposable Group / Audience Size (Reachable) | `COUNT(DISTINCT audience_member_id)` | Audience-building/segment-membership data only — **no Tlog required**; denominator of F1 | INFERRED |
| G4 | Audience Affinity Index (Percentage of Sales) | Per-SKU per-audience A1/A2/A4 share vs. audience's own baseline share | Tlog (per-SKU revenue/qty/shopper) + audience/exposure assignment | INFERRED; exact baseline formula undocumented |
| G5 | Media Cost Efficiency (Cost per Receipt/Shopper) | `Campaign Cost / A3` or `/ A4` | Campaign cost (exposure/campaign data) + Tlog (A3/A4) | INFERRED |
| G7 | Cumulative Metric (Running Total) | `SUM(daily value) OVER (ORDER BY date)`, running | Daily A1/A2/A4/F2 values — Tlog *or* exposure log depending on underlying KPI; classified here since its primary use (Sales Impact Evolution) runs on Reach/Shoppers in a campaign context | DERIVED_AND_VALIDATED (mechanics); depends on underlying KPI's own tier |
| G8 | Segment Population Share % — *Exposed vs. Control balance-check variant* | Same formula as Tier-1 G8, but scoped by exposure group | Shopper/segment dim + campaign group-assignment (exposure) data | INFERRED |
| G9 | Exposed vs Non-Exposed Behaviour Share | A1/A2/A4 filtered by `exposure_group`, plus each group's % share | Tlog (A1/A2/A4) + campaign group-assignment (exposure) data | DERIVED_AND_VALIDATED |

**Tier 2 dependency note:** F2/F3/F4/G1/G2 are pure media metrics and, notably, require **no Tlog
data at all** — only the exposure/impression log, click log, and campaign cost, none of which has been
supplied as physical DDL either (no `CV_Campaigns` table carries an impression-level exposure log, a
click log, or a campaign cost field — this is the same CF-008 "no retail-media exposure interface in
standard product" finding already logged in
[11_Standard_Model_Gap_Analysis.md §5](11_Standard_Model_Gap_Analysis.md)). F1/F8/F9/G4/G5/G8(exposed
variant)/G9 need both Tlog *and* an audience/exposure roster to scope "who was exposed." None of these
13 require control-group matching or significance testing — they are direct counts/ratios once both
data classes exist. **G7's tier is conditional on its underlying KPI** — flagged rather than forced
into one bucket, since the same cumulative pattern applies to both Tier-1 (Revenue/Quantity) and
Tier-2 (Reach) base metrics.

---

## Tier 3 — Requires modeling/statistical methodology from our side

| KPI ID | KPI | Why it's Tier 3 | Status (per 04) |
|---|---|---|---|
| F5 | Incremental Revenue/Quantity/Shoppers/Buyer Rate (Lift) | `Exposed_X − Adjusted_Control_X` — the "Adjusted" step (control-group selection, matching/propensity-weighting method) is not documented anywhere in source; this is a methodology we must design, not a formula we can read off a report | **UNVERIFIED/BLOCKING** |
| F6 | ROAS | `Incremental Revenue / Campaign Cost` — inherits F5's unresolved control-group methodology in its numerator | **UNVERIFIED/BLOCKING** (inherits F5) |
| F7 | P-Values (Statistical Significance) | Requires us to select and implement a significance-test type (t-test, bootstrap, etc.) against Exposed vs. Control distributions — never documented in any source file; also requires a defined multiple-comparisons policy given the `Is Multisegment Resampled` flag | **UNVERIFIED/BLOCKING** |

**Tier 3 scope note:** These 3 KPIs are the entire "incrementality/lift" family. They are the only
KPIs in the full catalogue that cannot be resolved by *any* amount of additional source-document
review or client-provided formula — they require us to actively design the control-group construction
and statistical-testing approach (per this agent's core measurement-methodology mandate), and every
downstream KPI that depends on F5 (i.e., F6) inherits the same blocking status. This is also the
single area where the **deterministic vs. modeled/aggregate distinction (CF-007/CF-008)** is most
consequential: whichever control-group design we choose must be explicitly labeled as such in every
KPI output, not presented as equivalent-rigor to the Tier 1/2 deterministic counts.

---

## Summary counts

| Tier | Count | KPI IDs |
|---|---|---|
| Tier 1 (Tlog + dim only) | 25 | A1–A9, B1–B3, C1–C5, D1–D3, E1–E2, G3, G6, G8(retail), G10, G11 |
| Tier 2 (Tlog + exposure, direct arithmetic) | 13 | F1, F2, F3, F4, F8, F9, G1, G2, G4, G5, G7(conditional), G8(exposed), G9 |
| Tier 3 (requires modeling from us) | 3 | F5, F6, F7 |
| Not yet classified / excluded | 2 | A4 is counted once under Tier 1 (retail variant); the campaign-context "Shoppers" reading of A4 used inside F1/F8/F9/G-series is folded into those Tier-2 rows, not double-counted |

All 43 KPI entries across [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md) (31: A1–A9,
B1–B3, C1–C5, D1–D3, E1–E2, F1–F9) and the client-attached `Report_KPI_Dimension_Analysis.xlsx` KPI
Catalog's additional G1–G11 series (12 rows; G8 is split across Tier 1/Tier 2 depending on whether it
is scoped to a retail segment or an Exposed/Control campaign comparison, hence 12 G-series appearances
for 11 unique G-IDs) are accounted for above with no omissions.

---

## Recap

- **Entities/KPIs affected:** All 43 KPIs across [04_KPI_Lineage_and_Formulas.md](04_KPI_Lineage_and_Formulas.md)
  (31: A1–F9) and `Report_KPI_Dimension_Analysis.xlsx`'s KPI Catalog sheet (+12: G1–G11, G8 split
  across two tiers); cross-referenced against the Tlog gap in
  [12_Client_Feed_Onboarding_Mapping.md §5](12_Client_Feed_Onboarding_Mapping.md) and the missing
  exposure-interface finding in [11_Standard_Model_Gap_Analysis.md §5](11_Standard_Model_Gap_Analysis.md).
- **Design decisions & rationale:** Tiering is based on *minimum sufficient data class*, not on
  current formula-confirmation status — a KPI with an UNVERIFIED formula (e.g. C3–C5, G4) is still
  Tier 1/2 if the only open question is arithmetic detail, not a missing data source; only F5–F7
  require us to build new statistical methodology, so they remain the sole Tier 3 members even after
  adding the G-series. G7 (Cumulative Metric) is flagged as tier-conditional rather than forced into
  one bucket, since it is a generic running-total pattern applied to both Tier-1 and Tier-2 base KPIs.
- **Data quality/privacy considerations:** Every Tier 1/2 KPI is currently blocked by the same
  physical-schema gap (no atomic Tlog table supplied) — this blocks measurement work generally, not
  just incrementality. The G-series adds no new PII surface beyond what A1–F9 already touch (same
  shopper/segment/audience fields); GDPR/consent handling requirements from prior files apply
  identically once Tlog and exposure-log access is granted.
- **Confidence level:** High for the Tier 1/Tier 2/Tier 3 assignment of each KPI (grounded directly in
  04's and the attached workbook's per-KPI required-base-fields entries). Medium for the exact formula
  within several rows (C3–C5, D3, G4, G8, G10 — all flagged INFERRED/UNVERIFIED in source) and for
  G7's tier-conditional classification, which is a judgment call rather than a source-stated fact.
  **Follow-up recommended:** back-fill the G1–G11 series into 04_KPI_Lineage_and_Formulas.md itself
  (currently only 04 lacks them; this file and the attached workbook now agree) so the two catalogues
  no longer diverge in KPI count.
