# Retail Media — document set, version 2

Rebuilt after the Unlimitail workshop and the segment-export epics. The change that runs through
all of it: **this extends an integration that is already live**, rather than proposing one from a
blank page. Segment export to the vendor CDP runs on a schedule today.

| # | Document | What changed |
|---|---|---|
| 1 | PRD | Rewritten. Opens from what exists; adds the three-step export change, multi-banner markets, the control-group decision as open, and what can be claimed per channel |
| 2 | Value narrative | Phases unchanged; adds what the new findings change for each, and a summary of what moved since v1 |
| 3 | Phased delivery plan | Starts from the live integration; names the export epics as the critical path into phase 2, and lists four sequencing risks |
| 4 | Interface specification | The eight handshakes, field level, both directions, with the joins and their floors — for the data team, who have not reviewed it yet |
| 5 | Discrepancy log | **New.** Internal inconsistencies (ours to fix) separated from external differences (raised, not conceded) |
| 6 | Implementation plan | Updated ground rules, build order, quality gates, and open engineering questions |
| 7 | Integration deck | **New.** For the Unlimitail meeting: handshakes, what we send, what we need back, five disagreements, eight questions |
| — | KPI catalogue | Unchanged from v1 |
| — | Console prototype | Unchanged from v1 |

## What the new findings changed, in one place
- **The integration model is settled**: we push membership. Loyalty id today; segment id, banner
  and country next; control flag after that.
- **The CDP is Mediarithmics**, and the join key is the **universal shopper id**.
- **Control is exported as a flag**, not withheld from the feed — which contradicted v1 of the PRD
  and is now recorded as internal inconsistency I-1.
- **Multi-banner markets break "one retailer per deployment"**: one shopper, several identifiers,
  banner as a dimension.
- **Cross-segment control assignment is out of scope** in the platform epics — the contamination
  risk is named rather than assumed solved.
- **Walled gardens return no customer-level exposure**, so some channels can answer phase 1
  questions and never phase 2 ones.
- **The segment id must return on exposure data** — the highest-value ask, and without it phase 2
  is blocked for paid media regardless of the control mechanism.
