# Retail Media — Implementation Plan

Engineering companion to the PRD v2.0. Scope: one retailer per deployment, with multi-banner
support. Phase 1 only is in scope for build; later phases are designed here so that phase 1 does
not foreclose them.

**This extends a live integration.** Segment export to the vendor CDP already runs on a schedule
today, carrying loyalty identifiers. Three export changes are scoped as platform epics and are the
critical path into phase 2: the Activate segment id, banner and country for multi-banner markets,
and the control group flag.

---

## 0. Ground rules

1. **Tiers degrade independently.** A tier 3 failure must never take down tier 0. Enforce with
   separate pipelines, separate tables, separate schedules.
2. **Vendor figures are ingested, never recomputed.** They land in their own table, keep the
   vendor's name and window, and never overwrite ours.
3. **Never train on vendor attribution.** It encodes their assumptions; training on it reproduces
   them.
4. **No exposed-versus-unexposed comparison, ever.** Add it to the code-review checklist. It is
   computable and it is wrong — it measures selection, not effect.
5. **One timezone convention globally.** They publish local-timezone twins of most facts. Pick UTC
   or local, document it at the top of the repository, never mix.
6. **Channel travels on every record** — offer, delivery event, redemption, exposure. It is a
   first-class dimension, not a reporting attribute added later.
7. **Banner travels with identity** in multi-banner markets. A shopper may hold several
   identifiers; de-duplication is an open risk, not a solved problem.

---

## 1. Repository layout

```
/docs/retail-media/          PRD, interface spec, phasing, discrepancy log, this plan
/prototype/                  console prototype
/ingest/
  /vendor/                   BigQuery share extraction
  /retailer/                 transaction log + offer-state return file
  /planning/                 assignment, offer registry, segment snapshots
/conform/                    key mapping, currency, timezone, dimension snapshots
/marts/                      rm_* tables
/metrics/                    KPI definitions as code, one module per family
/quality/                    reconciliation, match rates, alerting
/models/                     phase 2 and later only; empty in phase 1
/api/                        read API for the console
/console/                    front end
```

---

## 2. Build order for phase 1

| # | Step | Done when |
|---|---|---|
| 1 | Identity mapping and match-rate publication | Match rate is a daily metric with an alert floor, not a one-off check |
| 2 | Transaction log ingest with line-level margin | Margin reconciles to the retailer's own finance view |
| 3 | Offer-state return ingest | Rows exported and rows returned reconcile exactly; suppressions marked |
| 4 | Vendor warehouse extraction | Exposure, spend, attribution and dimensions land daily; dimensions snapshotted |
| 5 | The three-way join | A single row carries exposure, redemption and margin for one shopper |
| 6 | Metric families as code | Every figure computable independently by two people to the same answer |
| 7 | Console read API and screens | Tier labelling visible on every figure |

Nothing in this list requires a model. That is the point of phase 1.

---

## 3. What phase 1 must not foreclose

- **The assignment table.** Even if control assignment is not yet agreed, the schema and the write
  path should exist, so the first measured campaign is not blocked on plumbing.
- **Segment id on exposure.** Model the join now; leave it null until the vendor returns it.
- **Banner and country dimensions.** Carry them through the marts from day one, even where only one
  market is live.
- **Tier separation in storage.** Vendor and own results in separate tables from the first row
  written.

---

## 4. Quality gates that run daily

| Check | Floor | On breach |
|---|---|---|
| Identity match rate | 95% | Shopper-level metrics marked, not published |
| Product match rate | 99% | Exposure cannot be tied to sales; flag the affected campaigns |
| Export / return reconciliation | 100% | Rate metrics suppressed for the affected feed |
| Feed freshness | daily | Previous snapshot stands; no metric published on a partial day |
| Dimension snapshot | daily | Historical reporting is rebuilt from snapshots, not from current versions |

---

## 5. Open engineering questions

1. Which cloud are we on, and does that force the service-account route for the warehouse share?
2. Who owns the daily dimension snapshot, and where does it land?
3. Is the shopper hash stable across systems and over time? A rotating hash breaks every
   longitudinal metric silently.
4. Can the retailer's channel systems produce event rows rather than a final status?
5. What is the retention policy for exposure and assignment data? Both are needed long after a
   campaign ends.
6. How is a shopper with several banner identifiers represented in the marts — one row or several?
