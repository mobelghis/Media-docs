# The six helpers, and how they pass work to each other

Think of it as six people sitting in a row. The numbers come in one end and a
finished deck comes out the other. Each person has one job and hands their work
to the next.

```
   measurement tables
           |
           v
  [1] SCOUT        looks at every slice, lists anything unusual        no AI
           |              → about 50 candidates
           v
  [2] SKEPTIC      tries to prove each one wrong                       no AI
           |              → about 25 survive, graded: stands up / directional
           |                 each killed one keeps its reason
           v
  [3] EDITOR       picks about nine, drops repeats, puts them in order  no AI
           |              → 9 chosen
           |
           |  ===== THE GATE: only what is chosen gets words =====
           v
  [4] ADVISOR      works out what to do, with the money       sums in code,
           |                                                  wording by AI
           v
  [5] EXPLAINER    says it in one sentence                    AI, 9 calls
           |
           v
  [6] COMPOSER     decides which share a slide                AI, 1 call
           |
           v
     the deck
```

**The order matters more than it looks.** Writing sentences before the Editor has
chosen means paying for about 50 of them and throwing away 41. Running the
Editor first takes the bill down by roughly 80% and changes nothing else. See
`TOKEN_BUDGET.md`.

---

## Who does what kind of work

| Helper | Arithmetic | AI writing | Why |
|--------|-----------|------------|-----|
| Scout | all of it | none | Finding things is counting, not writing. |
| Skeptic | all of it | none | A rule that an AI could talk its way around is not a rule. |
| Editor | the choosing | the headline | Choosing is scoring; the headline is a sentence. |
| Advisor | the sums | the suggestion | We work out the money; the AI puts it in the right tone. |
| Explainer | none | all of it | This is purely wording. |
| Composer | none | the layout decisions | It never sees a number, only shapes and sizes. |

---

## What gets passed along

Everything that moves between helpers is a **finding**. One finding is one thing
worth saying. Its exact shape is in `contracts/finding.schema.json`. In words, a
finding holds:

- **what kind it is** — "one slice is far ahead of the others", "we delivered
  more than we sold", "the biggest audience is the weakest"
- **what it is about** — which breakdown, which slice, which number
- **the numbers** — the value, what it is being compared with, how far apart
  they are, how many buyers sit behind it
- **how much we trust it** — a score, a grade (stands up or directional), and
  anything the Skeptic made us admit
- **the words** — the sentence and the suggestion, once those helpers have run
- **the picture** — which chart to draw and how to cut it

A finding is never thrown away. One the Skeptic kills keeps its reason and shows
up on the "what was set aside" panel. One a person removes goes to the archive.
Both can be looked at later.

The Skeptic grades rather than only killing. A finding with 310 buyers behind it
is **directional** — it can be said, with its thinness printed next to it —
rather than silenced. A campaign too small for anything to stand up on its own
still gets a report; it just gets an honest one.

---

## The rule that holds the whole thing up

> **The computer counts. The AI writes.**

Every number in the finished deck can be traced to a database query. The AI is
handed finished, formatted numbers and asked only to say them well.

To make sure this stays true, there is a check after every AI call: take all the
numbers out of what the AI wrote and compare them to the numbers we sent it. If
there is one we did not send, throw the sentence away and use the plain template
instead.

That check is what lets us put the deck in front of a brand's own analyst.
