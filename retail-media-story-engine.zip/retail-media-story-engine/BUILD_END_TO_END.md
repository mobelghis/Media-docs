# Build it end to end

A working order. Each step is useful on its own and can be shown to someone.
Do not start a step until the one before it works.

Open `architecture.html` in a browser alongside this — it is the same thing as a
picture.

---

## Before you start: four decisions

Nothing below works until these are settled. They are product decisions, not
engineering ones.

1. **Whose branding does the deck carry** — the retailer's or the supplier's?
2. **Who sets the Skeptic's thresholds** — us, or each client? Stricter is
   fine; looser should need a conversation.
3. **Do we get planned spend and planned impressions?** Without them, half the
   delivery findings and everything about cost and return cannot exist.
4. **Does the walled-garden partner return anything beyond totals?** This decides
   how much of the product exists at all for those campaigns.

---

## Step 1 — The numbers layer

**What you are building.** One query engine that answers: *give me these
measures, split by these things, for these filters.* Nothing else in the product
works without it, and everything else is thin on top of it.

**What it must support.**

- About 20 measures (`rules/measures.md`)
- About 12 ways of splitting them: campaign, ad group, ad, audience, placement,
  banner, purchase channel, creative, category, product, UPC, week
- Filters on date range, campaign, ad group, ad
- Rates and ratios recalculated at each row's own grain — **never averaged from
  the rows below.** A ROAS column that averages campaign ROAS is wrong and
  somebody will notice.

**The one thing to get right.** Attributed buyers are de-duplicated inside a
campaign and **do not add up across campaigns**. A shopper reached by two
campaigns is one buyer in each. Either you build shopper-level de-duplication,
or the product refuses to print a combined buyer figure. It must never quietly
add them.

**Done when.** You can ask it for sales by UPC by week for two campaigns and the
answer ties to the warehouse.

---

## Step 2 — The program page

**What you are building.** The page people land on. One sentence of state, three
numbers, the decomposition, and a campaign list sorted by what needs attention.

**The triage rules** — this is the part that earns daily use:

| Reason | How it is worked out |
|---|---|
| Behind plan | delivered share of planned impressions, against the share of the flight elapsed, under 0.8 |
| Over-delivering | the same ratio over 1.45 — we eat that cost |
| Window closed, report due | the campaign has ended and the attribution window has closed |
| Ends this week | the flight ends within seven days |
| Partner file only | the campaign is a walled garden |

**The decomposition.** Every step is a measured quantity:

```
All brand sales by the shoppers we reached, inside the window
  − the part we cannot link to any ad
  = Attributed sales
      split by  after a click  /  after a view only
      split by  direct (promoted products)  /  halo (the brand's other products)
      split by  new or lapsed buyers  /  buyers already buying the brand
```

Baseline, cannibalisation, pull-forward and true incremental are **not drawn** —
not as bars, not as dotted outlines. They need a hold-out group. Say so once, in
words, with a button to request one on the next flight.

**Done when.** Someone opens it in the morning and knows what to do first.

---

## Step 3 — Explore

**What you are building.** The same query engine, a pivot table.

**The pattern that matters.** Nobody can read 57 columns. So:

- **Named metric sets**, capped at eight columns, saved and shared. Ship presets:
  core, growth, efficiency, basket, direct and halo.
- **A row detail panel** — click a row, see every measure for that one row,
  vertically, each with its definition.
- **The export carries everything**, whatever is on screen.

The line to hold: *the screen is for deciding, the export is for auditing.*

**Done when.** An analyst stops asking you for extracts.

---

## Step 4 — The Scout and the Skeptic

**No AI in this step.** Findings come out as plain data and you check them by
hand against the warehouse.

**The Scout** runs the query engine across every breakdown and every measure that
makes sense for it, and lists anything notable. About 50 candidates from about
100 slices. Full detail in `agents/01-scout.md`.

**The Skeptic** grades every one. Rules and thresholds in
`rules/skeptic-rules.md`. Three outcomes, not two:

- **Stands up** — 400+ buyers behind it, clear of the runner-up by the required
  gap
- **Directional** — 150 to 400 buyers, or clear of the runner-up by 60–100% of
  the required gap. Can be said, with its thinness printed next to it.
- **Not reportable** — below those floors. Killed, with the reason kept.

**Do not move on** until the Skeptic is killing the right things. Test it on your
smallest campaign and your largest. This step decides whether anyone trusts the
product.

**Done when.** You can show someone the list of rejections and they agree with
every one.

---

## Step 5 — The campaign brief

**What you are building.** The screen between the campaign list and the story.
Its job: *turn a campaign into a brief, and show enough to make the brief an
informed one.*

In order:

1. **A verdict sentence** — what happened, in one line, with the window on it
2. **The brief** — document type and audience, as chips. Not "renewal pitch"
   and "honest review": **mid-flight review, end-of-campaign review, planning
   input.** Chosen by purpose, printed on the cover and every footer, not
   removable.
3. **Readiness** — five or six lines, each with a tick or a gap. Including the
   one that matters: *no control group, so nothing here can say the ads caused
   the sales.*
4. **Delivery against outcome**, side by side
5. **The decomposition** for this campaign
6. **The drill chart** — campaign → ad group → ad
7. **A sign-off, and one button.** The Build button stays disabled until a
   person ticks that they have read the readiness block.

**Done when.** Nobody can get from a table row to a supplier-facing narrative
without a human looking at the data first.

---

## Step 6 — The Editor, then the words

**Order matters here, for cost.** The Editor runs **before** anything is written.
It chooses nine from the twenty-five that survived. Only those nine ever get a
sentence.

Then, in parallel:

- **Explainer** — three sentence options per finding, three different angles, not
  three rewordings
- **Advisor** — the recommendation, in the document type's tone. The money sum is
  done in code first; the AI only words it.

**The check that must exist.** Pull every number out of what the AI wrote and
compare it with what you sent. A number you did not send means the sentence is
discarded and a plain template is used. Not optional.

**Every sentence needs a template behind it** that reads acceptably. That is both
the fallback when the model is slow or wrong, and what lets the product work at
all if the AI is unavailable.

**Done when.** You can unplug the AI and the product still produces a readable
report.

---

## Step 7 — The story screen

**What you are building.** The findings as a readable argument.

- Chapters as section headings, cards beneath
- **Numbers rendered as locked tokens inside the editable sentence.** A person
  can type around them and not over them. This is what turns "the computer
  counts, the AI writes" from a claim into a property of the screen.
- The recommendation last, with the money inline
- Caveats as one small line, not a box
- One line above everything: *"9 findings told. 43 set aside — see what was set
  aside."* That disclosure is the best trust signal in the product.
- **Do not show the internal role names** to the end user. Scout, Skeptic and
  Editor belong in this repository, not in the header of a client-facing screen.

**Done when.** Someone reads it top to bottom and knows what to recommend.

---

## Step 8 — The Composer and the deck

**The Composer** decides which findings share a page. It is handed titles,
chapters, chart sizes and whether each finding can be said in a single number —
**never the numbers themselves**.

The rule it works to: a slide holds one chart and up to two supporting numbers.
A finding that can be said in one number rides along the bottom of another page
instead of taking one. Nine findings become about six slides.

**Then plain code writes the file.** Native PowerPoint — real text boxes, real
tables, vector charts, the retailer's master. Not pictures of charts.

Every slide gets the source line automatically: population, campaign, flight,
window, method, where the numbers came from, maturity, the document type, and
the word *attributed*.

**Done when.** The exported file opens in PowerPoint and a person can edit a word
without the layout breaking.

---

## Step 9 — Templates and the archive

**The archive.** Nothing is ever deleted. A finding a person removes keeps its
time and goes back exactly where it was. The Skeptic's kills are kept too.

**Templates.** Save a report shape — these findings, these cuts, this order —
and reuse it. *This is where two days becomes twenty minutes.* Everything before
this step makes a good report; this step makes the next one nearly free.

---

## What to watch once it is live

- **Cost per report**, broken down by stage, from day one (`TOKEN_BUDGET.md`)
- **How often the number check fires.** Often means the prompt is wrong.
- **How often people edit the generated sentence.** Always means the Explainer
  is wrong. Never means nobody is reading it.
- **How often people reorder findings.** Often means the Editor is wrong.
- **Whether anyone still rebuilds charts in PowerPoint after exporting.** If they
  do, something in the product is missing and they will tell you what.

---

## The two rules that survive every change of plan

1. **The computer counts. The AI writes.** No figure in the product comes from a
   language model.
2. **Nothing is silently deleted or silently claimed.** Every kill keeps its
   reason, every number carries where it came from, and nothing that needs a
   control group is estimated without one.
