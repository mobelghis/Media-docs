# Keeping the AI bill small

Written in plain words. The short version: **most of this product should never
call an AI at all**, and the parts that do should be handed small, finished
pieces of work.

---

## 1. Why this matters more than it looks

A retailer runs about 400 campaign reports a year. If every report made one AI
call per finding, and the engine raises 50 candidates per campaign, that is
20,000 calls a year — before anyone presses "rebuild" or changes the document
type, which people will do three or four times per report.

Done carelessly, this is the kind of feature that works beautifully in the demo
and then shows up as a line item nobody can defend. Done the way below, the AI
cost of a full report is roughly the price of a cup of coffee, and most of it is
cached.

---

## 2. The first rule: only pay for what gets said

The pipeline raises about 50 candidate findings. The Skeptic kills about half.
The Editor uses about 9.

**Write sentences only for the 9.** Not the 50, not the 25 that survived.

| Where you call | Calls per report | Cost |
|---|---|---|
| Every candidate the Scout raises | ~50 | the naive version |
| Everything that survives the Skeptic | ~25 | still half wasted |
| **Only what the Editor chose** | **~9** | **what to build** |

This single ordering decision — run the Editor *before* the Explainer, not after
— cuts the bill by about 80%. It costs nothing to implement. It is just the
order the stages run in.

The evidence screen needs titles for the rejected findings, but those come from
templates, not from an AI. A rejected finding never earns a written sentence.

---

## 3. The second rule: send the finding, not the campaign

The temptation is to hand the model the whole campaign and ask for a story. That
is expensive, slow, and produces numbers nobody can trace.

Send one finding, already worked out and already formatted:

```
finding type:      one slice is far ahead of the others
breakdown:         audience segment
slice:             health-snack buyers
measure:           attributed buyer conversion rate
value:             0.81%
campaign average:  0.25%
multiple:          3.2x
gap:               +0.55 pts
buyers behind it:  4,333
```

That is about **120 tokens in**. Asking for one sentence under forty words is
about **60 tokens out**. Nine findings, sentence and recommendation each, is
roughly **3,200 tokens per report**.

Compare with sending the campaign's breakdowns and asking for a narrative:
easily 15,000 tokens in, and every number in the answer needs checking.

---

## 4. The third rule: cache the parts that do not change

Four things in every call are identical every time:

- the instructions for that role
- the house style examples
- the glossary of what each measure is called and must never be called
- the rules about never inventing a number

That is the biggest part of the prompt and it never varies. Put it in the cached
part of the request. Most providers bill cached input at a fraction of fresh
input, so after the first report of the day the fixed part is close to free.

Order every prompt the same way: **fixed instructions first, then the one
finding.** If the fixed part moves around, nothing caches.

---

## 5. The fourth rule: match the model to the job

Not every call needs the same model.

| Call | What it is | Model |
|---|---|---|
| Explainer — one sentence from given numbers | mechanical rewriting | the small fast one |
| Advisor — one recommendation in a given tone | mechanical rewriting | the small fast one |
| Editor — the headline | one line, needs judgement | mid |
| Composer — the slide plan | a few decisions about shape | mid |

Nine small calls and two mid calls per report. No large-model call anywhere in
the normal path.

If a sentence comes back failing the number check (see below), retry **once** on
the mid model. If it fails again, use the template and move on. Never loop.

---

## 6. The fifth rule: run the nine in parallel

The nine Explainer calls do not depend on each other. Fire them together. The
report is then as slow as the slowest single sentence, not the sum of nine.

Expect the whole run to take two to four seconds — the arithmetic stages finish
in well under a second, and the AI stages are one parallel burst, then the
headline, then the layout.

---

## 7. The sixth rule: do not pay twice for the same report

People press "rebuild" and change the document type. Three or four times per
report is normal.

- **Changing the document type does not change a single number.** It changes
  which findings are chosen and how firmly recommendations are worded. So the
  *sentences* can be reused as they are. Only the recommendations and the
  headline need rewriting — about three calls, not eleven.
- **Key the cache on the finding, not the report.** A finding's identity is its
  type, its slice, its measure, and the measurement run it came from. Same key,
  same sentence, no call.
- **A person's edit wins forever.** Once somebody has rewritten a sentence,
  never regenerate it. Not on rebuild, not on document-type change, not on
  re-export.

With these three, the second and third builds of the same report cost almost
nothing.

---

## 8. What it adds up to

Rough shape for one full report, nine findings:

| Stage | Calls | In | Out |
|---|---|---|---|
| Explainer (3 sentence options × 9) | 9 | ~1,100 | ~1,600 |
| Advisor | 9 | ~900 | ~700 |
| Editor headline | 1 | ~250 | ~30 |
| Composer layout plan | 1 | ~400 | ~250 |
| **Total** | **20** | **~2,650** | **~2,580** |

Of the input, roughly three quarters is the fixed instruction block, which
caches. The variable part — the actual findings — is a few hundred tokens.

A rebuild after changing the document type costs about a fifth of that.

---

## 9. The checks that stop runaway spend

Put these in before launch, not after the first invoice.

1. **A hard ceiling per report.** If a report somehow wants more than 30 calls,
   stop and use templates for the rest. Log it. Something is wrong upstream.
2. **No call without a finding.** If the Editor chose nothing, there is nothing
   to write. A campaign too small to say anything about should cost nothing.
3. **One retry, never a loop.** A failed number check retries once on a better
   model, then falls back to the template.
4. **Cost per report on a dashboard**, broken down by stage, from day one. The
   moment a prompt grows, you will see it.
5. **Templates for everything.** Every sentence the AI writes must have a plain
   template behind it that reads acceptably. That is not only a cost control —
   it is what keeps the product working when the model is slow, down, or
   returning something that fails the check.

---

## 10. The thing not to do

Do not build this as one big call that takes the campaign and returns the deck.

It is cheaper per report on paper, and it costs you the product: you cannot
trace a number, you cannot show which findings were rejected and why, you cannot
reuse a sentence a person edited, you cannot cache anything, and the first time
a supplier's analyst checks the arithmetic, you have no answer.

Small calls, finished numbers, cached instructions, checked output.
