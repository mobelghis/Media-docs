# Retail Media Story Engine — the whole box

This folder has everything needed to start building. Read the files in this order.

| # | File | What it is |
|---|------|------------|
| 1 | `architecture.html` | **Open this first.** One picture of the whole system, and where the AI money goes. Open it in a browser. |
| 2 | `BUILD_END_TO_END.md` | The working order. Nine steps, each useful on its own, with what "done" means for each. |
| 3 | `IMPLEMENTATION_PLAN.md` | The fuller plan in plain words — what we are building, what runs where, what we feed the AI. |
| 4 | `TOKEN_BUDGET.md` | How to keep the AI bill small. The one ordering decision that cuts it by 80%. |
| 5 | `AGENTS.md` | How the six helpers work together, from raw numbers to a finished deck. |
| 6 | `agents/*.md` | One file per helper. These are the actual instruction files. Paste each into the system prompt of its own AI call. |
| 7 | `rules/skeptic-rules.md` | The rules that decide whether a finding may be said out loud. Numbers included. |
| 8 | `rules/measures.md` | Every number the product can show, and what it must never be called. |
| 9 | `contracts/*.json` and `contracts/api.md` | The shape of what moves between the parts, and the endpoints. For the back-end team. |
| 10 | `prototype/index.html` | The working prototype. Open it in a browser. No install needed. |

## The one-line version

The computer finds what is interesting in a campaign and proves it is real.
The AI puts it into words a person would use, and lays it out on slides.
Nobody can type over a number.

## What changed in this version

- **The order of the six helpers changed.** The Editor now chooses *before*
  anything is written, so only the nine findings that get said are ever paid
  for. That one change cuts the AI bill by about 80%.
- **The Skeptic grades instead of only killing** — stands up, directional, not
  reportable — so a small campaign gets an honest short report instead of
  silence.
- **The goal selector became a document type** — mid-flight review,
  end-of-campaign review, planning input — chosen by purpose and printed on
  every page, after a supplier-side reviewer called the old labels the most
  damaging thing in the product.
- **A decomposition replaced the incrementality waterfall.** Every step in it is
  counted; the four steps that need a hold-out group are named in words and not
  drawn.
- **New-to-brand and lapsed buyers were brought forward** from the deferred
  list. It is the only growth question attribution can answer without a
  hold-out, and both reviewers asked for it first.

---

## The one rule that must never be broken

**The computer counts. The AI writes.**

If an AI is ever allowed to work out a number, the first client who checks our
arithmetic will find a mistake, and we will lose the account. Every figure in
this product comes out of a database query. The AI is handed the finished
numbers and asked only to say them well.
