# The Skeptic's rule book

These are the rules that decide whether a finding is allowed to be said out
loud. They are the most important configuration in the product.

---

## Rule 1 — Enough behind it

| Test | Threshold | Why |
|---|---|---|
| Attributed buyers behind the slice | **400** | Below this, one unusual week moves the number. |
| Impressions behind the slice | **250,000** | Below this, delivery noise dominates. |

**Message shown when it fires:**

> Only 180 attributed buyers behind this slice — under the 400 we need before
> calling a difference real.

**Why it matters:** in the prototype this is the rule that kills the fake
winner. "Recipe video" has the best click rate of any creative in the campaign
and only 180 buyers behind it. Without this rule, every campaign would come
with a brilliant creative recommendation based on noise.

---

## Rule 2 — Clear of the pack

A leader is only a leader if it is clear of the **runner-up**, not just of the
average. And the more slices we examined, the further clear it has to be,
because more looking means more chances to be fooled.

```
gap required = 0.10 + 0.02 × log2(number of slices examined)
```

| Slices examined | Gap required |
|---|---|
| 20 | 19% |
| 50 | 21% |
| 97 | **23%** |
| 200 | 25% |

**Message shown when it fires:**

> Premium breakfast sits only 2% clear of the next audience (health-snack).
> Across 97 slices examined, a leader needs to be 23% clear before we call it a
> difference.

**Why the runner-up and not the average:** with only three or four slices in a
breakdown, the average is pulled around by the very slice we are testing. The
gap to the next one is steadier and, more useful still, a category manager can
understand the sentence.

---

## Rule 3 — Our data or theirs

If a finding needs shopper-level detail and the campaign is a walled garden
that returns totals only, it dies.

**Message shown when it fires:**

> This needs shopper-level detail. The partner returns totals only, so the
> number cannot be stood behind.

Findings about impressions, clicks and click rate survive, because the partner
does report those.

---

## Rule 4 — Missing inputs

No planned spend or planned impressions means no plan-versus-actual finding, and
no cost or return findings either.

**Message shown when it fires:**

> No planned spend or impressions were supplied for this campaign.

---

## Rule 5 — The window is still open (an admission, not a kill)

If the attribution window has not closed, the finding survives but travels with
a line:

> The 14-day window is still open on the last 2 weeks, so this figure can still
> rise.

---

## Rule 6 — A sum that rests on an assumption (an admission, not a kill)

The reallocation finding assumes the stronger audience holds its rate on extra
money. That assumption is printed on the slide:

> The reallocation figure assumes the stronger audience holds its rate on extra
> budget. It is smaller than this audience's current reach, so that is
> reasonable — but it is an estimate, not a promise.

---

## Who may change these

- **Making them stricter** — fine, let a client do it.
- **Making them looser** — should need a conversation. A client who wants the
  minimum buyer count dropped to 50 is asking us to help them mislead
  themselves.
- **Turning them off** — never.
