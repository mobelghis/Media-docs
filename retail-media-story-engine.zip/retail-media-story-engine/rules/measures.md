# Every number the product can show

Taken from the Phase 1 KPI catalogue. The naming matters: the words in the
"never call it" column have been retired because they promise more than the
number delivers.

---

## What we count

| Number | What it means | Never call it |
|---|---|---|
| Impressions | Ads actually shown | — |
| Estimated impressions | Ads we said we would show | — |
| Delivery multiplier | Actual ÷ planned impressions | — |
| Clicks | Valid clicks | — |
| Click-through rate | Clicks ÷ impressions | — |
| Media spend | What the brand paid | — |
| CPM | Spend per thousand ads shown | — |
| Exported shoppers | Shoppers we successfully sent for activation | — |
| Targeted shoppers | Shoppers the partner picked to target | — |
| Exposed shoppers | Shoppers with a qualifying exposure | — |
| Reached shoppers | Shoppers who saw at least one ad | **Reach** |
| Media frequency | Impressions ÷ reached shoppers | — |
| Exposable shoppers | Shoppers available for activation | **Exposable audience** |

## What they bought

| Number | What it means | Never call it |
|---|---|---|
| Attributed buyers | Shoppers who bought inside the window after seeing an ad | **Shoppers** |
| Attributed buyer conversion rate | Attributed buyers ÷ exposable shoppers | **Conversion rate** |
| Attributed sales | Sales credited by the attribution rule | **Revenue** |
| Attributed transactions | Baskets credited | **Transactions** |
| Attributed units | Units credited | — |
| Attributed sales per buyer | Sales ÷ buyers | **Revenue per shopper** |
| Purchases per buyer | Transactions ÷ buyers | **Purchase frequency** |
| Average attributed transaction | Sales ÷ transactions | **Average basket value** |
| Attributed units per transaction | Units ÷ transactions | **Items per basket** |
| Average attributed price per unit | Sales ÷ units | **Average price per product** |
| Repeat buyers | Buyers with two or more transactions in the window | **Loyal shoppers** |
| Repeat buyer rate | Repeat buyers ÷ all buyers | **Loyal shopper rate** |

## What it cost and returned

| Number | What it means |
|---|---|
| Attributed ROAS | Attributed sales ÷ media spend |
| Cost per attributed buyer | Spend ÷ buyers |
| Cost per attributed transaction | Spend ÷ transactions |
| Attributed margin | Margin on the credited sales |

## Who they were

| Number | What it means |
|---|---|
| Buyer share | Share of buyers in a profile group |
| Category buyer share | The same share among category buyers |
| Buyer share difference | Campaign share minus category share, in points |
| E-commerce attributed sales share | Share of credited sales bought online |
| E-commerce share difference | Campaign share minus category share, in points |
| Average and median time to purchase | Hours from the winning event to the purchase |

## Can we trust it

| Number | What it means |
|---|---|
| Result maturity | Preliminary, maturing, final or restated |
| Shopper identity match rate | Records we could resolve to a shopper |
| Campaign ID recognition rate | Partner rows we could map to a campaign |
| Product mapping rate | Product codes we could map |
| Attribution eligibility rate | Purchase lines with at least one eligible event |
| Attribution link creation rate | Eligible lines that got a final link |
| Late-arriving data rate | Records that arrived after the cut-off |

---

## Three words that never appear in Phase 1

**Incremental.** **Lift.** **Halo.**

All three need a group of shoppers deliberately held back from seeing the
campaign, decided before it starts. Until we have that, we measure what
*followed* the ads, not what the ads *caused*, and every slide says
**attributed**.

Four shopper groups are also deferred until their methods are approved:
control shoppers, new-to-brand buyers, new-to-category buyers, loyal buyers.
They appear nowhere in the product — not greyed out, not "coming soon", simply
absent, so nobody promises a brand something we cannot deliver.
