# How to build the Retail Media Story Engine

Written in plain words. No knowledge of our systems needed to follow it.

---

## 1. What problem we are solving

When a retail media campaign ends, somebody on our team opens a reporting tool,
copies numbers into PowerPoint, draws the charts again by hand, writes the
commentary, and emails the deck to the brand so they will book again.

It takes a day or two for every campaign. We run hundreds.

We are going to make the product do the boring parts — finding what matters,
drawing the charts, writing the first draft of the words, and laying out the
slides — so a person only has to do the part that needs a person: deciding what
to recommend.

---

## 2. What we are building, in four pieces

**Piece 1 — The program page.**
A list of all the campaigns for one brand, with filters at the top (dates,
campaign, ad group, ad). One chart shows where the money and the sales came
from, and you can click into it to go deeper: program → campaign → ad group →
ad. Each campaign has a button that says "build the deck".

**Piece 2 — The deep dive page.**
A big table. You choose which things go down the side (campaign, product, UPC,
week, audience, anything) and which numbers go across the top. You can sort it,
filter it, and download it. This is for the analyst who wants to check something
themselves.

**Piece 3 — The story.**
Press "build the deck" on a campaign and six helpers go to work. They look at
every slice of the campaign, throw away the ones that are not real, and come
back with about nine things worth saying — each one with a chart, a sentence,
and a suggestion for what to do next. A person can edit any sentence, remove
anything, and change the goal of the report.

**Piece 4 — The deck.**
The findings get laid out on slides. Not one per slide — the layout helper
decides which ones can share a page, so ten findings become six good slides
instead of ten half-empty ones. Then it exports to PowerPoint or PDF.

---

## 3. The six helpers

Each one is a separate step with one job. Full instructions for each are in the
`agents/` folder. Here is what they do in one line each.

| Helper | Job | Who does the work |
|--------|-----|-------------------|
| **Scout** | Look at every slice of the campaign and list anything unusual. | Computer |
| **Skeptic** | Try to prove each one wrong. Kill the ones that do not survive. | Computer |
| **Advisor** | Work out what to do about it, with the money attached. | Computer does the sums, AI writes the suggestion |
| **Explainer** | Say it in one sentence a brand manager would use. | AI |
| **Editor** | Pick the best nine, drop the repeats, put them in order, write the headline. | Computer picks, AI writes the headline |
| **Composer** | Decide which findings share a slide and what each page is called. | AI decides layout, computer places it |

Notice that four of the six are mostly arithmetic. **Only the wording and the
layout choices use AI.** That is on purpose, and it is the most important design
decision in the whole product.

---

## 4. Which part runs where

### The back end (the part the user never sees)

Built in whatever we already use — Python or Node, it does not matter.

**4.1 The numbers layer.**
One query engine over the measurement tables. It must be able to answer:
"give me these numbers, split by these things, for these filters." Everything
else is built on this one ability. The product has about fifteen numbers and
about twelve ways to split them (see `rules/measures.md`).

**4.2 The Scout and the Skeptic.**
Plain code. No AI. The Scout runs the query engine many times — once per way of
splitting the campaign, per number — and produces a list of candidates. The
Skeptic walks that list and marks each one as kept or killed, with a written
reason. The rules and the exact thresholds are in `rules/skeptic-rules.md`.

**4.3 The Advisor's sums.**
Plain code. When one audience is big and weak and another is small and strong,
the Advisor works out what moving some budget would have been worth, using the
rates each audience actually achieved. The formula is in the Advisor's file.

**4.4 The AI calls.**
Three places only:
- turning a finding into a sentence (Explainer)
- turning a finding into a suggestion (Advisor)
- deciding the slide layout (Composer)

Each is a separate call with its own instruction file from the `agents/` folder.
Each one is handed finished numbers and is forbidden from doing arithmetic.

**4.5 The deck builder.**
Takes the Composer's layout plan and writes a real PowerPoint file. Use a
library that makes native shapes — real text boxes, real tables, real vector
charts — not pictures of charts. The brand's team must be able to nudge a word
in PowerPoint without the deck falling apart.

**4.6 Storage.**
Three small tables of our own:
- **stories** — one row per deck, holding the goal, the chosen findings, the
  order, and any sentence a person edited
- **archive** — every finding a person removed, with the time and the reason, so
  nothing is ever lost
- **templates** — a saved order of findings, so next quarter's deck for the same
  brand assembles itself

### The front end (the part the user sees)

A normal web app. Five screens: program, deep dive, story, evidence, deck. Plus
the archive.

The important front-end rule: **the numbers arrive from the back end already
formatted and already final.** The front end does not calculate. If a percentage
has to be worked out, the back end works it out. This keeps the screen and the
PowerPoint and the database saying the same thing.

---

## 5. What we feed the AI, exactly

This is the part teams usually get wrong, so here it is in detail.

### For the Explainer (writing a sentence)

We send it:
- the finding's type (for example "one audience is far ahead of the others")
- the numbers, already worked out and already formatted — `0.81%`, `€4,896`,
  `3.2×`
- what each number is called
- the name of the thing it is about ("health-snack buyers")
- what it is being compared with, and that comparison's number
- the campaign's window and whether the result is final
- a few example sentences in our house style

We do **not** send it:
- raw table rows
- anything it would have to add up, divide, or round
- the whole campaign — just the one finding

We ask it for one sentence, under forty words, with every number exactly as we
gave it.

Then we check: if a number comes back that we did not send, we throw the
sentence away and use a plain template instead. This check is not optional.

### For the Advisor (writing a suggestion)

Same idea. We do the sum first — "moving €4,896 would have produced about 1,378
more buyers" — and ask the AI only to turn it into a recommendation in the right
tone for the chosen goal.

### For the Composer (laying out slides)

We send it a short list: each finding's title, which chapter it belongs to, how
big its chart is, and whether it can be said in a single number. We ask it which
ones should share a page, which layout to use, and what to call each page.

We do **not** send it the numbers at all. It is deciding furniture, not content.

---

## 6. The three honesty rules, built in

These are not nice-to-haves. They are why a brand will believe the deck.

**Rule 1 — Say where every number came from.**
Some campaigns run on our own shelf, where we can match an ad to a real
purchase, shopper by shopper. Others run inside Meta or a similar platform,
which sends back totals and nothing else. These are not the same quality of
answer and must never be added together. Every number carries a label:
*measured by us* or *reported by the partner*.

**Rule 2 — Say when the result is not finished.**
A shopper has fourteen days after seeing an ad to buy. So for two weeks after a
campaign ends, the sales figure is still going up. Every number carries its
state — preliminary, maturing, or final — and the deck says today's figure is a
floor, not a verdict.

**Rule 3 — Never claim the ads caused the sales.**
This phase measures what *followed* the ads. Proving what the ads *caused*
needs a group of shoppers we deliberately hold back, decided before the campaign
starts. Until we have that, the word "incremental" never appears, and the word
"attributed" appears on every slide.

---

## 7. What to build first

Each step is useful on its own. Do not start the next one until the last one
works.

**Step 1 — The numbers layer and the program page.**
One query engine, one screen with filters and a drillable chart, and the
campaign list. At the end of this step a person can already answer "how is the
program doing" without opening a spreadsheet.

**Step 2 — The deep dive.**
The same query engine, a different screen. Cheap to build once step 1 is done,
and it buys goodwill with analysts immediately.

**Step 3 — The Scout and the Skeptic.**
No AI yet. Findings come out as plain data and we check them by hand against the
numbers. Do not move on until the Skeptic is killing the right things — this is
the step that decides whether the product is trustworthy.

**Step 4 — The Explainer and the Advisor.**
Add the AI wording. Keep a plain template as a fallback for every sentence, and
use it whenever the check in section 5 fails.

**Step 5 — The story screen and the evidence screen.**
Let a person read the story, edit the sentences, remove things, and see
everything that was rejected and why.

**Step 6 — The Composer and the PowerPoint.**
Layout and export. Last, because everything before it has to be right first.

**Step 7 — Templates and the archive.**
Save a report shape and reuse it. This is where the two days become twenty
minutes.

---

## 8. How we will know it worked

- A campaign report takes **under half an hour** instead of a day or two.
- Most reports are built from a **saved template**, which means teams have
  agreed what a good report says.
- Brands ask **better questions** in renewal meetings, because the method is
  printed on the page.
- Nobody exports to PowerPoint and then rebuilds the charts anyway. If that is
  still happening, something in the product is missing.

---

## 9. Things to decide before building

1. **Whose branding does the deck carry** — the retailer's or the brand's? If
   each retailer needs their own master, it becomes a per-client asset somebody
   has to own.
2. **Is the story about one campaign or the whole program?** The prototype
   assumes one campaign, reached from a program page.
3. **Do we have planned spend and planned impressions?** Without them, the
   plan-versus-actual slide and everything about cost and return cannot be
   built.
4. **Does the walled-garden partner return anything beyond totals?** This
   decides how much of the report exists at all for those campaigns.
5. **Who sets the Skeptic's thresholds** — us, or each client? The prototype
   uses 400 buyers and a 23% gap. Letting clients loosen them is dangerous;
   letting them tighten them is fine.
