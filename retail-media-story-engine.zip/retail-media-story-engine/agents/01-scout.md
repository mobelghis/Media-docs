# Agent 1 — The Scout

**Runs as:** plain code. No AI call.
**Gets:** one campaign, and the filters the user has set.
**Gives back:** a list of candidate findings, usually 40 to 60.

---

## Its job in one line

Look at every slice of the campaign from every angle, and list anything that
looks unusual. Do not judge any of it — that is the next person's job.

---

## What it looks at

For each way of splitting the campaign (audience, ad group, ad, placement,
banner, purchase channel, product, creative) and for each number that makes
sense for that split, it works out the value for every slice and compares it
with the campaign average.

It also looks at a handful of whole-campaign things:

| What | What it is looking for |
|------|------------------------|
| Plan against actual | Did we deliver more or fewer impressions than we sold? Was the price per thousand better or worse than planned? |
| Against other campaigns | Is the click rate, conversion rate, cost per buyer or repeat rate ahead of or behind comparable campaigns? |
| The funnel | Where is the biggest drop between exported, targeted, reached and bought? |
| Size against performance | Is the biggest audience also the weakest one? This is the most valuable finding we can produce. |
| Against the category | Is the online share of sales higher than the category's? Do buyers look different from category buyers? |
| Timing | How long do shoppers take to buy, against the length of the window? |
| Data quality | Is any check below its floor? |
| Maturity | Is the window still open? This one is always raised and never dropped. |

---

## What it writes down for each candidate

- the kind of finding
- which split and which slice
- which number
- the value, and the campaign average it is being compared with
- **how far apart they are**, as a fraction of the average
- **how clear of the runner-up it is** — the gap to the next slice, as a
  fraction of that slice. This matters more than the gap to the average.
- how many attributed buyers and how many impressions sit behind it
- a weight, between about 0.6 and 1.3, for how much this kind of finding
  usually matters commercially
- how many slices were examined in total, so the Skeptic knows how many chances
  there were to find something by luck

---

## Rules

1. **Never judge.** A slice with four buyers gets listed like any other. The
   Skeptic kills it later, and the kill is written down for the evidence screen.
2. **Raise both ends.** For every split, raise the best slice and the worst one.
   A weak slice is where the money should move from.
3. **One concentration finding per split.** If one slice holds most of the
   sales, say so once, not once per number.
4. **Always raise maturity.** If the window is open, that finding exists, and
   nothing is allowed to kill it.
5. **Count the slices.** Pass the total count along. Looking at 97 slices gives
   97 chances to be fooled, and the Skeptic needs to know that.
