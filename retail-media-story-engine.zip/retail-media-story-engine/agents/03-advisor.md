# Agent 3 — The Advisor

**Runs as:** plain code for the sums, then one AI call for the wording.
**Gets:** a finding that survived the Skeptic, and the goal of the report.
**Gives back:** the same finding with a suggestion attached.

---

## Its job in one line

Turn "this happened" into "so do this", and put a number on it wherever we
honestly can.

---

## The sum it does itself (no AI)

The most valuable suggestion we can make is moving budget from a weak audience
to a strong one. The arithmetic is simple and must be done in code:

```
spend on an audience   = its share of impressions  ×  total campaign spend
buyers per euro        = its attributed buyers     ÷  its spend
money moved            = weak audience spend       ×  the share being moved (30%)
extra buyers           = money moved × (strong buyers per euro − weak buyers per euro)
extra sales            = extra buyers × the strong audience's sales per buyer
```

Worked example from the prototype:

- breakfast cereal took **€16,320** of media and returned **0.283** buyers per euro
- health-snack took **€7,680** and returned **0.564** buyers per euro
- moving 30% of the weak audience's budget — **€4,896** — gives
  **4,896 × (0.564 − 0.283) ≈ 1,378 more buyers**

This figure must always travel with its assumption: it supposes the stronger
audience keeps its rate on more money. That is reasonable when the money moved
is small next to the audience's existing reach, and it must be said on the
slide.

---

## The AI call

**System prompt:**

> You write the recommendation line in a retail media measurement report, for a
> retailer's team to send to a brand.
>
> You will be given one finding with its numbers already worked out. Write one
> sentence saying what to do about it.
>
> Rules:
> - Use only the numbers given to you. Never work out a new one.
> - Every finding gets a recommendation, including bad news. A weak result is
>   where the money should move from, not something to hide.
> - Never say why something happened. You do not know whether it was the
>   creative, the price or the weather.
> - Start with the phrase you are given for the goal.
> - Under forty words.

**What we send:**

```
goal:            renewal pitch | honest review | ask for more budget
opening phrase:  "We recommend" | "Worth considering" | "We would push for"
finding type:    the biggest audience is the weakest one
weak audience:   breakfast cereal buyers, 0.14% conversion, €16,320 of media
strong audience: health-snack buyers, 0.81% conversion, €7,680 of media
the sum:         move €4,896 → about 1,378 more buyers, about €38k more sales
```

**What good looks like:**

> We recommend moving 30% of the breakfast cereal budget — about €4,896 — into
> health-snack. At the rates both audiences actually achieved, that is roughly
> 1,378 more buyers and €38k of attributed sales for the same total spend.

---

## Rules

1. **No finding without a recommendation**, including the unflattering ones.
2. **Never "no bad news".** Those are different things, and the second one is
   how a report loses its credibility with a brand's own analysts.
3. **The goal changes the tone, never the number.**
4. **No causes.** Say what happened, how much, against what, and what to do.
