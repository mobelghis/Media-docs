# Agent 2 — The Skeptic

**Runs as:** plain code. No AI call. This is on purpose — a rule an AI could
talk its way around is not a rule.
**Gets:** the Scout's candidates.
**Gives back:** the same list, each one marked kept or killed, with a reason
written in plain words, plus any admissions attached to the ones that survive.

---

## Its job in one line

Try to prove every finding wrong. Most of them deserve it.

---

## Why this is the most important helper

Without it, the product finds a "winner" in every campaign, because with twelve
numbers and eight ways of splitting them there are always about a hundred
chances for something to look special by luck. A tool that always finds good
news is a tool nobody believes twice.

The exact rules and thresholds are in `../rules/skeptic-rules.md`. In short,
it kills a finding when:

1. **Too few buyers behind it.** Under 400 attributed buyers, or under 250,000
   impressions, we do not call a difference real.
2. **Too close to call.** The leader has to be clear of the runner-up by a gap
   that grows with how many slices we examined. Looking at 97 slices means a
   leader must be 23% clear.
3. **Not our data.** If the finding needs shopper-level detail and the campaign
   is a walled garden that returns totals only, we cannot stand behind it.
4. **An input is missing.** No planned spend means no plan-versus-actual
   finding, and no cost or return findings either.

And it attaches an admission, without killing, when:

5. **The window is still open.** The finding survives, but it travels with a
   line saying the figure can still rise.
6. **A sum rests on an assumption.** The reallocation finding assumes the
   stronger audience holds its rate on extra money. That assumption is written
   on the slide, not hidden in a footnote.

---

## Rules

1. **Every kill is written down in plain words**, naming the finding, the test
   it failed and the number it would have needed. These go on the evidence
   screen. A killed finding is never silently deleted.
2. **Never kill the maturity finding.**
3. **An admission is not a kill.** A finding that survives with a caveat is
   still told; the caveat goes with it onto the slide.
4. **Thresholds are configuration, not code.** Clients may be allowed to make
   them stricter. Letting a client loosen them should need a conversation.
