# Agent 6 — The Composer

**Runs as:** one AI call for the layout decisions, then plain code to place
things and write the file.
**Gets:** the chosen findings — their titles, chapters, chart sizes, and whether
each can be said in a single number. **It never sees the numbers themselves.**
**Gives back:** a slide plan.

---

## Its job in one line

One finding per slide wastes half of every page. Decide which findings share a
page, which layout fits, and what each page is called.

---

## Why this helper exists

A chart takes the top two thirds of a slide. Underneath it there is room for two
more facts. If every finding gets its own page, a ten-finding report becomes ten
half-empty slides, and the brand's attention runs out before the recommendation
does.

In the prototype, nine findings become **six slides**, with five findings
riding along the bottom of a page as a number and a line instead of taking a
page of their own.

---

## The layouts

| Layout | When | What is on it |
|---|---|---|
| **Cover** | always first | campaign name, advertiser, channel, flight, window, products, audiences, ad groups and ads, budget and spend |
| **Hero** | the lead finding | one big chart, the sentence, the recommendation, at most one rider |
| **Chart with riders** | most slides | one chart that needs the width, plus one or two findings underneath as a big number and one line |
| **Pair** | two compact charts from the same chapter | two half-width charts side by side |
| **Method** | always near the end | the rules, in words: window, credit, who counts as a buyer, which products, where the numbers came from, maturity, and what is not claimed |
| **Actions** | always last | every recommendation collected in one list |

---

## The rules it follows

1. **A finding can only ride along if it can be said in one number.** The engine
   works out that number; the Composer only asks whether one exists.
2. **The opportunity never rides along.** It is the point of the deck and always
   gets a page.
3. **Prefer riders from the same chapter.** Two delivery facts under a delivery
   chart read as one thought. A shopper fact under a delivery chart reads as a
   jumble.
4. **Two riders is the maximum.** Three is a dashboard.
5. **Say why.** Every slide carries a note explaining why those findings share a
   page. The person can disagree and split them.

---

## The AI call

**System prompt:**

> You lay out slides for a retail media measurement report.
>
> You will be given a list of findings with their titles, chapters, chart sizes
> and whether each can be stated in a single number. Decide which share a page,
> which layout fits, and what each page is called.
>
> Rules:
> - You will not be given any numbers and you must not invent any.
> - A finding may only share a page as a supporting number if it is marked as
>   able to be said in one number.
> - Never put more than two supporting findings on a page.
> - Prefer grouping findings from the same chapter.
> - Give each page a short title in plain words.
> - For each page, say in one sentence why those findings belong together.

---

## Then plain code writes the file

Take the plan and build a real PowerPoint — native text boxes, native tables,
vector charts, the retailer's master. Not pictures of charts. The brand's team
has to be able to nudge a word without the deck falling apart.

Every slide gets the source line automatically: the population, the campaign, the
flight, the window, the method, where the numbers came from, the maturity, and
the word *attributed*.
