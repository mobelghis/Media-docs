# Agent 0 — The Orchestrator

**Runs as:** plain code. It is the conductor, not a thinker.

---

## Its job in one line

Run the six helpers in order, hold on to everything they produce, and never let
a failure in one of them break the whole report.

---

## The order

```
1. load the campaign and the filters
2. SCOUT      → ~50 candidates                     (code, fast)
3. SKEPTIC    → kept / killed / graded, with reasons (code, fast)
4. ADVISOR    → the money sums                     (code, fast)
5. EDITOR     → the chosen nine, in order          (code)
   ================ THE GATE ================
6. EXPLAINER  → 3 sentence options each            (AI, 9 calls, in parallel)
7. ADVISOR    → recommendations                    (AI, 9 calls, in parallel)
8. EDITOR     → the headline                       (AI, 1 call)
9. COMPOSER   → the slide plan                     (AI, 1 call)
10. build the deck                                 (code)
```

Steps 2 to 5 are pure arithmetic and should finish in well under a second.

**The gate at step 5 is the whole cost control.** Earlier drafts of this design
wrote sentences before the Editor chose, which meant paying for about 50 and
using 9. Choosing first cuts the bill by roughly 80% and changes nothing a user
sees. Steps 6 and 7 run in parallel, so a report takes two to four seconds
rather than the sum of eighteen calls.

---

## What it must handle

**An AI call fails or is slow.** Use the plain template sentence for that
finding and carry on. The report is never blocked by the wording.

**An AI returns a number we did not send.** Throw it away, use the template,
and log it. If this happens often, the prompt is wrong.

**A campaign has almost no data.** The Skeptic grades rather than silencing:
findings with between 150 and 400 buyers behind them come back as
**directional** and are told with their thinness printed next to them. Below
150, nothing is said at all. A small campaign gets an honest short report, not
silence — silence just moves the claim into the verbal part of the meeting where
there is no caveat at all.

**A walled-garden campaign.** Most findings get killed for provenance. That is
correct. Show what survives and list what could not be answered, with the
reason, so the brand can see exactly what moving budget onto our own channels
would buy them.

---

## What it keeps

Everything, forever:

- every candidate the Scout raised
- every kill and its reason
- every finding that survived but was not chosen, and why
- every sentence the AI wrote, and every edit a person made to it
  (a sentence a person has edited is never regenerated — not on rebuild, not on
  a change of document type, not on re-export)
- every finding a person removed, in the archive

Nothing in this product is ever silently deleted. That is what makes the
evidence screen possible, and the evidence screen is what makes the story
believable.
