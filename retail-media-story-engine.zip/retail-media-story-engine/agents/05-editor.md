# Agent 5 — The Editor

**Runs as:** plain code to choose, one small AI call for the headline.
**Gets:** every finding that survived the Skeptic, and the goal of the report.
**Gives back:** about nine findings, in order, plus the headline.

---

## Its job in one line

A list of true things is not a story. Pick the ones that make an argument, drop
the ones that repeat each other, and put them in the order a person would
actually say them.

---

## How it scores

Every surviving finding already has a score from the Scout and the Skeptic:

```
score = how far from the average  ×  how much we trust the base  ×  how much this kind of finding matters
```

The goal of the report then nudges those scores. It does **not** add or remove
anything the Skeptic allowed through.

| Goal | What goes up | What comes down | What always stays |
|---|---|---|---|
| Renewal pitch | good news ×1.45, the opportunity ×1.25 | bad news ×0.6 | the opportunity, the maturity note |
| Honest review | data quality problems ×1.5 | nothing | at least two genuinely negative findings |
| Ask for more budget | the opportunity ×1.9, the funnel leak ×1.55 | good news ×0.9 | the opportunity, the maturity note |

---

## How it chooses

1. Sort by the nudged score.
2. Walk down the list and take findings, skipping one if:
   - another finding about the same slice is already in
   - the story already makes this point
   - that chapter already has three
3. Make sure the goal's minimum of negative findings is met. If it is not, pull
   the strongest negative ones back in and mark them as forced.
4. Make sure the opportunity is in. Every story needs one thing to do next.
5. Add the maturity note. It always travels.
6. Sort into chapter order: what we bought → who bought → what it sold → who
   they are → how solid it is.
7. Move the goal's lead finding to the front. For a renewal pitch that is the
   best piece of good news; for a budget ask it is the opportunity.

---

## The headline

One small AI call, or a template. It is the one line the brand will remember.

- Renewal pitch → "Every €1 of media is linked to €4.70 of sales"
- Honest review → "€158k of sales on €33,600 of media — concentrated in two of four audiences"
- Ask for more budget → "The same budget, spent where it worked, was worth about 1,378 more buyers"

Same campaign, same numbers, three true headlines. That is the goal selector
doing its job.

---

## Rules

1. **Never hide a finding the Skeptic allowed through.** The goal reorders and
   reweights; it does not censor.
2. **Always keep the opportunity and the maturity note.**
3. **Nine is the ceiling.** More than that and nobody reads it.
4. **Say why each one was kept.** The evidence screen shows the score and the
   reason for every choice.
