# Agent 4 — The Explainer

**Runs as:** one AI call per finding.
**Gets:** one finding with its numbers already worked out and already formatted.
**Gives back:** one sentence.

---

## Its job in one line

Say the finding the way a brand manager would say it, with the numbers in it.

---

## The AI call

**System prompt:**

> You write one sentence for a retail media measurement report.
>
> You will be given a finding with its numbers already worked out and already
> formatted. Write one sentence that states it plainly.
>
> Rules:
> - Use only the numbers given to you, written exactly as given. Never work out
>   a new number, never re-round one, never change a currency or a unit.
> - Put the important numbers in bold, like **0.81%**.
> - Say what, how much, and against what. Never say why.
> - No jargon. A category manager is not a data scientist.
> - Under forty words. One sentence.

**What we send:**

```
finding type:      one slice is far ahead of the others
breakdown:         audience segment
slice:             health-snack buyers
measure:           attributed buyer conversion rate
value:             0.81%
campaign average:  0.25%
multiple:          3.2×
gap:               +0.55 pts
buyers behind it:  4,333
```

**What good looks like:**

> The **health-snack** audience converted at **0.81%** — **3.2×** the campaign
> average of 0.25%, **+0.55 pts** above it.

**What bad looks like, and why:**

| Bad sentence | What is wrong |
|---|---|
| "Health-snack converted at 0.8%" | Re-rounded a number we gave as 0.81%. |
| "Health-snack converted 3× better, around 4,300 buyers" | Changed 3.2× to 3× and 4,333 to "around 4,300". |
| "Health-snack did best, probably because the creative suited them" | Invented a cause. |
| "Health-snack showed superior conversion efficiency" | Jargon, and dropped the numbers. |

---

## The check that runs afterwards

Pull every number out of the sentence the AI wrote. Compare them with the
numbers we sent. If there is one we did not send, **throw the sentence away** and
use a plain template instead.

This is not optional and it is not a nice-to-have. It is the thing that lets us
put the deck in front of the brand's own analyst.

---

## Three sentences, not one

For each finding we ask for three different angles — not three rewordings of the
same angle. The person picks one and edits it. For a leading-slice finding, the
three are usually:

1. the leader against the campaign average
2. the biggest slice against its own performance (size versus quality)
3. what the top two add up to, and what the weakest one did
