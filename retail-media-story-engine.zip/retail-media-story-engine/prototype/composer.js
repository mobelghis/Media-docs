/* ==================================================================
   THE COMPOSER — the sixth role.
   Decides which findings share a page, which layout fits, what the
   page is called, and why they belong together. It places; it never
   computes. Every number on a slide came from the engine.

   The rule it works to: a slide has room for one chart and up to two
   supporting numbers. Leaving that space empty wastes a page, so a
   finding that can be said in one number rides along as a callout
   instead of taking a page of its own.
================================================================== */

const SMALL_CHARTS = ['paired', 'bignum', 'repeat', 'donut2', 'quality', 'daily'];
const chartSize = f => (f.chart && SMALL_CHARTS.includes(f.chart.k)) ? 'small' : 'large';

const CHAPTER_TITLES = {
  delivery: 'What we bought',
  conversion: 'Who bought',
  commerce: 'What it sold',
  shoppers: 'Who they are',
  method: 'How solid this is'
};

function compose(findings, c, goal) {
  const slides = [];
  const placed = new Set();
  const pool = findings.filter(f => f.chapter !== 'method');
  const methodFindings = findings.filter(f => f.chapter === 'method');

  /* ---- 1. cover ---- */
  slides.push({ layout: 'cover', findings: [], title: c.name, no: 1,
    reason: 'Every deck opens with what the campaign actually was, so nobody has to ask in the meeting.' });

  /* a finding can ride along as a callout if it can be said in one number */
  const canRide = f => !!f.stat && !f.opportunity && f.direction !== 'opportunity' && !f.isLead;

  /* take up to n callouts, preferring the same chapter, then anything left */
  function takeRiders(hostChapter, n) {
    const same = pool.filter(f => !placed.has(f.id) && f.chapter === hostChapter && canRide(f));
    const other = pool.filter(f => !placed.has(f.id) && f.chapter !== hostChapter && canRide(f));
    const picked = [...same, ...other].slice(0, n);
    picked.forEach(f => placed.add(f.id));
    return picked;
  }

  /* ---- 2. the lead takes the second page, with at most one rider ---- */
  const lead = findings.find(f => f.isLead && f.chapter !== 'method') || pool[0];
  if (lead) {
    placed.add(lead.id);
    const riders = takeRiders(lead.chapter, goal === 'budget' && lead.direction === 'opportunity' ? 0 : 1);
    slides.push({
      layout: 'hero', findings: [lead], riders, title: lead.title,
      reason: riders.length
        ? `The strongest finding opens the deck. ${riders.length === 1 ? 'One further number' : 'Two further numbers'} from the same part of the story sits underneath it rather than taking a page.`
        : (goal === 'budget' && lead.direction === 'opportunity'
          ? 'This is the ask, so nothing shares the page with it.'
          : 'The strongest finding opens the deck on its own.')
    });
  }

  /* ---- 3. the rest: one chart per page, riders fill the space below ---- */
  const order = ['delivery', 'conversion', 'commerce', 'shoppers'];
  let guard = 0;
  while (pool.some(f => !placed.has(f.id)) && guard++ < 40) {
    // the next unplaced finding whose chart deserves the page, in chapter order
    const remaining = pool.filter(f => !placed.has(f.id));
    const host = order.map(ch => remaining.find(f => f.chapter === ch && chartSize(f) === 'large'))
      .find(Boolean) || remaining[0];
    if (!host) break;
    placed.add(host.id);

    // a small-chart partner shares the page as a second chart; otherwise take number riders
    const partner = pool.find(f => !placed.has(f.id) && f.chapter === host.chapter && chartSize(f) === 'small');
    if (partner && chartSize(host) === 'small') {
      placed.add(partner.id);
      slides.push({
        layout: 'pair', findings: [host, partner], riders: takeRiders(host.chapter, 1),
        title: CHAPTER_TITLES[host.chapter],
        reason: `Both are ${CHAPTER_TITLES[host.chapter].toLowerCase()} findings with compact charts, so they share a page instead of leaving half of two pages empty.`
      });
    } else {
      const riders = takeRiders(host.chapter, 2);
      slides.push({
        layout: 'chartstats', findings: [host], riders, title: host.title,
        reason: riders.length
          ? `This chart needs the full width, so the ${riders.length === 1 ? 'next finding rides' : 'next two findings ride'} along the bottom as ${riders.length === 1 ? 'a number' : 'numbers'} instead of taking ${riders.length === 1 ? 'a page' : 'two pages'}.`
          : 'This chart needs the full width and nothing left fits beside it.'
      });
    }
  }

  /* ---- 4. method ---- */
  if (methodFindings.length) {
    slides.push({ layout: 'method', findings: methodFindings, riders: [], title: CHAPTER_TITLES.method,
      reason: 'The rules and the maturity belong together, in words rather than charts, and they travel with every deck.' });
  }

  /* ---- 5. the actions page ---- */
  const withReco = findings.filter(f => f.reco && f.chapter !== 'method');
  if (withReco.length) {
    slides.push({ layout: 'actions', findings: withReco.slice(0, 5), riders: [], title: 'What we would do next',
      reason: 'Every recommendation collected in one place, so the meeting ends with a list rather than a feeling.' });
  }

  slides.forEach((s, i) => { s.no = i + 1; });
  const riderCount = slides.reduce((n, s) => n + (s.riders ? s.riders.length : 0), 0);
  return {
    slides,
    stats: {
      findings: findings.length,
      slides: slides.length,
      riders: riderCount,
      shared: slides.filter(s => (s.riders && s.riders.length) || s.layout === 'pair').length,
      wouldHaveBeen: findings.length + 3
    }
  };
}
