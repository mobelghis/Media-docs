/* ==================================================================
   THE STORY ENGINE
   Five roles. Findings are detected by arithmetic; only the wording
   is written. No number in this file comes from language generation.
     SCOUT     finds every candidate worth a look
     SKEPTIC   tries to kill each one
     ADVISOR   turns survivors into a recommendation with a number
     EXPLAINER says it in one sentence
     EDITOR    picks, de-duplicates, orders, writes the headline
================================================================== */

/* ---------- formatters ---------- */
const F = {
  int: n => n == null ? '—' : Math.round(n).toLocaleString('en-GB'),
  compact: n => {
    if (n == null) return '—';
    if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 1 : 2).replace(/\.?0+$/, '') + ' M';
    if (n >= 1e3) return (n / 1e3).toFixed(n >= 1e5 ? 0 : 1).replace(/\.0$/, '') + ' K';
    return Math.round(n).toLocaleString('en-GB');
  },
  money: n => n == null ? '—' : '€' + Math.round(n).toLocaleString('en-GB'),
  moneyC: n => {
    if (n == null) return '—';
    if (n >= 1e6) return '€' + (n / 1e6).toFixed(2).replace(/\.?0+$/, '') + ' M';
    if (n >= 1e3) return '€' + Math.round(n / 1e3) + ' k';
    return '€' + n.toFixed(2);
  },
  money2: n => n == null ? '—' : '€' + n.toFixed(2),
  pct1: n => n == null ? '—' : n.toFixed(1) + '%',
  pct2: n => n == null ? '—' : n.toFixed(2) + '%',
  pct3: n => n == null ? '—' : (Math.abs(n) < 1 ? n.toFixed(2) : n.toFixed(1)) + '%',
  pts: n => n == null ? '—' : (n > 0 ? '+' : '') + (Math.abs(n) < 1 ? n.toFixed(2) : n.toFixed(1)) + ' pts',
  x: n => n == null ? '—' : n.toFixed(1) + '×',
  dec: n => n == null ? '—' : n.toFixed(1),
  hours: n => n == null ? '—' : Math.round(n) + ' h'
};
const shortName = s => s.replace(/ buyers$/, '').replace(/ · sponsored$/, '').replace(/^Nordmark /, '').replace(/ Granola.*$/, '');

/* ---------- metric definitions on a breakdown ---------- */
const METRICS = {
  convRate:    { label: 'conversion rate',        short: 'Conversion rate',       fmt: F.pct3,   kind: 'rate',  needs: 'shopper', get: (r, T) => r.exposable ? r.buyers / r.exposable * 100 : null, total: T => T.convRate },
  ctr:         { label: 'click-through rate',     short: 'Click-through rate',    fmt: F.pct2,   kind: 'rate',  needs: 'media',   get: r => r.impressions ? r.clicks / r.impressions * 100 : null,  total: T => T.ctr },
  buyers:      { label: 'attributed buyers',      short: 'Attributed buyers',     fmt: F.int,    kind: 'count', needs: 'shopper', get: r => r.buyers,  total: T => T.buyers },
  sales:       { label: 'attributed sales',       short: 'Attributed sales',      fmt: F.moneyC, kind: 'count', needs: 'shopper', get: r => r.sales,   total: T => T.sales },
  salesPerBuyer:{label: 'sales per buyer',        short: 'Sales per buyer',       fmt: F.money2, kind: 'rate',  needs: 'shopper', get: r => r.salesPerBuyer, total: T => T.salesPerBuyer },
  avgTxn:      { label: 'average transaction',    short: 'Average transaction',   fmt: F.money2, kind: 'rate',  needs: 'shopper', get: r => r.avgTxn,  total: T => T.avgTxn },
  salesPerK:   { label: 'sales per 1,000 ads',    short: 'Sales per 1,000 ads',   fmt: F.money2, kind: 'rate',  needs: 'shopper', get: r => r.impressions ? r.sales / r.impressions * 1000 : null, total: T => T.sales / T.impressions * 1000 },
  cpBuyer:     { label: 'cost per buyer',         short: 'Cost per buyer',        fmt: F.money2, kind: 'rate',  needs: 'shopper', lowerBetter: true,
                 get: (r, T) => r.buyers ? (r.impressions / T.impressions * T.spend) / r.buyers : null, total: T => T.cpBuyer },
  impressions: { label: 'impressions',            short: 'Impressions',           fmt: F.compact, kind: 'count', needs: 'media', get: r => r.impressions, total: T => T.impressions },
  newShare:    { label: 'new-to-brand share',     short: 'New-to-brand share',    fmt: F.pct1,   kind: 'rate',  needs: 'shopper', get: r => r.buyers ? (r.newBuyers + r.lapsedBuyers) / r.buyers * 100 : null, total: T => T.newShare },
  cpNewBuyer:  { label: 'cost per new or lapsed buyer', short: 'Cost per new buyer', fmt: F.money2, kind: 'rate', needs: 'shopper', lowerBetter: true,
                 get: (r, T) => (r.newBuyers + r.lapsedBuyers) ? (r.impressions / T.impressions * T.spend) / (r.newBuyers + r.lapsedBuyers) : null, total: T => T.cpNewBuyer }
};
const spendOf = (r, T) => r.impressions / T.impressions * T.spend;

/* ---------- chapters ---------- */
const CHAPTERS = {
  delivery:   { n: 1, label: 'What we bought' },
  conversion: { n: 2, label: 'Who bought' },
  commerce:   { n: 3, label: 'What it sold' },
  shoppers:   { n: 4, label: 'Who they are' },
  method:     { n: 5, label: 'How solid it is' }
};

/* ==================================================================
   SCOUT — enumerate candidates
================================================================== */
function scout(c) {
  const T = c.T, out = [];
  let cells = 0;
  const add = f => { f.id = f.id || (f.type + ':' + (f.cut || '') + ':' + (f.slice || '') + ':' + (f.metric || '')); out.push(f); };

  /* -- plan vs actual -- */
  if (c.hasPlan && T.estImpressions) {
    const mult = T.impressions / T.estImpressions;
    add({ type: 'plan_delivery', chapter: 'delivery', weight: 1.0, direction: mult >= 1 ? 'up' : 'down',
      effect: Math.abs(mult - 1), base: T.impressions, baseKind: 'impressions',
      v: { mult, actual: T.impressions, planned: T.estImpressions },
      chart: { k: 'paired' } });
  }
  if (c.hasPlan && T.estCpm) {
    const eff = T.cpm / T.estCpm;
    add({ type: 'plan_cpm', chapter: 'delivery', weight: 0.85, direction: eff <= 1 ? 'up' : 'down',
      effect: Math.abs(1 - eff), base: T.impressions, baseKind: 'impressions',
      v: { eff, cpm: T.cpm, est: T.estCpm }, chart: { k: 'paired' } });
  }

  /* -- benchmark on headline rates -- */
  ['ctr', 'convRate', 'cpBuyer', 'repeatRate'].forEach(k => {
    const b = benchFor(k, c);
    const actual = k === 'repeatRate' ? T.repeatRate : (k === 'cpBuyer' ? T.cpBuyer : T[k]);
    if (b == null || actual == null) return;
    const lower = k === 'cpBuyer';
    const better = lower ? actual < b : actual > b;
    add({ type: 'bench', chapter: k === 'ctr' ? 'delivery' : (k === 'repeatRate' ? 'shoppers' : 'conversion'),
      metric: k, weight: 0.8, direction: better ? 'up' : 'down',
      effect: Math.abs(actual - b) / b, base: T.buyers, baseKind: 'buyers',
      v: { actual, bench: b, better }, chart: { k: k === 'repeatRate' ? 'repeat' : 'bignum' } });
  });

  /* -- per-cut outliers -- */
  Object.keys(c.cuts).forEach(cutKey => {
    const cut = c.cuts[cutKey];
    cut.metrics.forEach(mk => {
      const m = METRICS[mk]; if (!m) return;
      const vals = cut.rows.map(r => ({ r, v: m.get(r, T) })).filter(x => x.v != null);
      if (vals.length < 2) return;
      cells += vals.length;
      const ref = m.total(T);
      const sorted = vals.slice().sort((a, b) => b.v - a.v);
      const hi = m.lowerBetter ? sorted[sorted.length - 1] : sorted[0];
      const lo = m.lowerBetter ? sorted[0] : sorted[sorted.length - 1];
      // separation: how far clear of the runner-up is the leader? (robust to a noisy mean)
      const n = sorted.length;
      const hiNext = m.lowerBetter ? sorted[n - 2] : sorted[1];
      const loNext = m.lowerBetter ? sorted[1] : sorted[n - 2];
      const sepHi = hiNext && hiNext.v ? Math.abs(hi.v - hiNext.v) / Math.abs(hiNext.v) : 0;
      const sepLo = loNext && loNext.v ? Math.abs(loNext.v - lo.v) / Math.abs(loNext.v) : 0;
      if (m.kind === 'rate' && ref) {
        add({ type: 'outlier_high', chapter: chapterFor(cutKey, mk), cut: cutKey, slice: hi.r.name, metric: mk,
          weight: weightFor(cutKey, mk), direction: 'up',
          effect: Math.abs(hi.v - ref) / ref, separation: sepHi, runnerUp: hiNext && hiNext.r.name, runnerUpV: hiNext && hiNext.v,
          base: hi.r.buyers, baseKind: 'buyers', imp: hi.r.impressions,
          v: { value: hi.v, ref, row: hi.r, rows: cut.rows, runnerUp: hiNext && hiNext.r, runnerUpV: hiNext && hiNext.v },
          chart: { k: 'bars', cut: cutKey, metric: mk } });
        add({ type: 'outlier_low', chapter: chapterFor(cutKey, mk), cut: cutKey, slice: lo.r.name, metric: mk,
          weight: weightFor(cutKey, mk) * 0.9, direction: 'down',
          effect: Math.abs(lo.v - ref) / ref, separation: sepLo, runnerUp: loNext && loNext.r.name, runnerUpV: loNext && loNext.v,
          base: lo.r.buyers, baseKind: 'buyers', imp: lo.r.impressions,
          v: { value: lo.v, ref, row: lo.r, rows: cut.rows, runnerUp: loNext && loNext.r, runnerUpV: loNext && loNext.v },
          chart: { k: 'bars', cut: cutKey, metric: mk } });
      }
      if (m.kind === 'count') {
        const tot = vals.reduce((s, x) => s + x.v, 0);
        const share = sorted[0].v / tot;
        if (share >= 0.42) {
          add({ type: 'concentration', chapter: chapterFor(cutKey, mk), cut: cutKey, slice: sorted[0].r.name, metric: mk,
            weight: weightFor(cutKey, mk) * 0.95, direction: 'up',
            effect: share - 1 / vals.length, base: sorted[0].r.buyers, baseKind: 'buyers', imp: sorted[0].r.impressions,
            v: { share: share * 100, value: sorted[0].v, n: vals.length, rows: cut.rows },
            chart: { k: 'bars', cut: cutKey, metric: mk } });
        }
      }
    });

    /* -- size / performance mismatch: the reallocation opportunity -- */
    if (cut.hasOwnAudience) {
      const m = METRICS.convRate;
      const rows = cut.rows.filter(r => r.exposable);
      if (rows.length >= 2) {
        const withRate = rows.map(r => ({ r, v: m.get(r, T) }));
        const biggest = withRate.slice().sort((a, b) => b.r.exposable - a.r.exposable)[0];
        const best = withRate.slice().sort((a, b) => b.v - a.v)[0];
        if (biggest.r.name !== best.r.name && best.v > biggest.v * 1.5) {
          add({ type: 'mismatch', chapter: 'conversion', cut: cutKey, slice: biggest.r.name, metric: 'convRate',
            weight: 1.25, direction: 'opportunity',
            effect: (best.v - biggest.v) / biggest.v, base: biggest.r.buyers, baseKind: 'buyers', imp: biggest.r.impressions,
            v: { weak: biggest.r, weakRate: biggest.v, strong: best.r, strongRate: best.v, rows: cut.rows },
            chart: { k: 'bars', cut: cutKey, metric: 'convRate' } });
        }
      }
    }
  });

  /* -- new and lapsed buyers: the growth question attribution can answer honestly -- */
  if (T.newBuyers != null && T.buyers) {
    const share = (T.newBuyers + T.lapsedBuyers) / T.buyers * 100;
    add({ type: 'newbuyer', chapter: 'conversion', weight: 1.3, direction: share >= 35 ? 'up' : 'down',
      effect: Math.abs(share - 30) / 30, base: T.newBuyers + T.lapsedBuyers, baseKind: 'buyers',
      v: { share, newB: T.newBuyers, lapsed: T.lapsedBuyers, cost: T.cpNewBuyer, cpAll: T.cpBuyer, buyers: T.buyers },
      chart: { k: 'newbuyer' } });
    const cut = c.cuts.segment;
    if (cut) {
      const rows = cut.rows.map(r => ({ r, v: METRICS.newShare.get(r, T) })).filter(x => x.v != null).sort((a, b) => b.v - a.v);
      if (rows.length >= 2 && rows[0].v - rows[rows.length - 1].v > 15) {
        add({ type: 'newbuyer_cut', chapter: 'conversion', cut: 'segment', slice: rows[0].r.name, metric: 'newShare',
          weight: 1.2, direction: 'up', effect: Math.abs(rows[0].v - share) / share,
          separation: (rows[0].v - rows[1].v) / rows[1].v, runnerUp: rows[1].r.name,
          base: rows[0].r.buyers, baseKind: 'buyers', imp: rows[0].r.impressions,
          v: { value: rows[0].v, ref: share, row: rows[0].r, rows: cut.rows, worst: rows[rows.length - 1].r, worstV: rows[rows.length - 1].v },
          chart: { k: 'bars', cut: 'segment', metric: 'newShare' } });
      }
    }
  }

  /* -- funnel drop -- */
  if (c.funnel && c.funnel.length > 2) {
    let worst = null;
    for (let i = 1; i < c.funnel.length - 1; i++) {
      const drop = 1 - c.funnel[i].value / c.funnel[i - 1].value;
      if (!worst || drop > worst.drop) worst = { drop, from: c.funnel[i - 1], to: c.funnel[i] };
    }
    if (worst && worst.drop > 0.15) {
      add({ type: 'funnel_drop', chapter: 'delivery', weight: 0.95, direction: 'down',
        effect: worst.drop, base: worst.to.value, baseKind: 'shoppers',
        v: worst, chart: { k: 'funnel' } });
    }
  }

  /* -- category benchmarks -- */
  if (c.T.ecomShare != null) {
    const d = c.T.ecomShare - c.T.catEcomShare;
    add({ type: 'ecom', chapter: 'shoppers', weight: 0.9, direction: d > 0 ? 'up' : 'down',
      effect: Math.abs(d) / c.T.catEcomShare, base: c.T.buyers, baseKind: 'buyers',
      v: { share: c.T.ecomShare, cat: c.T.catEcomShare, d }, chart: { k: 'donut2' } });
  }
  if (c.profile) {
    Object.keys(c.profile).forEach(attr => {
      const p = c.profile[attr];
      const items = p.names.map((n, i) => ({ n, share: p.campaign[i], d: p.campaign[i] - p.category[i] }));
      const up = items.slice().sort((a, b) => b.d - a.d)[0];
      cells += items.length;
      add({ type: 'profile', chapter: 'shoppers', cut: attr, slice: up.n, weight: 0.85, direction: 'up',
        effect: Math.abs(up.d) / Math.max(1, up.share - up.d), base: c.T.buyers, baseKind: 'buyers',
        v: { up, items, attr, label: p.label }, chart: { k: 'pie2', attribute: attr } });
    });
  }

  /* -- timing -- */
  if (c.ttp && c.T.medTTP != null) {
    const early = c.ttp.values.slice(0, 3).reduce((s, v) => s + v, 0);
    add({ type: 'timing', chapter: 'shoppers', weight: 0.75, direction: 'up',
      effect: early / 100, base: c.T.buyers, baseKind: 'buyers',
      v: { med: c.T.medTTP, avg: c.T.avgTTP, early, windowDays: c.windowDays }, chart: { k: 'hist' } });
  }

  /* -- data quality -- */
  (c.quality || []).forEach(q => {
    if (q.floor != null && q.value < q.floor) {
      add({ type: 'quality_low', chapter: 'method', slice: q.name, weight: 1.1, direction: 'down',
        effect: (q.floor - q.value) / q.floor, base: c.T.buyers, baseKind: 'buyers',
        v: q, chart: { k: 'quality' } });
    }
  });

  /* -- maturity: always raised, never dropped -- */
  const open = c.daily.sales.length - c.daily.maturedTo;
  add({ type: 'maturity', chapter: 'method', weight: 1.4, direction: 'caveat', always: true,
    effect: open / c.daily.sales.length, base: c.T.buyers, baseKind: 'buyers',
    v: { open, closes: c.windowCloses, windowDays: c.windowDays, maturity: c.maturity },
    chart: { k: 'daily', series: 'sales' } });

  // one concentration story per breakdown — the strongest one
  const bestConc = {};
  out.forEach(f => {
    if (f.type !== 'concentration') return;
    const k = f.cut;
    if (!bestConc[k] || f.v.share > bestConc[k].v.share) bestConc[k] = f;
  });
  const trimmed = out.filter(f => f.type !== 'concentration' || bestConc[f.cut] === f);
  trimmed.forEach(f => { f.cells = cells; });
  return { findings: trimmed, cells };
}

function chapterFor(cutKey, mk) {
  if (mk === 'ctr' || mk === 'impressions') return 'delivery';
  if (mk === 'convRate') return 'conversion';
  if (cutKey === 'channel' || cutKey === 'banner') return 'shoppers';
  return 'commerce';
}
function weightFor(cutKey, mk) {
  const cw = { segment: 1.15, placement: 1.0, creative: 0.95, product: 0.9, banner: 0.8, channel: 0.85 }[cutKey] || 0.8;
  const mw = { convRate: 1.2, sales: 1.1, cpBuyer: 1.05, salesPerK: 1.0, buyers: 1.0, ctr: 0.9, salesPerBuyer: 0.8, avgTxn: 0.7, impressions: 0.6 }[mk] || 0.8;
  return cw * mw;
}

/* ==================================================================
   SKEPTIC — try to kill each finding
================================================================== */
const MIN_BUYERS = 400;          // stands up on its own
const SOFT_BUYERS = 150;         // below this, not reportable at all
const MIN_IMPRESSIONS = 250000;
const SOFT_IMPRESSIONS = 80000;

function skeptic(findings, c) {
  const T = c.T;
  // threshold grows with how many cells we looked at: more looks, bigger gap required
  const cells = findings.length ? findings[0].cells : 1;
  // the more slices we look at, the further clear of the pack a leader must be
  const mcThreshold = 0.10 + 0.02 * Math.log2(Math.max(2, cells));

  findings.forEach(f => {
    f.rejections = []; f.caveats = []; f.grade = 'stands';

    if (f.always) { f.kept = true; return; }

    // 1. base size
    if (['outlier_high', 'outlier_low', 'concentration', 'mismatch', 'newbuyer_cut'].includes(f.type)) {
      if (f.baseKind === 'buyers' && f.base != null && f.base < SOFT_BUYERS) {
        f.rejections.push({ rule: 'Not reportable', why: `Only ${F.int(f.base)} attributed buyers behind this slice — under the ${F.int(SOFT_BUYERS)} floor below which we say nothing at all.` });
      } else if (f.baseKind === 'buyers' && f.base != null && f.base < MIN_BUYERS) {
        f.grade = 'directional';
        f.gradeWhy = `${F.int(f.base)} attributed buyers behind it — enough to show a pattern, under the ${F.int(MIN_BUYERS)} we want before planning on it.`;
      }
      if (f.imp != null && f.imp < SOFT_IMPRESSIONS) {
        f.rejections.push({ rule: 'Not reportable', why: `Only ${F.compact(f.imp)} impressions on this slice — under the ${F.compact(SOFT_IMPRESSIONS)} floor.` });
      } else if (f.imp != null && f.imp < MIN_IMPRESSIONS) {
        f.grade = 'directional';
        f.gradeWhy = f.gradeWhy || `${F.compact(f.imp)} impressions behind it — a pattern, not yet a finding to plan on.`;
      }
    }

    // 2. is it actually clear of the pack? (and we looked at a lot of slices)
    if (['outlier_high', 'outlier_low'].includes(f.type)) {
      const sep = f.separation || 0;
      if (sep < mcThreshold * 0.6) {
        f.rejections.push({
          rule: 'Too close to call',
          why: `${shortName(f.slice)} sits only ${(sep * 100).toFixed(0)}% clear of the next ${(c.cuts[f.cut] || {}).noun || 'slice'} (${shortName(f.runnerUp || '')}). Across ${cells} slices examined, a leader needs ${(mcThreshold * 100).toFixed(0)}% to stand up and ${(mcThreshold * 60).toFixed(0)}% to be worth mentioning at all.`
        });
      } else if (sep < mcThreshold) {
        f.grade = 'directional';
        f.gradeWhy = f.gradeWhy || `${(sep * 100).toFixed(0)}% clear of ${shortName(f.runnerUp || 'the next slice')}, against the ${(mcThreshold * 100).toFixed(0)}% we want before calling it a difference.`;
      }
    }

    // 3. provenance
    if (c.provenance === 'partner') {
      const m = f.metric && METRICS[f.metric];
      if ((m && m.needs === 'shopper') || ['mismatch', 'profile', 'ecom', 'timing', 'bench'].includes(f.type)) {
        if (!(f.type === 'bench' && f.metric === 'ctr')) {
          f.rejections.push({ rule: 'Partner-reported', why: 'This needs shopper-level detail. The partner returns totals only, so the number cannot be stood behind.' });
        }
      }
    }

    // 4. missing plan inputs
    if (['plan_delivery', 'plan_cpm'].includes(f.type) && !c.hasPlan) {
      f.rejections.push({ rule: 'Input missing', why: 'No planned spend or impressions were supplied for this campaign.' });
    }

    // 5. maturity — a caveat, never a kill
    if (['outlier_high', 'outlier_low', 'concentration', 'mismatch', 'bench'].includes(f.type) && c.daily.maturedTo < c.daily.sales.length) {
      const open = c.daily.sales.length - c.daily.maturedTo;
      f.caveats.push(`The ${c.windowDays}-day window is still open on the last ${open} days, so this figure can still rise.`);
    }
    if (f.type === 'profile' || f.type === 'ecom') {
      f.caveats.push('Compared with category buyers over the same period, on the same definition.');
    }
    if (f.type === 'mismatch') {
      f.caveats.push('The reallocation figure assumes the stronger audience holds its rate on extra budget. It is smaller than this audience\'s current reach, so that is reasonable — but it is an estimate, not a promise.');
    }

    f.kept = f.rejections.length === 0;
  });

  findings.forEach(f => {
    const reliability = f.baseKind === 'buyers' && f.base
      ? Math.min(1, Math.log10(Math.max(10, f.base)) / Math.log10(5000))
      : 0.9;
    f.reliability = reliability;
    f.score = f.effect * reliability * f.weight * (f.grade === 'directional' ? 0.55 : 1);
  });

  return { mcThreshold, cells };
}

/* ==================================================================
   EXPLAINER + ADVISOR — wording and the recommendation
================================================================== */
function describe(f, c, goal) {
  const T = c.T;
  const m = f.metric && METRICS[f.metric];
  f.measureLabel = m ? m.short : null;
  const cut = f.cut && c.cuts[f.cut];
  const noun = cut ? cut.noun : 'line';
  const firm = goal === 'planning' ? 'For the next flight we would' : goal === 'midflight' ? 'While it is still running, we would' : 'We recommend';

  switch (f.type) {
    case 'plan_delivery': {
      const up = f.v.mult >= 1;
      f.title = up ? 'We delivered more than we sold' : 'Delivery came in under plan';
      f.sentence = `The campaign delivered <b>${F.compact(f.v.actual)}</b> impressions against a planned <b>${F.compact(f.v.planned)}</b> — <b>${F.x(f.v.mult)}</b> the booked volume at no extra cost.`;
      f.reco = up
        ? `${firm} holding the same budget next flight: the over-delivery is free reach we can show on the plan.`
        : `${firm} checking inventory availability before committing the same volume again.`;
      f.stat = { v: F.x(f.v.mult), l: 'impressions against plan' };
      return f;
    }
    case 'plan_cpm': {
      const cheaper = f.v.eff <= 1;
      f.title = cheaper ? 'Cheaper per thousand than planned' : 'More expensive per thousand than planned';
      f.sentence = `The effective CPM was <b>${F.money2(f.v.cpm)}</b> against <b>${F.money2(f.v.est)}</b> planned — <b>${Math.round(Math.abs(1 - f.v.eff) * 100)}%</b> ${cheaper ? 'cheaper' : 'dearer'} per thousand ads.`;
      f.reco = cheaper
        ? `${firm} reinvesting the saving rather than cutting the budget — the same money buys more reach than the plan assumed.`
        : `${firm} revisiting the floor price on this inventory before the next flight.`;
      f.stat = { v: F.money2(f.v.cpm), l: `CPM · ${F.money2(f.v.est)} planned` };
      return f;
    }
    case 'bench': {
      const k = f.metric, b = f.v;
      const name = { ctr: 'Click-through rate', convRate: 'Conversion rate', cpBuyer: 'Cost per buyer', repeatRate: 'Repeat purchase' }[k];
      const fmt = k === 'cpBuyer' ? F.money2 : (k === 'ctr' ? F.pct2 : F.pct3);
      f.title = `${name} ${b.better ? 'ahead of' : 'behind'} comparable ${(c.benchLabel || '').replace('comparable ', '').replace(' campaigns', '')} campaigns`;
      f.sentence = `${name} came in at <b>${fmt(b.actual)}</b> against <b>${fmt(b.bench)}</b> across ${c.benchLabel || 'comparable campaigns'} — <b>${b.actual > b.bench ? F.x(b.actual / b.bench) : F.x(b.bench / b.actual)}</b> ${b.better ? 'better' : 'worse'}.`;
      f.reco = b.better
        ? `${firm} using this as the benchmark in the next brief rather than the category norm.`
        : `${firm} looking at targeting and creative together before repeating this set-up.`;
      f.stat = { v: fmt(b.actual), l: `${name.toLowerCase()} · ${fmt(b.bench)} benchmark` };
      return f;
    }
    case 'outlier_high': {
      f.title = `${shortName(f.slice)} is the strongest ${noun}`;
      f.sentence = `The <b>${shortName(f.slice).toLowerCase()}</b> ${noun} reached <b>${m.fmt(f.v.value)}</b> on ${m.label} against a campaign average of <b>${m.fmt(f.v.ref)}</b> — <b>${F.x(f.v.value / f.v.ref)}</b> the average.`;
      f.reco = `${firm} weighting the next flight towards ${shortName(f.slice).toLowerCase()} and briefing more inventory against it.`;
      f.stat = { v: m.fmt(f.v.value), l: `${shortName(f.slice).toLowerCase()} · ${m.label}` };
      return f;
    }
    case 'outlier_low': {
      f.title = `${shortName(f.slice)} is the weakest ${noun}`;
      f.sentence = `The <b>${shortName(f.slice).toLowerCase()}</b> ${noun} came in at <b>${m.fmt(f.v.value)}</b> on ${m.label} against a campaign average of <b>${m.fmt(f.v.ref)}</b>.`;
      f.reco = `${firm} either reworking this ${noun} or moving its share of the budget to the ${noun}s that are carrying the campaign.`;
      f.stat = { v: m.fmt(f.v.value), l: `${shortName(f.slice).toLowerCase()} · ${m.label}` };
      return f;
    }
    case 'concentration': {
      f.title = `${shortName(f.slice)} carries the campaign`;
      f.sentence = `<b>${shortName(f.slice)}</b> accounts for <b>${F.pct1(f.v.share)}</b> of ${m.label} on its own, out of ${f.v.n} ${noun}s.`;
      f.reco = `${firm} treating this as a dependency as much as a strength — one ${noun} carrying ${F.pct1(f.v.share)} is a risk if it saturates.`;
      f.stat = { v: F.pct1(f.v.share), l: `${shortName(f.slice).toLowerCase()} share of ${m.label}` };
      return f;
    }
    case 'mismatch': {
      const weakSpend = spendOf(f.v.weak, T), strongSpend = spendOf(f.v.strong, T);
      const weakEff = f.v.weak.buyers / weakSpend;     // buyers per €
      const strongEff = f.v.strong.buyers / strongSpend;
      const moveShare = 0.3;
      const moved = weakSpend * moveShare;
      const gained = Math.round(moved * (strongEff - weakEff));
      const gainedSales = Math.round(gained * f.v.strong.salesPerBuyer);
      const weakNew = f.v.weak.buyers ? (f.v.weak.newBuyers + f.v.weak.lapsedBuyers) / f.v.weak.buyers * 100 : null;
      const strongNew = f.v.strong.buyers ? (f.v.strong.newBuyers + f.v.strong.lapsedBuyers) / f.v.strong.buyers * 100 : null;
      f.opportunity = { moved, gained, gainedSales, weakSpend, strongSpend, moveShare, weakNew, strongNew };
      if (weakNew != null && strongNew != null && strongNew < weakNew - 10) {
        f.counterCheck = `But look at who each audience brings. <b>${F.pct1(weakNew)}</b> of ${shortName(f.v.weak.name).toLowerCase()} buyers were new to the brand or won back, against <b>${F.pct1(strongNew)}</b> of ${shortName(f.v.strong.name).toLowerCase()}. Moving the money buys more purchases from shoppers who were already buying. If the objective is growth rather than efficiency, do the opposite.`;
      }
      f.title = 'The biggest audience is the weakest one';
      f.sentence = `<b>${shortName(f.v.weak.name)}</b> was the largest audience at <b>${F.compact(f.v.weak.exposable)}</b> shoppers but converted at <b>${F.pct3(f.v.weakRate)}</b>, while <b>${shortName(f.v.strong.name).toLowerCase()}</b> converted at <b>${F.pct3(f.v.strongRate)}</b> from <b>${F.compact(f.v.strong.exposable)}</b>.`;
      f.reco = `${firm} moving <b>${Math.round(moveShare * 100)}%</b> of the ${shortName(f.v.weak.name).toLowerCase()} budget — about <b>${F.money(moved)}</b> — into ${shortName(f.v.strong.name).toLowerCase()}. At the rates both audiences actually achieved, that is roughly <b>${F.int(gained)} more buyers</b> and <b>${F.moneyC(gainedSales)}</b> of attributed sales for the same total spend.`;
      f.stat = { v: '+' + F.int(gained), l: 'buyers if the budget moved' };
      return f;
    }
    case 'newbuyer': {
      const v = f.v;
      f.title = v.share >= 35 ? 'Nearly half the buyers were new to the brand' : 'Most buyers were already buying the brand';
      f.sentence = `<b>${F.int(v.newB + v.lapsed)}</b> of the <b>${F.int(v.buyers)}</b> attributed buyers — <b>${F.pct1(v.share)}</b> — had not bought the brand in the twelve weeks before the campaign. Each one cost <b>${F.money2(v.cost)}</b> of media, against <b>${F.money2(v.cpAll)}</b> for a buyer of any kind.`;
      f.reco = v.share >= 35
        ? `${firm} putting cost per new or lapsed buyer on the cover of this report. It is the one number here that cannot be inflated by reaching shoppers who were buying anyway.`
        : `${firm} widening the audience next flight. A campaign that mostly reaches existing buyers is defending the base, which is worth doing — but it should be bought and judged as that, not as growth.`;
      f.stat = { v: F.money2(v.cost), l: 'cost per new or lapsed buyer' };
      return f;
    }
    case 'newbuyer_cut': {
      f.title = `${shortName(f.slice)} brings the most new buyers`;
      f.sentence = `<b>${F.pct1(f.v.value)}</b> of <b>${shortName(f.slice).toLowerCase()}</b> buyers were new to the brand or won back, against <b>${F.pct1(f.v.ref)}</b> across the campaign and only <b>${F.pct1(f.v.worstV)}</b> for ${shortName(f.v.worst.name).toLowerCase()}.`;
      f.reco = `${firm} judging these two audiences on different things: one is buying growth, the other is defending the base. Holding both to the same cost per buyer will quietly kill the growth one.`;
      f.stat = { v: F.pct1(f.v.value), l: `new or lapsed · ${shortName(f.slice).toLowerCase()}` };
      return f;
    }
    case 'funnel_drop': {
      f.title = `The audience thins between ${f.v.from.name.replace(' Shoppers', '').toLowerCase()} and ${f.v.to.name.replace(' Shoppers', '').toLowerCase()}`;
      f.sentence = `<b>${F.pct1(f.v.drop * 100)}</b> of the audience is lost between <b>${f.v.from.name}</b> (${F.compact(f.v.from.value)}) and <b>${f.v.to.name}</b> (${F.compact(f.v.to.value)}) — the largest drop in the funnel.`;
      f.reco = `${firm} looking at this step first: recovering even a tenth of it is cheaper than buying the equivalent reach.`;
      f.stat = { v: '−' + F.pct1(f.v.drop * 100), l: `lost before ${f.v.to.name.replace(' Shoppers', '').toLowerCase()}` };
      return f;
    }
    case 'ecom': {
      const up = f.v.d > 0;
      f.title = up ? 'A visible lift in online share' : 'Online share below the category';
      f.sentence = `E-commerce took <b>${F.pct1(f.v.share)}</b> of attributed sales against <b>${F.pct1(f.v.cat)}</b> for the category over the same period — <b>${F.pts(f.v.d)}</b>.`;
      f.reco = up
        ? `${firm} pairing the next flight with the online slot, since that is where the campaign moved share.`
        : `${firm} testing an online-weighted flight, since the campaign did not shift the channel mix.`;
      f.stat = { v: F.pts(f.v.d), l: 'e-commerce share vs category' };
      return f;
    }
    case 'profile': {
      f.title = `Buyers skew ${f.v.up.n.toLowerCase()}`;
      f.sentence = `<b>${f.v.up.n}</b> make up <b>${f.v.up.share}%</b> of campaign buyers against <b>${f.v.up.share - f.v.up.d}%</b> of category buyers — <b>${F.pts(f.v.up.d)}</b> on ${f.v.label.toLowerCase()}.`;
      f.reco = `${firm} building the next audience around ${f.v.up.n.toLowerCase()} rather than the whole category.`;
      f.stat = { v: F.pts(f.v.up.d), l: `${f.v.up.n.toLowerCase()} against the category` };
      return f;
    }
    case 'timing': {
      f.title = 'Most buying happens in the first three days';
      f.sentence = `Half of attributed purchases land within <b>${F.hours(f.v.med)}</b> of exposure and <b>${f.v.early}%</b> within three days, against a <b>${f.v.windowDays}-day</b> window.`;
      f.reco = `${firm} concentrating weight in the first days of a flight, where the response actually is.`;
      f.stat = { v: F.hours(f.v.med), l: 'median time to purchase' };
      return f;
    }
    case 'quality_low': {
      f.title = `${f.v.name} is below our floor`;
      f.sentence = `${f.v.name} came in at <b>${f.v.value}${f.v.unit}</b> against a floor of <b>${f.v.floor}${f.v.unit}</b>.`;
      f.reco = `Flag this before the result is presented — it affects how much of the campaign we can stand behind.`;
      f.stat = { v: f.v.value + f.v.unit, l: f.v.name.toLowerCase() };
      return f;
    }
    case 'maturity': {
      f.title = 'This read is not finished yet';
      f.sentence = `The ${f.v.windowDays}-day window is still open on the last <b>${f.v.open} days</b> and closes on <b>${f.v.closes}</b>. Every figure here is a floor, not a verdict.`;
      f.reco = `Present these numbers as ${f.v.maturity.toLowerCase()}, and agree now to re-issue the report once the window closes.`;
      f.stat = { v: f.v.open + ' wks', l: 'still inside the window' };
      return f;
    }
  }
  f.title = 'Finding'; f.sentence = ''; f.reco = '';
  return f;
}

/* ==================================================================
   EDITOR — select, de-duplicate, order, headline
================================================================== */
const GOALS = {
  midflight: {
    label: 'Mid-flight review',
    hint: 'Is it delivering, and is anything going wrong while we can still fix it?',
    audience: 'Internal, and the supplier if something needs saying now',
    boost: f => (f.chapter === 'delivery' ? 1.5 : f.type === 'quality_low' ? 1.6 : f.type === 'funnel_drop' ? 1.4 : f.direction === 'down' ? 1.2 : 0.9),
    minDown: 1, allowDirectional: true,
    lead: p => p.find(f => f.direction === 'down') || p.find(f => f.chapter === 'delivery')
  },
  closeout: {
    label: 'End-of-campaign review',
    hint: 'What happened, in full, including what did not work.',
    audience: 'The supplier, as the record of the campaign',
    boost: f => (f.type === 'newbuyer' ? 1.3 : 1),
    minDown: 2, allowDirectional: true,
    lead: p => p.find(f => f.type === 'newbuyer') || p.find(f => f.direction === 'up')
  },
  planning: {
    label: 'Planning input',
    hint: 'What to do differently with the next budget.',
    audience: 'The supplier, before the next buy is committed',
    boost: f => (f.direction === 'opportunity' ? 1.9 : f.type === 'newbuyer' || f.type === 'newbuyer_cut' ? 1.5 : f.type === 'funnel_drop' ? 1.4 : f.direction === 'down' ? 1.15 : 0.9),
    minDown: 1, allowDirectional: true,
    lead: p => p.find(f => f.direction === 'opportunity') || p.find(f => f.type === 'newbuyer')
  }
};

function editor(findings, c, goal, maxSlides) {
  const g = GOALS[goal];
  const kept = findings.filter(f => f.kept);
  kept.forEach(f => { f.goalScore = f.score * g.boost(f); });

  const order = ['delivery', 'conversion', 'commerce', 'shoppers', 'method'];
  const picked = [];
  const usedSlices = new Set();
  const usedTypes = {};

  // maturity always travels with the deck
  const maturity = kept.find(f => f.type === 'maturity');
  // so does the new-and-lapsed-buyer read: it is the one growth number attribution can answer honestly
  const newBuyer = kept.find(f => f.type === 'newbuyer');
  if (newBuyer) { newBuyer.mustTravel = 'Kept on every deck: it is the only growth question attribution can answer without a hold-out group.'; }

  const pool = kept.filter(f => f.type !== 'maturity').sort((a, b) => {
    if (a.type === 'newbuyer') return -1;
    if (b.type === 'newbuyer') return 1;
    return b.goalScore - a.goalScore;
  });

  for (const f of pool) {
    if (picked.length >= maxSlides - 1) break;
    const sliceKey = (f.cut || '') + '|' + (f.slice || '');
    if (f.slice && usedSlices.has(sliceKey)) { f.dropped = 'Already covered by another finding about the same slice.'; continue; }
    const tcount = usedTypes[f.type] || 0;
    if (tcount >= (f.type === 'outlier_high' || f.type === 'outlier_low' ? 2 : 1)) { f.dropped = 'The story already makes this point.'; continue; }
    const chCount = picked.filter(p => p.chapter === f.chapter).length;
    if (chCount >= 3) { f.dropped = 'Enough already said in this chapter.'; continue; }
    picked.push(f); usedSlices.add(sliceKey); usedTypes[f.type] = tcount + 1;
  }

  // the opportunity always travels — it is the recommendation the deck exists for
  if (g.wantOpportunity && !picked.some(p => p.direction === 'opportunity')) {
    const opp = pool.find(f => f.direction === 'opportunity' && !picked.includes(f));
    if (opp) { opp.forced = 'Kept because every story needs one thing to do next.'; opp.dropped = null; picked.push(opp); }
  }
  // the honest minimum of genuinely negative findings
  const downs = picked.filter(p => p.direction === 'down');
  if (downs.length < g.minDown) {
    const extra = pool.filter(f => !picked.includes(f) && f.direction === 'down')
      .sort((a, b) => b.score - a.score).slice(0, g.minDown - downs.length);
    extra.forEach(f => { f.forced = 'Kept so the report is not only good news.'; f.dropped = null; picked.push(f); });
  }

  if (maturity) picked.push(maturity);
  picked.sort((a, b) => order.indexOf(a.chapter) - order.indexOf(b.chapter) || b.goalScore - a.goalScore);

  // the goal decides what the reader meets first
  const lead = g.lead(picked);
  if (lead) {
    const i = picked.indexOf(lead);
    if (i > 0) { picked.splice(i, 1); picked.unshift(lead); lead.isLead = true; }
    else if (i === 0) lead.isLead = true;
  }
  picked.forEach((f, i) => { f.slideNo = i + 1; f.selected = true; });

  // headline
  const T = c.T;
  const opp = picked.find(f => f.direction === 'opportunity');
  const nb = picked.find(f => f.type === 'newbuyer');
  let headline;
  if (goal === 'planning' && opp && opp.opportunity) {
    headline = `The same budget, spent where it worked, was worth about ${F.int(opp.opportunity.gained)} more buyers`;
  } else if (goal === 'midflight') {
    headline = `Day ${c.day} of ${c.ofDays}: ${F.money(T.spend)} spent, ${F.moneyC(T.sales)} of sales credited so far`;
  } else if (nb) {
    headline = `${F.pct1(nb.v.share)} of the buyers were new to the brand, at ${F.money2(T.cpNewBuyer)} each`;
  } else {
    headline = `Every €1 of media is linked to ${F.money2(T.roas)} of attributed sales`;
  }
  return { picked, headline, goal: g };
}

/* ==================================================================
   RUN — the whole pipeline
================================================================== */
function runEngine(c, goal, maxSlides) {
  goal = GOALS[goal] ? goal : 'closeout';
  const t0 = performance.now ? performance.now() : 0;
  const { findings, cells } = scout(c);
  const sk = skeptic(findings, c);
  findings.forEach(f => describe(f, c, goal));
  const ed = editor(findings, c, goal, maxSlides || 9);
  const t1 = performance.now ? performance.now() : 0;
  return {
    all: findings,
    kept: findings.filter(f => f.kept),
    rejected: findings.filter(f => !f.kept),
    dropped: findings.filter(f => f.kept && !f.selected),
    story: ed.picked,
    headline: ed.headline,
    goal: ed.goal,
    stats: { cells, scanned: findings.length, kept: findings.filter(f => f.kept).length, used: ed.picked.length, threshold: sk.mcThreshold, ms: Math.max(1, Math.round(t1 - t0)) }
  };
}
