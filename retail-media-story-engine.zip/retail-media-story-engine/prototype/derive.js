/* ==================================================================
   DERIVE — build the shape the story engine expects, from the facts.
   Nothing here invents a measure: everything is aggregated or declared.
================================================================== */

const BENCH = {
  onsite_search:  { ctr: 0.22, convRate: 0.19, cpBuyer: 3.40, repeatRate: 7.4, label: 'comparable onsite sponsored-product campaigns' },
  onsite_display: { ctr: 0.12, convRate: 0.14, cpBuyer: 4.10, repeatRate: 6.8, label: 'comparable onsite display campaigns' },
  email:          { ctr: 4.80, convRate: 1.90, cpBuyer: 1.60, repeatRate: 9.1, label: 'comparable email campaigns' },
  walled:         { ctr: 0.58, convRate: 0.09, cpBuyer: 7.80, repeatRate: null, label: 'comparable offsite campaigns' }
};
function benchKey(def) {
  if (def.provenance === 'partner') return 'walled';
  if (/Email/i.test(def.kind)) return 'email';
  if (/display/i.test(def.kind)) return 'onsite_display';
  return 'onsite_search';
}

/* a deterministic little helper for the things that live outside the fact table */
function hashSeed(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) / 4294967296; }

function deriveCampaign(cmId, extraFilter) {
  const def = CAMPAIGN_BY_ID[cmId];
  const rows = filterFacts(Object.assign({ campaigns: [cmId] }, extraFilter || {}));
  const T0 = total(rows);
  const wFrom = weekById(def.from), wTo = weekById(def.to);
  const today = weekById('w40');                       // "now" = week 40
  const liveWeeks = WEEKS.filter(w => w.idx >= wFrom.idx && w.idx <= Math.min(wTo.idx, today.idx));
  const seed = hashSeed(cmId);

  /* ---- totals ---- */
  const exposable = [...new Set(def.adgroups.map(g => g.segment))].reduce((s, id) => s + SEGMENTS.find(x => x.id === id).size, 0);
  const reached = Math.round(T0.impressions / (def.provenance === 'partner' ? 2.1 : 9.3));
  const T = Object.assign({}, T0, {
    estImpressions: def.plannedImpressions,
    estCpm: def.plannedSpend / def.plannedImpressions * 1000,
    estSpend: def.plannedSpend,
    exposable: Math.round(exposable),
    exported: Math.round(exposable * 1.08),
    targeted: Math.round(exposable),
    exposed: def.provenance === 'partner' ? null : Math.round(reached * 1.08),
    reached: reached,
    frequency: T0.impressions / reached,
    transactions: T0.txns,
    convRate: T0.buyers / exposable * 100,
    margin: def.provenance === 'partner' ? null : T0.sales * 0.295,
    repeatBuyers: def.provenance === 'partner' ? null : Math.round(T0.buyers * (0.082 + seed * 0.03)),
    repeatRate: def.provenance === 'partner' ? null : (0.082 + seed * 0.03) * 100,
    ecomShare: def.provenance === 'partner' ? null : (() => {
      const ec = rows.filter(r => r.channel === 'E-commerce').reduce((s, r) => s + r.sales, 0);
      return T0.sales ? ec / T0.sales * 100 : null;
    })(),
    catEcomShare: 3.0,
    newShare: T0.buyers ? (T0.newBuyers + T0.lapsedBuyers) / T0.buyers * 100 : null,
    cpNewBuyer: (T0.newBuyers + T0.lapsedBuyers) ? T0.spend / (T0.newBuyers + T0.lapsedBuyers) : null,
    haloShare: T0.sales ? T0.haloSales / T0.sales * 100 : null,
    avgTTP: def.provenance === 'partner' ? null : 96 + seed * 40,
    medTTP: def.provenance === 'partner' ? null : 54 + seed * 30
  });

  /* ---- cuts ---- */
  const segShare = {};
  [...new Set(def.adgroups.map(g => g.segment))].forEach(id => {
    const s = SEGMENTS.find(x => x.id === id);
    segShare[s.name] = s.size;
  });
  const mkCut = (key, label, noun, metrics, hasOwnAudience, exposableFor) => {
    const g = groupBy(rows, key).filter(r => r.buyers > 0);
    if (g.length < 2) return null;
    return {
      label, noun, metrics, hasOwnAudience,
      rows: g.map(r => ({
        name: r.name, buyers: r.buyers, sales: r.sales, txns: r.txns,
        impressions: r.impressions, clicks: r.clicks, spend: r.spend,
        newBuyers: r.newBuyers, lapsedBuyers: r.lapsedBuyers, directSales: r.directSales, haloSales: r.haloSales,
        salesPerBuyer: r.salesPerBuyer, avgTxn: r.avgTxn,
        exposable: exposableFor ? exposableFor(r) : null
      })).sort((a, b) => b.sales - a.sales)
    };
  };
  const cuts = {};
  const add = (k, c) => { if (c) cuts[k] = c; };
  add('segment', mkCut('segment', 'Audience segment', 'audience', ['convRate', 'buyers', 'sales', 'salesPerBuyer', 'ctr', 'cpBuyer', 'newShare', 'cpNewBuyer'], true, r => Math.round(segShare[r.name] || 0) || null));
  add('adgroup', mkCut('adgroup', 'Ad group', 'ad group', ['ctr', 'salesPerK', 'sales', 'buyers', 'cpBuyer'], false));
  add('ad', mkCut('ad', 'Ad', 'ad', ['ctr', 'salesPerK', 'buyers', 'sales'], false));
  add('placement', mkCut('placement', 'Placement', 'placement', ['ctr', 'salesPerK', 'sales', 'buyers', 'cpBuyer'], false));
  add('banner', mkCut('banner', 'Retail banner', 'banner', ['sales', 'buyers', 'ctr'], false));
  add('channel', mkCut('channel', 'Purchase channel', 'channel', ['sales', 'buyers', 'avgTxn'], false));
  add('product', mkCut('product', 'Product', 'product', ['sales', 'buyers', 'avgTxn'], false));
  add('creative', mkCut('creative', 'Creative', 'creative', ['ctr', 'salesPerK', 'buyers', 'sales'], false));

  /* ---- funnel ---- */
  const funnel = def.provenance === 'partner'
    ? [{ name: 'Exported Shoppers', value: T.exported }, { name: 'Targeted Shoppers', value: T.targeted },
       { name: 'Reached Shoppers', value: T.reached }, { name: 'Attributed Buyers', value: T.buyers }]
    : [{ name: 'Exported Shoppers', value: T.exported }, { name: 'Targeted Shoppers', value: T.targeted },
       { name: 'Exposed Shoppers', value: T.exposed }, { name: 'Reached Shoppers', value: T.reached },
       { name: 'Attributed Buyers', value: T.buyers }];

  /* ---- by week ---- */
  const byWeek = groupBy(rows, 'week');
  const wk = liveWeeks.map(w => byWeek.find(b => b.key === w.id) || { impressions: 0, clicks: 0, sales: 0 });
  const isLive = def.state === 'live';
  const daily = {
    labels: liveWeeks.map(w => w.label),
    impressions: wk.map(x => Math.round(x.impressions / 1000)),
    clicks: wk.map(x => +(x.clicks / 1000).toFixed(1)),
    sales: wk.map(x => Math.round(x.sales / 1000)),
    maturedTo: isLive ? Math.max(1, liveWeeks.length - 2) : liveWeeks.length
  };

  /* ---- profile, timing, quality: declared tables, not in the fact grain ---- */
  const p1 = Math.round(38 + seed * 14);
  const profile = def.provenance === 'partner' ? null : {
    lifestage: { label: 'Lifestage', names: ['Families', 'Young adults 18–39', 'Older couples 40–64', '65 and over'],
      campaign: [p1, Math.round(23 - seed * 3), Math.round(22 - seed * 2), 100 - p1 - Math.round(23 - seed * 3) - Math.round(22 - seed * 2)],
      category: [38, 24, 22, 16] },
    consostyle: { label: 'Consostyle', names: ['Gourmet', 'Nutrition', 'Convenience', 'Budget', 'Deal seekers'],
      campaign: [Math.round(24 + seed * 10), 24, 19, 15, 100 - Math.round(24 + seed * 10) - 24 - 19 - 15],
      category: [21, 22, 24, 18, 15] }
  };
  const ttp = def.provenance === 'partner' ? null :
    { buckets: ['<24h', '1–2d', '2–3d', '3–5d', '5–7d', '7–9d', '9–11d', '11–13d', '13–14d'], values: [34, 22, 14, 9, 7, 5, 4, 3, 2] };
  const quality = def.provenance === 'partner'
    ? [{ name: 'Campaign ID recognition rate', value: 100, floor: 98, unit: '%' },
       { name: 'Partner file freshness', value: 4, floor: null, unit: ' days' }]
    : [{ name: 'Shopper identity match rate', value: +(94.4 + seed * 3).toFixed(1), floor: 95, unit: '%' },
       { name: 'Campaign ID recognition rate', value: 99.8, floor: 98, unit: '%' },
       { name: 'Product mapping rate', value: +(96.2 + seed * 2).toFixed(1), floor: 95, unit: '%' },
       { name: 'Attribution eligibility rate', value: +(86.5 + seed * 4).toFixed(1), floor: 85, unit: '%' },
       { name: 'Attribution link creation rate', value: +(93.1 + seed * 3).toFixed(1), floor: 90, unit: '%' },
       { name: 'Late-arriving data rate', value: +(1.2 + seed).toFixed(1), floor: null, unit: '%' }];

  const windowCloses = new Date(wTo.start.getTime() + (6 + def.windowDays) * 864e5);
  return {
    id: cmId, name: def.name, advertiser: PROGRAM.advertiser, kind: def.kind,
    provenance: def.provenance, state: def.state, note: def.note,
    flight: `${wFrom.label} – ${new Date(wTo.start.getTime() + 6 * 864e5).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}`,
    windowDays: def.windowDays,
    windowCloses: windowCloses.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
    day: Math.min((today.idx - wFrom.idx + 1) * 7, (wTo.idx - wFrom.idx + 1) * 7),
    ofDays: (wTo.idx - wFrom.idx + 1) * 7,
    maturity: def.state === 'live' ? 'Maturing' : 'Final',
    products: def.products.map(p => PRODUCTS.find(x => x.id === p).name).join(', '),
    productCount: def.products.length,
    hasPlan: true, budget: def.plannedSpend,
    benchKey: benchKey(def), benchLabel: BENCH[benchKey(def)].label,
    adgroupCount: def.adgroups.length,
    adCount: def.adgroups.reduce((s, g) => s + g.ads.length, 0),
    segments: [...new Set(def.adgroups.map(g => SEGMENTS.find(s => s.id === g.segment).name))],
    T, cuts, funnel, daily, profile, ttp, quality
  };
}

/* benchmark lookup keyed by provenance rather than campaign id */
function benchFor(k, c) { const b = BENCH[c.benchKey || 'onsite_search']; return b ? b[k] : null; }
