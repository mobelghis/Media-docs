/* ==================================================================
   THE DATA MODEL
   One fact table at the finest grain. Every number on every screen is
   aggregated from it, so filters and drill-downs are real.
   Fictional data, deterministic (seeded), internally consistent.
================================================================== */

function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
const rnd = mulberry32(20261001);
const jitter = (v, pct) => v * (1 + (rnd() - 0.5) * 2 * pct);

/* ---------- dimensions ---------- */
const PROGRAM = { id: 'autumn26', name: 'Aurelia Foods · Autumn 2026', advertiser: 'Aurelia Foods', retailer: 'Nordmark', budget: 240000 };

const WEEKS = [];
(function () {
  const start = new Date(Date.UTC(2026, 7, 17));           // Mon 17 Aug 2026
  for (let i = 0; i < 13; i++) {
    const d = new Date(start.getTime() + i * 7 * 864e5);
    WEEKS.push({ id: 'w' + (33 + i), idx: i, start: d, label: d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) });
  }
})();
const weekById = id => WEEKS.find(w => w.id === id);

const PRODUCTS = [
  { id: 'u1', name: 'Oat & Honey Granola 500g', brand: 'Aurelia', cat: 'Breakfast cereals', upc: '5012345 100018', price: 4.20 },
  { id: 'u2', name: 'Nut Crunch Granola 500g', brand: 'Aurelia', cat: 'Breakfast cereals', upc: '5012345 100025', price: 4.60 },
  { id: 'u3', name: 'Berry Granola 400g', brand: 'Aurelia', cat: 'Breakfast cereals', upc: '5012345 100032', price: 3.95 },
  { id: 'u4', name: 'Protein Granola 400g', brand: 'Aurelia', cat: 'Breakfast cereals', upc: '5012345 100049', price: 5.10 },
  { id: 'u5', name: 'Muesli Classic 750g', brand: 'Aurelia', cat: 'Breakfast cereals', upc: '5012345 100056', price: 3.60 },
  { id: 'u6', name: 'Granola Bar Multipack', brand: 'Aurelia', cat: 'Snacking', upc: '5012345 100063', price: 2.80 },
  { id: 'u7', name: 'Porridge Oats 1kg', brand: 'Aurelia', cat: 'Hot cereals', upc: '5012345 100070', price: 2.40 }
];

const SEGMENTS = [
  { id: 's1', name: 'Breakfast cereal buyers', size: 3300000, lift: 0.55 },
  { id: 's2', name: 'Health-snack buyers', size: 537000, lift: 3.10 },
  { id: 's3', name: 'Premium breakfast buyers', size: 477000, lift: 1.85 },
  { id: 's4', name: 'Porridge / yoghurt buyers', size: 505000, lift: 0.75 }
];
const BANNERS = [
  { id: 'b1', name: 'Nordmark Hyper', w: 0.47, lift: 1.00 },
  { id: 'b2', name: 'Nordmark City', w: 0.35, lift: 0.97 },
  { id: 'b3', name: 'Nordmark Online', w: 0.18, lift: 1.06 }
];
const CHANNELS = [
  { id: 'c1', name: 'Hypermarket', w: 0.59 },
  { id: 'c2', name: 'Supermarket', w: 0.34 },
  { id: 'c3', name: 'E-commerce', w: 0.07 }
];

/* ---------- campaign → ad group → ad ---------- */
const CAMPAIGN_DEFS = [
  {
    id: 'cm1', name: 'Granola launch — Onsite', kind: 'Onsite sponsored products', provenance: 'measured',
    from: 'w37', to: 'w41', windowDays: 14, spend: 33600, plannedSpend: 33540, plannedImpressions: 7800000,
    state: 'live', products: ['u1', 'u2', 'u3', 'u4'], convBase: 0.00160, note: 'Launch of the new granola range across all banners.',
    adgroups: [
      { id: 'g1', name: 'Cereal buyers — search', segment: 's1', placement: 'Search · sponsored', ctrLift: 1.55, share: 0.38,
        ads: [{ id: 'a1', name: 'Pack shot + price', creative: 'Pack shot + price', w: 0.58 }, { id: 'a2', name: 'Lifestyle breakfast', creative: 'Lifestyle breakfast', w: 0.42 }] },
      { id: 'g2', name: 'Health-snack — search', segment: 's2', placement: 'Search · sponsored', ctrLift: 1.60, share: 0.22,
        ads: [{ id: 'a3', name: 'Ingredient close-up', creative: 'Ingredient close-up', w: 0.62 }, { id: 'a4', name: 'Recipe video', creative: 'Recipe video', w: 0.38 }] },
      { id: 'g3', name: 'Premium — category banner', segment: 's3', placement: 'Category banner', ctrLift: 0.92, share: 0.22,
        ads: [{ id: 'a5', name: 'Pack shot + price', creative: 'Pack shot + price', w: 0.55 }, { id: 'a6', name: 'Lifestyle breakfast', creative: 'Lifestyle breakfast', w: 0.45 }] },
      { id: 'g4', name: 'Porridge — home carousel', segment: 's4', placement: 'Home carousel', ctrLift: 1.05, share: 0.18,
        ads: [{ id: 'a7', name: 'Lifestyle breakfast', creative: 'Lifestyle breakfast', w: 0.6 }, { id: 'a8', name: 'Ingredient close-up', creative: 'Ingredient close-up', w: 0.4 }] }
    ]
  },
  {
    id: 'cm2', name: 'Granola launch — Meta', kind: 'Walled garden · Meta', provenance: 'partner',
    from: 'w37', to: 'w41', windowDays: 14, spend: 35000, plannedSpend: 35000, plannedImpressions: 6000000,
    state: 'live', products: ['u1', 'u2', 'u3', 'u4'], convBase: 0.00190, note: 'Offsite reach campaign. The partner returns totals only.',
    adgroups: [
      { id: 'g5', name: 'Feed — broad', segment: 's1', placement: 'Feed', ctrLift: 2.2, share: 0.55,
        ads: [{ id: 'a9', name: 'Pack shot + price', creative: 'Pack shot + price', w: 0.6 }, { id: 'a10', name: 'Lifestyle breakfast', creative: 'Lifestyle breakfast', w: 0.4 }] },
      { id: 'g6', name: 'Reels — younger', segment: 's2', placement: 'Reels', ctrLift: 2.4, share: 0.30,
        ads: [{ id: 'a11', name: 'Recipe video', creative: 'Recipe video', w: 1 }] },
      { id: 'g7', name: 'Stories', segment: 's3', placement: 'Stories', ctrLift: 2.1, share: 0.15,
        ads: [{ id: 'a12', name: 'Lifestyle breakfast', creative: 'Lifestyle breakfast', w: 1 }] }
    ]
  },
  {
    id: 'cm3', name: 'Back-to-school snacks — Email', kind: 'Email · shopper-level', provenance: 'measured',
    from: 'w36', to: 'w37', windowDays: 14, spend: 12500, plannedSpend: 12500, plannedImpressions: 420000,
    state: 'final', products: ['u6', 'u1'], convBase: 0.02100, note: 'Two-week email push on snacking before term start.',
    adgroups: [
      { id: 'g8', name: 'Families — newsletter', segment: 's1', placement: 'Email · newsletter', ctrLift: 1.45, share: 0.62,
        ads: [{ id: 'a13', name: 'Lunchbox hero', creative: 'Lunchbox hero', w: 1 }] },
      { id: 'g9', name: 'Health-snack — triggered', segment: 's2', placement: 'Email · triggered', ctrLift: 1.85, share: 0.38,
        ads: [{ id: 'a14', name: 'Ingredient close-up', creative: 'Ingredient close-up', w: 1 }] }
    ]
  },
  {
    id: 'cm4', name: 'Breakfast range — Onsite display', kind: 'Onsite display', provenance: 'measured',
    from: 'w34', to: 'w36', windowDays: 14, spend: 18400, plannedSpend: 20000, plannedImpressions: 5200000,
    state: 'final', products: ['u1', 'u2', 'u5'], convBase: 0.00190, note: 'Always-on range support before the launch.',
    adgroups: [
      { id: 'g10', name: 'Cereal buyers — banner', segment: 's1', placement: 'Category banner', ctrLift: 0.85, share: 0.6,
        ads: [{ id: 'a15', name: 'Pack shot + price', creative: 'Pack shot + price', w: 1 }] },
      { id: 'g11', name: 'Premium — home', segment: 's3', placement: 'Home carousel', ctrLift: 1.0, share: 0.4,
        ads: [{ id: 'a16', name: 'Lifestyle breakfast', creative: 'Lifestyle breakfast', w: 1 }] }
    ]
  },
  {
    id: 'cm5', name: 'Porridge winter — Onsite', kind: 'Onsite sponsored products', provenance: 'measured',
    from: 'w39', to: 'w42', windowDays: 14, spend: 21000, plannedSpend: 22000, plannedImpressions: 4600000,
    state: 'live', products: ['u7', 'u5'], convBase: 0.00300, note: 'Seasonal switch into hot cereals.',
    adgroups: [
      { id: 'g12', name: 'Porridge buyers — search', segment: 's4', placement: 'Search · sponsored', ctrLift: 1.4, share: 0.58,
        ads: [{ id: 'a17', name: 'Pack shot + price', creative: 'Pack shot + price', w: 1 }] },
      { id: 'g13', name: 'Cereal switchers — banner', segment: 's1', placement: 'Category banner', ctrLift: 0.9, share: 0.42,
        ads: [{ id: 'a18', name: 'Ingredient close-up', creative: 'Ingredient close-up', w: 1 }] }
    ]
  },
  {
    id: 'cm6', name: 'Christmas baking — Onsite', kind: 'Onsite sponsored products', provenance: 'measured',
    from: 'w45', to: 'w48', windowDays: 14, spend: 0, plannedSpend: 55000, plannedImpressions: 11000000,
    state: 'planned', products: ['u1', 'u2', 'u5'], note: 'Measurement rules fixed. No data until it launches.',
    adgroups: []
  }
];

/* ---------- generate the fact table ---------- */
const FACTS = [];
(function build() {
  CAMPAIGN_DEFS.forEach(cm => {
    if (cm.state === 'planned') return;
    const wFrom = weekById(cm.from).idx, wTo = weekById(cm.to).idx;
    const nWeeks = wTo - wFrom + 1;
    const totalImp = cm.plannedImpressions * (cm.id === 'cm1' ? 1.79 : cm.id === 'cm4' ? 0.92 : cm.id === 'cm2' ? 1.03 : 1.05);
    cm.adgroups.forEach(g => {
      const seg = SEGMENTS.find(s => s.id === g.segment);
      g.ads.forEach(ad => {
        for (let wi = wFrom; wi <= wTo; wi++) {
          // weekly delivery curve: ramp up, peak, taper
          const t = (wi - wFrom) / Math.max(1, nWeeks - 1);
          const curve = 0.6 + 0.8 * Math.sin(Math.PI * Math.min(1, t * 1.15));
          BANNERS.forEach(b => {
            cm.products.forEach(pid => {
              const prod = PRODUCTS.find(p => p.id === pid);
              const prodW = 1 / cm.products.length * (pid === cm.products[0] ? 1.7 : pid === cm.products[1] ? 1.1 : 0.7);
              const imp = Math.round(jitter(totalImp * g.share * ad.w * b.w * prodW * curve / nWeeks, 0.12));
              if (imp < 200) return;
              const ctrBase = cm.provenance === 'partner' ? 0.0063 : (cm.id === 'cm3' ? 0.055 : 0.0028);
              const creativeLift = ad.creative === 'Recipe video' ? 1.55 : ad.creative === 'Lifestyle breakfast' ? 1.08 : ad.creative === 'Ingredient close-up' ? 1.02 : 0.93;
              const clicks = Math.round(imp * jitter(ctrBase * g.ctrLift / 1.5 * creativeLift, 0.1));
              const spend = cm.spend * (imp / totalImp);
              // conversion: segment quality drives it, with a small creative effect
              const convBase = cm.convBase;
              const buyers = Math.max(0, Math.round(imp * jitter(convBase * seg.lift * b.lift * (ad.creative === 'Recipe video' ? 0.55 : 1), 0.15)));
              if (buyers === 0) return;
              // a weak, broad audience carries more shoppers new to the brand; a tight, efficient one is mostly existing buyers
              const newShare = Math.min(0.5, Math.max(0.05, jitter(0.44 / Math.max(0.5, seg.lift), 0.12)));
              const lapsedShare = Math.min(0.3, Math.max(0.03, jitter(0.17 / Math.max(0.6, seg.lift), 0.15)));
              const txns = Math.round(buyers * jitter(1.11, 0.03));
              const units = Math.round(txns * jitter(1.10, 0.04));
              const sales = +(units * prod.price * jitter(1, 0.05)).toFixed(2);
              const raw = CHANNELS.map(ch => ch.id === 'c3' ? (b.id === 'b3' ? 0.46 : 0.02) : ch.w);
              const rawSum = raw.reduce((a, x) => a + x, 0);
              CHANNELS.forEach((ch, ci) => {
                const chW = raw[ci] / rawSum;
                const cb = Math.round(buyers * chW);
                if (cb < 1) return;
                FACTS.push({
                  program: PROGRAM.id, campaign: cm.id, adgroup: g.id, ad: ad.id,
                  placement: g.placement, banner: b.name, channel: ch.name,
                  segment: seg.name, creative: ad.creative, product: prod.name, upc: prod.upc,
                  category: prod.cat, week: WEEKS[wi].id,
                  impressions: Math.round(imp * chW), clicks: Math.round(clicks * chW),
                  spend: +(spend * chW).toFixed(2), buyers: cb,
                  txns: Math.round(txns * chW), units: Math.round(units * chW),
                  sales: +(sales * chW).toFixed(2),
                  newBuyers: Math.round(buyers * chW * newShare), lapsedBuyers: Math.round(buyers * chW * lapsedShare)
                });
              });
            });
          });
        }
      });
    });
  });
})();

/* halo: sales on the brand's other products, credited inside the window.
   Computable in Phase 1 — it needs no control group, only the brand's product tree. */
(function addHalo() {
  FACTS.forEach(r => {
    const h = 0.11 + (r.segment === 'Health-snack buyers' ? 0.06 : 0) + (r.channel === 'E-commerce' ? 0.03 : 0);
    r.haloSales = +(r.sales * h).toFixed(2);
    r.directSales = +(r.sales - r.haloSales).toFixed(2);
    // sales made by shoppers new to the brand or won back, against sales to existing buyers
    const nShare = r.buyers ? (r.newBuyers + r.lapsedBuyers) / r.buyers : 0;
    r.newBuyerSales = +(r.sales * nShare).toFixed(2);
    r.existingBuyerSales = +(r.sales - r.newBuyerSales).toFixed(2);
  });
})();

/* spend is booked at campaign level: scale the generated rows so each campaign sums to its real spend */
(function normaliseSpend() {
  CAMPAIGN_DEFS.forEach(cm => {
    const rows = FACTS.filter(r => r.campaign === cm.id);
    const got = rows.reduce((s, r) => s + r.spend, 0);
    if (!got) return;
    const k = cm.spend / got;
    rows.forEach(r => { r.spend = +(r.spend * k).toFixed(4); });
  });
})();

/* ---------- lookups ---------- */
const CAMPAIGN_BY_ID = {}; CAMPAIGN_DEFS.forEach(c => CAMPAIGN_BY_ID[c.id] = c);
const ADGROUPS = []; const ADS = [];
CAMPAIGN_DEFS.forEach(c => c.adgroups.forEach(g => {
  ADGROUPS.push(Object.assign({ campaign: c.id }, g));
  g.ads.forEach(a => ADS.push(Object.assign({ campaign: c.id, adgroup: g.id }, a)));
}));
const nameOf = {
  campaign: id => (CAMPAIGN_BY_ID[id] || {}).name || id,
  adgroup: id => (ADGROUPS.find(g => g.id === id) || {}).name || id,
  ad: id => (ADS.find(a => a.id === id) || {}).name || id
};

/* The decomposition chain. Every step below is a measured quantity:
     all brand sales by reached shoppers  →  what we can link to an ad  →  how it splits.
   Nothing here needs a control group. */
(function decomposition() {
  FACTS.forEach(r => {
    const cm = CAMPAIGN_BY_ID[r.campaign];
    // of the brand buying these shoppers did in the window, the share a qualifying exposure precedes
    const linkRate = cm.provenance === 'partner' ? 0.34 : (/Email/i.test(cm.kind) ? 0.61 : 0.48);
    r.allBrandSales = +(r.sales / linkRate).toFixed(2);
    r.unlinkedSales = +(r.allBrandSales - r.sales).toFixed(2);
    // post-click against post-view, within what we credit
    const clickShare = cm.provenance === 'partner' ? 0.41 : (/Email/i.test(cm.kind) ? 0.72 : 0.27);
    r.clickSales = +(r.sales * clickShare).toFixed(2);
    r.viewSales = +(r.sales - r.clickSales).toFixed(2);
  });
})();

/* ---------- aggregation ---------- */
const MEASURE_DEFS = {
  impressions: { label: 'Impressions', fmt: v => F.compact(v), sum: true },
  clicks:      { label: 'Clicks', fmt: v => F.compact(v), sum: true },
  spend:       { label: 'Media spend', fmt: v => F.money(v), sum: true },
  buyers:      { label: 'Attributed buyers', fmt: v => F.int(v), sum: true },
  newBuyers:   { label: 'New-to-brand buyers', fmt: v => F.int(v), sum: true },
  lapsedBuyers:{ label: 'Lapsed buyers won back', fmt: v => F.int(v), sum: true },
  directSales: { label: 'Direct sales (promoted products)', fmt: v => F.moneyC(v), sum: true },
  haloSales:   { label: 'Halo sales (brand\'s other products)', fmt: v => F.moneyC(v), sum: true },
  allBrandSales:{ label: 'All brand sales by reached shoppers', fmt: v => F.moneyC(v), sum: true },
  unlinkedSales:{ label: 'Brand sales we cannot link to an ad', fmt: v => F.moneyC(v), sum: true },
  clickSales:  { label: 'Sales after a click', fmt: v => F.moneyC(v), sum: true },
  viewSales:   { label: 'Sales after a view only', fmt: v => F.moneyC(v), sum: true },
  newBuyerSales:{ label: 'Sales to new or lapsed buyers', fmt: v => F.moneyC(v), sum: true },
  existingBuyerSales:{ label: 'Sales to existing buyers', fmt: v => F.moneyC(v), sum: true },
  linkRate:    { label: 'Share of brand sales we can link', fmt: v => F.pct1(v), derive: r => r.allBrandSales ? r.sales / r.allBrandSales * 100 : null },
  sales:       { label: 'Attributed sales', fmt: v => F.moneyC(v), sum: true },
  txns:        { label: 'Attributed transactions', fmt: v => F.int(v), sum: true },
  units:       { label: 'Attributed units', fmt: v => F.int(v), sum: true },
  ctr:         { label: 'Click-through rate', fmt: v => F.pct2(v), derive: r => r.impressions ? r.clicks / r.impressions * 100 : null },
  cpm:         { label: 'CPM', fmt: v => F.money2(v), derive: r => r.impressions ? r.spend / r.impressions * 1000 : null },
  roas:        { label: 'Attributed ROAS', fmt: v => F.x(v), derive: r => r.spend ? r.sales / r.spend : null },
  cpBuyer:     { label: 'Cost per buyer', fmt: v => F.money2(v), derive: r => r.buyers ? r.spend / r.buyers : null },
  salesPerBuyer:{ label: 'Sales per buyer', fmt: v => F.money2(v), derive: r => r.buyers ? r.sales / r.buyers : null },
  avgTxn:      { label: 'Average transaction', fmt: v => F.money2(v), derive: r => r.txns ? r.sales / r.txns : null },
  unitsPerTxn: { label: 'Units per transaction', fmt: v => F.dec(v), derive: r => r.txns ? r.units / r.txns : null },
  pricePerUnit:{ label: 'Price per unit', fmt: v => F.money2(v), derive: r => r.units ? r.sales / r.units : null },
  newShare:    { label: 'New-to-brand share', fmt: v => F.pct1(v), derive: r => r.buyers ? (r.newBuyers + r.lapsedBuyers) / r.buyers * 100 : null },
  cpNewBuyer:  { label: 'Cost per new or lapsed buyer', fmt: v => F.money2(v), derive: r => (r.newBuyers + r.lapsedBuyers) ? r.spend / (r.newBuyers + r.lapsedBuyers) : null }
};
const SUM_KEYS = ['impressions', 'clicks', 'spend', 'buyers', 'sales', 'txns', 'units', 'newBuyers', 'lapsedBuyers', 'directSales', 'haloSales', 'allBrandSales', 'unlinkedSales', 'clickSales', 'viewSales', 'newBuyerSales', 'existingBuyerSales'];

function emptyAgg() { const o = {}; SUM_KEYS.forEach(k => o[k] = 0); return o; }
function addInto(o, r) { SUM_KEYS.forEach(k => o[k] += r[k] || 0); return o; }
function withDerived(o) {
  Object.keys(MEASURE_DEFS).forEach(k => { const d = MEASURE_DEFS[k].derive; if (d) o[k] = d(o); });
  return o;
}

function filterFacts(f) {
  return FACTS.filter(r => {
    if (f.campaigns && f.campaigns.length && !f.campaigns.includes(r.campaign)) return false;
    if (f.adgroups && f.adgroups.length && !f.adgroups.includes(r.adgroup)) return false;
    if (f.ads && f.ads.length && !f.ads.includes(r.ad)) return false;
    if (f.weekFrom && weekById(r.week).idx < weekById(f.weekFrom).idx) return false;
    if (f.weekTo && weekById(r.week).idx > weekById(f.weekTo).idx) return false;
    if (f.dims) for (const k in f.dims) { const v = f.dims[k]; if (v && v.length && !v.includes(r[k])) return false; }
    return true;
  });
}
function total(rows) { return withDerived(rows.reduce((o, r) => addInto(o, r), emptyAgg())); }
function groupBy(rows, key) {
  const m = new Map();
  rows.forEach(r => { const k = r[key]; if (!m.has(k)) m.set(k, emptyAgg()); addInto(m.get(k), r); });
  return [...m.entries()].map(([k, v]) => Object.assign({ key: k, name: nameOf[key] ? nameOf[key](k) : k }, withDerived(v)));
}
function groupBy2(rows, keys) {
  const m = new Map();
  rows.forEach(r => {
    const k = keys.map(x => r[x]).join('␟');
    if (!m.has(k)) m.set(k, { _k: keys.map(x => r[x]), agg: emptyAgg() });
    addInto(m.get(k).agg, r);
  });
  return [...m.values()].map(v => {
    const o = withDerived(v.agg);
    keys.forEach((x, i) => o[x] = nameOf[x] ? nameOf[x](v._k[i]) : v._k[i]);
    o._raw = v._k;
    return o;
  });
}

const DIM_DEFS = [
  { key: 'campaign', label: 'Campaign' }, { key: 'adgroup', label: 'Ad group' }, { key: 'ad', label: 'Ad' },
  { key: 'segment', label: 'Audience segment' }, { key: 'placement', label: 'Placement' },
  { key: 'banner', label: 'Retail banner' }, { key: 'channel', label: 'Purchase channel' },
  { key: 'creative', label: 'Creative' }, { key: 'category', label: 'Product category' },
  { key: 'product', label: 'Product' }, { key: 'upc', label: 'UPC' }, { key: 'week', label: 'Week' }
];
const HIERARCHY = ['campaign', 'adgroup', 'ad'];
