# The working prototype

Open `index.html` in any browser. Nothing to install.

The single file is everything. The separate source files beside it are the same
code before it was joined together, if you want to read it in pieces:

| File | What is in it |
|---|---|
| `model.js` | The made-up data, at the finest grain, plus the filtering and grouping |
| `derive.js` | Turns fact rows into the shape the engine expects |
| `engine.js` | **The Scout, Skeptic, Advisor, Explainer and Editor** |
| `composer.js` | **The Composer** |
| `charts.js` | Every chart |
| `app.js` | The screens |
| `style.css` | How it looks |

In the prototype the wording is produced by templates rather than AI calls, so
it runs with no network and no key. The real thing swaps those templates for the
calls described in `../agents/`. Everything else — the finding detection, the
rules, the scoring, the sums, the layout decisions — is exactly the logic to
build.

## What to click

1. **Program** — change the week range and watch the campaign list change. Click
   a bar to go program → campaign → ad group → ad.
2. **Deep dive** — add and remove dimensions and fields. Put `product` and `upc`
   down the side to get to the finest level.
3. Press **build the deck** on "Granola launch — Onsite".
4. **Story** — change the goal between the three and watch the story reshape.
   Remove a finding; it goes to the archive and comes back.
5. **Evidence** — every finding that was killed, and why.
6. **Deck** — nine findings on six slides. Open "why this layout?" on any slide.
7. Switch to **Granola launch — Meta** on the program page to see what a walled
   garden does to the story.

All figures are invented but internally consistent: the breakdowns add up to the
campaign totals, and the rates are worked out from them.
