/* ==================================================================
   UI — three places: Program · Campaign · Explore
   Campaign holds three steps: Brief → Story → Deck
================================================================== */
const S = {
  place: 'program',
  step: 'brief',
  weekFrom: 'w34', weekTo: 'w42',
  sortBy: 'attention',
  compare: [],
  campaignId: null, c: null, run: null, comp: null,
  docType: 'closeout',
  audience: 'The supplier',
  removed: {}, archive: [], edits: {},
  openFinding: null, setAside: false, setAsideTab: 'rejected',
  drill: [], drillMeasure: 'sales',
  deep: { set: 'core', dims: ['campaign', 'product'], measures: null, sortKey: 'sales', sortDir: -1, limit: 30, detail: null },
  modal: null, signed: false
};

const I = {
  chev: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg>',
  check: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>',
  x: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>',
  plus: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  dl: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>',
  lock: '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
  warn: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/></svg>',
  gap: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9" stroke-dasharray="3 3"/></svg>',
  back: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>'
};

/* ---------- helpers ---------- */
const filt = () => ({ weekFrom: S.weekFrom, weekTo: S.weekTo });
const provChip = c => c.provenance === 'measured'
  ? `<span class="prov meas">${I.check} Measured by us</span>`
  : `<span class="prov part">Partner-reported</span>`;
const gradeChip = f => f.grade === 'directional'
  ? `<span class="grade dir">Directional</span>` : `<span class="grade ok">Stands up</span>`;
const docLabel = () => GOALS[S.docType].label;
const srcLine = (c, n, total) =>
  `${PROGRAM.retailer} loyalty card holders · ${c.name} · flight ${c.flight} · ${c.windowDays}-day post-view / post-click window, last touch · ${c.provenance === 'measured' ? 'measured by us' : 'partner-reported totals'} · ${c.maturity.toLowerCase()}, window closes ${c.windowCloses} · attributed, not incremental · ${docLabel()} · internal &amp; confidential${n ? ` · ${n} of ${total}` : ''}`;
const story = () => S.run ? S.run.story.filter(f => !S.removed[f.id]) : [];

/* numbers inside an editable sentence are locked tokens, not text */
const lockNumbers = html => (html || '').replace(/<b>(.*?)<\/b>/g, '<span class="lk" contenteditable="false">$1</span>');

function loadCampaign(id) {
  S.campaignId = id; S.c = deriveCampaign(id);
  S.removed = {}; S.edits = {}; S.archive = []; S.drill = []; S.signed = false;
  rebuild();
}
function rebuild() {
  if (!S.c) return;
  S.run = runEngine(S.c, S.docType, 9);
  S.comp = compose(story(), S.c, S.docType);
}

/* ---------- what needs you: the triage reason per campaign ---------- */
function attention(def, agg) {
  const out = [];
  if (def.state === 'planned') return [{ t: 'Starts ' + weekById(def.from).label, k: 'none', rank: 9 }];
  const pace = agg.impressions / def.plannedImpressions;
  const elapsed = Math.min(1, Math.max(0.05, (weekById('w40').idx - weekById(def.from).idx + 1) / (weekById(def.to).idx - weekById(def.from).idx + 1)));
  if (def.state === 'live' && pace / elapsed < 0.8) out.push({ t: 'Behind plan — ' + F.pct1(pace / elapsed * 100) + ' of the pace we sold', k: 'bad', rank: 1 });
  if (def.state === 'live' && pace / elapsed > 1.45) out.push({ t: 'Over-delivering — ' + F.x(pace / elapsed) + ' the pace, at our cost', k: 'warn', rank: 2 });
  if (def.provenance === 'partner') out.push({ t: 'Partner file only — shopper questions cannot be answered', k: 'warn', rank: 5 });
  if (def.state === 'final') out.push({ t: 'Window closed — the report is due', k: 'bad', rank: 1 });
  if (def.state === 'live' && weekById(def.to).idx - weekById('w40').idx <= 1) out.push({ t: 'Ends this week — report due in ' + def.windowDays + ' days', k: 'warn', rank: 3 });
  if (!out.length) out.push({ t: 'Running to plan', k: 'none', rank: 8 });
  return out.sort((a, b) => a.rank - b.rank);
}

/* ---------- header ---------- */
function vHeader() {
  const places = [['program', 'Program'], ['campaign', 'Campaign'], ['explore', 'Explore']];
  return `<header class="top">
    <div class="topin">
      <div class="mk">Retail Media <span>/ Measurement</span></div>
      <div class="pk"><span class="lbl">Retailer</span><b>${PROGRAM.retailer}</b></div>
      <div class="pk"><span class="lbl">Supplier</span><b>${PROGRAM.advertiser}</b></div>
      ${S.c ? `<div class="pk"><span class="lbl">Campaign</span><b>${S.c.name}</b></div>` : ''}
      <div class="grow"></div>
      <div class="sy"><span class="dot"></span>week 40 · ${FACTS.length.toLocaleString('en-GB')} rows</div>
    </div>
    <nav class="tabs">
      ${places.map(([k, l]) => `<button data-act="place" data-k="${k}" class="${S.place === k ? 'on' : ''} ${k === 'campaign' && !S.c ? 'dim' : ''}">${l}</button>`).join('')}
      ${S.place === 'campaign' && S.c ? `<span class="steps">${[['brief', '1 Brief'], ['story', '2 Story'], ['deck', '3 Deck']].map(([k, l]) =>
        `<button data-act="step" data-k="${k}" class="${S.step === k ? 'on' : ''}">${l}</button>`).join('')}</span>` : ''}
    </nav></header>`;
}

/* ================================================================
   PROGRAM — a chooser and a triage list
================================================================ */
function vProgram() {
  const rows = filterFacts(filt());
  const T = total(rows);
  const booked = CAMPAIGN_DEFS.reduce((s, c) => s + c.plannedSpend, 0);
  const byCam = groupBy(rows, 'campaign');
  const list = CAMPAIGN_DEFS.map(def => {
    const agg = byCam.find(r => r.key === def.id) || withDerived(emptyAgg());
    return { def, agg, att: attention(def, agg) };
  });
  if (S.sortBy === 'attention') list.sort((a, b) => a.att[0].rank - b.att[0].rank || b.agg.sales - a.agg.sales);
  else list.sort((a, b) => (b.agg[S.sortBy] || 0) - (a.agg[S.sortBy] || 0));

  const needing = list.filter(x => x.att[0].k !== 'none').length;
  const live = CAMPAIGN_DEFS.filter(c => c.state === 'live').length;

  return `<div class="wrap">
    <section class="state">
      <p class="statement">${live} campaigns running, <b>${F.money(T.spend)}</b> spent of ${F.money(booked)} booked,
        <b>${needing === 0 ? 'nothing' : needing + (needing === 1 ? ' campaign' : ' campaigns')}</b> ${needing === 1 ? 'needs' : 'need'} a decision this week.</p>
      <div class="weekpick"><span class="lbl">Conversion weeks</span>
        <select data-act="wk" data-k="weekFrom">${WEEKS.map(w => `<option value="${w.id}" ${S.weekFrom === w.id ? 'selected' : ''}>${w.label}</option>`).join('')}</select>
        <span class="to">to</span>
        <select data-act="wk" data-k="weekTo">${WEEKS.map(w => `<option value="${w.id}" ${S.weekTo === w.id ? 'selected' : ''}>${w.label}</option>`).join('')}</select>
      </div>
    </section>

    <section class="strip3">
      <div><div class="lbl">Spend against booked</div><div class="bv">${F.money(T.spend)}</div><div class="bs">${F.pct1(T.spend / booked * 100)} of ${F.money(booked)}</div></div>
      <div><div class="lbl">Attributed sales</div><div class="bv">${F.moneyC(T.sales)}</div><div class="bs">${F.int(T.buyers)} buyers · ${F.pct1(T.newShare)} new to the brand</div></div>
      <div><div class="lbl">Attributed ROAS</div><div class="bv">${F.x(T.roas)}</div><div class="bs notlift">Attributed, not incremental</div></div>
    </section>

    ${vDecomposition(T, `${CAMPAIGN_DEFS.filter(d => d.state !== 'planned').length} campaigns · weeks ${weekById(S.weekFrom).label} to ${weekById(S.weekTo).label}`)}

    <section class="panel">
      <div class="phead">
        <div><h2>Campaigns</h2><div class="note">Sorted by what needs you. Click a row to open it.</div></div>
        <div class="btnrow">
          <select data-act="sort"><option value="attention" ${S.sortBy === 'attention' ? 'selected' : ''}>Needs you first</option>
            <option value="sales" ${S.sortBy === 'sales' ? 'selected' : ''}>Attributed sales</option>
            <option value="spend" ${S.sortBy === 'spend' ? 'selected' : ''}>Spend</option>
            <option value="roas" ${S.sortBy === 'roas' ? 'selected' : ''}>ROAS</option></select>
          ${S.compare.length >= 2 ? `<button class="btn pri sm" data-act="compare">Compare ${S.compare.length} campaigns</button>` : ''}
        </div>
      </div>
      <div class="tw"><table class="dt rows">
        <thead><tr><th class="cb"></th><th>Campaign</th><th>Needs you</th><th>Numbers from</th>
          <th class="n">Spend</th><th class="n">Sales</th><th class="n">ROAS</th><th class="n">New to brand</th><th></th></tr></thead>
        <tbody>${list.map(({ def, agg, att }) => {
          const dead = def.state === 'planned';
          return `<tr class="${dead ? 'muted' : 'clickable'} ${S.campaignId === def.id ? 'sel' : ''}" ${dead ? '' : `data-act="open" data-id="${def.id}"`}>
            <td class="cb">${dead ? '' : `<input type="checkbox" data-act="cmp" data-id="${def.id}" ${S.compare.includes(def.id) ? 'checked' : ''} aria-label="Compare">`}</td>
            <td><b>${def.name}</b><div class="sub">${def.kind}</div></td>
            <td>${att.map(a => `<span class="att ${a.k}">${a.k === 'bad' ? I.warn : ''}${a.t}</span>`).join('')}</td>
            <td>${def.provenance === 'measured' ? `<span class="prov meas">${I.check} Measured</span>` : `<span class="prov part">Partner</span>`}</td>
            <td class="n">${dead ? F.money(def.plannedSpend) + ' planned' : F.money(agg.spend)}</td>
            <td class="n">${dead ? '—' : '<b>' + F.moneyC(agg.sales) + '</b>'}</td>
            <td class="n">${dead ? '—' : F.x(agg.roas)}</td>
            <td class="n">${dead ? '—' : F.pct1(agg.newShare)}</td>
            <td class="n">${dead ? '' : `<span class="go">Open ${I.chev}</span>`}</td>
          </tr>`;
        }).join('')}</tbody></table></div>
    </section>

    ${S.compare.length >= 2 ? vCompare() : ''}
  </div>`;
}

function vCompare() {
  const rows = S.compare.map(id => {
    const agg = total(filterFacts(Object.assign({ campaigns: [id] }, filt())));
    return { def: CAMPAIGN_BY_ID[id], agg };
  });
  const measures = ['spend', 'impressions', 'ctr', 'buyers', 'newShare', 'sales', 'roas', 'cpBuyer', 'cpNewBuyer'];
  const sumBuyers = rows.reduce((s, r) => s + r.agg.buyers, 0);
  return `<section class="panel warnpanel">
    <div class="phead"><h2>Comparing ${rows.length} campaigns</h2>
      <button class="btn sm" data-act="clearcmp">${I.x} Clear</button></div>
    <div class="tw"><table class="dt">
      <thead><tr><th>Measure</th>${rows.map(r => `<th class="n">${r.def.name}</th>`).join('')}</tr></thead>
      <tbody>${measures.map(k => `<tr><td>${MEASURE_DEFS[k].label}</td>${rows.map(r => `<td class="n">${MEASURE_DEFS[k].fmt(r.agg[k])}</td>`).join('')}</tr>`).join('')}</tbody>
    </table></div>
    <div class="cannot">${I.lock} <b>These are shown side by side, not added up.</b>
      Attributed buyers are de-duplicated inside a campaign but not across campaigns — ${F.int(sumBuyers)} is the sum of the columns, and some shoppers appear in more than one.
      A single combined figure needs shopper-level de-duplication, which is not built yet, so the product will not print one.</div>
  </section>`;
}


/* ================================================================
   DECOMPOSITION — every step measured, nothing assumed.
   Starts from all the brand buying these shoppers did, and shows how
   much of it we can stand behind and what it is made of.
================================================================ */
function vDecomposition(T, scopeLabel, opts) {
  opts = opts || {};
  const all = T.allBrandSales || 0;
  if (!all) return '';
  const pc = v => Math.max(0.4, v / all * 100);
  const step = (label, value, sub, cls, offset) => `<div class="dstep ${cls}">
    <div class="dsl"><b>${label}</b><span>${sub}</span></div>
    <div class="dsbar"><span class="dsfill ${cls}" style="width:${pc(value)}%;margin-left:${offset || 0}%"></span></div>
    <div class="dsv">${F.moneyC(value)}<em>${F.pct1(value / all * 100)}</em></div>
  </div>`;
  const splitRow = (title, a, b, la, lb, ca, cb) => `<div class="dsplit">
    <div class="dspl">${title}</div>
    <div class="dsbar2">
      <span class="s1 ${ca}" style="width:${a / (a + b) * 100}%"><em>${la}</em><b>${F.moneyC(a)}</b></span>
      <span class="s1 ${cb}" style="width:${b / (a + b) * 100}%"><em>${lb}</em><b>${F.moneyC(b)}</b></span>
    </div></div>`;

  return `<section class="panel decomp">
    <div class="phead">
      <div><h2>What the sales are made of</h2>
        <div class="note">${scopeLabel} · every step below is counted, not modelled.</div></div>
      ${opts.right || ''}
    </div>
    <div class="dsteps">
      ${step('All brand sales by the shoppers we reached', all, `inside the attribution window`, 'all')}
      ${step('Not linked to any ad', T.unlinkedSales, 'they bought, but no qualifying exposure came first', 'unlinked', T.linkRate)}
      ${step('Attributed to this campaign', T.sales, `${F.pct1(T.linkRate)} of their brand buying`, 'attr')}
    </div>
    <div class="dsplits">
      ${splitRow('How the credit was earned', T.clickSales, T.viewSales, 'After a click', 'After a view only', 'c1', 'c2')}
      ${splitRow('What was bought', T.directSales, T.haloSales, 'Direct — promoted products', 'Halo — the brand&rsquo;s other products', 'c1', 'c3')}
      ${splitRow('Who bought it', T.newBuyerSales, T.existingBuyerSales, 'New to the brand or won back', 'Already buying the brand', 'c4', 'c5')}
    </div>
    <div class="phase2">
      <div class="p2h">${I.lock} What this decomposition cannot reach</div>
      <div class="p2grid">
        ${[['Baseline', 'what these shoppers would have bought anyway'],
           ['Cannibalisation', 'sales pulled from the brand&rsquo;s other lines'],
           ['Pull-forward', 'purchases brought earlier, not added'],
           ['True incremental', 'what the campaign actually caused']].map(x =>
          `<div><b>${x[0]}</b><span>${x[1]}</span></div>`).join('')}
      </div>
      <p class="p2n">All four need a group of shoppers held back before the campaign starts. This campaign has none, so the product does not estimate them — not as a bar, not as a dotted outline, not as a footnote.
        <button class="linkb" data-act="holdout">Request a hold-out on the next flight ${I.chev}</button></p>
    </div>
  </section>`;
}

/* ================================================================
   CAMPAIGN — step 1, the brief
================================================================ */
function vBrief() {
  const c = S.c, T = c.T;
  const def = CAMPAIGN_BY_ID[c.id];
  const agg = total(filterFacts({ campaigns: [c.id] }));
  const att = attention(def, agg);

  const ready = [
    { ok: true, t: 'Exposure data has arrived', d: `${F.compact(T.impressions)} impressions across ${c.adgroupCount} ad groups and ${c.adCount} ads` },
    { ok: c.provenance === 'measured', t: c.provenance === 'measured' ? 'Purchases matched to shoppers' : 'No shopper-level purchases', d: c.provenance === 'measured' ? `Identity match ${c.quality[0].value}%` : 'The partner returns totals only, so buyer, basket and profile questions cannot be answered' },
    { ok: true, t: 'Product scope is set', d: `${c.productCount} promoted items · ${c.products}` },
    { ok: true, t: 'Window is configured', d: `${c.windowDays} days post-view and post-click, last touch` },
    { ok: c.state !== 'live', t: c.state === 'live' ? 'Window is still open' : 'Window has closed', d: c.state === 'live' ? `Closes ${c.windowCloses}. Figures can still rise, so treat today's as a floor.` : `Closed ${c.windowCloses}. Figures are final.` },
    { ok: false, t: 'No control group', d: 'Incremental sales need a group held back before the campaign starts. This campaign has none, so nothing here can say the ads caused the sales.' }
  ];
  const gaps = ready.filter(r => !r.ok).length;

  const level = HIERARCHY[S.drill.length + 1] || 'ad';
  const scoped = { campaigns: [c.id] };
  if (S.drill[0]) scoped.adgroups = [S.drill[0]];
  const drillRows = groupBy(filterFacts(scoped), S.drill.length ? 'ad' : 'adgroup')
    .sort((a, b) => (b[S.drillMeasure] || 0) - (a[S.drillMeasure] || 0));
  const md = MEASURE_DEFS[S.drillMeasure];
  const mx = Math.max(...drillRows.map(r => r[S.drillMeasure] || 0)) || 1;

  return `<div class="wrap">
    <button class="backlink" data-act="place" data-k="program">${I.back} All campaigns</button>

    <section class="verdict">
      <div>
        <div class="lbl">${c.kind} · ${c.flight}</div>
        <p class="statement">${c.provenance === 'measured'
          ? `<b>${F.int(T.buyers)}</b> shoppers bought within ${c.windowDays} days of seeing this campaign, worth <b>${F.moneyC(T.sales)}</b> — <b>${F.pct1(T.newShare)}</b> of them new to the brand or won back.`
          : `The partner reports <b>${F.compact(T.impressions)}</b> impressions and <b>${F.moneyC(T.sales)}</b> of sales. Nothing below the total can be checked against our own till data.`}</p>
        <div class="vchips">${provChip(c)}<span class="att ${att[0].k}">${att[0].t}</span>
          <span class="prov neutral">${c.maturity}${c.state === 'live' ? ' · window closes ' + c.windowCloses : ''}</span></div>
      </div>
    </section>

    <section class="panel brief">
      <h2>What is this report for?</h2>
      <div class="briefgrid">
        <div><span class="lbl">Document type</span>
          <div class="chips">${Object.keys(GOALS).map(k => `<button class="chip ${S.docType === k ? 'on' : ''}" data-act="doctype" data-k="${k}">${GOALS[k].label}</button>`).join('')}</div>
          <p class="note">${GOALS[S.docType].hint}</p></div>
        <div><span class="lbl">Who it is for</span>
          <div class="chips">${['The supplier', 'Internal only', 'Supplier procurement'].map(a => `<button class="chip ${S.audience === a ? 'on' : ''}" data-act="aud" data-k="${a}">${a}</button>`).join('')}</div>
          <p class="note">Printed on the cover and in every slide footer, and it cannot be removed from the export.</p></div>
      </div>
    </section>

    <section class="panel">
      <div class="phead"><h2>Can we tell this story yet?</h2>
        <span class="lbl">${ready.length - gaps} of ${ready.length} ready</span></div>
      <div class="readylist">${ready.map(r => `<div class="rl ${r.ok ? 'ok' : 'gap'}">
        <span class="ri">${r.ok ? I.check : I.gap}</span>
        <div><b>${r.t}</b><div class="rd">${r.d}</div></div></div>`).join('')}</div>
    </section>

    <div class="cols2">
      <section class="panel">
        <h2>What we bought</h2>
        <div class="dual media">${[['Spend', F.money(T.spend), `of ${F.money(c.budget)} booked`],
          ['Impressions', F.compact(T.impressions), `${F.x(T.impressions / T.estImpressions)} the plan`],
          ['Clicks', F.compact(T.clicks), `CTR ${F.pct2(T.ctr)}`],
          ['Shoppers reached', F.compact(T.reached), `frequency ${F.dec(T.frequency)}`]].map(x =>
          `<div><div class="lbl">${x[0]}</div><div class="dv">${x[1]}</div><div class="ds">${x[2]}</div></div>`).join('')}</div>
      </section>
      <section class="panel">
        <h2>What came back</h2>
        <div class="dual sales">${[['Attributed buyers', F.int(T.buyers), `${F.pct3(T.convRate)} of those available`],
          ['New or won back', F.int(Math.round(T.buyers * T.newShare / 100)), `${F.pct1(T.newShare)} · ${F.money2(T.cpNewBuyer)} each`],
          ['Attributed sales', F.moneyC(T.sales), `${F.money2(T.salesPerBuyer)} per buyer`],
          ['Attributed ROAS', F.x(T.roas), 'not incremental']].map(x =>
          `<div><div class="lbl">${x[0]}</div><div class="dv">${x[1]}</div><div class="ds">${x[2]}</div></div>`).join('')}</div>
      </section>
    </div>

    ${c.provenance === 'measured' ? vDecomposition(c.T, `${c.name} · ${c.windowDays}-day window`) : `<section class="panel"><div class="phead"><h2>What the sales are made of</h2></div>
      <p class="cannot">${I.lock} <b>Nothing can be decomposed for a walled-garden campaign.</b> The partner returns a sales total and no shopper identities, so the product cannot say how much of it was direct or halo, how much came after a click, or how many buyers were new. The total is shown as received and never blended with measured results.</p></section>`}

    <section class="panel">
      <div class="phead">
        <div><h2>Where it came from</h2>
          <div class="crumbs">${['Campaign', ...S.drill.map(id => nameOf.adgroup(id))].map((t, i, a) =>
            `<button class="crumb ${i === a.length - 1 ? 'on' : ''}" data-act="undrill" data-i="${i}">${t}</button>${i < a.length - 1 ? `<span class="csep">${I.chev}</span>` : ''}`).join('')}</div></div>
        <select data-act="drillmeasure">${['sales', 'buyers', 'newBuyers', 'impressions', 'clicks', 'spend', 'roas', 'ctr'].map(k =>
          `<option value="${k}" ${S.drillMeasure === k ? 'selected' : ''}>${MEASURE_DEFS[k].label}</option>`).join('')}</select>
      </div>
      <div class="dbars">${drillRows.map(r => `<button class="dbar ${S.drill.length ? '' : 'can'}" ${S.drill.length ? 'disabled' : `data-act="drill" data-id="${r.key}"`}>
        <span class="dname">${r.name}</span>
        <span class="dtrack"><span class="dfill" style="width:${Math.max(1, (r[S.drillMeasure] || 0) / mx * 100)}%"></span></span>
        <span class="dval">${md.fmt(r[S.drillMeasure])}</span>
        ${S.drill.length ? '' : `<span class="dgo">${I.chev}</span>`}</button>`).join('')}</div>
    </section>

    <div class="sticky">
      <label class="sign"><input type="checkbox" data-act="sign" ${S.signed ? 'checked' : ''}>
        I have read the readiness block${gaps ? ` and the ${gaps} gap${gaps > 1 ? 's' : ''} above` : ''}</label>
      <div class="grow"></div>
      <button class="btn" data-act="place" data-k="explore">Open in Explore</button>
      <button class="btn pri ${S.signed ? '' : 'off'}" data-act="buildstory" ${S.signed ? '' : 'disabled'}>Build the story ${I.chev}</button>
    </div>
  </div>`;
}

/* ================================================================
   CAMPAIGN — step 2, the story
================================================================ */
function vStory() {
  const c = S.c, items = story();
  const setAsideCount = S.run.rejected.length + S.run.dropped.length + S.archive.length;
  let lastChapter = null;
  const cards = items.map((f, i) => {
    const head = f.chapter !== lastChapter ? `<h2 class="chsec">${CHAPTERS[f.chapter].label}</h2>` : '';
    lastChapter = f.chapter;
    return head + vFinding(f, i);
  }).join('');

  return `<div class="wrap">
    <button class="backlink" data-act="step" data-k="brief">${I.back} Back to the brief</button>
    <section class="headline">
      <div class="lbl">${docLabel()} · for ${S.audience.toLowerCase()}</div>
      <h1>${S.run.headline}</h1>
      <p class="toldline"><b>${items.length} findings told.</b> ${setAsideCount} set aside — ${S.run.rejected.length} did not hold up, ${S.run.dropped.length} were weaker or repeated a point already made${S.archive.length ? `, ${S.archive.length} removed by you` : ''}.
        <button class="linkb" data-act="setaside">See what was set aside ${I.chev}</button></p>
    </section>
    ${S.setAside ? vSetAside() : ''}
    <div class="fcards">${cards}</div>
    <div class="sticky">
      <button class="btn" data-act="step" data-k="brief">Change the brief</button>
      <div class="grow"></div>
      <button class="btn pri" data-act="step" data-k="deck">See it as slides ${I.chev}</button>
    </div>
  </div>`;
}

function vFinding(f, i) {
  const c = S.c;
  const text = S.edits[f.id] != null ? S.edits[f.id] : lockNumbers(f.sentence);
  const money = f.opportunity
    ? ` Moving <b>${F.money(f.opportunity.moved)}</b> would have been worth about <b>${F.int(f.opportunity.gained)}</b> more buyers and <b>${F.moneyC(f.opportunity.gainedSales)}</b> of sales, at the same total spend.`
    : '';
  return `<article class="fcard ${f.direction}">
    <div class="fhead"><h3>${f.title}</h3>
      <button class="ico del" data-act="remove" data-id="${f.id}" aria-label="Set aside">${I.x}</button></div>
    <div class="said" contenteditable="true" data-act="edit" data-id="${f.id}">${text}</div>
    <div class="fchart">${drawChart(c, f, 760, 190)}</div>
    ${f.counterCheck ? `<div class="counter"><span class="cl">${I.warn} The engine's check on its own advice</span>${f.counterCheck}</div>` : ''}
    ${f.reco ? `<p class="reco">${f.reco}${money}</p>` : ''}
    ${f.caveats.length || f.grade === 'directional' ? `<p class="cav">${I.lock} ${[f.grade === 'directional' ? f.gradeWhy : null].concat(f.caveats).filter(Boolean).join(' ')}</p>` : ''}
    ${f.mustTravel ? `<p class="cav">${I.lock} ${f.mustTravel}</p>` : ''}
    <div class="ffoot">${provChip(c)}${gradeChip(f)}
      <div class="grow"></div>
      <button class="why" data-act="why" data-id="${f.id}">Why this one? ${I.chev}</button></div>
    ${S.openFinding === f.id ? vWhy(f) : ''}
  </article>`;
}

function vWhy(f) {
  const rows = [
    ['How big is the gap', (f.effect * 100).toFixed(0) + '% from the campaign average'],
    f.separation != null ? ['How clear of the next one', (f.separation * 100).toFixed(0) + '% clear of ' + shortName(f.runnerUp || '—')] : null,
    ['How much is behind it', f.baseKind === 'buyers' ? F.int(f.base) + ' attributed buyers' : F.compact(f.base) + ' ' + f.baseKind],
    ['Grade of evidence', f.grade === 'directional' ? 'Directional — ' + (f.gradeWhy || '') : 'Stands up on its own'],
    ['Score', f.score.toFixed(3) + (f.goalScore !== f.score ? ` → ${f.goalScore.toFixed(3)} for a ${docLabel().toLowerCase()}` : '')]
  ].filter(Boolean);
  return `<div class="why-panel"><table class="kv">${rows.map(r => `<tr><td>${r[0]}</td><td class="n">${r[1]}</td></tr>`).join('')}</table></div>`;
}

function vSetAside() {
  const r = S.run;
  const groups = {};
  r.rejected.forEach(f => f.rejections.forEach(x => { (groups[x.rule] = groups[x.rule] || []).push({ f, why: x.why }); }));
  const tabs = [['rejected', 'Did not hold up', r.rejected.length], ['dropped', 'Weaker or repeated', r.dropped.length], ['removed', 'You removed', S.archive.length]];
  let body;
  if (S.setAsideTab === 'rejected') {
    body = Object.keys(groups).map(rule => `<div class="sg"><h4>${rule}<span>${groups[rule].length}</span></h4>
      ${groups[rule].map(({ f, why }) => `<div class="sr"><div class="st">${f.title || f.type}${f.measureLabel ? `<em>on ${f.measureLabel.toLowerCase()}</em>` : ''}</div><div class="sw">${why}</div></div>`).join('')}</div>`).join('')
      || '<div class="empty">Nothing was rejected.</div>';
  } else if (S.setAsideTab === 'dropped') {
    body = `<div class="sg"><h4>Passed the tests, weaker than what was told<span>${r.dropped.length}</span></h4>
      ${r.dropped.map(f => `<div class="sr"><div class="st">${f.title || f.type}${f.measureLabel ? `<em>on ${f.measureLabel.toLowerCase()}</em>` : ''}</div><div class="sw">${f.dropped || 'Scored below the findings that were told.'} <span class="sc">score ${f.score.toFixed(3)}</span></div></div>`).join('')}</div>`;
  } else {
    body = S.archive.length ? `<div class="sg"><h4>Removed by you<span>${S.archive.length}</span></h4>
      ${S.archive.map(a => `<div class="sr"><div class="st">${a.f.title}<em>removed ${a.at}</em></div><div class="sw">${a.f.sentence.replace(/<[^>]+>/g, '')}</div>
        <button class="btn sm" data-act="restore" data-id="${a.f.id}">${I.plus} Put it back</button></div>`).join('')}</div>`
      : '<div class="empty">You have not removed anything. Nothing is ever deleted — what you remove lands here.</div>';
  }
  return `<section class="panel setaside">
    <div class="phead"><h2>What was set aside</h2><button class="btn sm" data-act="setaside">${I.x} Close</button></div>
    <div class="satabs">${tabs.map(([k, l, n]) => `<button class="chip ${S.setAsideTab === k ? 'on' : ''}" data-act="satab" data-k="${k}">${l} <span class="ord">${n}</span></button>`).join('')}</div>
    <p class="note">A leader must be <b>${(S.run.stats.threshold * 100).toFixed(0)}%</b> clear of the next slice to stand up, and <b>${(S.run.stats.threshold * 60).toFixed(0)}%</b> to be worth mentioning as directional. ${S.run.stats.cells} slices were examined.</p>
    ${body}</section>`;
}

/* ================================================================
   CAMPAIGN — step 3, the deck
================================================================ */
function vDeck() {
  const c = S.c, comp = S.comp;
  return `<div class="wrap">
    <button class="backlink" data-act="step" data-k="story">${I.back} Back to the story</button>
    <div class="deckbar">
      <div><h1 class="h2">${c.advertiser} · ${c.name}</h1>
        <p class="note">${comp.slides.length} slides from ${comp.stats.findings} findings${comp.stats.riders ? `, ${comp.stats.riders} sharing a page` : ''} · ${docLabel()} · for ${S.audience.toLowerCase()}</p></div>
      <div class="btnrow"><button class="btn" data-act="pdf">${I.dl} PDF</button>
        <button class="btn pri" data-act="pptx">${I.dl} PowerPoint</button></div>
    </div>
    <div class="deck">${comp.slides.map(s => vSlide(s, comp.slides.length)).join('')}</div>
  </div>`;
}
function riderStrip(s) {
  if (!s.riders || !s.riders.length) return '';
  return `<div class="riders">${s.riders.map(f => `<div class="rider">
    <div class="rv">${f.stat.v}</div><div class="rl2">${f.stat.l}</div>
    <div class="rs">${S.edits[f.id] != null ? S.edits[f.id] : f.sentence}</div></div>`).join('')}</div>`;
}
function vSlide(s, total) {
  const c = S.c;
  if (s.layout === 'cover') {
    const T = c.T;
    return `<div class="slide cover">
      <div><div class="lbl">${PROGRAM.retailer} Retail Media · ${docLabel()} · for ${S.audience.toLowerCase()}</div>
        <h2 class="big">${c.name}</h2>
        <p class="covnote">${CAMPAIGN_BY_ID[c.id].note}</p>
        <div class="covgrid">${[['Supplier', c.advertiser], ['Channel', c.kind], ['Flight', c.flight],
          ['Attribution window', c.windowDays + ' days, post-view and post-click'],
          ['Products in scope', c.productCount + ' promoted items'],
          ['Audiences', c.segments.join(', ')],
          ['Ad groups · ads', c.adgroupCount + ' · ' + c.adCount],
          ['Budget', F.money(c.budget) + ' booked, ' + F.money(T.spend) + ' spent']].map(k =>
          `<div><span class="lbl">${k[0]}</span><b>${k[1]}</b></div>`).join('')}</div></div>
      <div class="covfoot">${provChip(c)}<span class="note">Attributed, not incremental · ${c.maturity.toLowerCase()} · no control group, so nothing here says the ads caused the sales</span></div></div>`;
  }
  if (s.layout === 'method') {
    return `<div class="slide"><div class="sh"><h2>${s.title}</h2><span class="prov neutral">${I.lock} On every deck</span></div>
      <table class="dt"><tbody>${[
        ['Window', `${c.windowDays} days after a qualifying view or click. The IAB default is 30; ${PROGRAM.retailer} discloses ${c.windowDays}.`],
        ['Credit', 'Last touch — the last qualifying event before the purchase takes the sale.'],
        ['Buyers', c.provenance === 'measured' ? 'Loyalty shoppers, resolved through the identity map.' : 'Not available — the partner returns totals, not identities.'],
        ['New to brand', 'A buyer with no purchase of the brand in the twelve weeks before the flight.'],
        ['Products', c.products],
        ['Numbers from', c.provenance === 'measured' ? 'We matched each exposure to a till or web receipt.' : 'Partner-reported totals, shown as received and never blended with ours.'],
        ['Maturity', `${c.maturity} — the window closes ${c.windowCloses}.`],
        ['Not claimed', 'No lift, no incrementality, no cannibalisation. Those need a group held back before the flight starts.']
      ].map(r => `<tr><td style="width:22%"><b>${r[0]}</b></td><td>${r[1]}</td></tr>`).join('')}</tbody></table>
      ${s.findings.map(f => `<p class="ins meth">${S.edits[f.id] != null ? S.edits[f.id] : f.sentence}</p>`).join('')}
      <div class="src">${srcLine(c, s.no, total)}</div></div>`;
  }
  if (s.layout === 'actions') {
    return `<div class="slide"><div class="sh"><h2>${s.title}</h2></div>
      <ol class="recos">${s.findings.map(f => `<li><b>${f.title}.</b> ${f.reco}</li>`).join('')}
        <li class="holdout"><b>Answer the incrementality question properly.</b> A hold-out group on the next flight costs about 5% of reach and answers whether the ads caused the sales. We can set it up before the next booking.</li></ol>
      <div class="src">${srcLine(c, s.no, total)}</div></div>`;
  }
  if (s.layout === 'pair') {
    return `<div class="slide"><div class="sh"><h2>${s.title}</h2>${provChip(c)}</div>
      <div class="pairgrid">${s.findings.map(f => `<div class="pairhalf"><h3>${f.title}</h3>
        <div class="chartbox">${drawChart(c, f, 330, 150)}</div>
        <p class="ins">${S.edits[f.id] != null ? S.edits[f.id] : f.sentence}</p></div>`).join('')}</div>
      ${riderStrip(s)}<div class="src">${srcLine(c, s.no, total)}</div></div>`;
  }
  const f = s.findings[0];
  return `<div class="slide"><div class="sh"><h2>${s.title}</h2>${provChip(c)}</div>
    <div class="scols"><div><p class="ins">${S.edits[f.id] != null ? S.edits[f.id] : f.sentence}</p>
      ${f.reco ? `<p class="ins reco-s"><b>Recommendation.</b> ${f.reco}</p>` : ''}
      ${f.counterCheck ? `<p class="ins counter-s">${f.counterCheck}</p>` : ''}</div>
      <div>${drawChart(c, f, 440, s.layout === 'hero' ? 215 : 190)}</div></div>
    ${riderStrip(s)}<div class="src">${srcLine(c, s.no, total)}</div></div>`;
}

/* ================================================================
   EXPLORE — metric sets, not 57 columns
================================================================ */
const METRIC_SETS = {
  core:      { label: 'Core', m: ['impressions', 'clicks', 'ctr', 'buyers', 'sales', 'roas'] },
  growth:    { label: 'Growth', m: ['buyers', 'newBuyers', 'lapsedBuyers', 'newShare', 'cpNewBuyer', 'sales'] },
  efficiency:{ label: 'Efficiency', m: ['spend', 'cpm', 'cpBuyer', 'cpNewBuyer', 'roas', 'sales'] },
  basket:    { label: 'Basket', m: ['buyers', 'txns', 'units', 'salesPerBuyer', 'avgTxn', 'pricePerUnit'] },
  scope:     { label: 'Direct and halo', m: ['sales', 'directSales', 'haloSales', 'buyers', 'units'] }
};
function vExplore() {
  const d = S.deep;
  const measures = d.measures || METRIC_SETS[d.set].m;
  const rows = filterFacts(filt());
  const g = groupBy2(rows, d.dims);
  g.sort((a, b) => ((b[d.sortKey] || 0) - (a[d.sortKey] || 0)) * (d.sortDir < 0 ? 1 : -1));
  const shown = g.slice(0, d.limit);
  const T = total(rows);
  return `<div class="wrap">
    <section class="panel">
      <div class="phead"><div><h2>Explore</h2><div class="note">${g.length.toLocaleString('en-GB')} rows at this grain · showing ${shown.length}. Click a row for every measure.</div></div>
        <div class="weekpick"><select data-act="wk" data-k="weekFrom">${WEEKS.map(w => `<option value="${w.id}" ${S.weekFrom === w.id ? 'selected' : ''}>${w.label}</option>`).join('')}</select>
          <span class="to">to</span>
          <select data-act="wk" data-k="weekTo">${WEEKS.map(w => `<option value="${w.id}" ${S.weekTo === w.id ? 'selected' : ''}>${w.label}</option>`).join('')}</select></div>
      </div>
      <div class="chooser">
        <div><span class="lbl">Rows</span><div class="chips">${DIM_DEFS.map(x =>
          `<button class="chip ${d.dims.includes(x.key) ? 'on' : ''}" data-act="dim" data-k="${x.key}">${x.label}${d.dims.includes(x.key) ? `<span class="ord">${d.dims.indexOf(x.key) + 1}</span>` : ''}</button>`).join('')}</div></div>
        <div><span class="lbl">Columns — pick a set, or build your own (8 maximum)</span>
          <div class="chips">${Object.keys(METRIC_SETS).map(k =>
            `<button class="chip set ${!d.measures && d.set === k ? 'on' : ''}" data-act="mset" data-k="${k}">${METRIC_SETS[k].label}</button>`).join('')}
            <span class="sep2"></span>
            ${Object.keys(MEASURE_DEFS).map(k => `<button class="chip tiny ${measures.includes(k) ? 'on' : ''}" data-act="meas" data-k="${k}" title="${MEASURE_DEFS[k].label}">${MEASURE_DEFS[k].label}</button>`).join('')}</div>
          </div>
      </div>
      <div class="tw"><table class="dt sticky">
        <thead><tr>${d.dims.map(k => `<th>${DIM_DEFS.find(x => x.key === k).label}</th>`).join('')}
          ${measures.map(k => `<th class="n sortable ${d.sortKey === k ? 'sorted' : ''}" data-act="sort2" data-k="${k}">${MEASURE_DEFS[k].label}${d.sortKey === k ? (d.sortDir < 0 ? ' ▾' : ' ▴') : ''}</th>`).join('')}</tr></thead>
        <tbody>
          <tr class="tot">${d.dims.map((k, i) => `<td>${i === 0 ? '<b>Total</b>' : ''}</td>`).join('')}${measures.map(k => `<td class="n"><b>${MEASURE_DEFS[k].fmt(T[k])}</b></td>`).join('')}</tr>
          ${shown.map((r, i) => `<tr class="clickable ${d.detail === i ? 'sel' : ''}" data-act="detail" data-i="${i}">
            ${d.dims.map(k => `<td>${r[k]}</td>`).join('')}${measures.map(k => `<td class="n">${MEASURE_DEFS[k].fmt(r[k])}</td>`).join('')}</tr>
            ${d.detail === i ? `<tr class="detailrow"><td colspan="${d.dims.length + measures.length}">
              <div class="detailgrid">${Object.keys(MEASURE_DEFS).map(k => `<div><span class="lbl">${MEASURE_DEFS[k].label}</span><b>${MEASURE_DEFS[k].fmt(r[k])}</b></div>`).join('')}</div></td></tr>` : ''}`).join('')}
        </tbody></table></div>
      <div class="deepfoot">
        ${g.length > d.limit ? `<button class="btn sm" data-act="more">Show 30 more</button>` : '<span class="note">All rows shown.</span>'}
        <button class="btn sm" data-act="csv">${I.dl} Export every measure</button>
        <span class="note">The screen is for deciding and the export is for auditing: the file carries all ${Object.keys(MEASURE_DEFS).length} measures, whatever is on screen. Buyers do not add up across rows — a shopper reached twice is one buyer in each.</span>
      </div>
    </section>
  </div>`;
}

/* ---------- modal ---------- */
function vModal() {
  if (!S.modal) return '';
  if (S.modal === 'holdout') {
    return `<div class="scrim" data-act="closemodal"><div class="sheet">
      <h3>Request a hold-out on the next flight</h3>
      <p class="note">This is the only way to answer "did the ads cause the sales". A group of shoppers is held back before the campaign starts — about 5% of reach — and the answer lands roughly four weeks after the flight ends.</p>
      <div class="holdgrid">${[['Cost to the supplier', 'About 5% of reach, no extra fee'],
        ['When the answer lands', 'Four weeks after the flight ends'],
        ['What it unlocks', 'Incremental sales, incremental ROAS, cannibalisation, the full decomposition'],
        ['What has to happen', 'The hold-out is drawn before the audience is exported. It cannot be added later.']].map(x =>
        `<div><span class="lbl">${x[0]}</span><b>${x[1]}</b></div>`).join('')}</div>
      <div class="mfoot"><div class="note">A line is added to the actions slide of this deck.</div>
        <button class="btn pri" data-act="closemodal">Add it to the deck</button></div></div></div>`;
  }
  const c = S.c;
  return `<div class="scrim" data-act="closemodal"><div class="sheet">
    <h3>${c.name.replace(/[^A-Za-z0-9]+/g, '_')}.pptx</h3>
    <p class="note">In the shipped product this writes a native PowerPoint — real text boxes, real tables, vector charts. Here it is the manifest the Composer produced.</p>
    <ol class="manifest">${S.comp.slides.map(s => `<li><b>${s.title}</b><span class="mlay">${s.layout}${s.riders && s.riders.length ? ` · ${s.riders.length} sharing the page` : ''}</span></li>`).join('')}</ol>
    <div class="mfoot"><div class="note">${docLabel()} · for ${S.audience.toLowerCase()} · printed on the cover and every footer</div>
      <button class="btn pri" data-act="closemodal">Close</button></div></div></div>`;
}

/* ---------- render ---------- */
function render() {
  let v;
  if (S.place === 'program') v = vProgram();
  else if (S.place === 'explore') v = vExplore();
  else if (!S.c) { S.place = 'program'; v = vProgram(); }
  else v = S.step === 'brief' ? vBrief() : S.step === 'story' ? vStory() : vDeck();
  document.getElementById('app').innerHTML = vHeader() + v + vModal();
}

/* ---------- events ---------- */
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const a = el.dataset.act;
  const go = () => { render(); window.scrollTo(0, 0); };
  if (a === 'place') { if (el.dataset.k === 'campaign' && !S.c) return; S.place = el.dataset.k; go(); }
  else if (a === 'step') { S.step = el.dataset.k; go(); }
  else if (a === 'open') { if (e.target.closest('input')) return; loadCampaign(el.dataset.id); S.place = 'campaign'; S.step = 'brief'; go(); }
  else if (a === 'cmp') { const id = el.dataset.id; S.compare = S.compare.includes(id) ? S.compare.filter(x => x !== id) : S.compare.concat(id); render(); }
  else if (a === 'clearcmp') { S.compare = []; render(); }
  else if (a === 'doctype') { S.docType = el.dataset.k; rebuild(); render(); }
  else if (a === 'aud') { S.audience = el.dataset.k; render(); }
  else if (a === 'sign') { S.signed = !S.signed; render(); }
  else if (a === 'buildstory') { if (!S.signed) return; S.step = 'story'; go(); }
  else if (a === 'holdout') { S.modal = 'holdout'; render(); }
  else if (a === 'drill') { S.drill = [el.dataset.id]; render(); }
  else if (a === 'undrill') { S.drill = S.drill.slice(0, +el.dataset.i); render(); }
  else if (a === 'setaside') { S.setAside = !S.setAside; render(); }
  else if (a === 'satab') { S.setAsideTab = el.dataset.k; render(); }
  else if (a === 'remove') {
    const f = S.run.story.find(x => x.id === el.dataset.id);
    S.removed[f.id] = true;
    S.archive.unshift({ f, at: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) });
    S.comp = compose(story(), S.c, S.docType); render();
  }
  else if (a === 'restore') {
    delete S.removed[el.dataset.id];
    S.archive = S.archive.filter(x => x.f.id !== el.dataset.id);
    S.comp = compose(story(), S.c, S.docType); render();
  }
  else if (a === 'why') { S.openFinding = S.openFinding === el.dataset.id ? null : el.dataset.id; render(); }
  else if (a === 'dim') {
    const k = el.dataset.k, d = S.deep;
    if (d.dims.includes(k)) { if (d.dims.length > 1) d.dims = d.dims.filter(x => x !== k); }
    else if (d.dims.length < 4) d.dims.push(k);
    d.detail = null; render();
  }
  else if (a === 'mset') { S.deep.set = el.dataset.k; S.deep.measures = null; render(); }
  else if (a === 'meas') {
    const d = S.deep, cur = d.measures || METRIC_SETS[d.set].m.slice();
    const k = el.dataset.k;
    if (cur.includes(k)) { if (cur.length > 1) d.measures = cur.filter(x => x !== k); }
    else if (cur.length < 8) d.measures = cur.concat(k);
    render();
  }
  else if (a === 'sort2') { if (S.deep.sortKey === el.dataset.k) S.deep.sortDir *= -1; else { S.deep.sortKey = el.dataset.k; S.deep.sortDir = -1; } render(); }
  else if (a === 'detail') { S.deep.detail = S.deep.detail === +el.dataset.i ? null : +el.dataset.i; render(); }
  else if (a === 'more') { S.deep.limit += 30; render(); }
  else if (a === 'csv') exportCsv();
  else if (a === 'pptx') { S.modal = 'pptx'; render(); }
  else if (a === 'closemodal') { S.modal = null; render(); }
  else if (a === 'pdf') { S.step = 'deck'; render(); setTimeout(() => window.print(), 80); }
});

document.addEventListener('change', e => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  if (el.dataset.act === 'wk') { S[el.dataset.k] = el.value; S.deep.detail = null; render(); }
  else if (el.dataset.act === 'sort') { S.sortBy = el.value; render(); }
  else if (el.dataset.act === 'drillmeasure') { S.drillMeasure = el.value; render(); }
});
document.addEventListener('blur', e => {
  const el = e.target.closest ? e.target.closest('[data-act="edit"]') : null;
  if (el) S.edits[el.dataset.id] = el.innerHTML;
}, true);

async function exportCsv() {
  const rows = filterFacts(filt()), d = S.deep;
  const g = groupBy2(rows, d.dims);
  const keys = Object.keys(MEASURE_DEFS);
  const head = [...d.dims.map(k => DIM_DEFS.find(x => x.key === k).label), ...keys.map(k => MEASURE_DEFS[k].label)];
  const body = g.map(r => [...d.dims.map(k => `"${String(r[k]).replace(/"/g, '""')}"`), ...keys.map(k => r[k] == null ? '' : Math.round(r[k] * 1000) / 1000)].join(','));
  const csv = head.join(',') + '\n' + body.join('\n');
  try {
    const dl = window.claude && claude.use ? await claude.use('downloads') : null;
    if (dl) { await dl.save({ filename: 'retail_media_explore.csv', data: csv }); return; }
  } catch (err) { /* declined or unavailable */ }
  const a2 = document.createElement('a');
  a2.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
  a2.download = 'retail_media_explore.csv'; a2.click();
  setTimeout(() => URL.revokeObjectURL(a2.href), 2000);
}

render();
