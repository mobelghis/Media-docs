/* ==================================================================
   Charts — drawn from the same numbers the engine reasons about
================================================================== */
const C = { teal: '#0F6E5C', purple: '#463BA0', amber: '#A8741A', grey: '#B9BFC4', ink: '#111820', mid: '#78899A', faint: '#E5E9E7', red: '#A33A2A' };
const PIE = ['#0F6E5C', '#463BA0', '#A8741A', '#7FB5A9', '#9A93C9'];
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

function sv(w, h, inner, label) {
  return `<svg viewBox="0 0 ${w} ${h}" width="100%" height="${h}" role="img" aria-label="${esc(label || 'chart')}" preserveAspectRatio="xMidYMid meet">${inner}</svg>`;
}
function tx(x, y, s, o = {}) {
  const fam = o.cond ? "'IBM Plex Sans Condensed'" : "'IBM Plex Mono'";
  return `<text x="${x}" y="${y}" font-family="${fam}" font-size="${o.size || 10}" fill="${o.fill || C.mid}" text-anchor="${o.anchor || 'start'}" font-weight="${o.weight || 400}">${esc(s)}</text>`;
}

/* actual vs planned */
function cPaired(c, f, w, h) {
  const T = c.T, big = h > 170;
  const pairs = f.type === 'plan_cpm'
    ? [{ lab: 'CPM', a: T.cpm, e: T.estCpm, fa: F.money2(T.cpm), fe: F.money2(T.estCpm) }]
    : [{ lab: 'Impressions', a: T.impressions, e: T.estImpressions, fa: F.compact(T.impressions), fe: F.compact(T.estImpressions) },
       { lab: 'CPM', a: T.cpm, e: T.estCpm, fa: F.money2(T.cpm), fe: F.money2(T.estCpm) }];
  const base = h - (big ? 34 : 26), gw = w / pairs.length, bw = Math.min(big ? 56 : 34, gw / 3.4);
  let o = `<line x1="0" y1="${base}" x2="${w}" y2="${base}" stroke="#D3D8D6"/>`;
  pairs.forEach((p, i) => {
    const mx = Math.max(p.a, p.e), cx = i * gw + gw / 2;
    const ha = p.a / mx * (base - 24), he = p.e / mx * (base - 24);
    o += `<rect x="${cx - bw - 3}" y="${base - ha}" width="${bw}" height="${ha}" fill="${C.purple}"/>`
      + `<rect x="${cx + 3}" y="${base - he}" width="${bw}" height="${he}" fill="${C.grey}"/>`
      + tx(cx - bw / 2 - 3, base - ha - 7, p.fa, { size: big ? 14 : 11, fill: C.ink, anchor: 'middle', weight: 500 })
      + tx(cx + bw / 2 + 3, base - he - 7, p.fe, { size: big ? 11 : 9, anchor: 'middle' })
      + tx(cx, base + 15, p.lab, { size: big ? 11.5 : 10, fill: '#41505F', anchor: 'middle', cond: 1, weight: 600 })
      + (big ? tx(cx, base + 29, 'actual · planned', { size: 9.5, anchor: 'middle' }) : '');
  });
  return sv(w, h, o, 'Actual against planned');
}

/* breakdown bars, with the leader marked */
function cBars(c, f, w, h) {
  const cut = c.cuts[f.chart.cut], m = METRICS[f.chart.metric], T = c.T;
  const media = ['impressions', 'clicks', 'ctr'].includes(f.chart.metric);
  const big = h > 170, L = big ? 180 : 130, RP = big ? 84 : 60;
  const pad = 18;
  let data = cut.rows.map(r => ({ name: r.name, v: m.get(r, T) })).filter(d => d.v != null)
    .sort((a, b) => m.lowerBetter ? a.v - b.v : b.v - a.v);
  const rh = (h - pad - 6) / data.length - (big ? 9 : 6), mx = Math.max(...data.map(d => d.v)) || 1;
  const ref = m.total(T);
  let o = '';
  data.forEach((d, i) => {
    const y = pad + i * (rh + (big ? 9 : 6)), bw = Math.max(1, d.v / mx * (w - L - RP));
    const isHit = d.name === f.slice || (f.v && f.v.weak && d.name === f.v.weak.name) || (f.v && f.v.strong && d.name === f.v.strong.name);
    const col = f.type === 'mismatch'
      ? (f.v.strong.name === d.name ? C.teal : (f.v.weak.name === d.name ? C.amber : C.grey))
      : (isHit ? (media ? C.purple : C.teal) : '#C7D2CE');
    o += `<rect x="${L}" y="${y}" width="${bw}" height="${rh}" fill="${col}"/>`
      + tx(L - 8, y + rh / 2 + 4, shortName(d.name), { size: big ? 11.5 : 9.5, fill: isHit ? C.ink : '#5B6775', anchor: 'end', cond: 1, weight: isHit ? 700 : 600 })
      + tx(L + bw + 7, y + rh / 2 + 4, m.fmt(d.v), { size: big ? 12.5 : 10.5, fill: isHit ? C.ink : '#5B6775', weight: isHit ? 600 : 400 });
  });
  if (ref) {
    const bx = L + ref / mx * (w - L - RP);
    o += `<line x1="${bx}" y1="${pad - 6}" x2="${bx}" y2="${h - 4}" stroke="${C.ink}" stroke-width="1.2" stroke-dasharray="4 3" opacity=".55"/>`
      + tx(Math.min(bx + 5, w - 140), pad - 10, 'campaign average ' + m.fmt(ref), { size: big ? 10 : 8.5, fill: '#41505F', cond: 1, weight: 600 });
  }
  return sv(w, h, o, 'Breakdown');
}

/* funnel */
function cFunnel(c, f, w, h) {
  const steps = c.funnel, big = h > 170;
  const L = big ? 150 : 110, rh = (h - 4) / steps.length - (big ? 9 : 6), mx = steps[0].value;
  let o = '';
  steps.forEach((s, i) => {
    const y = i * (rh + (big ? 9 : 6));
    const bw = Math.max(26, Math.sqrt(s.value / mx) * (w - L - (big ? 104 : 74)));
    const last = i === steps.length - 1;
    const isDrop = f.type === 'funnel_drop' && (s.name === f.v.to.name);
    o += `<rect x="${L}" y="${y}" width="${bw}" height="${rh}" fill="${last ? C.teal : (isDrop ? C.amber : C.purple)}" opacity="${last || isDrop ? 1 : 1 - .1 * i}"/>`
      + tx(L - 8, y + rh / 2 + 4, big ? s.name : s.name.replace(' Shoppers', ''), { size: big ? 11.5 : 9.5, fill: '#41505F', anchor: 'end', cond: 1, weight: 600 })
      + tx(L + bw + 8, y + rh / 2 + 4, F.compact(s.value), { size: big ? 12.5 : 10.5, fill: C.ink, weight: 500 });
    if (i > 0 && f.type === 'funnel_drop' && s.name === f.v.to.name) {
      o += tx(L + bw + 8, y + rh / 2 + (big ? 17 : 14), '−' + F.pct1(f.v.drop * 100), { size: big ? 10.5 : 9, fill: C.amber, weight: 600 });
    }
  });
  return sv(w, h, o, 'Audience funnel');
}

/* headline number + comparison */
function cBigNum(c, f, w, h) {
  const big = h > 170;
  const b = f.v, k = f.metric;
  const fmt = k === 'cpBuyer' ? F.money2 : (k === 'ctr' ? F.pct2 : F.pct3);
  const name = { ctr: 'Click-through rate', convRate: 'Conversion rate', cpBuyer: 'Cost per buyer' }[k] || 'This campaign';
  const col = b.better ? C.teal : C.amber;
  let o = tx(0, big ? 44 : 32, fmt(b.actual), { size: big ? 48 : 32, fill: col, weight: 500 })
    + tx(0, big ? 66 : 50, name + ' · this campaign', { size: big ? 12 : 10.5, fill: '#41505F', cond: 1, weight: 600 });
  const barY = big ? 90 : 66, bh = big ? 22 : 15, L = 0, W = w - (big ? 90 : 70);
  const mx = Math.max(b.actual, b.bench);
  [[b.actual, col, 'This campaign'], [b.bench, C.grey, 'Comparable campaigns']].forEach((p, i) => {
    const y = barY + i * (bh + (big ? 26 : 19));
    o += `<rect x="${L}" y="${y}" width="${Math.max(4, p[0] / mx * W)}" height="${bh}" fill="${p[1]}"/>`
      + tx(L, y - 5, p[2], { size: big ? 10.5 : 9, fill: '#41505F', cond: 1, weight: 600 })
      + tx(L + Math.max(4, p[0] / mx * W) + 8, y + bh / 2 + 4, fmt(p[0]), { size: big ? 12 : 10, fill: C.ink, weight: 500 });
  });
  return sv(w, h, o, 'Against comparable campaigns');
}

/* repeat buyers */
function cRepeat(c, f, w, h) {
  const T = c.T, big = h > 170;
  let o = tx(0, big ? 44 : 32, F.pct1(T.repeatRate), { size: big ? 48 : 32, fill: C.amber, weight: 500 })
    + tx(0, big ? 66 : 50, 'bought at least twice in the window', { size: big ? 12 : 10.5, fill: '#41505F', cond: 1, weight: 600 });
  const L = 0, W = w - (big ? 96 : 72), barY = big ? 92 : 68, bh = big ? 24 : 16;
  [['Attributed buyers', T.buyers, C.teal], ['Repeat buyers', T.repeatBuyers, C.amber]].forEach((p, i) => {
    const y = barY + i * (bh + (big ? 28 : 20));
    const bw = Math.max(4, p[1] / T.buyers * W);
    o += `<rect x="${L}" y="${y}" width="${bw}" height="${bh}" fill="${p[2]}"/>`
      + tx(L, y - 5, p[0], { size: big ? 10.5 : 9, fill: '#41505F', cond: 1, weight: 600 })
      + tx(L + bw + 8, y + bh / 2 + 4, F.int(p[1]), { size: big ? 12 : 10, fill: C.ink, weight: 500 });
  });
  return sv(w, h, o, 'Repeat purchase');
}

/* two donuts — campaign vs category */
function cDonut2(c, f, w, h) {
  const big = h > 170, r = Math.min(big ? 58 : 38, (h - 46) / 2), sw = big ? 15 : 10;
  const mk = (cx, pct, col, lab) => {
    const circ = 2 * Math.PI * r, cy = r + 10;
    return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${C.faint}" stroke-width="${sw}"/>`
      + `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${col}" stroke-width="${sw}" stroke-dasharray="${circ * pct / 100} ${circ}" transform="rotate(-90 ${cx} ${cy})"/>`
      + tx(cx, cy + (big ? 8 : 6), F.pct1(pct), { size: big ? 20 : 14, fill: C.ink, anchor: 'middle', weight: 500 })
      + tx(cx, cy + r + 20, lab, { size: big ? 11 : 9, fill: '#41505F', anchor: 'middle', cond: 1, weight: 600 });
  };
  let o = mk(r + 8, f.v.share, C.teal, 'Campaign') + mk(r * 3 + 34, f.v.cat, C.grey, 'Category');
  const dx = r * 4 + 62;
  o += tx(dx, r - 2, F.pts(f.v.d), { size: big ? 28 : 19, fill: C.amber, weight: 500 })
    + tx(dx, r + (big ? 18 : 14), 'e-commerce share of', { size: big ? 11 : 9.5, fill: '#41505F', cond: 1, weight: 600 })
    + tx(dx, r + (big ? 31 : 25), 'attributed sales vs category', { size: big ? 11 : 9.5, fill: '#41505F', cond: 1, weight: 600 });
  return sv(w, h, o, 'E-commerce share against the category');
}

/* profile pies */
function arcPath(cx, cy, r, a0, a1) {
  const p = a => [cx + r * Math.sin(a), cy - r * Math.cos(a)];
  const [x0, y0] = p(a0), [x1, y1] = p(a1);
  return `M ${cx} ${cy} L ${x0.toFixed(2)} ${y0.toFixed(2)} A ${r} ${r} 0 ${a1 - a0 > Math.PI ? 1 : 0} 1 ${x1.toFixed(2)} ${y1.toFixed(2)} Z`;
}
function onePie(cx, cy, r, vals, hi) {
  let a = 0, o = '';
  const tot = vals.reduce((s, v) => s + v, 0) || 1;
  vals.forEach((v, i) => {
    const a1 = a + 2 * Math.PI * v / tot;
    o += `<path d="${arcPath(cx, cy, r, a, a1)}" fill="${PIE[i % PIE.length]}" stroke="#fff" stroke-width="1" opacity="${hi == null || hi === i ? 1 : .42}"/>`;
    a = a1;
  });
  return o;
}
function cPie2(c, f, w, h) {
  const p = c.profile[f.chart.attribute], big = h > 170;
  const hi = p.names.indexOf(f.v.up.n);
  const r = Math.min(big ? 72 : 46, (h - (big ? 44 : 30)) / 2), cy = r + 6;
  let o = onePie(r + 4, cy, r, p.campaign, hi) + onePie(r * 3 + 26, cy, r, p.category, hi)
    + tx(r + 4, cy + r + 18, 'Campaign buyers', { size: big ? 11 : 9, fill: '#41505F', anchor: 'middle', cond: 1, weight: 600 })
    + tx(r * 3 + 26, cy + r + 18, 'Category buyers', { size: big ? 11 : 9, fill: '#41505F', anchor: 'middle', cond: 1, weight: 600 });
  const lx = r * 4 + 48;
  p.names.forEach((n, i) => {
    const y = 14 + i * (big ? 24 : 17), d = p.campaign[i] - p.category[i];
    o += `<rect x="${lx}" y="${y - 8}" width="9" height="9" fill="${PIE[i % PIE.length]}" opacity="${hi === i ? 1 : .45}"/>`
      + tx(lx + 15, y, n, { size: big ? 11 : 9.5, fill: hi === i ? C.ink : '#5B6775', cond: 1, weight: hi === i ? 700 : 600 })
      + tx(lx + 15, y + (big ? 12 : 8.5), `${p.campaign[i]}% · ${F.pts(d)}`, { size: big ? 10 : 8.5, fill: d > 0 ? C.teal : C.mid });
  });
  return sv(w, h, o, 'Buyer profile against the category');
}

/* time to purchase */
function cHist(c, f, w, h) {
  const d = c.ttp, big = h > 170, base = h - (big ? 26 : 18);
  const n = d.values.length, bw = w / n, mx = Math.max(...d.values);
  let o = `<line x1="0" y1="${base}" x2="${w}" y2="${base}" stroke="#D3D8D6"/>`;
  d.values.forEach((v, i) => {
    const bh = v / mx * (base - 16);
    o += `<rect x="${i * bw + 2}" y="${base - bh}" width="${bw - 4}" height="${bh}" fill="${i < 3 ? C.teal : '#C7D2CE'}"/>`
      + tx(i * bw + bw / 2, base - bh - 5, v + '%', { size: big ? 10.5 : 8, fill: C.ink, anchor: 'middle', weight: 500 })
      + tx(i * bw + bw / 2, base + (big ? 15 : 12), d.buckets[i], { size: big ? 9.5 : 8, anchor: 'middle' });
  });
  return sv(w, h, o, 'Time from exposure to purchase');
}

/* daily, with the open window shaded */
function cDaily(c, f, w, h) {
  const d = c.daily, big = h > 170, base = h - (big ? 26 : 18);
  const vals = d.sales, n = vals.length, bw = w / n, mx = Math.max(...vals) || 1;
  let o = `<rect x="${d.maturedTo * bw}" y="0" width="${(n - d.maturedTo) * bw}" height="${base}" fill="${C.amber}" opacity=".1"/>`;
  vals.forEach((v, i) => {
    const bh = v / mx * (base - 8), open = i >= d.maturedTo;
    o += `<rect x="${i * bw + 1.5}" y="${base - bh}" width="${Math.max(2, bw - 3)}" height="${bh}" fill="${C.teal}" opacity="${open ? .42 : 1}"/>`;
  });
  o += `<line x1="0" y1="${base}" x2="${w}" y2="${base}" stroke="#D3D8D6"/>`
    + tx(d.maturedTo * bw + 5, 12, 'still filling in', { size: big ? 10.5 : 9, fill: C.amber, cond: 1, weight: 600 });
  if (big) {
    o += tx(0, h - 7, d.labels[0], { size: 10 }) + tx(w, h - 7, 'yesterday', { size: 10, anchor: 'end' });
  }
  return sv(w, h, o, 'Attributed sales by day');
}

/* data quality rows */
function cQuality(c, f, w, h) {
  const items = c.quality, big = h > 170, rh = h / items.length;
  let o = '';
  items.forEach((q, i) => {
    const y = i * rh, bad = q.floor != null && q.value < q.floor;
    if (i) o += `<line x1="0" y1="${y}" x2="${w}" y2="${y}" stroke="${C.faint}"/>`;
    o += tx(0, y + rh / 2 + 4, q.name, { size: big ? 11.5 : 10, fill: '#41505F', cond: 1, weight: 600 })
      + tx(w, y + rh / 2 + 4, q.value + q.unit, { size: big ? 13 : 11, fill: bad ? C.red : C.ink, anchor: 'end', weight: 500 })
      + (q.floor != null ? tx(w - (big ? 64 : 52), y + rh / 2 + 4, 'floor ' + q.floor + q.unit, { size: big ? 9.5 : 8.5, anchor: 'end' }) : '');
  });
  return sv(w, h, o, 'Data quality');
}

const CHART = { paired: cPaired, bars: cBars, funnel: cFunnel, bignum: cBigNum, repeat: cRepeat, donut2: cDonut2, pie2: cPie2, hist: cHist, daily: cDaily, quality: cQuality };
function drawChart(c, f, w, h) {
  const fn = CHART[f.chart && f.chart.k];
  if (!fn) return '';
  try { return fn(c, f, w, h); } catch (e) { return ''; }
}
