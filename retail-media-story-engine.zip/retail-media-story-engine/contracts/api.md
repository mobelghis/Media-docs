# The web addresses the front end calls

Six endpoints. Everything the product does goes through one of these.

---

### 1. The program page

```
GET /api/program/{programId}/summary
    ?weekFrom=w37&weekTo=w41
    &campaigns=cm1,cm2&adgroups=g1&ads=a1
```

Gives back the totals, the campaign list, the week-by-week series, and the
breakdown for whatever level of the hierarchy is open.

---

### 2. The drill-down

```
GET /api/program/{programId}/breakdown
    ?level=adgroup&parent=cm1&measure=sales&{the same filters}
```

Gives back one row per slice at that level, with every measure.

---

### 3. The deep dive

```
POST /api/query
{
  "filters":  { "weekFrom": "w37", "weekTo": "w41", "campaigns": ["cm1"] },
  "dimensions": ["product", "upc"],
  "measures": ["impressions", "clicks", "buyers", "sales", "roas"],
  "sort": { "key": "sales", "dir": "desc" },
  "limit": 200
}
```

One endpoint, any shape. This is the query engine the whole product rests on.

---

### 4. Build the story

```
POST /api/campaigns/{campaignId}/story
{ "goal": "renewal" | "honest" | "budget" }
```

Runs all six helpers. Gives back the headline, the chosen findings in order,
everything the Skeptic killed with its reason, and everything that survived but
was not chosen.

This is the slow one — a few seconds, because of the AI calls. Stream it if the
wait shows.

---

### 5. Save and change a story

```
PUT    /api/stories/{storyId}        the goal, the order, edited sentences
DELETE /api/stories/{storyId}/findings/{findingId}   → moves it to the archive
POST   /api/stories/{storyId}/findings/{findingId}/restore
GET    /api/stories/{storyId}/archive
```

Nothing is ever deleted. Removing a finding moves it to the archive with the
time, and it comes back exactly where it was.

---

### 6. Export

```
POST /api/stories/{storyId}/export
{ "format": "pptx" | "pdf", "freeze": true }
```

`freeze: true` stamps the numbers at this moment, so the deck in the brand's
inbox and the figures discussed in the meeting agree.
