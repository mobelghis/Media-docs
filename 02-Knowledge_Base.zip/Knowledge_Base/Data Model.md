# Data Model

**Status:** 15 of 15 planned Unlimitail source documents analyzed. All source documents have now been reviewed.
**Last updated:** 2026-09-12
**Documents analyzed:** DOC01 - "Retail Media Measurement – closed loop concept design (no incrementality).docx"; DOC02 - "Unlimitail - Kick-off Meeting.pptx"; DOC03 - "7_Integration_Deck_Unlimitail.pptx"; DOC04 - "Unlimitail - Sales to Delivery handover.pptx"; DOC05 - "Eran_Mo KT - Session 1.docx" (no new data-feed content; Personalization entities captured in Domain Model.md instead); DOC06 - "Unlimitail Business Stream.pptx"; DOC07 - "Unlimitail & NIQ Discovery Workshop July 2026 (3).pptx"; DOC08 - "Unlimitail July 2027 workshop - discovery summary.docx" (narrative-only; simplified data flow captured below, no new field-level detail); DOC09 - "Unlimitail Workshop June 26.xlsx" (agenda/planning only; no new field-level data content beyond confirming the same core platform categories already captured); DOC10 - "ADLM Jira 2026-09-12T16_26_03-0400.xls" (measurement-prerequisite artifacts — Arm Assignment, Ghost Log, Frozen Eligibility Snapshot, Frozen Parameters — captured in Domain Model.md instead); DOC11 - "Unlimitail_Dataplatform RFQ_UCs list...xlsx" (use-case-level, not field-level; captured in Requirements Inventory.md/Domain Model.md); DOC12/DOC13 - Unlimitail email-summary documents (too generic for field-level data model content)

## Purpose
Captures data elements, entities, attributes, and relationships identified from client documents, as a business-level (not necessarily physical) data model. Note: this is distinct from `Data_Model_Design/03_Canonical_Data_Model.md`, which is the physical/technical data model produced for the earlier retail-media report analysis (WB1-5/deck6/7); this file tracks data elements surfaced specifically through the incremental client-document review process.

## Data Entities (Interface Files per DOC01)
| Entity / File | Description | Key Fields | Source / Cadence | Source Document |
|---|---|---|---|---|
| Customers Mapping File | Maps retailer Loyalty ID to Retail Media ID (RampID/UID 2.0), historized | LOYALTY_ID, RETAIL_MEDIA_ID, RETAIL_MEDIA_ID_TYPE, EFFECTIVE_FROM, EFFECTIVE_TO | Retailer (via ID-resolution onboarding); Daily | DOC01 |
| Ad Interactions File | Shopper-level ad engagement events (consented only) | PARTNER_ID, ADVERTISER_ID, RETAIL_MEDIA_ID, CAMPAIGN_ID, AD_GROUP_ID, AD_ID, TIMESTAMP, INTERACTION_TYPE (I/V/W/C/P), costs, CURRENCY, media type/format, channel/site/URLs, video-quartile flags, PURCHASE_VALUE, device/geo fields (~35 fields total) | ID resolution solution/CDP/DSP; Daily | DOC01 |
| T-Log Data File | Actual shopper purchase transactions (SKU-level) | Not re-specified — reuses NIQ's existing T-Log interface | Retailer; Daily | DOC01 |
| Targeting File | Who was targeted with which ad group, and when | PARTNER_ID, ADVERTISER_ID, RETAIL_MEDIA_ID, CAMPAIGN_ID, AD_GROUP_ID, AD_ID, TIMESTAMP | Retailer / DSP; Daily (future: near real-time) | DOC01 |
| Campaign Metadata File | Campaign-level descriptors | CAMPAIGN_ID, CAMPAIGN_NAME/DESCRIPTION, START_DATE, END_DATE, BUDGET, BUDGET_TYPE, BUDGET_CURRENCY, PRIMARY_CHANNEL, OBJECTIVE, INTERACTION_PAYMENT_TYPE, ACTIVE, CREATION_DATE, LAST_UPDATE_DATE | DSP/Advertising platform; Daily | DOC01 |
| Ad Group/Line Item Metadata File | Ad-group-level descriptors | AD_GROUP_ID, AD_GROUP_NAME/DESCRIPTION, AUDIENCE, BUDGET, BUDGET_TYPE, BUDGET_CURRENCY | DSP/Advertising platform; Daily | DOC01 |
| Ad/Creative Metadata File | Ad/creative-level descriptors | AD_ID, AD_NAME/DESCRIPTION, AD_MEDIA_TYPE, AD_FORMAT, REDIRECT_URL, LANDING_PAGE_URL, CREATION_DATE, LAST_UPDATE_DATE | DSP/Advertising platform; Daily | DOC01 |
| Ad Products File | Maps an ad to the retailer's product/brand/category for sales measurement | AD_ID, RETAILER_REFERENCE_PRODUCT_ID | Retailer; Daily | DOC01 |
| Campaign Engagement File | Daily aggregated cost/engagement metrics per ad | DATE, CAMPAIGN_ID, AD_GROUP_ID, AD_ID, AD_MEDIA_TYPE, AD_FORMAT, CHANNEL, RETAILER_TOTALADV_COST, ADVERTISER_TOTALADV_COST, IMPRESSIONS, VIEWS, CLICKS | DSP/Advertising platform; Daily | DOC01 |
| Advertisers Mapping File | Maps advertiser to CPG/brand for RLS | ADVERTISER_ID, RETAILER_CPG_ID, HIGH_BRAND_ID | Retailer; Daily | DOC01 |

## Data Elements / Attributes Detail
Full field-level detail (types, mandatory flags, MVP inclusion) captured verbatim from DOC01 in the underlying analysis; the Ad Interactions File is the richest (~35 fields spanning identifiers, cost, device, geo, video-completion, and click-path attributes). Full field list preserved in the source document dump at `_analysis/out_ttd_docx_dump.txt` for traceability.

## Relationships
- Campaign (1) → Ad Group (N) → Ad (N); all three metadata files share the Campaign/AdGroup/Ad key chain.
- Customers Mapping (1 Loyalty_ID) → (N Retail_Media_ID over time) — temporal/historized relationship.
- Ad Interactions (N) reference Retail_Media_ID (→ Customers Mapping), Campaign/AdGroup/Ad IDs (→ metadata files).
- T-Log purchases are matched to Ad Interactions via Retail_Media_ID/Loyalty_ID + Attribution Window (not a static FK — a time-windowed join).
- Ad Products File provides the Ad→Product/Brand/Category link needed to measure attributable sales at a product level.
- Advertisers Mapping File provides the Advertiser→CPG→Brand link used purely for Row-Level Security scoping.
- Campaign Engagement File is a **daily aggregate** of the same cost/impression/click facts also derivable from Ad Interactions detail — the source doc leaves open whether both are needed or if aggregates can be derived bottom-up (see Open Questions OQ-C003).

## Cross-Reference to Prior Analysis
The previously-built `Data_Model_Design/` and `Report_KPI_Dimension_Analysis.xlsx` deliverables (based on the 7 Unlimitail sample report files: WB1-WB5 + deck6/deck7) describe a conceptually similar domain — campaigns, ad groups, exposure/interaction data, attribution-style KPIs (F1-F9, G1-G11), ROAS-equivalent metrics, and shopper segmentation. WB2 (`NIQ_Datasheet_Liftcampaign.xlsx`) and deck7 (`NIQ_Measurement Report example.pptx`) in particular appear to be **downstream reporting outputs** of an architecture consistent with (but not proven identical to) the one described in this document. This should be used to help answer several Open Questions below once the remaining Unlimitail documents are reviewed.

## Phase 1 Onboarding Data Parameters (per DOC02)
Note: DOC02 describes the Insights Premium (Phase 1) onboarding, not the Retail Media Measurement data interfaces from DOC01 (which are Phase 2/TBD scope — see Assumptions Log AS-010). Captured here since it defines the actual current data-ingestion parameters for the active engagement:
- **Scope**: Carrefour France, Spain, Brazil — one onboarding project, common business/data design, 3 separate Activate portal instances.
- **Volumetrics (baseline sizing)**: ~15 million shoppers; ~10 billion transactions for analytics.
- **Historical data**: 24 months required, delivered by the customer in Activate standard format; customer handles extraction, transformation, masking, and secure upload.
- **Ongoing cadence**: 2 free historical load cycles, daily incremental uploads, weekly refreshes; data-quality accountability shared between NIQ and Unlimitail.
- **NIQ-provided reference/taxonomy data** (flows INTO Unlimitail, not out): FMCG syndicated product characteristics, manufacturer mappings, category hierarchies, product enrichment attributes, local-language taxonomy definitions. Unlimitail enriches its own data lake with this data before sending it into Activate.
- **Validation checkpoints**: "First Data Validation" (on data as delivered by customer, pre-load) and "Second Data Validation" (post-ETL, after NIQ loads it into Activate) — both produce a "Validation Excel" artifact.

## Contracted Product/Module Scope ("Order Form", per DOC02 embedded images)
DOC02 embeds (as images, not extractable text) a contractual "Order Form" table defining exactly which Activate modules/reports are licensed. **Note: this is a contract-scope artifact, not the incoming-feed data format** — the field-level incoming-feed layout (file/record structure Carrefour will send) has still NOT been located in any document reviewed so far (see Open Questions OQ-C018).

| # | Module / Feature | Included? |
|---|---|---|
| 1 | Activate Modules and Functional Highlights (parent) | — |
| 1.2.1 | Customer & Sales Insights | YES PREMIUM |
| 1.2.2 | Offer Management and Personalization | FUTURE STAGE |
| 1.2.3 | Supply Chain Insights | NO |
| 1.2.4 | Promotional Insights and Planning | NO |
| 1.2.5 | Assortment Rationalization | NO |
| 1.3 | Suppliers Collaboration & Data Monetization | NO |
| 2 | Customer & Sales Insights (parent) | YES PREMIUM |
| 2.2 | Sales Analytics (Sales Performance, Category Share, Performance by day & hour reports) | YES |
| 2.3 | Shopper Analytics (Loyalty Behavior, Shopper Appeal, Shopper Wallet Share, Heavy-Medium-Light reports) | YES |
| 2.4 | Basket Analytics (Purchase Combinations, Basket Cross Shop, Multi-Unit Buy reports) | YES |
| 2.5 | Supplier/Brand Analytics (Gain/Loss & Switching, New Product Launch reports) | YES |
| 3 | Offer Management and Personalization | FUTURE STAGE |
| 4 | Supply Chain | NO |
| 5 | Promo Analytics & Planning (parent) | NO |
| 5.2 | Promo Effectiveness MODULE (parent — but Promo Performance Report itself = YES; Promo Comparison/Dashboard reports = NO) | NO (module), partial YES (1 report) |
| 6 | Assortment MODULE (parent) | NO |
| 6.2 | Assortment Performance Analytics (parent — but Assortment Distribution Report itself = YES; Assortment Performance report & Rationalization tool = NO) | NO (module), partial YES (1 report) |
| 6.3 | Consumer Decision Trees (2025 Roadmap) | NO |
| 6.4 | Planogram reporting (Filters/KPIs, Performance Report) | NO |
| **7** | **Retail Media Measurement** | **YES — will be customized to Unlimitail based on 6 use cases** |
| 8.1 | Standard Report features | YES |
| 8.2 | HomePage Screen | YES |
| 8.3 | Segmentation & Audiences (Segmentation Studio): Shopper Attributes, Category/Brand/Virtual Category Segmentation, Row Level Segmentation, Segments Creation, Segment Export | YES (all sub-items) |
| 8.4 | Data Exporter | YES |
| 8.5 | User Management/Permission Mechanism: Unlimitail profiles = YES; Suppliers profiles & Users = NO; **RLS Mechanism (Category, CPG, Brand, Store, Segments) = NO**; SSO = YES | Mixed (see cells) |
| 8.6 | Attributes Management: User-defined attributes = YES; ETL attributes = YES | YES |

**Important refinement**: Item 7 confirms Retail Media Measurement is contractually **included** (not merely a future "TBD" idea) but requires customization against "6 use cases" (not yet enumerated in any document reviewed). This nuances the earlier "Phase 2 and beyond (TBD)" framing from the roadmap slide (slide 3) — it is sold/contracted, but not yet scheduled/detailed. Also notable: the **RLS Mechanism itself is explicitly NOT yet included** (8.5), and Supplier/CPG profiles & users are NOT included — both consistent with Phase 1 being internal-Unlimitail-users-only.

## Integration Data Flow (per DOC03: "7_Integration_Deck_Unlimitail.pptx")
This document is the most direct and detailed answer found so far to the incoming-feed-format/data-flow/integration-points question. It describes a **generic Unlimitail integration architecture** applicable to any activation-platform/DSP partner (no specific partner named in the deck) — distinct from, and more concrete than, DOC01's TTD-based template.

**Architecture flow**: Retailer data (transaction/customer/store/product) → Clean Data Hub (governed sharing layer) → CDP/CBP/CDI (identity resolution to universal ID) → Audience creation (segment logic) → Activation platforms (onsite Epsilon/Citrus-type, offsite open web LiveRamp, Meta/walled gardens, DSPs) → Events back (exposure/clicks/impressions, where available) → Measurement (sales matching, then reporting).

**Outbound feeds (Unlimitail → partner)**, delivered as files (GCS preferred; SFTP/HTTPS supported):
| Feed | Content | Purpose |
|---|---|---|
| Product catalogue | upc, description, category hierarchy, brand | So partner's dim_product/dim_category match Unlimitail's; product join floor = 99% on upc↔gtin |
| Shopper dimensions | universal-id-ready key + audience-building attributes | So audiences can be defined on real shopper behavior and resolved partner-side |
| Segment membership | segment_id, definition_version, point-in-time membership | Membership drifts — the snapshot at publication time is the record of what was targeted |
| Orders and customers | as specified in onboarding | Reconciliation of the order feed against the partner's own fact_order |

**Inbound data objects (partner → Unlimitail)**, via a BigQuery dataset share at retailer tier, from the **Core Dataset** (NOT the Reporting Datamart, which holds current-dimension-only state):
| Object | Grain | Content | Critical? |
|---|---|---|---|
| fact_realised_ad_agg_2 | shopper | Customer-level exposure — who saw the ad | "The single most important table" |
| fact_realised_ad | impression | Impressions, clicks, reach, frequency, placement | |
| fact_ad_request | request | Fill rate, unsold inventory, unmet demand | |
| fact_enhanced_attribution | campaign × SKU | Partner's own attributed outcome/ROAS, stored as theirs | |
| fact_ledger + fta_campaign_spend | transaction/campaign | Media spend — must be unioned or fixed placements are missed | |
| dim_campaign_attr | campaign | Where Unlimitail's PROGRAMME id lives — the reconciliation key | Required |
| dim_product / dim_category | product | Partner's view of the catalogue Unlimitail sent, for mapping | |
| log_status | load | Load start/end/status — Unlimitail's pipeline trigger | Required |

See Business Processes.md (BP-10, BP-11) for the full 8-handshake (H1–H8) table and the join/match-rate floor table (product 99%, shopper 95%, session 90%, feed integrity 100%).

**Gap still open**: this document defines the data objects, mechanism, and cadence, but not the exact field-level record layout (column names/types/nullability) for any of the above feeds/objects — that level of detail has still not been located in any document reviewed (see Open Questions OQ-C018).

## Reference (Syndicated FMCG) Data Provision (per DOC04)
A distinct, contractually-defined data feed from NIQ **to** Unlimitail (opposite direction from the DOC03 integration feeds): NIQ provides FMCG syndicated reference data ("Product Characteristics") for France, Spain, and Brazil, defined solely by NIQ per country (not retailer-specific). Delivered as an **initial historical batch**, then at a mutually agreed frequency, as a **flat file to be ingested and managed by Unlimitail** (operational stream still WIP, not yet on the delivery workplan per DOC04's own note). Indicative fields (subject to feasibility assessment) — the most concrete field-level detail found so far for any feed:
| Country | Indicative Fields |
|---|---|
| France | Secteur, Rayon, Sous Rayon, Fabricant |
| Spain | Sector, Sección, Categoría, Fabricante |
| Brazil | Cesta, Categoria, Fabricante |

Contract terms: data is NIQ's exclusive IP (Unlimitail may ingest/enrich its own datasets and use as additional Activate fields, but gains no other rights); NIQ is not obligated to customize beyond standard local SLAs; third-party (non-Carrefour) retailer data requires that retailer's written authorization.

## Retail Media Tech Stack Data Flow — File-Level Detail (per DOC06, labeled "phase 2 scope")
DOC06's slide 13 ("NIQ Activate in Unlimitail's Retail Media Tech Stack") gives the **most concrete field-level file layouts found so far** for the audience-creation → activation → attribution → measurement flow between Activate, a CDP (Universal ID/audience activation), and a media channel (example given: The Trade Desk):
| File | Fields |
|---|---|
| NIQ Hierarchy enrichment | EAN + X levels of Product Characteristics |
| Audience | Audience ID + Universal ID + Control Y/N |
| Activate Data ("per spec") incl. Shopper Attributes | Universal ID + Custom Segment + Attribute (full data interface) |
| Audience (channel-specific) | Universal ID converted to channel-specific ID |
| Campaigns metadata | Campaign, Channel, Ad Groups (Audience), Ads (Audience) |
| Attribution loop-back | Universal ID, Audience ID, Campaign ID, Ad Group ID, Ad ID, Channel, Action (Impression/Click), Timestamp |
| Ad–SKUs mapping | Source and destination **TBD** (explicitly unresolved in the deck) |

This significantly narrows OQ-C018 (incoming feed field-level layout) for the media-measurement flow specifically, though it does not fully reconcile with DOC01's file-based interface names or DOC03's BigQuery-object model — see AS-012 and the renewed CF-008 signal in Domain Model.md regarding whether this flow is Phase 1 or Phase 2 scope.

## Retail Media Tech Stack Data Flow — Authoritative 8-Arrow Spec (per DOC07, supersedes/extends DOC06)
DOC07 contains the same architecture diagram as DOC06 but with a dedicated "Data Feed Items per Integration Arrow" slide giving the fullest field-level spec found across all documents:
| Arrow | From → To | Fields |
|---|---|---|
| 1 | NIQ Characteristics DB → CDP | NIQ product hierarchy definitions (category, sub-category, product group); NIQ product characteristics/attributes for hierarchy classification |
| 2 | Carrefour → CDP | Carrefour product attributes (non-hierarchy: brand, pack size, format) |
| 3 | CDP → Activate (NIQ) | Customer data (profile/identity); Transaction log (TLOG); Product hierarchy (NIQ) & product attributes (Carrefour); Customer attributes & customer segments |
| 4 | Activate (NIQ) → CDP (Audience Push) | Segment ID; Customer Universal ID; Control sub-group definition (when applicable) |
| 5 | CDP → Offsite Channels | Segment ID; Customer Universal ID; Channel-specific campaign setup parameters |
| 6 | Offsite Channels → CDP (Performance) | Campaign ID; Segment ID & Universal ID; Event data (impressions, clicks, conversions) — **non-walled-gardens only** |
| 7 | CDP → Activate (NIQ) (Closed-Loop) | Segment ID & Universal ID; Campaign ID; Event/interaction data (clicks, views, conversions) |
| 8 | Campaign Metadata DB → Activate (NIQ) | Campaign ID; Campaign attributes (dates, budget, objectives, brand, product scope, channel mix) |

**Critical scope caveat (DOC07 slide "Solution Assumptions & Considerations," Phase 1-2):** Universal Customer ID and Product Hierarchy/Attributes integration are explicitly "Critical for phase 1 — confirmed"; Carrefour segment loading is "Confirmed already in phase 1"; but **closed-loop measurement (Arrows 6-7) applies to non-walled-garden channels only and is explicitly "phase 2"** — in-store and walled-garden channels are "beyond phase 2." This is the clearest documented evidence yet distinguishing which parts of the flow are Phase 1 vs. Phase 2 — see renewed CF-008 in Open Questions.md.

## Simplified As-Is Data Flow (per DOC08, client-side narrative)
DOC08 independently describes the same overall flow using different component names, corroborating DOC03/DOC06/DOC07's architecture from the client's own operational perspective:
Retailer data → Clean Data Hub / governed data layer → CDP / identity resolution / universal ID → Audience creation and segment logic → Activation platforms / broadcasters → Campaign events, exposure, clicks, impressions, or aggregate outputs → Sales / transaction matching → Measurement and reporting.
Notable new/renamed component: **OneDB** — expected central campaign-metadata store (see Domain Model.md). Confirms the same integration gaps already logged (identity normalization across e-commerce/in-store, product/catalog hierarchy consistency, campaign master-of-record) from an independent, non-technical source.

## Revision Log
| Date | Source Document | Change Summary |
|---|---|---|
| 2026-09-12 | DOC10/DOC11/DOC12/DOC13 | Reviewed; no new field-level data content. DOC10's measurement-prerequisite artifacts (Arm Assignment, Ghost Log, Frozen Eligibility Snapshot) and DOC11's use-case catalog captured at the concept level in Domain Model.md instead; DOC12/DOC13 too generic for field-level detail. |
| 2026-09-12 | DOC09 - Unlimitail Workshop June 26 (agenda/planning workbook) | Reviewed; agenda/planning-only, no new field-level data content (confirms same core platform categories already captured under DOC03/DOC06/DOC07). |
| 2026-09-12 | DOC08 - Unlimitail July 2027 workshop discovery summary (As-Is narrative) | Added the client-side simplified as-is data flow (corroborating DOC03/DOC06/DOC07's architecture) and the OneDB component reference. |
| 2026-09-12 | DOC07 - Discovery Workshop July 2026 (agenda/template) | Added the authoritative 8-arrow, field-level data flow spec (supersedes/extends DOC06's simpler version) plus the critical Phase 1 vs Phase 2 scope caveat distinguishing audience integration (Phase 1) from closed-loop measurement (Phase 2, non-walled-garden only). |
| 2026-09-12 | DOC06 - Unlimitail Business Stream (config workshop) | Added the most concrete field-level file layouts found so far for the audience/activation/attribution data flow (7 named files with explicit field lists), from a slide explicitly labeled "phase 2 scope." |
| 2026-09-12 | DOC04 - Unlimitail Sales to Delivery handover (internal NIQ deck) | Added Reference (Syndicated FMCG) Data Provision section — the most concrete field-level feed detail found so far (France/Spain/Brazil indicative field names), plus contract terms (IP, feasibility, third-party authorization). |
| 2026-09-12 | DOC03 - 7_Integration_Deck_Unlimitail (Integration Workshop) | Added the full Integration Data Flow section: architecture diagram (Clean Data Hub → CDP → audience → activation → measurement), 4 outbound feeds, 8 inbound BigQuery data objects, and cross-reference to the 8-handshake and join-floor tables in Business Processes.md. Confirmed field-level record layout is still an open gap. |
| 2026-09-12 | DOC02 - Unlimitail Kick-off Meeting (Carrefour, Phase 1) | Added Phase 1 onboarding data parameters (volumetrics, history requirement, load cadence, NIQ→Unlimitail reference/taxonomy data flow, validation checkpoints) plus the full contracted Order Form module/report entitlement table extracted from embedded slide images; refined Retail Media Measurement scope status (contracted, pending 6-use-case customization). Confirmed incoming-feed field-level layout still not located in any document. |
| 2026-09-12 | DOC01 - Retail Media Measurement closed loop concept design (TTD) | Initial population: 10 data-interface entities/files and their key relationships for the MVP closed-loop measurement solution. Cross-referenced against prior Unlimitail sample-report analysis. |
| 2026-09-12 | — | File initialized, no client documents analyzed yet |
