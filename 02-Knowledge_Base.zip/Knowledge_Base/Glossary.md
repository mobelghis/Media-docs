# Glossary

**Status:** 15 of 15 planned Unlimitail source documents analyzed. All source documents have now been reviewed.
**Last updated:** 2026-09-12
**Documents analyzed:** DOC01 - "Retail Media Measurement – closed loop concept design (no incrementality).docx"; DOC02 - "Unlimitail - Kick-off Meeting.pptx"; DOC03 - "7_Integration_Deck_Unlimitail.pptx"; DOC04 - "Unlimitail - Sales to Delivery handover.pptx"; DOC05 - "Eran_Mo KT - Session 1.docx"; DOC06 - "Unlimitail Business Stream.pptx"; DOC07 - "Unlimitail & NIQ Discovery Workshop July 2026 (3).pptx"; DOC08 - "Unlimitail July 2027 workshop - discovery summary.docx"; DOC09 - "Unlimitail Workshop June 26.xlsx"; DOC10 - "ADLM Jira 2026-09-12T16_26_03-0400.xls" (NIQ Activate Personalization product backlog export, generic/all-clients); DOC11 - "Unlimitail_Dataplatform RFQ_UCs list - NIQ Response V1 - UPDATED 20 Jan 26 _Phase 1 estimations.xlsx"; DOC12 - "Unlimitail_Detailed_Email_Analysis.docx"; DOC13 - "Unlimitail_Email_Summary(2).docx"

## Purpose
Defines business and technical terms, acronyms, and named entities encountered across client documents, with source attribution. Where terminology conflicts across documents, both definitions are preserved with a note.

## Terms
| Term | Definition | Source Document | Notes / Conflicts |
|---|---|---|---|
| RMN | Retail Media Network — a retailer's owned digital advertising network. | DOC01 | |
| DSP | Demand-Side Platform — the ad-buying/serving platform used by advertisers (e.g., TheTradeDesk). | DOC01 | TTD-specific example; Unlimitail's actual DSP TBC (AS-001). |
| TTD / TheTradeDesk | The DSP selected as the MVP integration partner in DOC01. | DOC01 | **Assumption-flagged**: to be replaced/confirmed for the Unlimitail engagement. |
| UID 2.0 (Unified ID 2.0) | TTD's deterministic, PII-based customer identifier with user transparency/privacy controls; negates need for separate identity resolution in TTD's MVP. | DOC01 | TTD-specific; Unlimitail equivalent TBC (AS-002/AS-004). |
| RampID | An alternate (identity-resolution-vendor-supplied) retail media identifier type referenced alongside UID 2.0. | DOC01 | |
| Loyalty ID | The retailer's internal customer/loyalty identifier. | DOC01 | |
| Retail Media ID | A DSP/ad-ecosystem identifier (e.g., RampID, UID 2.0) used to link ad exposure to a shopper. | DOC01 | |
| T-Log (Transaction Log) | The retailer's record of actual purchase transactions; reuses NIQ's existing T-Log interface. | DOC01 | |
| Impression | An ad-load event (INTERACTION_TYPE = I). | DOC01 | |
| View | An ad-view event (INTERACTION_TYPE = V), incl. Video View (W). | DOC01 | |
| Click | A user click on a displayed ad (INTERACTION_TYPE = C). | DOC01 | |
| Conversion / Purchase | A purchase event attributed to an ad (INTERACTION_TYPE = P). | DOC01 | |
| CTR (Click-Through Rate) | % of impressions resulting in a click. | DOC01 | |
| Conversion Rate | % of impressions resulting in a purchase of an advertised product (identified customers only). | DOC01 | |
| CPM | Cost per 1,000 impressions = Advertising Cost ÷ (Impressions/1000). | DOC01 | |
| CPC | Cost per click = Advertising Cost ÷ Clicks. | DOC01 | |
| ROAS (Return on Ad Spend) | Attributed Sales ÷ Advertising Cost. Primary MVP KPI. | DOC01 | Matches the "F6 ROAS" KPI already cataloged in `Report_KPI_Dimension_Analysis.xlsx`. |
| Incremental ROAS (iROAS) | ROAS measured incrementally vs. a control group; Phase 2 scope, out of MVP. DOC14's discovery questionnaire uses the abbreviation "iROAS" for the same concept, asked as a distinct discussion question alongside plain ROAS. | DOC01, DOC14 | Relates to prior unresolved OQ01 (lift/incrementality methodology undocumented in sample reports). |
| Attribution Window | Max time lag between ad exposure and purchase to be considered attributable (default 14 days/336h). | DOC01 | |
| Attribution Model | Logic for crediting a sale across multiple exposures (MVP = last-touch). | DOC01 | |
| Closed-Loop Measurement | The overall methodology: ad exposure → purchase, "closed" at checkout/loyalty identification. | DOC01 | |
| CPG | Consumer Packaged Goods company — used interchangeably with "Advertiser"/"Brand" in DOC01. | DOC01 | |
| RLS (Row-Level Security) | Access-control model scoping which campaigns a user can see. | DOC01 | |
| NielsenIQ Activate | The SaaS platform intended to host the measurement reports (per DOC01). | DOC01 | Possible naming overlap/relation to "Memory 360"/"Unlimitail" branding seen in prior sample reports — see Open Questions CF-001. |
| Ad Group / Line Item | A container of targeting/bid/budget/creative strategy within a Campaign. | DOC01 | |
| Creative / Ad | The actual video/image/HTML5/text advertisement asset. | DOC01 | |
| Campaign Goal (TTD) | One of: Reach, Incremental Reach, CPC, CPA, vCPM, CPCV, ROAS, CTR, VCR, Viewability — up to 3 hierarchically interdependent goals per TTD campaign. | DOC01 | TTD-specific taxonomy; Unlimitail's equivalent TBC (AS-003). |
| Carrefour | The Retailer client for this engagement, confirmed active in France, Spain, and Brazil. | DOC02 | |
| Unlimitail | The retail-media/JV partner delivering this program on behalf of Carrefour. | DOC02 | |
| Insights Premium | The Phase 1 product module (Event Analyzer + Assortment Distribution reports). | DOC02 | |
| Event Analyzer Report | Phase 1 report analyzing promotional/event performance. | DOC02 | |
| Assortment Distribution Report | Phase 1 report analyzing product assortment effectiveness. | DOC02 | |
| Portal | A country-specific NIQ Activate deployment/instance (France, Spain, Brazil in Phase 1). | DOC02 | |
| Business Configuration Document | The single document defining shared business/data configuration across the 3 Phase 1 portals. | DOC02 | |
| Data Injection | A single onboarding data-loading event covering all 3 countries under one project. | DOC02 | |
| BAU (Business As Usual) | The steady-state operating phase after Go-Live, with its own recurring meeting cadence. | DOC02 | |
| KoM (Kick-off Meeting) | The formal project-start meeting establishing scope, workstreams, and next steps. | DOC02 | |
| UAT / C-UAT | User Acceptance Testing; C-UAT = Customer UAT, distinct from internal CS UAT. | DOC02 | |
| Steering Committee | An optional senior governance forum for major approvals (implementation plan, UAT results, rollout plan). | DOC02 | |
| Workstream | One of 4 Phase 1 delivery tracks: Project Management, Data Onboarding, Business Stream, Support. | DOC02 | |
| Sign-off Gate | A formal approval checkpoint (6 total) that must be passed before the team proceeds to the next onboarding task. | DOC02 | |
| Clean Data Hub | A governed layer for the retailer to share data with downstream systems without moving it uncontrolled. | DOC03 | |
| CDP / CBP / CDI | Identity-resolution layer normalizing customer/account/card/individual identifiers to a universal ID. | DOC03 | |
| PROGRAMME | Proposed level-0 entity above Campaign, written into a partner's dim_campaign_attr for cross-channel reconciliation. | DOC03 | Proposed, not yet confirmed adopted. |
| Lane A / Lane B | Lane A = retailer-owned-channel offers (email/app/wallet/POS); Lane B = paid media (audience published, brand buys, partner activates). | DOC03 | |
| Ghost Bid / PSA Control | A per-campaign randomized holdout mechanism where the ad server withholds or serves a placebo to a random subset of the reachable audience, preserving both reach and causal validity. | DOC03 | |
| Core Dataset vs. Reporting Datamart | BigQuery data tiers; Datamart = current-dimension-only (loses history); Core Dataset = full history, required for accurate measurement. | DOC03 | |
| Match-rate Floor | A published daily join-quality threshold (e.g., 99% product, 95% shopper, 90% session, 100% feed integrity) below which a metric is flagged rather than reported. | DOC03 | |
| fact_realised_ad_agg_2 | Inbound BigQuery table: shopper-grain customer-level ad exposure; "the single most important table." | DOC03 | |
| fact_realised_ad | Inbound BigQuery table: impression-grain impressions/clicks/reach/frequency/placement. | DOC03 | |
| fact_ad_request | Inbound BigQuery table: request-grain fill rate/unsold inventory/unmet demand. | DOC03 | |
| fact_enhanced_attribution | Inbound BigQuery table: campaign×SKU-grain partner-side attributed outcome/ROAS. | DOC03 | |
| fact_ledger / fta_campaign_spend | Inbound BigQuery tables: transaction/campaign-grain media spend. | DOC03 | |
| dim_campaign_attr | Inbound BigQuery table: campaign-grain dimension holding Unlimitail's PROGRAMME id — the reconciliation key. | DOC03 | |
| dim_product / dim_category | Inbound BigQuery tables: partner's view of the product catalogue Unlimitail sent. | DOC03 | |
| log_status | Inbound BigQuery table: load start/end/status, used as Unlimitail's pipeline trigger. | DOC03 | |
| TCV | Total Contract Value — the 3-year Unlimitail contract's TCV is $1.2M USD (Section 1 / Phase 1, Carrefour France/Spain/Brazil). | DOC04 | |
| Publicis Groupe | Co-founder of Unlimitail; contributes media/ad tech via Epsilon/CitrusAd. | DOC04 | |
| Epsilon / CitrusAd | Retail media technology platform used by Unlimitail, contributed by Publicis Groupe. | DOC04 | |
| LiveRamp (legacy) | Unlimitail's current/legacy provider of identity resolution, clean room, data lake, and insight/measurement — being replaced by this engagement. | DOC04 | |
| Memory / Memory 360 (legacy) | Unlimitail's legacy insights tool for France (via Carrefour France subscription) — distinct from and being replaced by NielsenIQ Activate. | DOC04 | Resolves CF-001. |
| Mediarithmics | Unlimitail's understood new/incoming CDP provider. | DOC04 | |
| GeoPurchase | NIQ media data asset: a data-science model translating sales dynamics into "Precision Areas." | DOC04 | |
| Digital Purchases | NIQ media data asset: e-commerce purchase-behavior tracking based on electronic receipts. | DOC04 | |
| Coupon Bank | A named container of Coupons in the Personalization module; linked 1:1 to a Marketing Policy. | DOC05 | |
| Marketing Policy (aka Campaign Template) | Defines the top-level eligibility segment, control group %, channel opt-in filter, min/max coupons per shopper, and diversity rules for all Campaigns linked to it. | DOC05 | |
| Campaign (aka Wave) | An instance under a Marketing Policy with its own start/end dates and Offers; the legacy product name is "Wave." | DOC05 | |
| Offer | A Coupon combined with a targeting definition (marketing objective, eligibility segment, CSV list, or segment); 1 Coupon can back many Offers. | DOC05 | |
| Marketing Objective | Automatic offer targeting mode: Retention (bought before), Cross-sell (scored likely-to-buy, hasn't bought), Win-back (bought before, lapsed), Filler (remaining eligible population). | DOC05 | |
| SKU Coupon / Category Coupon / Virtual Category Coupon | The 3 Coupon types: SKU (single CPG + specific products), Category (catalogue-category level, retailer-funded), Virtual Category (attribute-based grouping outside the catalogue hierarchy). | DOC05 | |
| Allocation (Personalization) | The offline batch optimization process assigning eligible Offers to eligible shoppers under all defined constraints. | DOC05 | |
| Generic Hierarchy | Product/store dimension fields (department, category, region, etc.) supported as filters/dimensions in ALL Activate reports. | DOC06 | |
| Attribute | Product/store/transaction fields (private label flag, promo Y/N, store format, etc.) supported in only *most* Activate reports (not yet Category Share/G&L/NPL). | DOC06 | |
| Same Store (toggle) | A report filter marking stores that have been open continuously for the last 24 months, for like-for-like comparison. | DOC06 | |
| Same Customer (base definition) | Customers who purchased at least once per quarter in each of the last 2 years; excludes new/gone/infrequent shoppers. | DOC06 | |
| Retail Media Maturity Model | NIQ's 4-stage framework for RMN sophistication: Data Fragmentation → Operational → Closed Loop → Ecosystem, tied to first-party data, identity resolution, and measurement maturity. | DOC07 | |
| Ownership Matrix | A RACI-style table assigning each platform layer (Planning, Audience/CDP, DSPs, Clean Rooms, Measurement, Reporting) to NIQ, Unlimitail, or Partners as Lead/Input/Integrate/Access. | DOC07 | |
| Alternative Conversion / Alternative Lift | A measurement method used when true exposure data is unavailable; compares targeted/exposable audiences rather than confirmed-exposed users. Explicitly considered less rigorous than true lift, but currently a major share of Unlimitail's measurement work. | DOC08 | |
| Partner Lift | Lift measurement conducted directly inside a walled-garden platform (e.g., Meta) using that platform's own methodology, used when Unlimitail cannot access exposed-user data in its own environment. | DOC08 | |
| Phase 2 SOW | A Statement of Work reference cited in DOC09's discovery-workshop kickoff agenda, explicitly scoping the June-July 2026 discovery workshop series (and by extension its outputs, DOC07/DOC08) as "Phase 2" work. Not yet confirmed against the actual SOW document — see AS-019, OQ-C042. | DOC09 | |
| Control Group Selection Logic | NIQ Activate's Personalization allocation module's mechanism for choosing which shoppers form the control/holdout group; historically biased (e.g., a fixed 1,500-shopper or 50%-of-pool rule for one retailer) rather than statistically mirroring the test group — being generically fixed per CR-31111/CR-30454. A shopper cannot be placed into more than 2 control groups (configurable). | DOC10 | |
| Net Lift | Incremental spend after subtracting the discount/reward value given (e.g., €100 baseline → €120 purchased with €10 discount → net spend €110 → net lift €10). | DOC10 | |
| Gross Lift | Incremental spend before subtracting the discount/reward value (same example → gross lift €20). Configurable alternative to Net Lift per retailer preference. | DOC10 | |
| FEASIBILITY (RFQ rating) | NIQ's technical-feasibility rating for each RFQ use case: "Natively supported," "Natively supported with advanced set-up," "Requires custom development," or "Not feasible / Not supported." | DOC11 | |
| Current Product Coverage Level | NIQ's rating of how completely Activate currently covers an RFQ use case, independent of feasibility: Full, Partial, TBD, or None. | DOC11 | |
| Sales Impact Review | An RFQ use case (#2): measuring incremental KPIs (sales, revenue) attributable to a campaign by isolating its effect relative to a control group, subject to a validated Incrementality Test. Flagged as a Phase 1 requirement in the RFQ but rated "Coverage: None" (not yet built). | DOC11 | |

## Revision Log
| Date | Source Document | Change Summary |
|---|---|---|
| 2026-09-12 | DOC14 - Unlimitail NIQ Discovery Questionnaire (pre-workshop prep template) | Added "iROAS" as a confirmed abbreviation alias to the existing "Incremental ROAS" term. |
| 2026-09-12 | DOC11 - Unlimitail Dataplatform RFQ Use Cases list (NIQ Response, 20 Jan 2026) | Added 3 glossary terms: FEASIBILITY (RFQ rating), Current Product Coverage Level, Sales Impact Review. |
| 2026-09-12 | DOC10 - ADLM Jira export (NIQ Activate Personalization backlog) | Added 3 glossary terms: Control Group Selection Logic, Net Lift, Gross Lift. |
| 2026-09-12 | DOC09 - Unlimitail Workshop June 26 (agenda/planning workbook) | Added 1 glossary term: Phase 2 SOW. |
| 2026-09-12 | DOC08 - Unlimitail July 2027 workshop discovery summary (As-Is narrative) | Added 2 glossary terms: Alternative Conversion/Alternative Lift, Partner Lift. |
| 2026-09-12 | DOC07 - Discovery Workshop July 2026 (agenda/template) | Added 2 glossary terms: Retail Media Maturity Model, Ownership Matrix. |
| 2026-09-12 | DOC06 - Unlimitail Business Stream (config workshop) | Added 4 glossary terms: Generic Hierarchy, Attribute, Same Store toggle, Same Customer base definition. |
| 2026-09-12 | DOC05 - Eran_Mo KT Session 1 (Personalization module KT) | Added 8 glossary terms covering the Personalization domain: Coupon Bank, Marketing Policy, Campaign/Wave, Offer, Marketing Objective, the 3 Coupon types, and Allocation. |
| 2026-09-12 | DOC04 - Unlimitail Sales to Delivery handover (internal NIQ deck) | Added 8 glossary terms: TCV, Publicis Groupe, Epsilon/CitrusAd, LiveRamp (legacy), Memory/Memory 360 (legacy, resolving CF-001), Mediarithmics, GeoPurchase, Digital Purchases. |
| 2026-09-12 | DOC03 - 7_Integration_Deck_Unlimitail (Integration Workshop) | Added 14 glossary terms covering the integration architecture, BigQuery data objects, control-group/ghost-bid mechanisms, and identity-resolution layer. |
| 2026-09-12 | DOC02 - Unlimitail Kick-off Meeting (Carrefour, Phase 1) | Added 14 glossary terms from the Phase 1 kickoff deck (Carrefour, Insights Premium, portal/onboarding/governance terminology). |
| 2026-09-12 | DOC01 - Retail Media Measurement closed loop concept design (TTD) | Initial population: 22 glossary terms from the closed-loop TTD concept design document. |
| 2026-09-12 | — | File initialized, no client documents analyzed yet |
