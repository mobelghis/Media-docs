# Business Processes

**Status:** 15 of 15 planned Unlimitail source documents analyzed. All source documents have now been reviewed.
**Last updated:** 2026-09-12
**Documents analyzed:** DOC01 - "Retail Media Measurement – closed loop concept design (no incrementality).docx"; DOC02 - "Unlimitail - Kick-off Meeting.pptx"; DOC03 - "7_Integration_Deck_Unlimitail.pptx"; DOC04 - "Unlimitail - Sales to Delivery handover.pptx"; DOC05 - "Eran_Mo KT - Session 1.docx"; DOC06 - "Unlimitail Business Stream.pptx"; DOC07 - "Unlimitail & NIQ Discovery Workshop July 2026 (3).pptx"; DOC08 - "Unlimitail July 2027 workshop - discovery summary.docx"; DOC09 - "Unlimitail Workshop June 26.xlsx"; DOC10 - "ADLM Jira 2026-09-12T16_26_03-0400.xls" (NIQ Activate Personalization product backlog export, generic/all-clients); DOC11 - "Unlimitail_Dataplatform RFQ_UCs list - NIQ Response V1 - UPDATED 20 Jan 26 _Phase 1 estimations.xlsx"; DOC12 - "Unlimitail_Detailed_Email_Analysis.docx"; DOC13 - "Unlimitail_Email_Summary(2).docx"

## Purpose
Documents end-to-end business processes/workflows described or implied by client documents, including actors, steps, triggers, and outcomes.

## Process Inventory
| Process ID | Process Name | Actors | Trigger | Summary | Source Document |
|---|---|---|---|---|---|
| BP-01 | Customer Identity Mapping Onboarding | Retailer, Identity Resolution provider | Retailer onboards its PII customer base to an ID resolution company | Retailer's Loyalty IDs are matched/mapped to a Retail Media ID (RampID/UID 2.0); mapping is historized (Effective_From/To) since IDs can change over time. | DOC01 |
| BP-02 | Daily Data Ingestion (ETL) | DSP (TTD), Retailer, NielsenIQ Activate | Scheduled daily batch (all feed types) | 9 daily files (Customer Mapping, Ad Interactions, T-Log, Targeting, Campaign/AdGroup/Ad Metadata, Ad Products, Campaign Engagement, Advertisers Mapping) are ingested into a standard data model via ETL. | DOC01 |
| BP-03 | Sales Attribution Matching | NielsenIQ Activate (system process) | Post-ingestion, daily | Ad interactions (impressions/views) are matched to T-Log purchases within the Attribution Window using the configured Attribution Model (MVP = last-touch), producing "Attributed Sales." | DOC01 |
| BP-04 | ROAS / KPI Calculation | NielsenIQ Activate (system process) | Post-attribution, daily | Cost data from the DSP is combined with Attributed Sales to compute ROAS and other KPIs (CTR, Conversion Rate, CPM, CPC, Reach, etc.); matched-universe results are extrapolated to the total customer base (methodology TBD — see Open Questions). | DOC01 |
| BP-05 | Measurement Reporting & Self-Serve Access | Retailer user, Advertiser/CPG user | User logs into NielsenIQ Activate SaaS UI | User views summary KPI cards, a 2-KPI trend chart, and a drill-down table, filtered/broken down by Campaign hierarchy, Engagement, Product, Geo, and Period — subject to RLS (own campaigns only for Advertisers) and permission tiering. | DOC01 |
| BP-06 | Program Kick-off & Governance Setup | NIQ PM (Jony Gurfinkel), Customer PM (Richard Fercoq), all workstream owners | Contract signed / project start | Kickoff meeting establishes Phase 1 vs. Phase 2 scope, the 4 workstreams, governance cadence, and immediate next steps (data-stream kickoff). | DOC02 |
| BP-07 | Phase 1 Onboarding End-to-End (16 weeks) | NIQ Data Onboarding, Business Stream, Support/Solution team; Customer counterparts | Kickoff complete | Sequential flow: Data Spec & Sample Data → Functional Specs → Historical Data Upload & Validation → Data Development (ETL) → Automated Periodical Load Config & Validation → Portal Configuration & QA & User Setup → Training → UAT → Go-Live. **[Client-confirmed, 2026-09-12]** This same onboarded data (T-Log/customer) is the shared foundation reused for Retail Media Measurement and Segmentation — not a separate onboarding pipeline per capability (see AS-020). | DOC02 |
| BP-08 | Governance & Sign-off Approval | NIQ PM/Product Expert/Data WS Leader, Customer stakeholders | Each major deliverable/milestone reached | 6 formal sign-off gates (Project Plan; Business Specification; Data Onboarding Spec & Sample Files; First Data Validation pre-load; Second Data Validation post-ETL; UAT) — team must not proceed without sign-off. | DOC02 |
| BP-09 | Recurring Project Governance Cadence | All workstream owners, Steering Committee | Weekly (ongoing) | Weekly workstream/follow-up meetings plus an optional Steering Committee (4 checkpoints: approve implementation plan, review UAT results, implementation summary, approve rollout plan); transitions to a separate BAU meeting cadence post-Go-Live. | DOC02 |
| BP-10 | Integration Data Exchange (Outbound + Inbound) | Unlimitail (Clean Data Hub/CDP), Activation Platform/DSP partner | Per onboarding + ongoing daily/on-change cadence | 8 "handshakes" (H1–H8) exchange product catalogue, shopper dimensions, segment membership, programme ID, exposure, attributed outcome, spend, and control/holdout mechanism between Unlimitail and the activation partner — see Data Model.md for full detail. | DOC03 |
| BP-11 | Join/Match-Rate Quality Monitoring | Unlimitail (measurement system) | Daily, post-ingestion | 4 join keys (product, shopper, session, feed integrity) are matched and their match rate published daily against a floor (99%/95%/90%/100%); a number built on a below-floor join is flagged rather than reported. | DOC03 |
| BP-12 | Contract Commercial Lifecycle | NIQ Finance/CS, Unlimitail | Contract signature / quarterly | Quarterly advance invoicing (from June 1, 2026); 2026 implementation-year value recognized at 3 milestones (Kick-off €58,333; Data Onboarding Completion €58,333; UAT €58,333); 36-month term with 12-month auto-renewal unless 90-day termination notice. | DOC04 |
| BP-13 | Personalization Campaign Setup & Allocation | NIQ Product/CS, Retailer | Per campaign | Setup order: Coupon Bank → Marketing Policy (eligibility, control group, channel opt-in, min/max, diversity) → Campaign (dates) → Offer (coupon + targeting). User triggers Allocation (offline optimization, 30 min–several hours); campaign either goes Active (success) or Failed (if any shopper missed the minimum, can be manually approved anyway); once approved, recommendation files are pushed to the retailer, who executes the actual send; redemption data is returned via file interface and updates the campaign for a period after completion. **[DOC10 — platform dependency, generic]** The underlying control-group selection logic used here is being generically fixed (CR-31111/CR-30454) to statistically mirror the test group, and per-offer (not just programme-level) lift attribution depends on measurement-prerequisite artifacts (arm assignment, ghost log) still being built (CR-40346, targeted PI 2026.4) ahead of the Advanced Lift Measurement Framework (CR-38880, targeted PI 2027.3). | DOC05 |
| BP-14 | Retail Media Campaign E2E Process (generic) | Advertiser/Brand, UNL Business/Operations, NIQ Analytics | Per campaign | 7 stages: Brief & Request → Planning & Approvals → Targeting & Audiences → Campaign Build & Activation → In-Flight Optimization → Measurement & Attribution → Reporting & Insights. Presented as the generic reference process against which Activate's fit and gaps are being assessed (workshop discovery topic, not yet confirmed as Unlimitail's actual as-is process). | DOC07 |
| BP-15 | Unlimitail Current (As-Is) Campaign Operating Model | Sales, Insights/Analytics, Operations, Brand/Advertiser, Agency/Creative Partner, Platforms/Partners | Per campaign | Client's own narrative of today's real-world flow, closely mirroring BP-14's generic stages: (1) Planning & opportunity identification — sales/insights use retailer data (down to SKU/store level) to surface problems (customer/region/category loss, competitor pressure) before a brief exists; (2) Brief creation & objective definition — issue translated into a specific objective (win-back, recruitment, upsell, retention, awareness, consideration, conversion); budget often pre-set by the brand; (3) Audience creation & feasibility — sales defines initial audience from behavior/loyalty/basket data, checked for platform reachability/match rate before commitment; (4) Campaign activation across platforms — Operations sets up the campaign per-platform (onsite via Epsilon/Citrus, offsite via LiveRamp/open web, Meta/social, DSPs) — explicitly **no single unified campaign system**; (5) Optimization — largely pre-launch feasibility/power-testing; daily in-flight optimization is rare (one cited exception: "CCR Retail"); onsite is more controllable than offsite; (6) Measurement & reporting — uses Brand Lift Survey/Conversion/Lift/Alternative-lift/Partner-lift per channel (see Measurement Type Taxonomy in Domain Model.md); top-level media metrics available ~2 days post-campaign, full business-impact report typically ~45 days post-campaign; (7) Reporting output — still highly manual (dashboards + Excel), analyst-curated storytelling rather than full self-serve. | DOC08 |
| BP-16 | Discovery Workshop MVP vs. Phase 2+ Scoping Methodology | Product, Consultant, Tech, Program Leadership | Once, during the June-July 2026 discovery workshop series | The workshop's Day 2 "Solution Scenarios & Design Direction" and closing sessions define a structured scoping method: agree the desired future/target-state E2E flow (brief → planning → activation → measurement → reporting → insights → optimization); explicitly separate **MVP scope** (retailers/channels/campaign types, required data feeds, minimum planning support, must-have measurement outputs, launch criteria) from **Phase 2+ capabilities** (additional channels, advanced planning, self-serve workflows, incrementality, cross-channel deduplication, optimization, automation). Final deliverables: current-state process/tech-stack summary, Activate integration hypothesis, channel attribution/data-feasibility view, target-state E2E workflow, MVP scope & go-live deliverables, Phase 2/future roadmap items, and an open-questions/risks/owners/next-steps action plan. **[DOC14 addendum]** The pre-workshop questionnaire/prep guide sent to the client formalizes the Day-1 discovery intake into 4 tracks: (1) Retail Media Business & Operating Model (org structure, campaign lifecycle, audience taxonomy/refresh, DSPs/channels used, bottlenecks); (2) Measurement, Reporting & Advertiser Experience (KPIs, attribution methods, incrementality/ROAS/iROAS measurement, reporting gaps); (3) Personalized Promotions & Offer Personalization (offer design/funding/approval, supplier participation, redemption metrics); (4) Data, Technology & Architecture (systems, identity/matching identifiers, integrations, refresh/latency, planned migrations) — this 4-track structure aligns with and appears to be the template underlying DOC07's discovery agenda and DOC08's as-is narrative. | DOC09, DOC14 |

## Process Detail

### BP-02: Daily Data Ingestion (ETL)
1. DSP (TheTradeDesk) sends: Campaign Metadata, Ad Group/Line Item Metadata, Ad/Creative Metadata, Campaign Engagement (aggregated cost/impressions/views/clicks).
2. Identity Resolution/CDP (or DSP) sends: Ad Interactions (impression/view/click/conversion-level, consented only), Targeting file (who was targeted, when).
3. Retailer sends: Customer Mapping File (Loyalty ID ↔ Retail Media ID), T-Log (transactions), Ad Products File (ad↔product/brand/category), Advertisers Mapping File (advertiser↔CPG↔brand, for RLS).
4. All files land in a standard data model via scalable, configurable ETL (per-retailer configuration variance expected).

### BP-03/BP-04: Attribution & ROAS Calculation ("Closed Loop")
1. For each Ad Interaction (impression/view) with a Retail Media ID, look up the matching T-Log purchases for the same shopper within the Attribution Window (default 14 days after exposure).
2. Apply the Attribution Model (MVP = last touch: the most recent qualifying impression/view gets 100% credit for the sale) if multiple exposures exist.
3. Sum Attributed Sales per Ad/Campaign; divide by Advertising Cost (default = advertiser cost) to compute ROAS.
4. Extrapolate from the matched-customer universe to the full customer base to correct for partial identity-match coverage (methodology and bias-control approach explicitly marked TBD in source — see OQ-C006).

### BP-05: Measurement Reporting
1. User authenticates into NielsenIQ Activate; RLS scopes visible campaigns (Retailer = all, Advertiser/CPG = own only).
2. User applies filters (Campaign hierarchy, Engagement, Product, Period — single period, no compare) and selects a breakdown grain (Daily/Weekly/Monthly/Quarterly; Hourly post-MVP).
3. UI renders: (a) summary KPI cards, (b) 2-KPI trend chart (switchable KPIs), (c) detailed drill-down table across campaign/product/interaction dimensions.
4. Permission tiering (monetization-driven) governs which filters/dimensions/KPIs a given user tier can access.

### BP-07: Phase 1 Onboarding End-to-End (16-week timeline, per DOC02)
1. **Data Specification & Sample Data** → **Functional Specifications** (parallel early tracks).
2. **Historical Data Upload & Validation** — customer provides 24 months of historical data in Activate standard format; gated by "Data & Functional Spec Signoff."
3. **Data Development (ETL)** — NIQ builds/executes ingestion; gated by "Data Validation Signoff."
4. **Configuration of Automated Periodical Data Load + Validation** (recurring daily/weekly refresh setup).
5. **Portal Configuration & QA & User Setup** across the 3 country portals.
6. **Training** (training kit prep).
7. **UAT** — internal CS UAT, then Customer UAT — gated by "UAT Signoff."
8. **Go-Live**, followed by transition to BAU meeting cadence.
- Target milestones (per DOC02): sample data files due no later than 29/07/26; Data onboarding end date 14/09/26; Portal configuration 15–28/09/26; Internal CS UAT 02–12/10/26; Ready for Customer UAT 12/10/26; Ready for Go-Live 29/10/26 (optional, based on agreed C-UAT date). Timeline explicitly caveated as tentative pending Project Plan approval and subject to summer-vacation impact.

### BP-08: Governance & Sign-off Approval (per DOC02)
| Sign-off | What | Gate | Owner (NIQ) | Method |
|---|---|---|---|---|
| Project Plan | Key milestones & customer commitment dates | First step after kickoff | PM | Meeting, email |
| Business Specification document | Configuration doc, user types/profiles | Before historical data received | Product Expert | Inside the spec |
| Data onboarding spec & sample files | File format/content, delivery method, periodical load agreement | Before historical data received | Data WS Leader | Inside the spec |
| First Data Validation | Historical data KPIs based on data delivered by customer | Before historical load | Data WS Leader | Validation Excel |
| Second Data Validation | Historical data KPIs based on data loaded to Activate (post-ETL) | Last stage of historical load, before product configuration | Data WS Leader | Validation Excel |
| UAT sign-off | Customer user acceptance | Before Go-Live | PM | Email |

### BP-10: Integration Data Exchange (per DOC03)
**Outbound (Unlimitail → activation partner)**, delivered as files (Google Cloud Storage preferred; SFTP/HTTPS supported):
1. Product catalogue (upc, description, category hierarchy, brand) — before any campaign, then on change.
2. Shopper dimensions (universal-id-ready key + audience-building attributes) — initial load, then daily delta.
3. Segment membership (segment_id, definition_version, point-in-time membership snapshot) — on publication and on change.
4. Orders and customers (as specified in onboarding) — for reconciliation against the partner's own order feed.

**Inbound (activation partner → Unlimitail)**, accessed via a BigQuery dataset share at retailer tier, from the **Core Dataset** (not the Reporting Datamart, which holds current-dimension-only state and would lose history):
- `fact_realised_ad_agg_2` (shopper grain) — customer-level exposure; "the single most important table."
- `fact_realised_ad` (impression grain) — impressions, clicks, reach, frequency, placement.
- `fact_ad_request` (request grain) — fill rate, unsold inventory, unmet demand.
- `fact_enhanced_attribution` (campaign × SKU grain) — the partner's own attributed outcome/ROAS, stored as theirs (never recomputed by Unlimitail).
- `fact_ledger` + `fta_campaign_spend` (transaction/campaign grain) — media spend; must be unioned or fixed placements are missed.
- `dim_campaign_attr` (campaign grain, **required**) — where Unlimitail's PROGRAMME id lives; the reconciliation key.
- `dim_product` / `dim_category` (product grain) — the partner's view of the catalogue Unlimitail sent, for mapping.
- `log_status` (load grain, **required**) — load start/end/status; Unlimitail's pipeline trigger.

**The 8 Handshakes (H1–H8)**:
| # | Exchange | Direction | Mechanism | Cadence |
|---|---|---|---|---|
| H1 | Product catalogue & category hierarchy | Unlimitail → partner | file | Before any campaign, then on change |
| H2 | Shopper dimensions for audience logic | Unlimitail → partner | file | Initial load, then daily delta |
| H3 | Segment definition & membership | Unlimitail → partner | file | On publication and on change |
| H4 | Unlimitail's PROGRAMME id written on partner's campaign | Unlimitail ↔ partner | `dim_campaign_attr` | At campaign setup |
| H5 | Customer-level exposure | Partner → Unlimitail | BigQuery share | Daily |
| H6 | Partner's attributed outcome and ROAS | Partner → Unlimitail | BigQuery share | Daily |
| H7 | Media spend and billing | Partner → Unlimitail | BigQuery share | Daily |
| H8 | Control/holdout mechanism | To be agreed | — | Per campaign |

H4 is flagged as the handshake most easily missed and the one everything else reconciles on — without it, exposure cannot be tied to Unlimitail's offers, audiences, or the retailer's sales.

### BP-11: Join/Match-Rate Quality Monitoring (per DOC03)
| Join | Keys | Floor | If it breaks |
|---|---|---|---|
| Product | upc ↔ gtin | 99% | Media exposure cannot be tied to sales |
| Shopper | hashed loyalty id ↔ customer id | 95% | All shopper-level measurement fails |
| Session | session key ↔ sessionId | 90% | Attribution cannot be reconciled between parties |
| Feed integrity | rows exported ↔ rows returned | 100% | Every rate metric has a wrong denominator |

## Revision Log
| Date | Source Document | Change Summary |
|---|---|---|
| 2026-09-12 | DOC14 - Unlimitail NIQ Discovery Questionnaire (pre-workshop prep template) | Annotated BP-16 with DOC14's 4-track pre-workshop intake structure (Operating Model, Measurement/Reporting, Personalization, Data/Tech/Architecture), which appears to be the template underlying DOC07's agenda and DOC08's as-is narrative. |
| 2026-09-12 | DOC10 - ADLM Jira export (NIQ Activate Personalization backlog) | Annotated BP-13 with platform dependency context: control-group logic fix and lift-measurement-prerequisite artifacts (generic, not Unlimitail-specific). |
| 2026-09-12 | Client Clarification (chat, re: DOC01/DOC06) | Updated BP-07 with client confirmation that Insights Premium onboarding data is shared/reused for Retail Media Measurement and Segmentation. |
| 2026-09-12 | DOC09 - Unlimitail Workshop June 26 (agenda/planning workbook) | Added BP-16, the discovery workshop's own MVP-vs-Phase-2+ scoping methodology and full deliverables list — this is the planning document behind DOC07/DOC08's outputs. |
| 2026-09-12 | DOC08 - Unlimitail July 2027 workshop discovery summary (As-Is narrative) | Added BP-15, the client's own as-is campaign operating model narrative (7 stages), corroborating BP-14's generic model and providing the fullest description yet of today's fragmentation gaps and manual reporting reality. |
| 2026-09-12 | DOC07 - Discovery Workshop July 2026 (agenda/template) | Added BP-14 (generic 7-stage Retail Media Campaign E2E process used as the discovery-workshop reference model). |
| 2026-09-12 | DOC06 - Unlimitail Business Stream (config workshop) | Added the Generic Hierarchy/Attributes reporting model and related business rules (see Domain Model.md). |
| 2026-09-12 | DOC04 - Unlimitail Sales to Delivery handover (internal NIQ deck) | Added BP-12 (Contract Commercial Lifecycle — quarterly invoicing, 2026 milestone-based value recognition, 36-month term/auto-renewal). |
| 2026-09-12 | DOC03 - 7_Integration_Deck_Unlimitail (Integration Workshop) | Added BP-10 (Integration Data Exchange — 8 handshakes, outbound/inbound feed detail) and BP-11 (Join/Match-Rate Quality Monitoring). This is the most direct answer found so far to the incoming-feed-format/data-flow/integration-points request. |
| 2026-09-12 | DOC02 - Unlimitail Kick-off Meeting (Carrefour, Phase 1) | Added 4 new processes (BP-06–BP-09): kickoff/governance setup, the 16-week Phase 1 onboarding E2E flow with milestone dates, the 6-gate sign-off governance model, and the recurring weekly/steering-committee/BAU meeting cadence. |
| 2026-09-12 | DOC01 - Retail Media Measurement closed loop concept design (TTD) | Initial population: 5 core processes (identity mapping, daily ETL, attribution matching, ROAS calculation, self-serve reporting) for the MVP closed-loop retail media measurement offering. |
| 2026-09-12 | — | File initialized, no client documents analyzed yet |
