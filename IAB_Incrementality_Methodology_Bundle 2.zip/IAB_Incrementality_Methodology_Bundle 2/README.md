# IAB Incrementality Methodology for Retail Media — complete bundle

Prepared 28 September 2026. The live, editable version of the methodology document is the
doc "IAB Incrementality Methodology for Retail Media" on claude.ai; this bundle is a
self-contained copy of everything.

## What is in each folder

| Folder | Contents |
|---|---|
| `01-methodology-document/` | The methodology in three formats: Word (`.docx`), PDF, and Markdown (`.md`, the plain-text source; formulas written in LaTeX) |
| `02-diagram/` | The two-paths flow diagram (PNG) and the four formulas as images (`formulas/`) |
| `03-reference-code/iab-lift/` | Python reference implementation (`iab_lift.py`), the simulation that tests it (`demo_simulation.py`), three SQL scripts, and a code README |
| `04-simulation-results/` | Output of the simulation: comparison table (`demo_results.csv`), full console output including the 40-run coverage check, and an example result object with disclosures (`example_result_path2A.json`) |
| `05-iab-source-documents/` | The key IAB passages the methodology relies on, quoted verbatim with page context and links to every source PDF |

## The methodology in five lines

1. The IAB standard is a control group chosen at random before anyone can be exposed, and never exposed afterwards.
2. Walled gardens (Meta and other aggregated channels): hold out on our side before upload, upload the control as an exclusion audience, measure both groups on till data (intent to treat), scale by the platform's reach.
3. Shopper-level channels: the partner holds back a random share of the shoppers its own allocation selected, before serving, and returns that list (IAB/MRC: "the same targeting and bidding logic" for both groups).
4. Picking the control from the non-exposed ("the diff") is classed by IAB as a weak proxy; with matching it is a modelled estimate at best and must be labelled as such. In the simulation it overstated the true effect about 6x (raw) and 3.7x (matched).
5. No lift figure is published unless the quality gates pass (sample ratio, balance, placebo, contamination, completeness) and the disclosures listed in the document are included.

## Running the code

```
cd 03-reference-code/iab-lift
pip install numpy pandas scipy scikit-learn
python demo_simulation.py --reps 40
```

## Note on the IAB PDFs

The official PDFs could not be downloaded from the build environment. Download them from the
links in `05-iab-source-documents/IAB_key_passages_verbatim.md`:

- IAB/MRC Retail Media Measurement Guidelines (Jan 2024)
- IAB & IAB Europe Guidelines for Incremental Measurement in Commerce Media (Nov 2025)
- IAB Europe Commerce Media Measurement Standards V2.1 (May 2026)
