# IAB source documents: key passages, verbatim

The IAB PDFs themselves could not be downloaded into this bundle (the build environment
cannot reach iab.com or iabeurope.eu). Download them from the links below. The passages
quoted here were read directly from those PDFs on 28 September 2026 and are the ones the
methodology relies on.

## 1. IAB/MRC Retail Media Measurement Guidelines (January 2024)
https://www.iab.com/wp-content/uploads/2024/01/IAB_Retail_Media_Measurement_Guidelines_January2024.pdf
(also hosted by MRC: https://mediaratingcouncil.org/sites/default/files/Standards/IAB_Retail_Media_Measurement_Guidelines_January2024.pdf)

### Chapter 4 intro
> "Scientific experiments such as randomized controlled trials (RCTs) aim to utilize the most unbiased baseline estimate to measure the incrementality of outcomes by randomly dividing a sample into those who were exposed and those who were not exposed to a marketing activation."

> "Transparency and Disclosure: Maintain transparency about the methodologies and data (such as limiting exposures to viewable impressions) used, assumptions made, test duration, pre-campaign hold-out periods, and potential limitations of your incrementality measurement approach."

### 4.1 Randomized controlled trials
> "Inferential Statistics: Use statistical tests like t-tests or an analysis of covariance to ascertain if the differences in the means are statistically significant."

> "MRC Standards highly recommends using RCTs, where individuals or units are randomly assigned to a test group or a control group. This random assignment helps ensure that the two groups are statistically identical in all respects except for the treatment, which helps minimize bias and confounding variables."

> "When using an RCT to measure incremental lift, it's important to ensure that randomization between the treatment and control groups is not conflated with randomization between the intention-to-treat and control groups. Depending on the type of RCT implementation employed, it may be necessary to utilize intent-to-treat (ITT) analysis methods if users in the test group only have an "opportunity" to be exposed to an ad campaign or leverage approaches centered around other implementations such as Ghost Ads or PSA methods."

> "The best way to avoid this methodological error is to ensure that any RCT for advertising incrementality uses the same targeting and bidding logic that determines who receives treatment to also determine who is placed in the control group."

> "Example: If a retailer's audience of two million shoppers is randomly split into two groups of one million shoppers for the purpose of an RCT, the group that is being targeted for treatment is really an intention-to-treat group, since there's no guarantee that all one million of those shoppers will ultimately be exposed to the treatment (the ad) over the course of the experiment."

### 4.1 Synthetic controls
> "Forensic approaches are particularly relevant when: Holdouts are not always available or appropriate ... Brands and retailers are reluctant to leave money on the table by not advertising to the target group"

> "evidence that the measurement has controlled for it can be validated through AA, BB testing prior to AB testing (here A = test group and B = control group)."

> "Employ statistical methods, such as propensity score matching, to ensure the control group's purchase and digital behavior closely mirrors that of the test group."

> "Establish strict criteria to prevent selection bias ... This includes monitoring for any systematic differences in unobserved characteristics between the test and control groups"

### 4.1 Machine learning models / uplift
> "To be considered part of the treatment group, exposure to a viewable impression is required by MRC. If this is not possible to limit to viewable impressions, it should be disclosed per MRC Outcomes and Data Quality Standards."

> "Marketers should also be mindful of potential biases, particularly unobserved variable bias, which can arise when matching is based solely on observed features."

### 4.4 Statistical and sample-based requirements (disclosures)
> "Disclosure of any biases known to the measurement organization which may exert a significant effect on the findings shown in the report, as well as quality controls to address and reduce inherent biases"
> "Disclosures of sample bases including relative sample sizes"
> "Disclosure and quantification of sampling and non-sampling error"
> "Disclosure of error (sampling and non-sampling) as well as guidance for use of error estimates such as confidence intervals"
> "Disclosure of assumptions including prior knowledge and hypothesis design"

### 1.2 Data retention
> "Retail media measurement organizations should maintain detailed collected data (pre- and post-processing) supporting measurement for a sufficient period—at least twelve months after the release of data."

### 3.6 Attribution windows
> "These windows must be disclosed before campaign execution and measurement and as part of disclosures corresponding to reported results."

> "typical attribution windows for digital measurement are often 3, 7, 14, 28, or 30 days"

## 2. IAB & IAB Europe, Guidelines for Incremental Measurement in Commerce Media (November 2025)
https://iabeurope.eu/wp-content/uploads/IAB_and_IAB_Europe_Guidelines_Incremental_Measurement_Commerce_Media_November_2025.pdf
Landing page: https://www.iab.com/guidelines/guidelines-for-incremental-measurement-in-commerce-media/

> "Incrementality measures the causal impact of marketing by identifying the additional business outcomes directly driven by a campaign or tactic, compared to what would have occurred in the absence of marketing activity."

> "Incrementality differs from attribution and ROAS: those methods show what happened, not whether marketing caused the result."

Method classes (table, page 3):
- Experiment-based — "Random Control Tests (RCTs), Hold out / Ghost Ads, Matched Markets" — causal strength "Strong"
- Model-based Counterfactual — "Synthetic control, Machine Learning propensity models" — "Strong to Moderate"
- Econometric — "Marketing Mix Modeling (MMM), Time-Series Regression" — "Moderate to Weak"
- Hybrid Proxies — "New-to-brand percentage, baseline vs. exposed analysis, platform-reported incrementality, Simple Multi-Touch Attribution" — "Weak"; "Provides directional evidence of lift by comparing performance indicators or relying on platform-specific attribution / modeling rather than an independent, true control group."

Three requirements (pages 6–7):
> "A CREDIBLE COUNTERFACTUAL OR INTERVENTION ... The rigor of this initial design is the primary factor determining the causal strength of the entire model."
> "CONTROLLING FOR BIAS ... Use explicit identification assumptions, control for confounders (including non-media factors in the model), test for parallel trends (in time-series data), or use geo-randomization and instrumental variables when appropriate."
> "SEPARATION OF SIGNAL FROM NOISE ... a lift estimate that is statistically insignificant (e.g. falls within the noise floor) is not reliable for decision making." ... "Require statistical robustness — e.g., confidence intervals that exclude zero, bootstrapping, falsification tests, and sensitivity analyses to verify results."

## 3. IAB Europe Commerce Media Measurement Standards V2.1 (May 2026) — certifiable
https://iabeurope.eu/wp-content/uploads/IAB-Europes-Commerce-Media-Measurement-Standards-V2.1-May-2026.pdf
Landing page: https://iabeurope.eu/knowledge_hub/iab-europes-commerce-incl-retail-media-measurement-standards-v2/

> "The only way to guarantee adherence to these standards is through IAB Europe's Retail Media Certification."

> "A CMN doesn't have to provide incrementality measurement to be certified, but if they do, they have to use one of the methods specified in the Guidelines."

> "It is recommended that a 30-day post-view and post-click lookback window is used as the default for endemic on and off-site, with the ability to also provide flexible windows."

> "Halo attribution can be provided for all formats. The standard definition for Halo is: Same Brand, Same Category"

> "Same SKU (parent SKU) attribution should be provided for all sponsored product ads."

## 4. Other references
- IAB, Demystifying Incrementality in Commerce Media (Nov 2025): https://www.iab.com/guidelines/demystifying-incrementality-in-commerce-media/
- Gordon, Zettelmeyer, Bhargava, Chapsky (2019), "A Comparison of Approaches to Advertising Measurement: Evidence from Big Field Experiments at Facebook", Marketing Science 38(2):193–225: https://pubsonline.informs.org/doi/10.1287/mksc.2018.1135 (free copy: https://www.kellogg.northwestern.edu/faculty/gordon_b/files/fb_comparison.pdf)
  - Abstract finding: observational methods "generally ... overestimate ad effectiveness relative to the RCT"; "in half of our studies, the estimated percentage increase in purchase outcomes is off by a factor of three".
- Johnson, Lewis, Nubbemeyer (2017), "Ghost Ads: Improving the Economics of Measuring Ad Effectiveness", Journal of Marketing Research 54(6):867–884 (the ghost-ad design behind Path 2, design A).
- Meta GeoLift (open source, MIT): https://github.com/facebookincubator/GeoLift
- Google matched_markets: https://github.com/google/matched_markets
