"""
demo_simulation.py - end-to-end run of every measurement path on synthetic data where the
true effect is known, so each design can be checked against the truth.

The synthetic world is built the way retail media behaves in reality:
  * shoppers differ in a hidden 'activity level' that drives both future sales AND how likely
    the partner's allocation is to pick them and how likely they are to be reached;
  * a second hidden trait ('online engagement') drives being reached and sales, and is not
    visible in our till data at all - which is exactly what matching cannot fix.

Run:  python demo_simulation.py            (single run, prints the comparison table)
      python demo_simulation.py --reps 30  (repeats the randomised designs to check that the
                                            95% intervals contain the truth ~95% of the time)
"""
import argparse
import numpy as np
import pandas as pd

import iab_lift as L


def make_world(n=200_000, seed=1):
    rng = np.random.default_rng(seed)
    a = rng.normal(size=n)                      # hidden activity level
    e = rng.normal(size=n)                      # hidden online engagement (never observed)

    def spend(noise_seed):
        r = np.random.default_rng(noise_seed)
        p_buy = 1 / (1 + np.exp(-(-1.3 + 0.9 * a + 0.35 * e)))
        buys = r.random(n) < p_buy
        amt = r.lognormal(mean=1.4 + 0.25 * a, sigma=0.6, size=n)
        return np.where(buys, amt, 0.0)

    df = pd.DataFrame({
        "shopper_id": [f"S{i:07d}" for i in range(n)],
        "y_pre": spend(seed + 100),                                   # brand sales, pre-period
        "cat_pre": spend(seed + 200) * 3 + rng.gamma(2, 2, n),        # category sales, pre-period
        "visits_pre": rng.poisson(np.exp(0.8 + 0.5 * a)),             # store trips, pre-period
        "banner": rng.choice(["north", "south", "east"], n, p=[.5, .3, .2]),
    })
    df["y0"] = spend(seed + 300)                                      # sales with NO ads (post)
    # true effect of being reached: +5% on what they'd buy anyway, plus 3% chance of an
    # extra purchase worth ~5
    uplift = 0.05 * df["y0"] + (rng.random(n) < 0.03) * rng.lognormal(1.5, 0.4, n)
    df["y1"] = df["y0"] + uplift                                      # sales IF reached
    # partner allocation score (their model, we don't see it): favours active shoppers
    df["alloc_score"] = 0.9 * a + 0.3 * np.log1p(df["y_pre"]) + rng.normal(0, 0.7, n)
    # probability of actually being reached once served (visits the site/app, sees the ad)
    df["p_reach"] = 1 / (1 + np.exp(-(-0.3 + 1.1 * e + 0.5 * a)))
    df["u_reach"] = rng.random(n)
    return df


def reached(sub):
    return (sub["u_reach"] < sub["p_reach"]).astype(int)


def outcome(sub):
    return np.where(sub["exposed"] == 1, sub["y1"], sub["y0"])


def path1_walled_garden(w, holdout=0.10, match_rate=0.70, seed_salt="CMP-001"):
    """Holdout before upload; platform returns reach as ONE NUMBER."""
    d = L.assign_holdout(w, salt=seed_salt, holdout_rate=holdout, strata=["banner"])
    rng = np.random.default_rng(5)
    matched_on_platform = rng.random(len(d)) < match_rate          # platform ID match
    d["exposed"] = ((d["arm"] == "test") & matched_on_platform & (reached(d) == 1)).astype(int)
    d["y"] = outcome(d)
    reach_reported = int(d.loc[d["arm"] == "test", "exposed"].sum())
    truth = (d.loc[d["exposed"] == 1, "y1"] - d.loc[d["exposed"] == 1, "y0"]).mean()
    res = L.estimate_randomised_lift(d.drop(columns="exposed"), reach=reach_reported,
                                     holdout_rate=holdout, measurement_window="flight + 14 days",
                                     method="Path 1 - pre-upload random holdout, ITT, aggregate reach",
                                     n_boot=0)
    return res, truth


def path2a_partner_holdout(w, holdout=0.10, alloc_share=0.5):
    """Partner allocates on everyone, then holds back a random 10% of THE ALLOCATED before
    serving and returns that list (ghost-ad logic)."""
    d = w.copy()
    cut = d["alloc_score"].quantile(1 - alloc_share)
    d = d[d["alloc_score"] >= cut].copy()                            # the partner's target list
    d = L.assign_holdout(d, salt="CMP-002-partner", holdout_rate=holdout)
    d["exposed"] = ((d["arm"] == "test") & (reached(d) == 1)).astype(int)
    d["y"] = outcome(d)
    truth = (d.loc[d["exposed"] == 1, "y1"] - d.loc[d["exposed"] == 1, "y0"]).mean()
    res = L.estimate_randomised_lift(d, holdout_rate=holdout, measurement_window="flight + 14 days",
                                     method="Path 2A - partner holds out after allocation, before serving",
                                     n_boot=0)
    return res, truth


def path2b_our_holdout(w, holdout=0.10, alloc_share=0.5):
    """We hold out before sending; partner allocates on the test group only."""
    d = L.assign_holdout(w, salt="CMP-003", holdout_rate=holdout, strata=["banner"])
    test = d["arm"] == "test"
    cut = d.loc[test, "alloc_score"].quantile(1 - alloc_share)
    allocated = test & (d["alloc_score"] >= cut)
    d["exposed"] = (allocated & (reached(d) == 1)).astype(int)
    d["y"] = outcome(d)
    truth = (d.loc[d["exposed"] == 1, "y1"] - d.loc[d["exposed"] == 1, "y0"]).mean()
    res = L.estimate_randomised_lift(d, holdout_rate=holdout, measurement_window="flight + 14 days",
                                     method="Path 2B - our pre-send holdout, shopper-level exposure",
                                     n_boot=0)
    return res, truth


def path2c_diff_method(w, alloc_share=0.5):
    """Send everyone; control = picked from whoever was not exposed (the 'diff')."""
    d = w.copy()
    cut = d["alloc_score"].quantile(1 - alloc_share)
    d["exposed"] = ((d["alloc_score"] >= cut) & (reached(d) == 1)).astype(int)
    d["y"] = outcome(d)
    truth = (d.loc[d["exposed"] == 1, "y1"] - d.loc[d["exposed"] == 1, "y0"]).mean()
    naive = L.naive_exposed_vs_unexposed(d)
    # a random sample of the non-exposed is still just the non-exposed
    matched = L.matched_did_lift(d, covariates=["y_pre", "cat_pre", "visits_pre"],
                                 measurement_window="flight + 14 days")
    return naive, matched, truth


def row(name, est, lo, hi, truth, cls):
    return {"design": name, "IAB method class": cls, "estimate per exposed": round(est, 3),
            "95% CI": f"[{lo:.3f}, {hi:.3f}]", "true effect": round(truth, 3),
            "bias %": round(100 * (est - truth) / truth, 1),
            "truth inside CI": lo <= truth <= hi}


def main(reps: int):
    w = make_world()
    rows = []
    r1, t1 = path1_walled_garden(w)
    rows.append(row("1  walled garden: our holdout, aggregate reach", r1.effect_per_exposed,
                    *r1.effect_per_exposed_ci, t1, r1.method_class))
    r2a, t2a = path2a_partner_holdout(w)
    rows.append(row("2A partner holdout after allocation", r2a.effect_per_exposed,
                    *r2a.effect_per_exposed_ci, t2a, r2a.method_class))
    r2b, t2b = path2b_our_holdout(w)
    rows.append(row("2B our holdout before sending", r2b.effect_per_exposed,
                    *r2b.effect_per_exposed_ci, t2b, r2b.method_class))
    naive, m2c, t2c = path2c_diff_method(w)
    rows.append(row("2C-naive exposed vs non-exposed (the diff)", naive["diff"], naive["ci_low"],
                    naive["ci_high"], t2c, "Hybrid proxy"))
    rows.append(row("2C-matched non-exposed + DiD", m2c.effect_per_exposed,
                    *m2c.effect_per_exposed_ci, t2c, m2c.method_class))
    table = pd.DataFrame(rows)
    pd.set_option("display.width", 200, "display.max_columns", 20)
    print(table.to_string(index=False))
    table.to_csv("demo_results.csv", index=False)

    print("\nQuality gates, path 2A:")
    for g in r2a.quality_gates:
        print("  ", g)
    print("\nQuality gates, path 2C matched:")
    for g in m2c.quality_gates:
        print("  ", g)
    with open("example_result_path2A.json", "w") as f:
        f.write(r2a.to_json())

    if reps:
        hits = {"1": 0, "2A": 0, "2B": 0}
        for s in range(reps):
            ws = make_world(n=60_000, seed=100 + s)
            for k, fn in (("1", path1_walled_garden), ("2A", path2a_partner_holdout),
                          ("2B", path2b_our_holdout)):
                r, t = fn(ws)
                lo, hi = r.effect_per_exposed_ci
                hits[k] += lo <= t <= hi
        print(f"\nCoverage over {reps} repetitions (target ~95%):",
              {k: f"{100 * v / reps:.0f}%" for k, v in hits.items()})


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--reps", type=int, default=0)
    main(ap.parse_args().reps)
