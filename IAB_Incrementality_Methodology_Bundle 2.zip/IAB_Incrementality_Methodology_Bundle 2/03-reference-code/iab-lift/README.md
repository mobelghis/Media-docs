# iab-lift — reference code for retail media incrementality

Implements the incrementality methods described in the IAB/MRC Retail Media Measurement
Guidelines (Jan 2024, ch. 4) and the IAB & IAB Europe Guidelines for Incremental Measurement
in Commerce Media (Nov 2025). IAB publishes no code; this is our implementation of what those
documents describe. Needs Python 3.10+, numpy, pandas, scipy, scikit-learn.

| File | What it does |
|---|---|
| `iab_lift.py` | Assignment (hash-based, stratified), power/sizing, quality gates (sample ratio, balance, placebo, contamination), estimators (ITT, ANCOVA, effect per exposed, iROAS), matched DiD fallback, result object with disclosures |
| `demo_simulation.py` | Runs every design on synthetic data with a known true effect. `--reps 40` checks interval coverage |
| `sql/01_assign_holdout.sql` | The same assignment in SQL, where the audience lives |
| `sql/02_shopper_outcomes.sql` | One row per assigned shopper with window and pre-period outcomes from the TLOG |
| `sql/03_itt_lift_aggregate.sql` | Unadjusted ITT readout in SQL for dashboards / sanity checks |

## Minimal use

```python
import iab_lift as L
aud = L.assign_holdout(eligible_df, salt="CMP-2026-0142", holdout_rate=0.10, strata=["banner"])
# ... send aud[aud.arm=="test"] out, run the campaign, build one row per shopper with y, y_pre ...
res = L.estimate_randomised_lift(outcomes_df, holdout_rate=0.10, spend=50_000,
                                 reach=312_455,            # walled garden: platform's reach figure
                                 measurement_window="2026-10-01..2026-10-28 + 14 days")
print(res.to_json())      # every gate must pass before the figure is published
```

## Demo result (200k synthetic shoppers, true effect known)

| Design | IAB class | Bias vs truth | Truth in 95% CI |
|---|---|---|---|
| 1 walled garden: our holdout + aggregate reach | Experiment | within noise | yes |
| 2A partner holds out after allocation | Experiment | within noise | yes |
| 2B our holdout before sending | Experiment | within noise | yes |
| 2C exposed vs non-exposed ("the diff") | Proxy | about +530% | no |
| 2C matched non-exposed + DiD | Model-based | about +270% | no (balance checks all passed) |

Interval coverage over 40 repetitions: 95% / 100% / 92% for designs 1 / 2A / 2B.

## Open-source tools for the cases this module does not cover
- Geo / store-cluster tests (in-store screens, channels with no shopper IDs): Meta **GeoLift** (R, MIT, synthetic control) — github.com/facebookincubator/GeoLift ; Google **matched_markets** (Python, time-based regression); Google **CausalImpact**; **CausalPy** (PyMC Labs).
- Uplift / heterogeneous effects on top of an RCT: **CausalML** (Uber), **scikit-uplift**, **EconML** (Microsoft), **DoWhy**.
