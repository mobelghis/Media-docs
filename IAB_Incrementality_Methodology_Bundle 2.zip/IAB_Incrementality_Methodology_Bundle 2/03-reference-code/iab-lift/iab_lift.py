"""
iab_lift.py - reference implementation of incrementality measurement for retail media,
aligned to:

  * IAB/MRC Retail Media Measurement Guidelines (Jan 2024), chapter 4 "Guidelines and Best
    Practices When Measuring Incrementality" and the disclosure requirements in 4.4 / chapter 5.
  * IAB & IAB Europe Guidelines for Incremental Measurement in Commerce Media (Nov 2025):
    the three causal requirements (credible counterfactual, control of bias, separation of
    signal from noise) and the four method classes.
  * IAB Europe Commerce Media Measurement Standards V2.1: incrementality is optional for
    certification, but if offered it must use one of the methods in the Guidelines above.

IAB does not publish code. This module is our implementation of the methods those documents
describe. Dependencies: numpy, pandas, scipy, scikit-learn (matching only).

Two measurement paths:

  PATH 1 - aggregated channels (walled gardens: Meta, Google, TikTok, in-store screens ...)
      randomise a holdout BEFORE the audience leaves us -> send test only -> measure the
      outcome for BOTH groups on our own till data (TLOG) -> intent-to-treat (ITT) lift,
      scaled to "effect on the reached" with the reach figure the platform returns.

  PATH 2 - shopper-level exposure channels (DSP / ad network returns who was exposed)
      2A  partner holds back a random share of the shoppers ITS allocation selected, before
          serving, and returns that list  (ghost-ad logic - the IAB/MRC recommended design)
      2B  we hold back a random share before sending (same maths as path 1, plus the
          shopper-level exposure file for the effect-on-exposed figure)
      2C  no randomised holdout: control built from the non-exposed by matching
          (IAB/MRC "synthetic control / forensic matching"; IAB 2025 class "model-based
          counterfactual"). Must be labelled as modelled, never as measured.

Everything here works on one row per shopper. Column conventions:
    shopper_id, arm ('test'|'control'), exposed (0/1), y (outcome in the measurement window),
    y_pre (same outcome in the pre-period), plus any covariates.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, asdict
from typing import Iterable, Optional, Sequence

import numpy as np
import pandas as pd
from scipy import stats

# ------------------------------------------------------------------------------------------
# 1. ASSIGNMENT - deterministic, reproducible, auditable randomisation
# ------------------------------------------------------------------------------------------

def hash_uniform(ids: Iterable, salt: str) -> np.ndarray:
    """Map each id to a uniform number in [0,1) with SHA-256(salt|id).
    Same salt + same id -> same number, forever. The salt is the campaign's measurement id,
    so assignments are independent across campaigns and can be re-derived by an auditor."""
    out = []
    for i in ids:
        h = hashlib.sha256(f"{salt}|{i}".encode()).hexdigest()
        out.append(int(h[:15], 16) / float(16 ** 15))
    return np.asarray(out)


def assign_holdout(audience: pd.DataFrame, salt: str, holdout_rate: float,
                   strata: Optional[Sequence[str]] = None,
                   id_col: str = "shopper_id") -> pd.DataFrame:
    """Split the FINAL eligible audience (after every eligibility filter, suppression and
    consent check) into test and control.

    With strata, each stratum gets exactly round(rate * n) controls (ranked by hash), which
    guarantees balance on the stratifying variables (e.g. banner, value tier, prior buyer).
    Without strata, a shopper is control when hash < rate.
    """
    if not 0 < holdout_rate < 1:
        raise ValueError("holdout_rate must be between 0 and 1")
    df = audience.drop_duplicates(subset=[id_col]).copy()
    df["u"] = hash_uniform(df[id_col].astype(str), salt)
    if strata:
        df["rank_in_stratum"] = df.groupby(list(strata))["u"].rank(method="first")
        n_in_stratum = df.groupby(list(strata))[id_col].transform("size")
        n_ctrl = np.round(holdout_rate * n_in_stratum)
        df["arm"] = np.where(df["rank_in_stratum"] <= n_ctrl, "control", "test")
        df = df.drop(columns="rank_in_stratum")
    else:
        df["arm"] = np.where(df["u"] < holdout_rate, "control", "test")
    df["assignment_salt"] = salt
    df["holdout_rate"] = holdout_rate
    return df


# ------------------------------------------------------------------------------------------
# 2. PLANNING - power / minimum detectable effect (IAB 2025: "signal from noise")
# ------------------------------------------------------------------------------------------

def mde_itt(sd: float, n_test: int, n_control: int, alpha: float = 0.05,
            power: float = 0.8) -> float:
    """Smallest per-shopper ITT difference (outcome units) detectable at alpha, power."""
    z = stats.norm.ppf(1 - alpha / 2) + stats.norm.ppf(power)
    return z * sd * np.sqrt(1 / n_test + 1 / n_control)


def required_n(sd: float, mde: float, holdout_rate: float, exposure_rate: float = 1.0,
               alpha: float = 0.05, power: float = 0.8, r2_pre: float = 0.0) -> int:
    """Total audience needed to detect an effect of `mde` PER EXPOSED shopper.
    Intent-to-treat dilutes the effect by the exposure rate, so the ITT target is
    mde * exposure_rate. r2_pre: share of outcome variance explained by the pre-period
    covariate (ANCOVA shrinks variance by (1 - r2))."""
    z = stats.norm.ppf(1 - alpha / 2) + stats.norm.ppf(power)
    var = sd ** 2 * (1 - r2_pre)
    itt = mde * exposure_rate
    p = holdout_rate
    n = (z ** 2) * var * (1 / (1 - p) + 1 / p) / itt ** 2
    return int(np.ceil(n))


# ------------------------------------------------------------------------------------------
# 3. QUALITY GATES - run before any lift number is published
# ------------------------------------------------------------------------------------------

def srm_test(n_test: int, n_control: int, holdout_rate: float) -> dict:
    """Sample-ratio mismatch: does the observed split match the planned split?
    p < 0.001 means the assignment or the data pipeline is broken -> do not report."""
    n = n_test + n_control
    exp = np.array([n * (1 - holdout_rate), n * holdout_rate])
    chi2, p = stats.chisquare([n_test, n_control], exp)
    return {"check": "sample_ratio", "chi2": float(chi2), "p_value": float(p),
            "passed": bool(p >= 0.001)}


def standardized_mean_diff(a: np.ndarray, b: np.ndarray) -> float:
    s = np.sqrt((np.var(a, ddof=1) + np.var(b, ddof=1)) / 2)
    return 0.0 if s == 0 else float((np.mean(a) - np.mean(b)) / s)


def balance_table(df: pd.DataFrame, covariates: Sequence[str], group_col: str = "arm",
                  treat_value="test", threshold: float = 0.1) -> pd.DataFrame:
    """Pre-period balance. |SMD| < 0.1 is the conventional threshold."""
    rows = []
    t = df[df[group_col] == treat_value]
    c = df[df[group_col] != treat_value]
    for cov in covariates:
        smd = standardized_mean_diff(t[cov].to_numpy(float), c[cov].to_numpy(float))
        rows.append({"covariate": cov, "mean_test": t[cov].mean(), "mean_control": c[cov].mean(),
                     "smd": smd, "passed": abs(smd) < threshold})
    return pd.DataFrame(rows)


def placebo_test(df: pd.DataFrame, pre_outcome: str = "y_pre", group_col: str = "arm",
                 treat_value="test") -> dict:
    """A/A (IAB/MRC: 'AA, BB testing prior to AB testing'): apply the lift estimator to the
    PRE-period, when nobody was exposed. The confidence interval should contain zero."""
    t = df.loc[df[group_col] == treat_value, pre_outcome].to_numpy(float)
    c = df.loc[df[group_col] != treat_value, pre_outcome].to_numpy(float)
    r = welch_diff(t, c)
    r.update({"check": "placebo_pre_period", "passed": bool(r["ci_low"] <= 0 <= r["ci_high"])})
    return r


def contamination_rate(df: pd.DataFrame) -> dict:
    """Share of the control group that nonetheless appears in the exposure file."""
    ctrl = df[df["arm"] == "control"]
    rate = float(ctrl["exposed"].mean()) if "exposed" in df and len(ctrl) else float("nan")
    return {"check": "control_contamination", "rate": rate,
            "passed": bool(rate <= 0.01) if not np.isnan(rate) else None}


# ------------------------------------------------------------------------------------------
# 4. ESTIMATORS
# ------------------------------------------------------------------------------------------

def welch_diff(t: np.ndarray, c: np.ndarray, alpha: float = 0.05) -> dict:
    """Difference in means with Welch standard error (IAB/MRC: 't-tests')."""
    mt, mc = t.mean(), c.mean()
    vt, vc = t.var(ddof=1) / len(t), c.var(ddof=1) / len(c)
    se = np.sqrt(vt + vc)
    df_w = (vt + vc) ** 2 / (vt ** 2 / (len(t) - 1) + vc ** 2 / (len(c) - 1))
    q = stats.t.ppf(1 - alpha / 2, df_w)
    d = mt - mc
    return {"mean_test": float(mt), "mean_control": float(mc), "diff": float(d),
            "se": float(se), "ci_low": float(d - q * se), "ci_high": float(d + q * se),
            "p_value": float(2 * (1 - stats.t.cdf(abs(d / se), df_w))) if se > 0 else float("nan")}


def ancova_diff(y: np.ndarray, treat: np.ndarray, covs: np.ndarray, alpha: float = 0.05) -> dict:
    """Regression-adjusted difference (IAB/MRC: 'analysis of covariance', 'regression
    analysis'). y = a + b*treat + g*covs, heteroskedasticity-robust (HC1) standard error.
    Same expected value as the simple difference under randomisation, tighter interval."""
    X = np.column_stack([np.ones_like(y), treat, covs])
    XtX_inv = np.linalg.pinv(X.T @ X)
    beta = XtX_inv @ X.T @ y
    resid = y - X @ beta
    n, k = X.shape
    meat = (X * resid[:, None] ** 2).T @ X
    V = XtX_inv @ meat @ XtX_inv * n / (n - k)
    se = float(np.sqrt(V[1, 1]))
    q = stats.norm.ppf(1 - alpha / 2)
    b = float(beta[1])
    return {"diff": b, "se": se, "ci_low": b - q * se, "ci_high": b + q * se,
            "p_value": float(2 * (1 - stats.norm.cdf(abs(b / se)))) if se > 0 else float("nan")}


def bootstrap_ratio_ci(t: np.ndarray, c: np.ndarray, exposure_t: Optional[np.ndarray] = None,
                       n_boot: int = 1000, alpha: float = 0.05, seed: int = 7) -> dict:
    """Percentile bootstrap for relative lift (%) and, if exposure is given, for the
    effect per exposed shopper (ITT / exposure rate)."""
    rng = np.random.default_rng(seed)
    lifts, tots = [], []
    for _ in range(n_boot):
        it = rng.integers(0, len(t), len(t))
        ic = rng.integers(0, len(c), len(c))
        mt, mc = t[it].mean(), c[ic].mean()
        lifts.append((mt - mc) / mc if mc else np.nan)
        if exposure_t is not None:
            er = exposure_t[it].mean()
            tots.append((mt - mc) / er if er else np.nan)
    lo, hi = 100 * alpha / 2, 100 * (1 - alpha / 2)
    out = {"lift_pct_ci": [float(np.nanpercentile(lifts, lo)), float(np.nanpercentile(lifts, hi))]}
    if tots:
        out["effect_per_exposed_ci"] = [float(np.nanpercentile(tots, lo)),
                                        float(np.nanpercentile(tots, hi))]
    return out


@dataclass
class LiftResult:
    method: str                      # e.g. "Randomised holdout - intent to treat"
    method_class: str                # IAB 2025: experiment-based / model-based counterfactual / ...
    causal_strength: str             # IAB 2025 table: strong / strong-to-moderate / weak
    n_test: int
    n_control: int
    measurement_window: str
    outcome: str
    mean_test: float
    mean_control: float
    itt_per_shopper: float
    itt_ci: list
    p_value: float
    lift_pct: float
    lift_pct_ci: list
    incremental_total: float         # ITT x number of test shoppers
    incremental_total_ci: list
    exposure_rate: Optional[float] = None
    effect_per_exposed: Optional[float] = None
    effect_per_exposed_ci: Optional[list] = None
    spend: Optional[float] = None
    iroas: Optional[float] = None
    iroas_ci: Optional[list] = None
    quality_gates: list = field(default_factory=list)
    disclosures: dict = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, default=float)


def estimate_randomised_lift(df: pd.DataFrame, outcome: str = "y", pre_outcome: str = "y_pre",
                             spend: Optional[float] = None, reach: Optional[int] = None,
                             holdout_rate: Optional[float] = None,
                             measurement_window: str = "", method: str = "",
                             alpha: float = 0.05, cap_quantile: Optional[float] = None,
                             n_boot: int = 1000) -> LiftResult:
    """Paths 1, 2A and 2B. `df` holds EVERY shopper assigned (test and control) - not just
    the exposed. Test shoppers who were never reached stay in the test group (that is what
    makes the comparison fair). Effect per exposed = ITT / exposure rate (Bloom estimator),
    valid because control shoppers cannot be exposed (one-sided non-compliance).

    reach: for aggregated channels, the number of test shoppers the platform reports as
    reached; for shopper-level channels leave None and supply an `exposed` column.
    cap_quantile: optional outlier cap applied identically to both groups (must be disclosed).
    """
    d = df.copy()
    disclosures = {}
    if cap_quantile:
        cap = d[outcome].quantile(cap_quantile)
        d[outcome] = d[outcome].clip(upper=cap)
        if pre_outcome in d:
            d[pre_outcome] = d[pre_outcome].clip(upper=d[pre_outcome].quantile(cap_quantile))
        disclosures["outlier_cap"] = f"outcome capped at the {cap_quantile:.3%} quantile ({cap:.2f}) in both groups"

    t_mask = d["arm"] == "test"
    t = d.loc[t_mask, outcome].to_numpy(float)
    c = d.loc[~t_mask, outcome].to_numpy(float)
    n_t, n_c = len(t), len(c)

    gates = []
    if holdout_rate:
        gates.append(srm_test(n_t, n_c, holdout_rate))
    if pre_outcome in d:
        gates.append(placebo_test(d, pre_outcome))
        bt = balance_table(d, [pre_outcome])
        gates.append({"check": "pre_period_balance", "smd": float(bt["smd"].iloc[0]),
                      "passed": bool(bt["passed"].iloc[0])})
    if "exposed" in d:
        gates.append(contamination_rate(d))

    simple = welch_diff(t, c, alpha)
    if pre_outcome in d:
        adj = ancova_diff(d[outcome].to_numpy(float), t_mask.to_numpy(float),
                          d[[pre_outcome]].to_numpy(float), alpha)
        est, disclosures["estimator"] = adj, "ANCOVA on pre-period outcome, HC1 robust SE"
    else:
        est, disclosures["estimator"] = simple, "difference in means, Welch SE"
    itt, lo, hi = est["diff"], est["ci_low"], est["ci_high"]
    mc = simple["mean_control"]

    exposure_t = None
    if "exposed" in d:
        exposure_t = d.loc[t_mask, "exposed"].to_numpy(float)
        er = float(exposure_t.mean())
        disclosures["exposure_source"] = "shopper-level exposure file"
    elif reach is not None:
        er = reach / n_t
        disclosures["exposure_source"] = "aggregate reach reported by platform (not verified per shopper)"
    else:
        er = None

    # Intervals by the delta method, centred on the (adjusted) ITT estimate.
    q = stats.norm.ppf(1 - alpha / 2)
    se_itt = est["se"]
    se_mc = c.std(ddof=1) / np.sqrt(n_c)
    lift = itt / mc if mc else float("nan")
    se_lift = np.sqrt((se_itt / mc) ** 2 + (itt * se_mc / mc ** 2) ** 2) if mc else float("nan")
    lift_ci = [lift - q * se_lift, lift + q * se_lift]
    epe = epe_ci = None
    if er:
        se_er = np.sqrt(er * (1 - er) / n_t) if exposure_t is not None else 0.0
        epe = itt / er
        se_epe = np.sqrt((se_itt / er) ** 2 + (itt * se_er / er ** 2) ** 2)
        epe_ci = [epe - q * se_epe, epe + q * se_epe]
        if exposure_t is None:
            disclosures["reach_uncertainty"] = "reach treated as exact; its sampling error is not in the interval"
    if n_boot:
        disclosures["bootstrap_check"] = bootstrap_ratio_ci(t, c, exposure_t, n_boot=n_boot, alpha=alpha)

    res = LiftResult(
        method=method or "Randomised holdout - intent to treat",
        method_class="Experiment-based", causal_strength="Strong",
        n_test=n_t, n_control=n_c, measurement_window=measurement_window, outcome=outcome,
        mean_test=simple["mean_test"], mean_control=mc,
        itt_per_shopper=itt, itt_ci=[lo, hi], p_value=est["p_value"],
        lift_pct=lift, lift_pct_ci=lift_ci,
        incremental_total=itt * n_t, incremental_total_ci=[lo * n_t, hi * n_t],
        exposure_rate=er, effect_per_exposed=epe, effect_per_exposed_ci=epe_ci,
        quality_gates=gates, disclosures=disclosures)
    if spend:
        res.spend = spend
        res.iroas = res.incremental_total / spend
        res.iroas_ci = [res.incremental_total_ci[0] / spend, res.incremental_total_ci[1] / spend]
    return res


# ------------------------------------------------------------------------------------------
# 5. PATH 2C - matched control from the non-exposed (model-based counterfactual)
# ------------------------------------------------------------------------------------------

def matched_did_lift(df: pd.DataFrame, covariates: Sequence[str], outcome: str = "y",
                     pre_outcome: str = "y_pre", ratio: int = 1, caliper_sd: float = 0.2,
                     measurement_window: str = "", spend: Optional[float] = None,
                     seed: int = 11) -> LiftResult:
    """Exposed vs matched non-exposed, then difference-in-differences.

    Steps (IAB/MRC 'Synthetic controls' + 'Matched-market tests'):
      1. propensity model P(exposed | pre-period covariates) on the sent audience
      2. nearest-neighbour match each exposed shopper to `ratio` non-exposed shoppers on the
         logit of the propensity, within a caliper; unmatched exposed are dropped and counted
      3. balance check on every covariate (|SMD| < 0.1) - report fails if not met
      4. placebo on the pre-period (should be ~0 after matching - it is matched on, so this
         is weak evidence; a second, earlier pre-period is better if available)
      5. effect = (post_exposed - pre_exposed) - (post_matched - pre_matched)
    Label: model-based counterfactual. Never present as a measured / experimental result.
    """
    from sklearn.linear_model import LogisticRegression
    from sklearn.neighbors import NearestNeighbors

    d = df.reset_index(drop=True).copy()
    X = d[list(covariates)].to_numpy(float)
    Xs = (X - X.mean(0)) / np.where(X.std(0) == 0, 1, X.std(0))
    ps = LogisticRegression(max_iter=1000).fit(Xs, d["exposed"]).predict_proba(Xs)[:, 1]
    ps = np.clip(ps, 1e-6, 1 - 1e-6)
    d["logit_ps"] = np.log(ps / (1 - ps))

    ex = d[d["exposed"] == 1]
    ne = d[d["exposed"] == 0]
    nn = NearestNeighbors(n_neighbors=ratio).fit(ne[["logit_ps"]].to_numpy())
    dist, idx = nn.kneighbors(ex[["logit_ps"]].to_numpy())
    caliper = caliper_sd * d["logit_ps"].std()
    keep = (dist <= caliper).all(axis=1)
    ex_m = ex[keep]
    ctrl_idx = idx[keep].ravel()
    ctrl_m = ne.iloc[ctrl_idx]

    matched = pd.concat([ex_m.assign(arm="test"), ctrl_m.assign(arm="control")])
    bal = balance_table(matched, list(covariates))
    gates = [{"check": "matched_balance", "max_abs_smd": float(bal["smd"].abs().max()),
              "passed": bool(bal["passed"].all())},
             {"check": "exposed_matched_share", "rate": float(keep.mean()),
              "passed": bool(keep.mean() >= 0.9)}]

    t_delta = (ex_m[outcome] - ex_m[pre_outcome]).to_numpy(float)
    c_delta = (ctrl_m[outcome] - ctrl_m[pre_outcome]).to_numpy(float)
    est = welch_diff(t_delta, c_delta)   # ignores match dependence - conservative enough for a sketch
    n_t = len(ex_m)
    mc = float(ctrl_m[outcome].mean())
    res = LiftResult(
        method="Matched non-exposed control with difference-in-differences",
        method_class="Model-based counterfactual", causal_strength="Strong to moderate (depends on unobserved confounding)",
        n_test=n_t, n_control=len(ctrl_m), measurement_window=measurement_window, outcome=outcome,
        mean_test=float(ex_m[outcome].mean()), mean_control=mc,
        itt_per_shopper=est["diff"], itt_ci=[est["ci_low"], est["ci_high"]], p_value=est["p_value"],
        lift_pct=est["diff"] / mc if mc else float("nan"), lift_pct_ci=[float("nan"), float("nan")],
        incremental_total=est["diff"] * n_t,
        incremental_total_ci=[est["ci_low"] * n_t, est["ci_high"] * n_t],
        exposure_rate=1.0, effect_per_exposed=est["diff"],
        effect_per_exposed_ci=[est["ci_low"], est["ci_high"]], quality_gates=gates,
        disclosures={"estimator": "1:%d nearest-neighbour propensity match, caliper %.2f SD, then DiD" % (ratio, caliper_sd),
                     "covariates": list(covariates),
                     "limitation": "Assumes no unobserved differences between exposed and matched shoppers "
                                   "that affect sales. The platform's allocation logic is not observed."})
    if spend:
        res.spend, res.iroas = spend, res.incremental_total / spend
        res.iroas_ci = [res.incremental_total_ci[0] / spend, res.incremental_total_ci[1] / spend]
    return res


def naive_exposed_vs_unexposed(df: pd.DataFrame, outcome: str = "y") -> dict:
    """The comparison the standards classify as a proxy. Provided ONLY to show the bias."""
    return welch_diff(df.loc[df["exposed"] == 1, outcome].to_numpy(float),
                      df.loc[df["exposed"] == 0, outcome].to_numpy(float))
