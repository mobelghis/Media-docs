-- 03_itt_lift_aggregate.sql
-- The unadjusted intent-to-treat readout in pure SQL, for dashboards and sanity checks.
-- The published figure should come from iab_lift.py (ANCOVA-adjusted, with quality gates).
-- Input: the result of 02_shopper_outcomes.sql materialised as rm_shopper_outcomes.

WITH g AS (
    SELECT arm,
           COUNT(*)                       AS n,
           AVG(y)                         AS mean_y,
           VAR_SAMP(y)                    AS var_y,
           AVG(buyer)                     AS penetration,
           AVG(exposed)                   AS exposure_rate
    FROM rm_shopper_outcomes
    WHERE measurement_id = @campaign_salt
    GROUP BY arm
),
t AS (SELECT * FROM g WHERE arm = 'test'),
c AS (SELECT * FROM g WHERE arm = 'control')
SELECT
    t.n                                         AS n_test,
    c.n                                         AS n_control,
    c.n / (t.n + c.n)                           AS observed_holdout_share,   -- compare to plan (SRM)
    t.mean_y - c.mean_y                         AS itt_per_shopper,
    SQRT(t.var_y / t.n + c.var_y / c.n)         AS se_itt,
    (t.mean_y - c.mean_y) - 1.96 * SQRT(t.var_y / t.n + c.var_y / c.n) AS itt_ci_low,
    (t.mean_y - c.mean_y) + 1.96 * SQRT(t.var_y / t.n + c.var_y / c.n) AS itt_ci_high,
    (t.mean_y - c.mean_y) / NULLIF(c.mean_y, 0) AS lift_pct,
    (t.mean_y - c.mean_y) * t.n                 AS incremental_sales,
    (t.penetration - c.penetration) * t.n       AS incremental_buyers,
    t.exposure_rate                             AS exposure_rate_test,
    c.exposure_rate                             AS contamination_rate_control, -- must be ~0
    (t.mean_y - c.mean_y) / NULLIF(t.exposure_rate, 0) AS effect_per_exposed_shopper
FROM t CROSS JOIN c;
