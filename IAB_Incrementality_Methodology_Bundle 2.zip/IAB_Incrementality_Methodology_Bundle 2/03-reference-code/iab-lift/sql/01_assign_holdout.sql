-- 01_assign_holdout.sql
-- Deterministic random holdout, computed where the audience lives (SingleStore / MySQL
-- dialect shown; BigQuery: TO_HEX(SHA256(...)), Snowflake: SHA2(..., 256)).
--
-- Run ONCE per campaign on the FINAL eligible audience (after eligibility, suppression and
-- consent filters), then freeze the result. Never re-run on a changed audience: late adds
-- get assigned by the same formula, nobody is ever re-assigned.
--
-- Parameters: @campaign_salt (the measurement id, e.g. 'CMP-2026-0142'), @holdout_rate (0.10)

CREATE TABLE IF NOT EXISTS rm_assignment (
    measurement_id   VARCHAR(64)  NOT NULL,
    shopper_id       VARCHAR(64)  NOT NULL,
    segment_id       VARCHAR(64)  NOT NULL,
    arm              VARCHAR(8)   NOT NULL,         -- 'test' | 'control'
    u                DOUBLE       NOT NULL,         -- the hash-uniform, kept for audit
    holdout_rate     DOUBLE       NOT NULL,
    assigned_at      DATETIME     NOT NULL,
    PRIMARY KEY (measurement_id, shopper_id)
);

INSERT INTO rm_assignment
SELECT
    @campaign_salt                                             AS measurement_id,
    a.shopper_id,
    a.segment_id,
    CASE WHEN h.u < @holdout_rate THEN 'control' ELSE 'test' END AS arm,
    h.u,
    @holdout_rate,
    NOW()
FROM eligible_audience a
JOIN LATERAL (
    -- first 15 hex chars of SHA-256(salt|id) -> integer -> [0,1)
    SELECT CONV(SUBSTRING(SHA2(CONCAT(@campaign_salt, '|', a.shopper_id), 256), 1, 15), 16, 10)
           / POW(16, 15) AS u
) h
WHERE a.measurement_id = @campaign_salt;

-- Stratified variant (exact share per stratum, e.g. banner x value tier):
--   rank shoppers by u inside the stratum and take the first ROUND(rate * n) as control.
-- SELECT ..., CASE WHEN ROW_NUMBER() OVER (PARTITION BY banner, tier ORDER BY u)
--                   <= ROUND(@holdout_rate * COUNT(*) OVER (PARTITION BY banner, tier))
--              THEN 'control' ELSE 'test' END AS arm

-- Outbound file for the partner / platform = test only.
-- For walled gardens, ALSO upload the control list as an EXCLUSION audience in the same
-- ad account so broad, lookalike or 'expanded' targeting cannot reach them.
-- SELECT shopper_id, segment_id FROM rm_assignment WHERE measurement_id=@campaign_salt AND arm='test';
