-- 02_shopper_outcomes.sql
-- One row per ASSIGNED shopper (test and control, reached or not) with the outcome in the
-- measurement window and the same outcome in the pre-period. This is the input to
-- iab_lift.estimate_randomised_lift(). Shoppers with no purchase MUST appear with 0.
--
-- Measurement window = the same calendar window for both groups:
--   [flight_start, flight_end + post_days]   (post_days = the client's headline window, e.g. 14)
-- Pre-period = same length immediately before flight_start (or 52 weeks for seasonal brands).
-- Promoted products = the campaign's SKU list (parent SKU incl. variants, per IAB Europe);
-- halo is a second outcome column, never mixed into the first.

WITH params AS (
    SELECT @campaign_salt AS mid, @flight_start AS fs,
           DATE_ADD(@flight_end, INTERVAL @post_days DAY) AS fe,
           DATE_SUB(@flight_start, INTERVAL DATEDIFF(DATE_ADD(@flight_end, INTERVAL @post_days DAY), @flight_start) DAY) AS ps
),
sales AS (
    SELECT t.shopper_id,
           SUM(CASE WHEN t.txn_date BETWEEN p.fs AND p.fe THEN t.net_amount ELSE 0 END) AS y,
           SUM(CASE WHEN t.txn_date >= p.ps AND t.txn_date < p.fs THEN t.net_amount ELSE 0 END) AS y_pre,
           COUNT(DISTINCT CASE WHEN t.txn_date BETWEEN p.fs AND p.fe THEN t.basket_id END) AS trips
    FROM tlog_lines t
    JOIN campaign_products cp ON cp.measurement_id = @campaign_salt AND cp.product_id = t.product_id
    CROSS JOIN params p
    WHERE t.txn_date >= p.ps AND t.txn_date <= p.fe
    GROUP BY t.shopper_id
),
exposure AS (                      -- shopper-level channels only; omit for walled gardens
    SELECT shopper_id, 1 AS exposed, SUM(viewable_impressions) AS viewable_impressions
    FROM rm_exposure
    WHERE measurement_id = @campaign_salt AND viewable_impressions > 0
    GROUP BY shopper_id
)
SELECT a.shopper_id, a.arm, a.segment_id,
       COALESCE(s.y, 0)      AS y,
       COALESCE(s.y_pre, 0)  AS y_pre,
       COALESCE(s.trips, 0)  AS trips,
       CASE WHEN s.y > 0 THEN 1 ELSE 0 END AS buyer,
       COALESCE(e.exposed, 0) AS exposed,
       COALESCE(e.viewable_impressions, 0) AS viewable_impressions
FROM rm_assignment a
LEFT JOIN sales s    ON s.shopper_id = a.shopper_id
LEFT JOIN exposure e ON e.shopper_id = a.shopper_id
WHERE a.measurement_id = @campaign_salt;
