---
title: IAB Incrementality Methodology for Retail Media
subtitle: Control-group methodology for walled-garden and shopper-level channels, with pseudocode and reference code
date: 28 September 2026
---

## The answer in brief

The IAB standard for proving lift is a control group chosen at random before anyone could be exposed, and never exposed afterwards. Your walled-garden flow already does this. Your non-walled-garden flow does not: taking the control from whoever was not exposed is classed by IAB as a proxy, not a measurement.

- **Walled gardens (Meta and other aggregated channels).** Hold the control out before the audience is uploaded, send the test group only, and measure both groups on our own till data. This is a randomised holdout with intent-to-treat analysis, which IAB rates as a strong causal method.
- **Shopper-level channels (the partner returns who was exposed).** The IAB/MRC guidance says the control must be chosen by "the same targeting and bidding logic" that picks who is treated. So the partner runs its allocation on everyone, then holds back a random share of the shoppers ***it selected***, before serving, and returns that list. That is the design to ask for. It matches the partner's earlier proposal (hold back 5% just before serving and return the list), provided the 5% is drawn from the shoppers their allocation selected.
- **The diff method (exposed list vs original list, control picked from the rest).** The non-exposed differ from the exposed because the partner's allocation picked the exposed for a reason. IAB places "baseline vs. exposed analysis" in its weakest class. With matching and before/after comparison it becomes a modelled estimate at best, and it must be labelled that way. In our test on synthetic data with a known answer, the raw diff overstated the effect about six times; matching still overstated it nearly four times.

IAB publishes no code. The reference code in this bundle implements the methods the IAB documents describe, and was checked against a known true effect.

## What the standards are

Four IAB documents govern this, and only one is certifiable. That one (IAB Europe V2.1) does not require incrementality, but says that if you offer it, it must use a method from the 2025 Guidelines.

| Document | Status | What it says about lift |
| --- | --- | --- |
| [IAB/MRC Retail Media Measurement Guidelines](https://www.iab.com/wp-content/uploads/2024/01/IAB_Retail_Media_Measurement_Guidelines_January2024.pdf), Jan 2024, chapter 4 | Guidelines, mapped to MRC standards and audits | RCTs "highly recommended"; control chosen by the same targeting and bidding logic as the treated; ITT, ghost ads or PSA where test shoppers only have an opportunity to see the ad; synthetic controls and matched markets as alternatives, with strict bias checks; full disclosure list |
| [IAB & IAB Europe Guidelines for Incremental Measurement in Commerce Media](https://iabeurope.eu/wp-content/uploads/IAB_and_IAB_Europe_Guidelines_Incremental_Measurement_Commerce_Media_November_2025.pdf), Nov 2025 | Guidelines, no audit | Four method classes graded by causal strength; three requirements a method must meet to claim causality |
| [IAB Europe Commerce Media Measurement Standards V2.1](https://iabeurope.eu/wp-content/uploads/IAB-Europes-Commerce-Media-Measurement-Standards-V2.1-May-2026.pdf), May 2026 | Certifiable (Retail Media Certification Programme) | Incrementality optional; if offered, one of the 2025 Guidelines' methods. 30-day default lookback for attribution, flexible shorter windows |
| [Demystifying Incrementality in Commerce Media](https://www.iab.com/guidelines/demystifying-incrementality-in-commerce-media/), Nov 2025 | Explainer | Definitions and business outcomes; no method rules |

### The four method classes (IAB 2025)

| Class | Examples | Causal strength | Where it fits here |
| --- | --- | --- | --- |
| Experiment-based | Randomised control tests, holdout / ghost ads, matched markets | Strong | Path 1 and Path 2, designs A and B |
| Model-based counterfactual | Synthetic control, machine-learning propensity models | Strong to moderate | Path 2, design C (matched non-exposed) |
| Econometric | Marketing mix models, time-series regression | Moderate to weak | Not for single-campaign lift |
| Hybrid proxies | New-to-brand %, **baseline vs. exposed analysis**, platform-reported incrementality | Weak | The raw diff; platform lift figures |

### The three requirements to claim a causal result

1. **A credible counterfactual.** A valid "what if not" group, separated from the test group by design. The IAB says the rigour of this design "is the primary factor determining the causal strength of the entire model".
2. **Control of bias.** Seasonality, pricing, promotions and other campaigns must not be credited to the ad. Test for it: parallel pre-trends, placebo tests, confounder controls.
3. **Separation of signal from noise.** Confidence intervals that exclude zero, bootstrapping, falsification and sensitivity tests. An insignificant lift "is not reliable for decision making".

### Rules that bind the control group (IAB/MRC, chapter 4)

- The control is assigned at random; the two groups must be "statistically identical in all respects except for the treatment".
- Randomising who is *targeted* is not the same as randomising who is *exposed*. When test shoppers only get an opportunity to see the ad, analyse by intent to treat, or use ghost ads or PSA designs.
- To avoid that error, use "the same targeting and bidding logic that determines who receives treatment to also determine who is placed in the control group".
- To count as treated, a shopper needs a viewable impression; if exposure cannot be limited to viewable impressions, disclose it.
- Matched and synthetic controls need matching on brand, category and retailer purchase behaviour, propensity-score checks, and A/A tests before the real comparison.

## The two paths at a glance

![Both paths pick the control at random before anyone can be exposed](../02-diagram/measurement-paths-diagram.png)

In both paths the comparison is every test shopper against every control shopper, reached or not; exposure data only scales the result to the shoppers actually reached.

## Path 1: aggregated channels (walled gardens)

For Meta and any channel that returns only totals, the control is held out on our side before upload, and the lift is read from our own till data. The platform's exposure figure is used only to scale the result to the shoppers it reached.

The key point: we never need the platform to tell us who saw the ad. We know who was *assigned* to each group, and we see what every one of them bought. Comparing all test shoppers with all control shoppers (reached or not) is an intent-to-treat comparison, and it is unbiased because the split was random.

### Steps

1. **Freeze the eligible audience.** Apply every eligibility, suppression and consent filter first. The holdout is drawn from the final list, never before filtering.
2. **Size the test.** Estimate the expected match rate and reach on the platform, then check the audience is big enough (see the statistics section). Low match rates dilute the effect, so walled gardens need larger audiences.
3. **Assign test and control.** Hash each shopper ID with the campaign's measurement ID; the lowest 10% (or the planned share) become control. Stratify by banner and value tier so both groups match on them exactly.
4. **Record the assignment before anything leaves.** Store the table with a timestamp, the salt and the planned share. It is never changed; late additions are assigned by the same formula.
5. **Upload the test group only.** Also upload the control as an **exclusion audience** in the same ad account, so broad, lookalike or "expanded" targeting cannot reach them.
6. **Run the campaign.** Keep the control out of every other campaign for the same brand on that platform for the flight and the measurement window.
7. **Collect the platform totals.** Matched audience size, reach, impressions, viewable impressions and spend, as the platform reports them.
8. **Measure outcomes on the till data.** One row per assigned shopper, test and control, with sales of the campaign products in the fixed window (flight start to flight end plus the headline window, e.g. 14 days) and the same measure in a pre-period. Non-buyers are zeros, not missing.
9. **Run the quality gates.** Sample ratio, pre-period balance, placebo on the pre-period. Stop if any fails.
10. **Estimate.** Intent-to-treat lift per shopper (regression-adjusted on pre-period sales), incremental sales for the whole test group, lift %, iROAS, then the effect per reached shopper = ITT ÷ (reach ÷ test group size).
11. **Report with disclosures.** Method class "Experiment-based: randomised holdout, intent to treat"; state that reach is platform-reported and not verified per shopper.

### Pseudocode

```text
# before launch
audience   = final_eligible_audience(campaign)          # after every filter
for s in audience:
    u      = sha256(campaign.measurement_id + "|" + s.id) -> uniform[0,1)
    s.arm  = "control" if rank_within_stratum(u) <= round(holdout * n_stratum) else "test"
freeze(assignment_table, timestamp, salt, holdout)       # immutable
upload(platform, target = test_ids)
upload(platform, exclusion = control_ids)                # blocks lookalike / broad reach

# after flight + window
platform = { reach, impressions, viewable, spend }      # aggregate only
rows = for each assigned shopper (test AND control, reached or not):
          y     = sales of campaign SKUs in [flight_start, flight_end + window]
          y_pre = same measure, same length, before flight_start
assert srm_p_value(rows) >= 0.001
assert |smd(y_pre, test vs control)| < 0.1
assert placebo_ci(y_pre) contains 0
itt        = coef_of_test in  y ~ test + y_pre        # ANCOVA, robust SE
incr_sales = itt * n_test
lift_pct   = itt / mean(y | control)
iroas      = incr_sales / platform.spend
reach_rate = platform.reach / n_test
effect_per_reached = itt / reach_rate                   # Bloom estimator
publish(result, method = "Randomised holdout, ITT", disclosures)
```

If the platform offers its own conversion-lift study, its figure is reported as the platform's, beside ours and labelled, never blended (IAB places platform-reported incrementality in the weakest class unless validated).

## Path 2: shopper-level exposure channels

When the partner returns who was exposed, ask it to hold out a random share of the shoppers its allocation selected, before serving (design A). If it cannot, hold out before sending (design B). Build the control from the non-exposed (design C) only when neither is possible, and label the result as modelled.

| Design | Who holds out, and when | What we send | IAB class | Use when |
| --- | --- | --- | --- | --- |
| **A. Partner holdout after allocation** (recommended) | Partner, after its allocation picks the target, before serving | Everyone | Experiment-based (ghost-ad logic), strong | Default for any partner that can do it |
| **B. Our holdout before sending** | Us, before export | Test group only | Experiment-based (ITT), strong | Partner cannot hold out; audience large enough to absorb dilution |
| **C. Matched non-exposed** | Nobody; control built afterwards | Everyone | Model-based counterfactual, strong to moderate at best | No holdout possible; always labelled modelled |

### Why design A is the standard one

The partner's allocation decides who is worth targeting. If the control is drawn from the same selected shoppers, test and control are alike in everything the allocation looked at, and in everything it did not. Only chance decides who is served. This is what IAB/MRC means by using "the same targeting and bidding logic" for both groups. It also loses less power than design B, because shoppers the allocation would never pick are not in either group.

### Steps, design A

1. **Send the full audience** with the segment ID, as now.
2. **Partner allocates** as usual and produces its target list.
3. **Partner randomises within the target list:** a fixed share (5 to 10%) is flagged control by a hash of the shopper ID and our measurement ID, so we can re-derive it. Stratify by segment if several segments share a campaign.
4. **Partner never serves the control** on any placement of that campaign, and logs each control shopper as "would have been served".
5. **Partner returns three things per shopper:** target-test (served), target-control (held out), and exposure detail for the test group (viewable impressions, first and last exposure date). Shoppers not selected by the allocation are returned as "not targeted"; they are excluded from the lift comparison.
6. **We verify the split:** recompute the hash; check sample ratio; check that no control shopper appears in the exposure file.
7. **Measure outcomes on the till data** for target-test and target-control, same window and pre-period as path 1.
8. **Quality gates, then estimate:** ITT among the targeted = effect of being targeted; divide by the share of target-test with a viewable impression = effect per exposed shopper.

### Steps, design B

Identical to path 1, except the partner's exposure file gives the exposure rate per shopper instead of a platform total, and exposure is linked to the till data at shopper level. The comparison is all test versus all control, never exposed versus control.

### Steps, design C (only when no holdout exists)

1. **Diff the lists:** non-exposed = sent audience minus exposed. Split them into "not targeted" and "targeted but not reached"; ask the partner for the allocation score of every shopper, because matching on it removes most of the selection.
2. **Build a propensity model** of being exposed from pre-period behaviour: brand, category and retailer sales, trips, recency, digital activity where available, plus the partner's score.
3. **Match** each exposed shopper to one or more non-exposed shoppers on that propensity, within a caliper. Report the share of exposed that found a match.
4. **Check balance** on every covariate (standardised difference below 0.1). If it fails, stop.
5. **Placebo test** on an earlier pre-period not used for matching; the estimated effect must be close to zero.
6. **Difference-in-differences:** (exposed after − before) − (matched after − before).
7. **Report as "Model-based counterfactual"**, with the covariates, the match rate and the stated assumption that nothing unobserved drives both exposure and sales.

### Pseudocode, designs A and C

```text
# ---- design A: partner side ----
target = allocation(full_audience)                       # partner's own logic
for s in target:
    s.arm = "control" if sha256(measurement_id + "|" + s.id) -> u < holdout else "test"
serve(target where arm == "test")                        # control never served
return { s.id, s.segment_id, s.arm, targeted = true, viewable_impr, first_seen, last_seen }
       + { s.id, targeted = false } for the rest

# ---- design A: our side ----
verify: recomputed arm == returned arm for every targeted shopper
verify: count(control with viewable_impr > 0) == 0
rows  = targeted shoppers only, test AND control, reached or not, with y, y_pre
itt   = coef_of_test in  y ~ test + y_pre
exposure_rate      = mean(viewable_impr > 0 | test)
effect_per_exposed = itt / exposure_rate
incr_sales         = itt * n_test_targeted

# ---- design C: fallback ----
non_exposed = sent_audience - exposed
ps   = logistic( exposed ~ y_pre + cat_pre + trips_pre + recency + partner_score )
pairs = nearest_neighbour(exposed, non_exposed, on = logit(ps), caliper = 0.2 sd)
assert max |smd(covariates, pairs)| < 0.1
assert placebo_did(earlier_pre_period, pairs) ~ 0
effect = mean(y - y_pre | exposed matched) - mean(y - y_pre | controls matched)
publish(result, method = "Model-based counterfactual", label = "modelled, not measured")
```

## Why the non-exposed are not a control group

On synthetic data where the true effect is known, every randomised design landed on the truth; the diff overstated it 6.3 times, and careful matching still overstated it 3.7 times while passing every balance check.

The test world: 200,000 shoppers. A hidden activity level drives both future sales and the partner's choice of whom to target. A second hidden trait, online engagement, drives both being reached and buying, and never appears in the till data. True effect: about 0.27 in sales per exposed shopper.

| Design | IAB class | Estimate per exposed shopper (95% interval) | True effect | Truth inside interval |
| --- | --- | --- | --- | --- |
| Path 1: our holdout, aggregate reach only | Experiment-based | 0.30 (0.15 to 0.45) | 0.24 | Yes |
| Design A: partner holdout after allocation | Experiment-based | 0.25 (0.09 to 0.41) | 0.27 | Yes |
| Design B: our holdout before sending | Experiment-based | 0.22 (0.03 to 0.40) | 0.27 | Yes |
| The diff: exposed vs non-exposed | Hybrid proxy | 1.71 (1.67 to 1.75) | 0.27 | No |
| Design C: matched non-exposed + before/after | Model-based counterfactual | 0.99 (0.93 to 1.06) | 0.27 | No |

Repeated 40 times on fresh data, the randomised designs' 95% intervals contained the true effect 95%, 100% and 92% of the time, as they should.

Three lessons for the product:

- **The diff flatters the campaign.** The partner's allocation targets shoppers who were going to buy more anyway, so exposed-vs-rest credits the ad with the allocation's skill. This matches the published evidence: across 15 Facebook experiments, observational methods generally overestimated the effect, and in half of the studies were off by a factor of three ([Gordon et al., 2019](https://pubsonline.informs.org/doi/10.1287/mksc.2018.1135)).
- **A balance table does not prove the control is valid.** Design C balanced every observed covariate and was still wrong, because what drove exposure was partly invisible to us.
- **Randomised designs are noisier but honest.** Their intervals are wider; the fix is a bigger audience or holdout, not a different control.

## The statistics

Every randomised design uses the same three calculations: the intent-to-treat difference, adjusted for pre-period sales; its scaling to exposed shoppers; and its totals. The IAB/MRC guidance names each tool used here: comparison of means, t-tests, analysis of covariance and regression.

**Outcome per shopper.** Sales (or units, trips, buyer yes/no) of the campaign's products in one fixed calendar window for both groups: flight start to flight end plus the headline window. A per-exposure lookback cannot be used for lift, because the control has no exposure date. Halo (same brand, same category, per IAB Europe) is a separate outcome, never added to the first.

**Intent-to-treat effect**, regression-adjusted, with heteroskedasticity-robust standard errors:

$$y_i = \alpha + \tau_{ITT}\,T_i + \gamma\,y_i^{pre} + \varepsilon_i$$

Without the pre-period term this is the plain difference of means (Welch t-test). With it, the estimate is the same on average and the interval is narrower.

**Effect per exposed shopper** (the Bloom estimator; valid because control shoppers cannot be exposed):

$$\tau_{exposed} = \frac{\tau_{ITT}}{e}, \qquad e = \frac{\text{test shoppers with a viewable impression}}{\text{test shoppers}}$$

For walled gardens, e is the platform's reach divided by the number of test shoppers uploaded, and its uncertainty is not in the interval (disclose it).

**Totals and ratios:**

$$\text{incremental sales} = \tau_{ITT}\,N_{test}, \quad \text{lift} = \frac{\tau_{ITT}}{\bar{y}_{control}}, \quad \text{iROAS} = \frac{\tau_{ITT}\,N_{test}}{\text{spend}}$$

Incremental buyers use the same formula on the buyer yes/no outcome. Intervals come from the delta method; the code also runs a bootstrap as a cross-check.

**Heavy spenders.** A handful of very large baskets can swing the result. If outliers are capped, the cap is set before looking at results, applied identically to both groups, and disclosed.

### Audience sizing

The total audience needed to detect a given effect per exposed shopper, at 95% confidence and 80% power:

$$N = \frac{(z_{0.975} + z_{0.80})^2\,\sigma^2 (1 - R^2)}{(\delta\,e)^2} \left( \frac{1}{1-p} + \frac{1}{p} \right)$$

σ is the standard deviation of the outcome per shopper, R² the share of it the pre-period explains, δ the effect per exposed shopper to detect, e the exposure rate, p the holdout share. Worked example: σ = 12, δ = 0.40, p = 10%.

| Exposure rate | No pre-period adjustment | Pre-period explains 30% |
| --- | --- | --- |
| 100% | 78,489 | 54,943 |
| 60% | 218,025 | 152,618 |
| 30% | 872,098 | 610,469 |

Halving the exposure rate roughly quadruples the audience needed. That is why walled gardens with low match rates, and design B, need large audiences, and why design A (which excludes the never-targeted) is more efficient.

## Quality gates before a number is published

A lift figure is published only when every gate below passes; a failed gate blocks the figure and the report says why.

| Gate | Test | Pass rule | If it fails |
| --- | --- | --- | --- |
| Sample ratio | Chi-square of observed test/control counts vs the planned split | p ≥ 0.001 | Assignment or data pipeline is broken; investigate, do not report |
| Assignment reproducible | Recompute each shopper's arm from the hash and salt | 100% match | Partner or pipeline changed the split |
| Control contamination | Share of control shoppers in the exposure file | ≤ 1% (target 0) | Report ITT only; disclose; fix exclusion setup |
| Pre-period balance | Standardised mean difference on pre-period sales, trips, category sales | \|SMD\| < 0.1 | Randomisation suspect (A/B) or matching failed (C) |
| Placebo (A/A) | The same estimator on the pre-period, when no one was exposed | Interval contains 0 | Hidden bias; do not report |
| Power | Minimum detectable effect from the actual group sizes | Stated before launch; below the expected effect | Report as inconclusive, not as "no effect" |
| Match share (design C only) | Share of exposed shoppers with a match inside the caliper | ≥ 90% | Estimate covers only the matched; disclose |
| Data completeness | Assigned shoppers with a till-data row (zeros included) | 100% of assigned | Missing rows bias the result; fix the join |

Two further checks each quarter: re-run a campaign as an A/A test (no ads to either group) to confirm the pipeline returns zero, and compare repeated campaigns for the same brand to see whether lift persists, as the 2025 Guidelines recommend.

## What every lift report must disclose

IAB/MRC chapter 4 lists what a measurement provider discloses with an incrementality result; this is that list applied to our reports.

- [ ] Method and its IAB class (experiment-based / model-based counterfactual), and who held out the control and when
- [ ] Holdout share, how shoppers were assigned (hash, salt, strata), and the date the assignment was frozen
- [ ] Sample sizes of each group, and for walled gardens the uploaded, matched and reached counts
- [ ] Measurement window and pre-period dates, stated before the campaign runs
- [ ] Outcome definition: products counted (parent SKU incl. variants), halo kept separate, gross or net sales, online / in-store split
- [ ] Exposure definition: viewable impressions (MRC) or, where not possible, what was used instead
- [ ] Estimator, covariates, and any outlier cap
- [ ] Point estimate with 95% confidence interval and p-value, for ITT and effect per exposed
- [ ] Results of every quality gate
- [ ] Assumptions and known biases or limitations (e.g. reach not verified per shopper; unobserved confounding for design C; other media the control may have seen)
- [ ] Share of results that is extrapolated to unidentified shoppers, if any
- [ ] Data retention: records kept at least 12 months so results can be reprocessed and audited

## Reference code and open-source tools

IAB publishes no reference code, so there is no official implementation to adopt. The package in folder 03 implements every step above and is tested against a known true effect.

| File | What it does |
| --- | --- |
| iab_lift.py | Hash-based stratified assignment; audience sizing; quality gates (sample ratio, balance, placebo, contamination); ITT with ANCOVA; effect per exposed; incremental sales, lift, iROAS; matched difference-in-differences fallback; result object with disclosures, exportable as JSON |
| demo_simulation.py | Runs path 1 and designs A, B, C on synthetic data; `--reps 40` checks interval coverage |
| sql/01_assign_holdout.sql | The same assignment in SQL (SingleStore dialect, notes for BigQuery and Snowflake), plus the exclusion-audience export |
| sql/02_shopper_outcomes.sql | One row per assigned shopper from the till data, zeros included, with pre-period and exposure |
| sql/03_itt_lift_aggregate.sql | Unadjusted ITT readout in SQL for dashboards and sanity checks |

Python 3.10+, numpy, pandas, scipy, scikit-learn. The published figure comes from the Python estimator; the SQL readout is for checking.

Open-source tools for what this package does not cover:

- **Channels with no shopper IDs** (in-store screens, some off-site media): geo or store-cluster tests. [GeoLift](https://github.com/facebookincubator/GeoLift) (Meta, R, MIT licence, synthetic control with power analysis and market selection); Google's matched_markets (Python, time-based regression); Google CausalImpact; CausalPy. These are the IAB/MRC "matched-market" method.
- **Who responds best, on top of a holdout:** CausalML (Uber), scikit-uplift, EconML (Microsoft). The IAB/MRC guidance notes uplift models are more reliable when trained on randomised data.

## Sources

- [IAB/MRC Retail Media Measurement Guidelines, January 2024](https://www.iab.com/wp-content/uploads/2024/01/IAB_Retail_Media_Measurement_Guidelines_January2024.pdf): chapter 4 (incrementality methods, ITT, ghost ads, synthetic controls, matched markets, disclosures) and section 3.6 (attribution windows)
- [IAB & IAB Europe, Guidelines for Incremental Measurement in Commerce Media, November 2025](https://iabeurope.eu/wp-content/uploads/IAB_and_IAB_Europe_Guidelines_Incremental_Measurement_Commerce_Media_November_2025.pdf): four method classes, three causal requirements
- [IAB Europe Commerce Media Measurement Standards V2.1, May 2026](https://iabeurope.eu/wp-content/uploads/IAB-Europes-Commerce-Media-Measurement-Standards-V2.1-May-2026.pdf): incrementality optional for certification, methods per the 2025 Guidelines; 30-day default lookback
- [IAB, Demystifying Incrementality in Commerce Media](https://www.iab.com/guidelines/demystifying-incrementality-in-commerce-media/)
- [Gordon, Zettelmeyer, Bhargava, Chapsky, "A Comparison of Approaches to Advertising Measurement", Marketing Science, 2019](https://pubsonline.informs.org/doi/10.1287/mksc.2018.1135)
- [Meta GeoLift](https://github.com/facebookincubator/GeoLift)
