-- 03_verify_load.sql
SELECT * FROM ops.load_batch ORDER BY load_batch_id DESC LIMIT 1;
SELECT count(*) AS exposure_rows FROM core.fact_exposure WHERE load_batch_id = :load_batch_id;
SELECT campaign_key, count(*) AS impressions, sum(total_cost_usd) AS spend_usd
FROM core.fact_exposure WHERE load_batch_id=:load_batch_id GROUP BY campaign_key ORDER BY impressions DESC;
SELECT rejection_code, count(*) FROM ops.rejected_record WHERE load_batch_id=:load_batch_id GROUP BY rejection_code;
SELECT count(*) AS unresolved_dimension_keys FROM core.fact_exposure
WHERE load_batch_id=:load_batch_id AND (creative_key IS NULL OR placement_key IS NULL OR device_key IS NULL OR geography_key IS NULL);
