# Canonical Retail Media Exposure Model v3

Run order:
1. `psql "$DATABASE_URL" -f 01_create_schema.sql`
2. `python -m pip install pandas pyarrow "psycopg[binary]"`
3. `python load_unlimitail_parquet.py <feed.parquet>`
4. `psql "$DATABASE_URL" -v load_batch_id=<id> -f 03_verify_load.sql`

The Python loader creates a PostgreSQL session TEMP table and executes the transform SQL in the same session.
