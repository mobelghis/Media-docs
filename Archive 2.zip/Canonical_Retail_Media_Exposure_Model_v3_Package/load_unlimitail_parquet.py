#!/usr/bin/env python3
"""Load Parquet/JSONL into a PostgreSQL TEMP table, then execute canonical SQL in the same session."""
import argparse, hashlib, os
from pathlib import Path
import pandas as pd
import psycopg
from psycopg import sql

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def read_file(path):
    return pd.read_parquet(path,engine='pyarrow') if path.suffix.lower()=='.parquet' else pd.read_json(path,lines=True,dtype=False)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('file'); args=ap.parse_args(); path=Path(args.file)
    df=read_file(path); df.columns=[str(c).strip().lower() for c in df.columns]; df=df.where(pd.notna(df),None)
    with psycopg.connect(os.environ['DATABASE_URL']) as conn:
      with conn.cursor() as cur:
        cur.execute("""INSERT INTO ops.load_batch(source_system,source_file,file_checksum) VALUES('UNLIMITAIL',%s,%s)
                       ON CONFLICT(source_system,source_file,file_checksum) DO UPDATE SET received_at=now() RETURNING load_batch_id""",(path.name,sha256(path)))
        batch_id=cur.fetchone()[0]
        df.insert(0,'source_file',path.name); df.insert(0,'source_row_number',range(1,len(df)+1)); df.insert(0,'load_batch_id',batch_id)
        for c in df.columns:
            if c not in {'load_batch_id','source_row_number'}: df[c]=df[c].map(lambda v:None if v is None else str(v))
        cur.execute("CREATE TEMP TABLE temp_unlimitail_impression (LIKE raw.unlimitail_impression INCLUDING DEFAULTS) ON COMMIT DROP")
        columns=list(df.columns)
        copy_sql=sql.SQL('COPY temp_unlimitail_impression ({}) FROM STDIN').format(sql.SQL(',').join(map(sql.Identifier,columns)))
        with cur.copy(copy_sql) as cp:
            for row in df.itertuples(index=False,name=None): cp.write_row(row)
        transform=Path(__file__).with_name('02_transform_temp_to_canonical.sql').read_text().replace(':load_batch_id',str(batch_id))
        cur.execute(transform)
        print(f'Loaded batch {batch_id}; rows staged: {len(df)}')
if __name__=='__main__': main()
