# Retail Media — Implementation Plan

Engineering companion to the PRD. Scope: one retailer per deployment. Phase 1 only is
in-scope for build; Phases 2-4 are designed here so Phase 1 does not foreclose them.

---

## 0. Ground rules

1. **Tiers degrade independently.** A Tier 3 failure must never take down Tier 0. Enforce with
   separate pipelines, separate tables, separate schedules.
2. **Tier 1 is ingested, never recomputed.** Vendor attribution lands in its own table, keeps the
   vendor's name and window on it, and never overwrites our figures.
3. **Never train on Tier 1.** Vendor numbers encode the vendor's attribution assumptions.
4. **No exposed-vs-unexposed comparison, ever.** Add a code-review checklist item. It is
   computable in Phase 1 and it is wrong — it measures selection, not effect.
5. **One timezone convention globally.** Unlimitail publishes `_ltz` twins of most facts.
   Pick UTC or local, document it at the top of the repo, never mix.
6. **Channel travels on every record.** Offer, delivery event, redemption, exposure. It is a
   first-class dimension, not a reporting attribute added later.

---

## 1. Repository layout

```
/docs/retail-media/          PRD, input spec, phasing, this plan
/prototype/                  retail-media-console.html
/ingest/
  /unlimitail/               BigQuery share extraction
  /retailer/                 TLOG + offer-state return file
  /planning/                 assignment, offer registry, segment snapshots
/conform/                    key mapping, currency, timezone, SCD snapshots
/marts/                      rm_* tables
/metrics/                    KPI definitions as code, one module per family
/quality/                    reconciliation, match rates, alerting
/models/                     phase 2+ only; empty in phase 1
/api/                        read API for the console
/console/                    front end
```

**Metrics as code, not as SQL scattered through the app.** Every KPI in the catalogue gets one
definition in `/metrics/`, tagged with its tier. The console calls those; it never writes its own
aggregations. This is what makes the tier labelling in the UI trustworthy rather than decorative.

---

## 2. Data model

### 2.1 Registry
| Table | Grain | Notes |
|---|---|---|
| `rm_program` | program | Level-0 entity. Funder, objective, budget envelope, flight dates |
| `rm_campaign` | campaign | Lane, channel, dates, budget. Ours for offers, mirrored for media |
| `rm_wave` | wave | Timing and cap within a campaign |
| `rm_offer` | offer | Mechanic, discount value, funded_by, eligible SKU set, channel |
| `rm_segment` | segment | Published audience definitions, access scope, definition version |
| `rm_segment_membership` | segment x shopper x date | Snapshot at assignment time, not current state |

### 2.2 Assignment — the Tier 2 foundation
| Column | Notes |
|---|---|
| `hashed_shopper_id` | Matches export and TLOG |
| `program_id` | |
| `assignment` | `test` / `control` |
| `assigned_at` | Must precede first exposure |
| `stratum_spend_decile`, `stratum_category_buyer`, `stratum_recency_band`, `stratum_store_cluster` | Balance checking |
| `wash_expiry` | Earliest re-target date |

**Append-only. Immutable. Versioned.** A rerun must never overwrite it. Enforce with a database
constraint, not a convention. Control shoppers are excluded from the outbound feed entirely and
exist only here.

### 2.3 Facts
| Table | Grain | Source | Tier |
|---|---|---|---|
| `rm_offer_issue` | shopper x offer | Planning tool export | 0 |
| `rm_offer_state` | shopper x offer x event | Retailer return file | 0 |
| `rm_redemption` | shopper x offer x line | Return file joined to TLOG | 0 |
| `rm_exposure` | shopper x impression | `fact_realised_ad` | 0 |
| `rm_ad_request` | request | `fact_ad_request` | 0 |
| `rm_spend` | campaign x day | `fact_ledger` + `fact_fta_campaign_spend` | 0 |
| `rm_vendor_attribution` | campaign x SKU | `fact_enhanced_attribution` | 1 |

### 2.4 Outputs
`rm_program_summary` · `rm_channel_summary` · `rm_segment_summary` · `rm_lift_result`
(program x cut x method, with interval and p-value) · `rm_feed_health` (feed x day).

Tier 1 and Tier 2 results live in separate tables permanently. Reconciliation requires both.

---

## 3. Ingestion

### 3.1 Unlimitail — BigQuery share
- **Trigger off `log_status`, not cron.** It records load start, end and status. A late warehouse
  build must delay our run, not publish a half-loaded day.
- Request **Core Dataset** access (transaction-level) rather than only the Reporting Datamart
  (aggregated, current dimension versions only).
- **Snapshot every dimension daily.** SCD history is our responsibility.
- If we are not on Google Cloud, we get a service account with API access only — build extraction
  into our lake rather than querying in place.
- Union `fact_ledger` with `fact_fta_campaign_spend` or fixed-tenancy cost is silently omitted
  from every ROAS denominator.

### 3.2 Retailer — TLOG
Daily. Required fields include line-level `discount_amount`, `margin_usd` (net) and ideally
`gross_margin`. Without margin, Phase 1 loses Program P&L and the product degrades to a
better-looking version of what the network already sells.

### 3.3 Retailer — offer-state return file
Daily during flight, not only at campaign end. Event rows with timestamps, not a final status.
States: `issued`, `suppressed`, `delivered`, `bounced`, `opened`, `clicked`, `redeemed`, `expired`.
Redeemed rows carry `discount_applied` and `transaction_id`; suppressed rows carry
`non_send_reason`.

---

## 4. Conformance

Three joins carry the product:

| Join | Ours | Theirs | Floor |
|---|---|---|---|
| Product | `upc` | `gtin` | 99% |
| Shopper | hashed loyalty id | `customer_id` | 95% |
| Session | session key | `sessionId` | 90% |

Plus **export-return reconciliation at 100%** — rows sent to the retailer must equal rows
returned. Suppressions are marked, never dropped.

Each floor is a published daily metric with alerting. Integration quality degrades quietly; the
failure mode is a slowly falling match rate nobody notices until a result looks strange.

---

## 5. Phase 1 build sequence

| # | Workstream | Output | Depends on |
|---|---|---|---|
| 1 | Registry schema and planning-tool export contract | `rm_program` … `rm_offer` populated | Planning tool |
| 2 | TLOG ingestion and canonical mapping | `transactions` conformed with margin | Retailer feed |
| 3 | Return-file ingestion and state model | `rm_offer_state`, `rm_redemption` | Return file spec agreed |
| 4 | Unlimitail extraction | `rm_exposure`, `rm_ad_request`, `rm_spend`, `rm_vendor_attribution` | Retailer-tier access |
| 5 | Conformance and quality layer | Match rates, reconciliation, `rm_feed_health` | 2, 3, 4 |
| 6 | Metrics layer — families 1-8 | 93 Tier 0 metrics as code | 5 |
| 7 | Read API | Typed endpoints per screen | 6 |
| 8 | Console — Plan, Day 1, Performance, Audience, Channel, KPI dictionary, Inputs | Shipped UI | 7 |
| 9 | Alerting and runbook | On-call for feed failures | 5 |

**Ship gate:** identity match above 95% and export-return reconciliation at 100% for four
consecutive weeks.

**Parallel, not blocking:** the assignment table lands in the planning tool during Phase 1 so that
Phase 2 can begin on the first campaign after Phase 1 ships. It is a planning-tool change, not a
Retail Media change, and it is the only dependency that cannot be added retrospectively.

---

## 6. Phase 2 build sequence

| # | Component | Notes |
|---|---|---|
| 1 | Stratified randomised assignment | Spend decile, category buyer status, recency band, store cluster |
| 2 | Balance diagnostics | Standardised mean difference per stratum. Publish it — it is the credibility evidence |
| 3 | Power and MDE calculator | Sizes the holdout before commitment; feeds the sales forecast |
| 4 | Difference-in-means estimator | Bootstrapped confidence intervals |
| 5 | CUPED variance reduction | Pre-period spend as covariate. **Highest return per unit of effort in the whole roadmap** — tightens intervals at no data cost, so smaller holdouts become viable and the revenue cost of measurement drops |
| 6 | Multiple-comparison correction | Testing twenty segments without it manufactures significance |
| 7 | Difference-in-differences | Store-level read for unidentified shoppers |
| 8 | Lift by channel and by lane | Channel-level incrementality — the input Phase 4 needs |

**Ship gate:** three campaigns measured end to end with balance checks passing and intervals on
every headline figure.

---

## 7. Phases 3 and 4 — design notes only

**Phase 3** is largely reuse. Counterfactual baseline tables by product and week already exist,
including baseline margin, alongside pre-computed cannibalisation, halo and pull-forward measures
at promo level. The work is validating those against Phase 2 experimental results and wiring them
in. **Validate before reuse** — the existing baseline was built for price promotions and its
behaviour on media-driven programs is unproven.

**Phase 4** requires accumulated Phase 2 history as training labels. Expect 8-12 measured programs
before uplift models are trustworthy. Priority order:
1. Channel affinity / next-best-channel (highest commercial value, feeds the planning tool)
2. Uplift / ITE scoring
3. Saturation curves and frequency caps
4. Incremental CLV
5. Forecast lift and ROAS for the planning screen

---

## 8. Console

Seven views: Plan, Day 1, Performance, Incrementality, Audience, Channel, KPI dictionary,
Inputs & gaps. Colour encodes provenance and tier — teal for our data, indigo for the vendor feed,
amber exclusively for Tier 2/3, red for gaps. Assumption badges mark every inference pending
vendor confirmation.

**Day 1 renders Tier 0 only.** Lift, ROAS and attributed sales are actively suppressed with a
visible marker rather than silently absent — making the suppression visible is what stops a brand
asking for ROAS on day two.

Every Tier 2/3 figure carries an interval or a p-value. Non-significant segment results render in
grey, not in the accent colour.

---

## 9. Testing

- **Contract tests** on every inbound feed: schema, required fields, enum values, row counts.
- **Reconciliation tests**: export rows equal return rows; vendor spend equals ledger plus FTA.
- **Metric regression tests**: each of the 93 Tier 0 metrics has a fixture with a known answer.
- **Tier isolation test**: with the vendor feed absent, Tier 0 offer metrics must still compute.
- **Assignment immutability test**: attempting to overwrite an assignment row must fail.
- **A guard test that fails the build** if any metric compares exposed against unexposed
  populations without an assignment join.

---

## 10. Open items

| # | Item | Owner | Blocks |
|---|---|---|---|
| 1 | Retailer-tier warehouse access in the retailer's contract | Commercial | Phase 1 |
| 2 | Customer-level exposure at retailer tier | Unlimitail | Phase 1 overlap and frequency |
| 3 | Assignment table in the planning tool | Planning product | Phase 2 entirely |
| 4 | TLOG margin at line level confirmed | Retailer | Phase 1 Program P&L |
| 5 | Return-file spec agreed, mark-don't-remove contractual | Retailer | Phase 1 |
| 6 | Shopper key consistent across e-commerce and loyalty | Retailer | Phase 1 |
| 7 | Ghost-bid / PSA control capability | Unlimitail | Phase 2 unidentified read |
| 8 | Conversion window and attribution models confirmed | Unlimitail | Reconciliation |
| 9 | Write access to campaign custom attributes | Unlimitail | Cross-channel roll-up |
| 10 | Store master with clusters and 12 weeks of pre-period sales | Retailer | Phase 2 unidentified read |

---

## 11. The one thing

**The assignment table with the test/control flag, written at selection time in the planning
tool.** Every Phase 2, 3 and 4 capability traces back to it. It is the only dependency in the
system that cannot be fixed retrospectively, and it costs almost nothing to add now versus
everything to add later.

Phase 1 does not need it. Phase 1 should not wait for it. But it must land before the first
campaign anyone intends to measure.
