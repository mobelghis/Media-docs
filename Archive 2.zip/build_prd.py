# -*- coding: utf-8 -*-
"""Generates the Retail Media Reporting enterprise PRD as a .docx file."""
import os
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

BASE = os.path.dirname(os.path.abspath(__file__))
SHOT = lambda f: os.path.join(BASE, 'screenshots', f)

# ---------------------------------------------------------------------------
# KPI CATALOG (source of truth: Retail_Media_Phase1_MVP_KPI_Catalog (2).xlsx)
# ---------------------------------------------------------------------------
KPI = {
 1:  dict(name="Impressions", category="Media Delivery", status="Supported",
          definition="Number of valid ad impressions delivered."),
 2:  dict(name="Estimated Impressions", category="Media Planning",
          status="Supported when campaign_plan_budget is created and populated",
          definition="Number of impressions approved in the active campaign media plan before delivery begins."),
 3:  dict(name="Impression Delivery Multiplier", category="Media Delivery", status="Requires additional table",
          definition="Actual impressions compared with planned impressions."),
 4:  dict(name="CPM", category="Media Efficiency", status="Conditional",
          definition="Cost for every 1,000 delivered impressions."),
 5:  dict(name="Estimated CPM", category="Media Planning",
          status="Supported when campaign_plan_budget is created and populated",
          definition="Planned media cost for every 1,000 planned impressions in the approved campaign plan."),
 6:  dict(name="CPM Efficiency Ratio", category="Media Efficiency", status="Requires additional table",
          definition="Actual CPM compared with planned CPM."),
 7:  dict(name="Reach", category="Media Delivery", status="Supported",
          definition="Unique Activate shoppers with a qualifying media event."),
 8:  dict(name="Clicks", category="Media Delivery", status="Supported",
          definition="Number of valid campaign clicks."),
 9:  dict(name="Exposable Audience", category="Audience", status="Requires confirmed physical table",
          definition="Unique shoppers successfully made available for activation."),
 10: dict(name="Shoppers", category="Commerce", status="Supported",
          definition="Unique campaign shoppers with at least one attributed purchase."),
 11: dict(name="Conversion Rate", category="Conversion", status="Requires confirmed physical table",
          definition="Share of the exposable audience that became attributed shoppers."),
 12: dict(name="Shopper Share by Audience Segment", category="Audience", status="Supported",
          definition="Share of attributed shoppers belonging to each audience segment."),
 13: dict(name="Conversion-Rate Difference", category="Conversion",
          status="Supported when audience_export and attribution_link_fact are available",
          definition="Percentage-point difference between a segment's conversion rate and the overall campaign rate."),
 14: dict(name="Revenue", category="Commerce", status="Supported",
          definition="Total sales value credited to the campaign."),
 15: dict(name="Transactions", category="Commerce", status="Supported",
          definition="Distinct purchase transactions credited to the campaign."),
 16: dict(name="Revenue per Shopper", category="Commerce", status="Supported",
          definition="Average attributed sales per attributed shopper."),
 17: dict(name="Purchase Frequency", category="Commerce", status="Supported",
          definition="Average attributed transactions per attributed shopper."),
 18: dict(name="Average Basket Value", category="Commerce", status="Supported",
          definition="Average attributed sales per attributed transaction."),
 19: dict(name="Items per Basket", category="Commerce", status="Supported",
          definition="Average attributed units per attributed transaction."),
 20: dict(name="Average Price per Product", category="Commerce", status="Supported",
          definition="Average attributed sales per attributed unit."),
 21: dict(name="Loyal Shoppers", category="Loyalty", status="Supported",
          definition="Attributed shoppers with at least two separate attributed transactions."),
 22: dict(name="Loyal Shopper Rate", category="Loyalty", status="Supported",
          definition="Percentage of attributed shoppers with at least two attributed transactions."),
 23: dict(name="E-commerce Revenue Share", category="Channel", status="Requires confirmed dimension",
          definition="Share of attributed revenue generated through e-commerce."),
 24: dict(name="E-commerce Revenue Share Difference vs Category", category="Channel Benchmark",
          status="Requires confirmed dimensions",
          definition="Product e-commerce share minus category e-commerce share."),
 25: dict(name="Buyer Share", category="Shopper Profile", status="Requires confirmed dimension",
          definition="Share of attributed shoppers in a selected profile group."),
 26: dict(name="Category Buyer Share", category="Shopper Profile Benchmark", status="Requires confirmed dimensions",
          definition="Share of category buyers in a selected profile group."),
 27: dict(name="Buyer Share Difference vs Category", category="Shopper Profile Benchmark",
          status="Supported when campaign_product_scope is created",
          definition="Percentage-point difference between product buyers' profile share and category buyers' profile share."),
 28: dict(name="Media Spend", category="Media Efficiency", status="Requires additional table",
          definition="Total approved media cost."),
 29: dict(name="Click-Through Rate", category="Media Efficiency", status="Supported",
          definition="Percentage of impressions that generated a click."),
 30: dict(name="Media Frequency", category="Media Delivery", status="Supported",
          definition="Average impressions per reached shopper."),
 31: dict(name="Attributed Units", category="Commerce", status="Supported",
          definition="Total units credited to the campaign."),
 32: dict(name="Attributed Margin", category="Commerce", status="Conditional",
          definition="Total margin credited to the campaign."),
 33: dict(name="Attributed ROAS", category="Media Efficiency", status="Requires additional table",
          definition="Attributed sales per unit of media spend."),
 34: dict(name="Cost per Attributed Shopper", category="Media Efficiency", status="Requires additional table",
          definition="Average media cost per attributed shopper."),
 35: dict(name="Cost per Attributed Transaction", category="Media Efficiency", status="Requires additional table",
          definition="Average media cost per attributed transaction."),
 36: dict(name="Average Time to Purchase", category="Attribution", status="Supported",
          definition="Average hours from winning event to purchase."),
 37: dict(name="Median Time to Purchase", category="Attribution", status="Supported",
          definition="Middle hours from winning event to purchase."),
 38: dict(name="Attributed Sales Share", category="Commerce Share", status="Supported",
          definition="Percentage of attributed sales in a breakdown."),
 39: dict(name="Attributed Shopper Share", category="Commerce Share", status="Supported",
          definition="Percentage of attributed shoppers in a breakdown."),
 40: dict(name="Attributed Transaction Share", category="Commerce Share", status="Supported",
          definition="Percentage of attributed transactions in a breakdown."),
 41: dict(name="Media Event Deduplication Rate", category="Diagnostic", status="Requires supporting governance",
          definition="Duplicate raw media rows divided by received rows."),
 42: dict(name="Shopper Identity Match Rate", category="Diagnostic", status="Requires supporting governance",
          definition="Eligible shopper records successfully identity-matched."),
 43: dict(name="Campaign ID Recognition Rate", category="Diagnostic", status="Requires supporting governance",
          definition="Returned media rows mapped to a known campaign."),
 44: dict(name="Product Mapping Rate", category="Diagnostic", status="Requires supporting governance",
          definition="Relevant products mapped to a governed UPC/product."),
 45: dict(name="Attribution Eligibility Rate", category="Diagnostic",
          status="Supported when measurement_run and data_quality_readiness are populated",
          definition="Percentage of qualifying purchase lines with at least one eligible media-event candidate."),
 46: dict(name="Attribution Link Creation Rate", category="Diagnostic",
          status="Supported when measurement_run and data_quality_readiness are populated",
          definition="Percentage of candidate-eligible purchase lines with one final winning attribution link persisted."),
 47: dict(name="Direct / Halo Classification Coverage", category="Diagnostic", status="Supported",
          definition="Attributed links assigned an approved direct or halo scope."),
 48: dict(name="TLOG Reconciliation Difference", category="Diagnostic", status="Supported",
          definition="Difference between bridge snapshots and source TLOG values."),
 49: dict(name="Late-Arriving Data Rate", category="Diagnostic", status="Requires supporting governance",
          definition="Source records received after the cutoff."),
 50: dict(name="Result Maturity Status", category="Diagnostic", status="Requires supporting governance",
          definition="Publication state of a result version."),
}

print(f"Loaded {len(KPI)} KPIs")

# ---------------------------------------------------------------------------
# DOCX HELPERS
# ---------------------------------------------------------------------------
ACCENT = RGBColor(0x1F, 0x3B, 0x57)   # dark slate blue for headings
RULE_GREY = RGBColor(0x6B, 0x6B, 0x6B)

def set_cell_shading(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:fill'), hex_color)
    tcPr.append(shd)

def style_table_header(table, hex_color="1F3B57"):
    for cell in table.rows[0].cells:
        set_cell_shading(cell, hex_color)
        for p in cell.paragraphs:
            for r in p.runs:
                r.font.bold = True
                r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

def add_label_block(doc, label, content):
    """label in bold on its own line, then a paragraph or bullet list under it."""
    if label:
        p = doc.add_paragraph()
        run = p.add_run(label)
        run.bold = True
        run.font.size = Pt(10.5)
    if content is None:
        doc.add_paragraph("Not applicable.")
        return
    if isinstance(content, str):
        doc.add_paragraph(content)
    else:
        for item in content:
            doc.add_paragraph(str(item), style='List Bullet')

def add_kpi_table(doc, kpi_ids):
    table = doc.add_table(rows=1, cols=4)
    table.style = 'Light Grid Accent 1'
    hdr = table.rows[0].cells
    hdr[0].text, hdr[1].text, hdr[2].text, hdr[3].text = (
        'KPI (Catalog #)', 'Category', 'Business Definition', 'Data Model Readiness')
    for kid in kpi_ids:
        k = KPI[kid]
        row = table.add_row().cells
        row[0].text = f"{k['name']} (#{kid})"
        row[1].text = k['category']
        row[2].text = k['definition']
        row[3].text = k['status']
    style_table_header(table)
    doc.add_paragraph()

def add_gwt_table(doc, criteria):
    table = doc.add_table(rows=1, cols=3)
    table.style = 'Light Grid Accent 1'
    hdr = table.rows[0].cells
    hdr[0].text, hdr[1].text, hdr[2].text = 'Given', 'When', 'Then'
    for c in criteria:
        row = table.add_row().cells
        row[0].text, row[1].text, row[2].text = c['given'], c['when'], c['then']
    style_table_header(table)
    doc.add_paragraph()

def add_story(doc, story):
    h = doc.add_heading(f"Story {story['id']} \u2014 {story['title']}", level=2)
    add_label_block(doc, "Business Objective", story['business_objective'])
    add_label_block(doc, "User Story", story['user_story'])
    add_label_block(doc, "Business Context", story['business_context'])
    add_label_block(doc, "Functional Requirements", story['functional_requirements'])
    add_label_block(doc, "Business Rules", story['business_rules'])
    add_label_block(doc, "Data Requirements", story['data_requirements'])
    if story.get('kpi_dependencies'):
        p = doc.add_paragraph(); r = p.add_run("KPI Dependencies"); r.bold = True
        add_kpi_table(doc, story['kpi_dependencies'])
    else:
        add_label_block(doc, "KPI Dependencies", ["None \u2014 this story does not render calculated KPI values."])
    add_label_block(doc, "Permission Requirements", story['permission_requirements'])
    add_label_block(doc, "Reporting Requirements", story['reporting_requirements'])
    add_label_block(doc, "Export Requirements", story['export_requirements'])
    add_label_block(doc, "Validation Rules", story['validation_rules'])
    add_label_block(doc, "Error States", story['error_states'])
    add_label_block(doc, "Empty States", story['empty_states'])
    add_label_block(doc, "Edge Cases", story['edge_cases'])
    add_label_block(doc, "Audit Requirements", story['audit_requirements'])
    p = doc.add_paragraph(); r = p.add_run("Acceptance Criteria (Given / When / Then)"); r.bold = True
    add_gwt_table(doc, story['acceptance_criteria'])
    add_label_block(doc, "Dependencies", story['dependencies'])
    add_label_block(doc, "Assumptions", story['assumptions'])
    add_label_block(doc, "Open Questions", story['open_questions'])
    add_label_block(doc, "Future Enhancements", story['future_enhancements'])
    doc.add_paragraph()

def add_epic(doc, epic):
    doc.add_page_break()
    doc.add_heading(f"EPIC {epic['id']}: {epic['title']}", level=1)
    if epic.get('screenshot'):
        doc.add_picture(SHOT(epic['screenshot']), width=Inches(6.3))
        last_p = doc.paragraphs[-1]
        last_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        cap = doc.add_paragraph(epic.get('screenshot_caption', ''))
        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for r in cap.runs:
            r.italic = True
            r.font.size = Pt(9)
    add_label_block(doc, "Epic Overview", epic['overview'])
    add_label_block(doc, "Business Problem", epic['business_problem'])
    add_label_block(doc, "User Value", epic['user_value'])
    add_label_block(doc, "Business Outcomes", epic['business_outcomes'])
    add_label_block(doc, "Success Metrics", epic['success_metrics'])
    doc.add_paragraph()
    for story in epic['stories']:
        add_story(doc, story)

# ---------------------------------------------------------------------------
# EPIC 1: CAMPAIGN DISCOVERY
# ---------------------------------------------------------------------------
EPIC_1 = dict(
  id=1, title="CAMPAIGN DISCOVERY",
  screenshot="02-list-full.png",
  screenshot_caption="Reference wireframe: Campaign List screen (low-fidelity, structure and states only).",
  overview=(
    "Epic 1 delivers the single, permission-scoped entry point through which any authorized "
    "user locates a campaign, understands its current status, and moves into either its full "
    "measurement report or the cross-campaign comparison view. It is the front door to the "
    "entire Retail Media reporting product."
  ),
  business_problem=[
    "Retail Media Managers and Advertiser users currently have no self-service way to see which "
    "campaigns they are entitled to view or whether a result is ready, in progress, or blocked.",
    "Status visibility today depends on ad-hoc communication with an analyst or account team, "
    "creating response-time friction and duplicated status-check requests.",
    "Without a consistent, permission-aware list, entitlement logic is enforced inconsistently "
    "across channels (email, shared spreadsheets, verbal updates), creating data-governance risk.",
  ],
  user_value=[
    "Users see, in one place, every campaign they are entitled to see, with no manual requests required.",
    "Users can distinguish 'ready to review' from 'still being calculated' from 'blocked' without opening a report.",
    "Users reach the full report or the comparison view in a single click from the point of discovery.",
  ],
  business_outcomes=[
    "Reduced analyst and account-team time spent answering 'is my report ready' requests.",
    "Consistent, centrally enforced entitlement logic across all campaign visibility surfaces.",
    "A scalable foundation that supports onboarding additional retailers and advertisers without "
    "incremental manual status-reporting overhead.",
    "Faster time-to-insight, which is a leading driver of retail media platform renewal and expansion.",
  ],
  success_metrics=[
    "Median time from campaign result availability to first user view of the report, trending down release over release.",
    "Percentage reduction in manual status-check support tickets within two quarters of launch.",
    "Percentage of sessions where a user reaches a report or comparison view without leaving the Campaign List.",
    "Zero confirmed entitlement-leak incidents (a user viewing a campaign outside their permitted scope).",
  ],
  stories=[
    dict(
      id="1.1", title="View Campaigns",
      business_objective=(
        "Give every authorized user a single, reliable list of all campaigns within their "
        "permitted scope, so that campaign discovery never depends on a manual request."
      ),
      user_story=(
        "As a Retail Media Manager or Advertiser user, I want a list of every campaign I am "
        "authorized to see, so that I can locate a specific campaign and gauge its status without "
        "contacting an analyst."
      ),
      business_context=[
        "This story is the baseline entitlement-aware inventory of campaigns; all other discovery "
        "and comparison capabilities (Stories 1.2, 1.3, 4.1\u20134.3) are built on top of it.",
        "The campaign list is retailer- and advertiser-scoped: a given user's list composition "
        "must reflect only the retailer/advertiser relationships they are entitled to, not a "
        "global view of all campaigns in the platform.",
      ],
      functional_requirements=[
        "The system shall render one row per campaign the authenticated user is entitled to view.",
        "The platform shall display, per campaign: advertiser name, campaign name, campaign period, "
        "campaign lifecycle status, and measurement/result status.",
        "The system shall allow navigation from any campaign row directly to that specific "
        "campaign's measurement report.",
        "The platform shall provide a persistent entry point from the list to the Campaign "
        "Comparison view (Epic 4).",
        "The system shall refresh status fields (lifecycle and measurement status) without "
        "requiring a full page reload when the underlying pipeline state changes.",
      ],
      business_rules=[
        "A campaign shall appear in a user's list if and only if the user holds an active "
        "entitlement to the campaign's advertiser-retailer combination.",
        "Campaigns shall be ordered with the viewing user's own organization's campaigns "
        "prioritized at the top of the list, followed by remaining entitled campaigns ordered by "
        "most recent campaign end date.",
        "Campaign lifecycle status (e.g., Running, Finished) shall be system-derived from campaign "
        "start/end dates and may not be manually overridden.",
        "Measurement/result status shall be system-derived from the Reporting Data State model "
        "(see Cross-Product Requirements, Section 2) and must never be manually overridden to "
        "mask a true data condition.",
      ],
      data_requirements=[
        "Campaign metadata: advertiser ID/name, retailer ID/name, campaign ID, campaign name, "
        "media channel, campaign start/end date, attribution window end date.",
        "Current Reporting Data State per campaign (see Cross-Product Section 2) to compute the "
        "displayed measurement status.",
        "User-to-advertiser/retailer entitlement mapping, resolved at request time (not cached "
        "beyond the session's permission TTL).",
      ],
      kpi_dependencies=[],
      permission_requirements=[
        "Only authenticated users with an active Report Viewer entitlement (or higher) for at "
        "least one advertiser/retailer combination may access this screen.",
        "A user with zero active entitlements shall see a permission-aware empty state, not an error.",
        "Entitlement checks shall be re-evaluated on every list load; cached entitlement data "
        "shall not exceed the organization's configured permission cache TTL (default: 15 minutes).",
      ],
      reporting_requirements=[
        "The list shall reflect the live Reporting Data State at load time; it must not display a "
        "stale cached status older than the platform's configured staleness threshold (default: 5 minutes).",
      ],
      export_requirements=[
        "Export of the list view itself is out of scope for this story; see Story 3.3 for result export.",
      ],
      validation_rules=[
        "The system shall validate that every rendered row corresponds to a campaign the "
        "requesting user is currently entitled to see; any row failing this check must be "
        "excluded, not greyed out.",
      ],
      error_states=[
        "If entitlement resolution fails (service unavailable), the system shall display a "
        "retryable error state and must not fall back to an unfiltered (unsafe) list.",
        "If campaign metadata is partially unavailable for a given row, the system shall render "
        "the available fields and flag the missing field rather than omitting the row.",
      ],
      empty_states=[
        "If the user has zero entitled campaigns, the system shall display an explanatory empty "
        "state describing how to request access, rather than a blank table.",
      ],
      edge_cases=[
        "A campaign whose advertiser/retailer entitlement is revoked mid-session shall be removed "
        "from the list on next refresh, and any open report tab for that campaign shall be "
        "access-checked on next interaction (see Story 3.2's re-check-on-open rule).",
        "A campaign with no media activity yet (pre-launch) shall appear with a clearly distinct "
        "pre-launch status rather than being hidden.",
      ],
      audit_requirements=[
        "The system shall log, at minimum, user ID, timestamp, and the resolved entitlement scope "
        "used to render the list, for a rolling retention period defined by the organization's "
        "audit policy (default: 13 months).",
      ],
      acceptance_criteria=[
        dict(given="a user holds an active entitlement for 3 advertiser/retailer combinations",
             when="the user opens the Campaign List",
             then="exactly the campaigns within those 3 combinations are shown, and no others"),
        dict(given="a user's entitlement is revoked for one advertiser while viewing the list",
             when="the user refreshes or reopens the list",
             then="campaigns under the revoked advertiser no longer appear"),
        dict(given="a user has zero active entitlements",
             when="the user opens the Campaign List",
             then="a permission-aware empty state with an access-request path is shown, not a blank table or a system error"),
      ],
      dependencies=["Cross-Product Section 1 (User Roles & Permissions)",
                    "Cross-Product Section 2 (Reporting Data State Management)"],
      assumptions=[
        "An entitlement service capable of resolving user-to-advertiser/retailer scope at request "
        "time already exists or will be delivered alongside this story.",
      ],
      open_questions=[
        "Should entitlement be modeled at advertiser level, retailer level, or the cross-product "
        "of both? The wireframe does not specify a permission model; this must be confirmed with "
        "Identity/Access Architecture before build.",
      ],
      future_enhancements=[
        "Saved views / pinned campaigns per user.",
        "Real-time (push-based) status updates instead of refresh-based.",
      ],
    ),
    dict(
      id="1.2", title="Filter and Search Campaigns",
      business_objective=(
        "Allow users with a large campaign portfolio to narrow the Campaign List to a relevant "
        "subset quickly, so that discovery time does not scale linearly with portfolio size."
      ),
      user_story=(
        "As a Retail Media Manager managing many campaigns, I want to filter and search the "
        "campaign list, so that I can find a specific campaign or group of campaigns in seconds."
      ),
      business_context=[
        "The source wireframe includes a 'Filters' affordance with no defined filter criteria or "
        "search field; this story closes that gap and defines the minimum viable filter/search "
        "contract required before Engineering can estimate it.",
        "As retailer and advertiser coverage grows, list size will grow materially; filtering is "
        "not optional polish but a scalability requirement.",
      ],
      functional_requirements=[
        "The system shall provide a free-text search across advertiser name, campaign name, and "
        "campaign ID.",
        "The platform shall provide structured filters for, at minimum: advertiser, retailer, "
        "media channel, campaign lifecycle status, and measurement/result status.",
        "The system shall support combining multiple filters and search simultaneously (logical AND "
        "across filter types, logical OR within a multi-select filter).",
        "The platform shall persist the user's last-used filter/search state for the duration of "
        "their session.",
        "The system shall display the count of matching campaigns and provide a one-click way to "
        "clear all active filters.",
      ],
      business_rules=[
        "Filter option values (e.g., the list of advertisers available to filter by) shall be "
        "scoped to the user's entitlements; a user must never be able to filter into a campaign "
        "outside their permitted scope.",
        "Search and filtering shall operate only over campaigns already resolved as entitled in "
        "Story 1.1 \u2014 filtering must not be used as a substitute for entitlement enforcement.",
      ],
      data_requirements=[
        "Indexable campaign attributes: advertiser, retailer, media channel, campaign lifecycle "
        "status, measurement/result status, campaign name, campaign ID.",
      ],
      kpi_dependencies=[],
      permission_requirements=[
        "Filter option lists shall be generated from the same entitlement-scoped data set used in "
        "Story 1.1, never from a global unfiltered source.",
      ],
      reporting_requirements=[
        "Filtered/searched results shall apply the same Reporting Data State freshness rules as "
        "Story 1.1.",
      ],
      export_requirements=[
        "If export is later added to the list view, it must export only the currently filtered "
        "result set, with the active filters stated in the export header.",
      ],
      validation_rules=[
        "The system shall treat an empty search string as 'no search filter applied', not as a "
        "zero-result query.",
      ],
      error_states=[
        "If filter metadata (e.g., the advertiser list) fails to load, the system shall disable the "
        "affected filter control with a visible explanation rather than silently omitting it.",
      ],
      empty_states=[
        "If a filter/search combination matches zero campaigns, the system shall present a "
        "'no matches' state with a one-click action to clear filters, distinct from the "
        "zero-entitlement empty state in Story 1.1.",
      ],
      edge_cases=[
        "A search term matching a campaign the user is not entitled to shall return zero results "
        "for that campaign, not a redacted/teaser row.",
        "Filtering by a status value that currently has zero matching campaigns shall still be "
        "selectable (not hidden), to avoid implying the status does not exist in the taxonomy.",
      ],
      audit_requirements=[
        "Search/filter usage does not require individual audit logging; aggregate, anonymized "
        "usage analytics are sufficient for product-analytics purposes.",
      ],
      acceptance_criteria=[
        dict(given="a user with 40 entitled campaigns filters by retailer and measurement status",
             when="both filters are applied",
             then="only campaigns matching both conditions are shown and the result count updates accordingly"),
        dict(given="a user searches for a campaign name that does not exist in their entitled set",
             when="the search executes",
             then="a 'no matches' empty state is shown, with no indication that a similarly named campaign exists outside the user's scope"),
      ],
      dependencies=["Story 1.1 (View Campaigns)"],
      assumptions=[
        "Filter/search is executed server-side against entitlement-scoped data, not client-side "
        "against an unfiltered payload.",
      ],
      open_questions=[
        "What is the full target list of filterable fields? The source wireframe shows only a "
        "'Filters' button with no defined criteria \u2014 required before UX or Engineering can scope this.",
        "Should filters be shareable via URL/deep link for collaboration between teammates?",
      ],
      future_enhancements=[
        "Saved filter presets per user or per team.",
        "Natural-language search (e.g., 'campaigns ending this month with issues').",
      ],
    ),
    dict(
      id="1.3", title="Campaign Status Tracking",
      business_objective=(
        "Give users an accurate, trustworthy, at-a-glance status for every campaign's lifecycle "
        "and measurement readiness, eliminating ambiguity about whether a number is final."
      ),
      user_story=(
        "As a Retail Media Manager or Advertiser user, I want to see a campaign's lifecycle and "
        "measurement status at a glance, so that I know whether I am looking at a final, "
        "in-progress, or blocked result before I open it."
      ),
      business_context=[
        "This story formalizes the status vocabulary implied by the wireframe's example rows "
        "(Running/Finished; Processing/Data issue/Result published/Partly suppressed) into the "
        "full Reporting Data State model defined in Cross-Product Section 2.",
        "Trustworthy status communication is foundational to the product's core promise: never "
        "present an uncertain number as if it were certain.",
      ],
      functional_requirements=[
        "The system shall display, per campaign, a lifecycle status derived from campaign "
        "start/end dates (e.g., Scheduled, Running, Finished).",
        "The platform shall display, per campaign, a measurement/result status derived from the "
        "Reporting Data State model (Draft, Processing, Awaiting Data, Partially Available, "
        "Published, Suppressed, Failed Validation, Archived).",
        "The system shall expose, on hover or expansion, a plain-language reason for any "
        "non-Published measurement status.",
        "The platform shall update displayed status automatically as the underlying pipeline "
        "state transitions, without requiring manual refresh by an operator.",
      ],
      business_rules=[
        "Measurement status shall never be set to Published unless every section required for "
        "publication (per Story 3.1's publishing workflow) has passed validation.",
        "A campaign with any Suppressed section shall surface an overall status of Suppressed or "
        "Partially Available at the list level, never Published, even if other sections are complete.",
        "Status values shall be drawn exclusively from the governed Reporting Data State taxonomy; "
        "free-text or ad-hoc status labels are not permitted.",
      ],
      data_requirements=[
        "Per-campaign, per-section Reporting Data State records, including state, reason code, "
        "responsible party, and expected resolution date where applicable.",
      ],
      kpi_dependencies=[],
      permission_requirements=[
        "Visibility of the underlying reason/diagnostic detail behind a non-Published status may "
        "be restricted to internal roles (Retail Media Manager, Data Operations) and withheld or "
        "simplified for Advertiser users, per the permission matrix in Cross-Product Section 1.",
      ],
      reporting_requirements=[
        "Status changes shall be reflected within the platform's configured staleness threshold "
        "(default: 5 minutes) of the underlying pipeline event.",
      ],
      export_requirements=["Not applicable to this story."],
      validation_rules=[
        "The system shall reject any attempt to set a campaign's measurement status directly "
        "(manual override); status must always be system-derived from underlying section states.",
      ],
      error_states=[
        "If status computation fails for a campaign, the system shall display an explicit "
        "'status unavailable' indicator rather than defaulting to a false Published or Ready state.",
      ],
      empty_states=["Not applicable \u2014 every campaign must have a resolvable status at all times."],
      edge_cases=[
        "A campaign that completes its media flight but has not yet entered its attribution "
        "window must show Processing, not Finished/Published.",
        "A campaign status changing from Published to Suppressed post-publication (e.g., a later "
        "privacy-threshold breach) must immediately update the list-level status and trigger the "
        "re-suppression workflow described in Cross-Product Section 2.",
      ],
      audit_requirements=[
        "Every status transition (including the before/after state, timestamp, and triggering "
        "system or user) shall be logged and retained per the organization's audit policy.",
      ],
      acceptance_criteria=[
        dict(given="a campaign's attribution window has not yet closed",
             when="a user views the Campaign List",
             then="the campaign's measurement status reads Processing, with a plain-language reason and expected resolution timing"),
        dict(given="a Published campaign's data later breaches a privacy suppression threshold",
             when="the breach is detected",
             then="the campaign's status automatically transitions to Suppressed and this transition is recorded in the audit log"),
      ],
      dependencies=["Cross-Product Section 2 (Reporting Data State Management)",
                    "Story 1.1 (View Campaigns)"],
      assumptions=[
        "A pipeline/orchestration layer exists (or will be delivered) capable of emitting "
        "section-level state change events that this story consumes.",
      ],
      open_questions=[
        "What is the authoritative source system for lifecycle status (campaign start/end) \u2014 "
        "the media planning system, the retailer feed, or a value entered in-platform?",
      ],
      future_enhancements=[
        "Proactive notifications when a campaign's status changes (see Cross-Product NFRs).",
        "SLA countdown indicators (e.g., 'expected in 3 days') rather than static text.",
      ],
    ),
  ],
)

EPICS = [EPIC_1]

# ---------------------------------------------------------------------------
# Reusable rule fragments (reduce duplication across Epic 2 stories)
# ---------------------------------------------------------------------------
SUPPRESSION_RULE = (
  "Any value, segment breakdown, or benchmark comparison representing fewer than the "
  "organization's configured minimum shopper threshold (default: 100 attributed shoppers, or a "
  "stricter retailer-specific minimum where one applies) shall be suppressed and replaced with a "
  "Suppressed state indicator, to prevent re-identification of individual shoppers."
)
BENCHMARK_RULE = (
  "Benchmark comparisons (e.g., brand vs. category) shall only be computed and displayed when "
  "both the brand-level and category-level populations independently clear the suppression "
  "threshold; if either side is suppressed, the comparison as a whole shall be marked Suppressed "
  "rather than partially shown."
)
RETAILER_ADVERTISER_NOTE = (
  "Retailer-specific data-sharing agreements may restrict which of these KPIs may be disclosed "
  "to the advertiser; the platform shall support per-retailer KPI visibility configuration "
  "rather than a single global disclosure rule."
)
UNAVAILABLE_DATA_HANDLING = (
  "Where an upstream value required for this section is not yet available, the section shall "
  "render in the Awaiting Data or Partially Available state (Cross-Product Section 2) with a "
  "plain-language explanation; it must never render a zero, blank, or fabricated placeholder value."
)
SOURCE_RETAILER = (
  "Figures in this section are sourced from the retailer's loyalty/transaction data and are "
  "subject to the retailer's data-quality and reconciliation controls (KPI #48, TLOG "
  "Reconciliation Difference)."
)
SOURCE_MEDIA_PARTNER = (
  "Figures in this section are sourced from the media delivery partner and, unlike "
  "retailer-sourced figures, are not independently validated by the platform prior to display; "
  "this distinction shall be visibly disclosed next to the figures."
)

# ---------------------------------------------------------------------------
# EPIC 2: CAMPAIGN MEASUREMENT REPORTING
# ---------------------------------------------------------------------------
EPIC_2 = dict(
  id=2, title="CAMPAIGN MEASUREMENT REPORTING",
  screenshot="01-report-full.png",
  screenshot_caption="Reference wireframe: Campaign Report screen, all 14 sections (low-fidelity, structure and states only).",
  overview=(
    "Epic 2 is the core value proposition of the product: a single, trustworthy, section-by-"
    "section measurement report that explains what happened during a campaign, how confident the "
    "platform is in each number, and why any given figure may not yet be available. It spans "
    "campaign facts, audience definitions, delivery, conversion, business outcomes, repeat "
    "purchase, channel and shopper-profile performance, attribution, incrementality, and a "
    "human-authored conclusion."
  ),
  business_problem=[
    "Advertisers and Retail Media Managers currently receive campaign results through "
    "inconsistent, manually assembled reports (spreadsheets, slide decks) with no standard "
    "definition of what 'done' or 'reliable' means for a given number.",
    "Without a uniform confidence/readiness model, stakeholders cannot tell whether a KPI is "
    "final, still being computed, blocked by missing data, or structurally not yet supported.",
    "KPI calculation logic today lives in disparate analyst workbooks rather than a governed, "
    "versioned catalog, creating inconsistency risk across campaigns and reporting periods.",
  ],
  user_value=[
    "A single place to understand what happened in a campaign, phrased in business language, "
    "backed by a governed KPI catalog.",
    "Clear, consistent signaling of whether a number is final, in progress, or blocked \u2014 removing "
    "the guesswork of 'can I trust this'.",
    "Benchmarked context (brand vs. category) wherever population size allows, without ever "
    "exposing re-identifiable small-sample data.",
  ],
  business_outcomes=[
    "Reduced manual analyst effort assembling campaign readouts.",
    "A consistent, governed KPI definition set usable across all retailers and advertisers, "
    "reducing dispute risk over 'whose number is right'.",
    "Privacy-by-design suppression logic reduces regulatory and reputational risk tied to "
    "small-sample shopper data exposure.",
    "A foundation that scales to additional KPIs and measurement methods (e.g., incrementality) "
    "without re-architecting the report.",
  ],
  success_metrics=[
    "Percentage of report sections reaching Published state within the organization's target SLA "
    "after campaign end.",
    "Reduction in analyst hours spent manually assembling campaign readouts.",
    "Number of KPI definition disputes/escalations per quarter, trending to zero.",
    "Percentage of benchmarked comparisons successfully computed (not suppressed) across all "
    "published campaigns.",
  ],
  stories=[
    dict(
      id="2.1", title="Campaign Overview",
      business_objective=(
        "Give every report viewer a single, unambiguous summary of what the campaign was and how "
        "it was measured, before they look at any performance number."
      ),
      user_story=(
        "As a report viewer, I want to see the campaign's core facts and measurement method up "
        "front, so that I understand what I am about to read before I see any numbers."
      ),
      business_context=[
        "Maps to wireframe report Section 1 (Campaign overview) and Section 4 (How this was "
        "measured), combined here because both are prerequisite context rather than performance data.",
        "This section sets reader expectations and must be the first section rendered in every "
        "report, regardless of data state elsewhere in the report.",
      ],
      functional_requirements=[
        "The system shall display, at minimum: report type, campaign type, objective, campaign "
        "period, attribution window, measurement period, redirection link, targeting basis, and "
        "campaign ID.",
        "The platform shall display a plain-language, three-step explanation of the measurement "
        "method (audience building, exposable group, sales measurement) and its stated limits.",
        "The system shall disclose the data source (retailer loyalty data) for these facts "
        "directly alongside them.",
        "The platform shall render this section even when every other report section is in a "
        "non-Published state, since it contains no performance KPIs subject to suppression.",
      ],
      business_rules=[
        "Campaign facts displayed here shall be treated as immutable once the campaign is "
        "Published; any correction after publication must go through the republishing workflow "
        "defined in Story 3.1, not a silent edit.",
        "The measurement-method explanation text shall be centrally governed (not editable "
        "per-campaign) so that all campaigns using the same method describe it identically.",
      ],
      data_requirements=[
        "Campaign metadata fields listed in Functional Requirements above.",
        "A centrally maintained, versioned library of measurement-method descriptions, keyed by "
        "method type, so the correct explanation renders for each campaign's actual method.",
      ],
      kpi_dependencies=[2, 5],
      permission_requirements=[
        "Visible to any user entitled to view the campaign (Report Viewer role or higher); no "
        "additional restriction beyond campaign-level entitlement applies to this section.",
      ],
      reporting_requirements=[
        "This section's data state is independent of other sections' states and shall never show "
        "as Awaiting Data solely because performance sections are incomplete.",
      ],
      export_requirements=[
        "Included by default in any export or share of the report (Stories 3.2, 3.3).",
      ],
      validation_rules=[
        "The system shall validate that attribution window and measurement period are logically "
        "consistent with campaign start/end dates before allowing the report to progress past Draft.",
      ],
      error_states=[
        "If a required campaign fact is missing, the system shall display the fact as "
        "'Not provided' with a flag for Data Operations follow-up, rather than omitting the field silently.",
      ],
      empty_states=["Not applicable \u2014 this section is mandatory and always rendered."],
      edge_cases=[
        "A campaign spanning multiple media channels must list all channels, not only the first.",
        "A campaign using a non-standard or hybrid measurement method must map to the closest "
        "governed method description and flag the deviation for Data Science review.",
      ],
      audit_requirements=[
        "Any post-publication correction to campaign facts shall be logged with before/after "
        "values, the responsible user, and the republishing event it was part of.",
      ],
      acceptance_criteria=[
        dict(given="a user opens any campaign report",
             when="the report loads",
             then="the Campaign Overview section renders first, with all nine core facts and the measurement-method explanation, regardless of the state of later sections"),
        dict(given="a campaign fact (e.g., redirection link) is missing upstream",
             when="the report renders",
             then="the field shows 'Not provided' and a Data Operations follow-up flag is created, rather than the field disappearing"),
      ],
      dependencies=["Cross-Product Section 2 (Reporting Data State Management)"],
      assumptions=["Campaign metadata is sourced from an upstream campaign/media-planning system of record."],
      open_questions=[
        "Who owns and versions the governed measurement-method description library \u2014 Data "
        "Science or Product?",
      ],
      future_enhancements=["Inline links from each fact to a glossary definition."],
    ),
    dict(
      id="2.2", title="Audience Definitions",
      business_objective=(
        "Make the campaign's audience segmentation logic fully transparent and mutually "
        "exclusive, so that every downstream segment-level number can be trusted not to double-count shoppers."
      ),
      user_story=(
        "As a report viewer, I want to see exactly how the campaign's shopper segments are "
        "defined and that they don't overlap, so that I can trust segment-level numbers later in the report."
      ),
      business_context=[
        "Maps to wireframe report Section 2 (Audience definitions): four mutually exclusive "
        "segments, each with an 'excluding...' qualifier except the first, plus an explanatory hint.",
        "This section is the contract that all later segment-based breakdowns (2.4, 2.5, 2.8) "
        "depend on; if segment definitions are ambiguous, every downstream KPI breakdown is suspect.",
      ],
      functional_requirements=[
        "The system shall display each audience segment's definition as a numbered, ordered list, "
        "making the exclusion/precedence order explicit.",
        "The platform shall display, for each segment after the first, the specific prior "
        "segment(s) it excludes.",
        "The system shall display a hint explaining that the segmentation is mutually exclusive by "
        "construction (a shopper belongs to exactly one segment).",
      ],
      business_rules=[
        "Segment definitions shall be evaluated in a fixed, documented precedence order; changing "
        "that order changes segment membership and must be versioned, not silently altered.",
        "The union of all segments shall always equal the full Exposable Audience (KPI #9); the "
        "platform shall validate this invariant before publishing any segment-based section.",
      ],
      data_requirements=[
        "Segment definition rules (precedence order, exclusion logic) per campaign, stored in a "
        "versioned configuration rather than embedded in report-rendering code.",
        "Exposable Audience population data to validate the mutual-exclusivity invariant.",
      ],
      kpi_dependencies=[9, 12],
      permission_requirements=[
        "Visible to any user entitled to view the campaign; segment definitions themselves are "
        "not considered sensitive and are not subject to the suppression threshold (only "
        "populated segment counts are).",
      ],
      reporting_requirements=[UNAVAILABLE_DATA_HANDLING],
      export_requirements=["Included by default in any export or share of the report."],
      validation_rules=[
        "The system shall reject publication of this section if the mutual-exclusivity invariant "
        "(segments sum to total Exposable Audience) fails validation.",
      ],
      error_states=[
        "If the invariant check fails, the system shall mark this section Failed Validation and "
        "surface the discrepancy to Data Operations rather than publishing an inconsistent segmentation.",
      ],
      empty_states=[
        "If a campaign defines fewer than the standard four segments, the system shall render "
        "only the defined segments rather than placeholder rows for undefined ones.",
      ],
      edge_cases=[
        "A shopper qualifying for multiple segment definitions simultaneously must be resolved to "
        "exactly one segment per the documented precedence order \u2014 this resolution logic must be "
        "deterministic and reproducible on recomputation.",
      ],
      audit_requirements=[
        "Any change to segment precedence/exclusion logic for a campaign shall be logged with the "
        "prior and new logic, the responsible user, and effective date.",
      ],
      acceptance_criteria=[
        dict(given="a campaign defines four mutually exclusive audience segments",
             when="the Audience Definitions section is published",
             then="the sum of all segment populations equals the total Exposable Audience, with no overlap or gap"),
        dict(given="the mutual-exclusivity invariant fails during validation",
             when="an operator attempts to publish the report",
             then="publication is blocked, the section is marked Failed Validation, and Data Operations is notified"),
      ],
      dependencies=["Story 2.1 (Campaign Overview)"],
      assumptions=["A standard four-segment taxonomy is the default; some campaigns may define fewer."],
      open_questions=[
        "Should segment definitions be fully custom per campaign, or drawn from a shared, "
        "retailer-level segment template library?",
      ],
      future_enhancements=["Visual Venn-style confirmation of mutual exclusivity for internal QA users."],
    ),
    dict(
      id="2.3", title="Campaign Delivery Performance",
      business_objective=(
        "Show how the campaign's media actually delivered against plan, clearly distinguishing "
        "media-partner-sourced figures from retailer-validated figures."
      ),
      user_story=(
        "As a report viewer, I want to see how many impressions, clicks, and reach the campaign "
        "delivered compared to plan, so that I can judge whether the media ran as expected."
      ),
      business_context=[
        "Maps to wireframe report Section 3 (Campaign delivery): a 2-row readout (Impressions, "
        "CPM) plus a 4-card KPI row (Impressions, CPM, Reach, Clicks), with an explicit hint that "
        "these figures are unvalidated media-partner data.",
      ],
      functional_requirements=[
        "The system shall display delivered Impressions, CPM, Reach, and Clicks as primary KPI cards.",
        "The platform shall display planned-vs-actual comparisons (Impression Delivery Multiplier, "
        "CPM Efficiency Ratio) wherever planning data is available.",
        "The system shall visibly flag that these figures originate from the media delivery "
        "partner and have not been independently validated by the platform.",
      ],
      business_rules=[
        SOURCE_MEDIA_PARTNER,
        "Planned-vs-actual comparisons shall only render when both planned (campaign_plan_budget) "
        "and actual figures exist; absence of planning data shall not block display of actual delivery figures.",
      ],
      data_requirements=[
        "Media delivery feed: impressions, clicks, reach, CPM, spend, at campaign (and ideally "
        "channel) granularity.",
        "Campaign plan/budget data (planned impressions, planned CPM) where available.",
      ],
      kpi_dependencies=[1, 2, 3, 4, 5, 6, 7, 8, 28, 29, 30],
      permission_requirements=[
        "Visible to any user entitled to view the campaign; no additional restriction, since these "
        "are aggregate media metrics, not shopper-level data.",
      ],
      reporting_requirements=[UNAVAILABLE_DATA_HANDLING],
      export_requirements=["Included by default in any export or share of the report."],
      validation_rules=[
        "The system shall flag (not block) delivery figures that fall outside a configurable "
        "sanity-check range (e.g., CTR implausibly high) for Data Operations review prior to publication.",
      ],
      error_states=[
        "If the media delivery feed is late or incomplete for the reporting period, the section "
        "shall render in Awaiting Data state with the specific missing feed identified.",
      ],
      empty_states=[
        "If no planning data exists for the campaign, planned-vs-actual comparison rows shall be "
        "omitted rather than shown as zero or blank.",
      ],
      edge_cases=[
        "A campaign spanning multiple media partners must aggregate figures consistently and "
        "disclose per-partner sourcing if definitions differ (e.g., viewability standards).",
        "Negative or corrected delivery figures (partner-side makegoods/corrections) must be "
        "reflected via a versioned update, not silently overwritten without an audit trail.",
      ],
      audit_requirements=[
        "Any correction to delivery figures after initial publication shall be logged with the "
        "prior value, new value, source feed, and timestamp.",
      ],
      acceptance_criteria=[
        dict(given="the media delivery feed has not yet arrived for the reporting period",
             when="a user opens the report",
             then="the Campaign Delivery Performance section shows Awaiting Data with the missing feed identified, not a zero or blank KPI"),
        dict(given="both planned and actual impressions exist for a campaign",
             when="the section renders",
             then="the Impression Delivery Multiplier is computed and displayed alongside the raw actual and planned figures"),
      ],
      dependencies=["Story 2.1 (Campaign Overview)"],
      assumptions=["A media delivery feed and (optionally) a campaign plan/budget feed exist as upstream inputs."],
      open_questions=[
        "Which party is accountable for reconciling media-partner-reported figures against "
        "platform expectations \u2014 is any validation planned beyond passive sanity-check flags?",
      ],
      future_enhancements=["Channel-level delivery breakdown within this section."],
    ),
    dict(
      id="2.4", title="Conversion Performance",
      business_objective=(
        "Quantify how effectively the exposed audience converted into purchasing shoppers, "
        "overall and by audience segment, so stakeholders can see where conversion was strongest."
      ),
      user_story=(
        "As a report viewer, I want to see what share of the audience the campaign reached "
        "actually bought, overall and by segment, so that I can judge how effective the targeting was."
      ),
      business_context=[
        "Maps to wireframe report Section 5 (Conversion overview: total-only data table, a "
        "proportion card exposable-group \u2192 purchasing shoppers, and a readout) and Section 6 "
        "(Conversion by segment: readout plus a 4-segment data table).",
      ],
      functional_requirements=[
        "The system shall display overall Conversion Rate as a proportion (exposable audience to "
        "attributed shoppers) and as a headline percentage.",
        "The platform shall display a per-segment breakdown of Shoppers, Shopper Share, and "
        "Conversion Rate for each of the segments defined in Story 2.2.",
        "The system shall display each segment's Conversion-Rate Difference versus the overall "
        "campaign conversion rate.",
      ],
      business_rules=[
        SUPPRESSION_RULE,
        "Per-segment rows shall only display once the segment's population independently clears "
        "the suppression threshold; segments below threshold shall be grouped into an "
        "'Other (suppressed)' row rather than omitted without explanation.",
        "Conversion-Rate Difference shall always be computed against the same overall rate shown "
        "in this section, never against a rate computed from a different population cut.",
      ],
      data_requirements=[
        "Exposable Audience and attributed-shopper counts, overall and per segment.",
        "Segment definitions from Story 2.2.",
      ],
      kpi_dependencies=[9, 10, 11, 12, 13],
      permission_requirements=[
        "Visible to any user entitled to view the campaign, subject to the suppression rule above.",
      ],
      reporting_requirements=[UNAVAILABLE_DATA_HANDLING],
      export_requirements=["Included by default; suppressed rows must remain suppressed in exported copies."],
      validation_rules=[
        "The system shall validate that per-segment shopper counts sum to the overall attributed "
        "shopper count before publishing this section.",
      ],
      error_states=[
        "If segment-level attribution data is unavailable while overall figures exist, this "
        "section shall render in Partially Available state (overall shown, segment breakdown Awaiting Data).",
      ],
      empty_states=[
        "If zero shoppers converted, the system shall explicitly state a 0% conversion rate with "
        "supporting context, rather than omitting the section.",
      ],
      edge_cases=[
        "A segment with a non-zero but suppressed population must still be included in the "
        "overall conversion-rate denominator even though its own row is suppressed.",
      ],
      audit_requirements=[
        "Suppression decisions (which rows were suppressed and why) shall be logged at "
        "publication time for governance review.",
      ],
      acceptance_criteria=[
        dict(given="a segment has fewer than 100 attributed shoppers",
             when="the Conversion by Segment table renders",
             then="that segment's row is grouped into 'Other (suppressed)' rather than shown individually, while still counting toward the overall conversion rate"),
        dict(given="segment-level attribution data has not yet landed",
             when="overall conversion data is available",
             then="the section shows Partially Available, with the overall rate shown and the segment table marked Awaiting Data"),
      ],
      dependencies=["Story 2.2 (Audience Definitions)"],
      assumptions=["Attribution linking (purchase-to-exposure matching) occurs upstream of this section."],
      open_questions=[
        "What is the organization's final minimum suppression threshold \u2014 100 shoppers is a "
        "proposed default pending Privacy/Legal confirmation.",
      ],
      future_enhancements=["Trend-over-time conversion rate within a single campaign's lifecycle."],
    ),
    dict(
      id="2.5", title="Business Outcomes",
      business_objective=(
        "Translate conversion into concrete business value \u2014 revenue, transactions, margin \u2014 "
        "overall and by audience segment, so stakeholders can see where value was created."
      ),
      user_story=(
        "As a report viewer, I want to see the revenue, basket size, and transaction patterns the "
        "campaign drove, by segment, so that I can judge the campaign's commercial impact."
      ),
      business_context=[
        "Maps to wireframe report Section 7 (Business equation by audience): a readout plus an "
        "8-numeric-column data table across the four audience segments and a total row.",
      ],
      functional_requirements=[
        "The system shall display, per segment and in total: Revenue, Transactions, Revenue per "
        "Shopper, Purchase Frequency, Average Basket Value, Items per Basket, Average Price per "
        "Product, and Attributed Units.",
        "The platform shall display Attributed Margin where the organization's finance data "
        "sharing agreement permits margin disclosure.",
      ],
      business_rules=[
        SUPPRESSION_RULE,
        "Average/ratio KPIs (e.g., Average Basket Value) shall never be computed from a suppressed "
        "or below-threshold segment's underlying counts, even if the ratio itself looks innocuous.",
        RETAILER_ADVERTISER_NOTE,
      ],
      data_requirements=[
        "Attributed transaction-level detail: revenue, units, margin (where permitted), per "
        "segment and overall.",
      ],
      kpi_dependencies=[14, 15, 16, 17, 18, 19, 20, 31, 32],
      permission_requirements=[
        "Attributed Margin visibility shall be gated by a distinct, finance-sensitive permission "
        "separate from general Report Viewer access, since margin is commercially sensitive to the retailer.",
      ],
      reporting_requirements=[UNAVAILABLE_DATA_HANDLING],
      export_requirements=[
        "Margin figures shall be excluded from exports/shares to any recipient lacking the "
        "finance-sensitive permission, even if they can view margin in-app.",
      ],
      validation_rules=[
        "The system shall validate that per-segment revenue and transactions sum to the "
        "corresponding total row before publication.",
      ],
      error_states=[
        "If margin data is unavailable or the data-sharing agreement is undetermined, the Margin "
        "column shall be omitted entirely rather than shown as zero or 'N/A' in a way that implies zero margin.",
      ],
      empty_states=["If a segment has zero attributed transactions, its row shall show explicit zeros, not blank cells."],
      edge_cases=[
        "Returns/refunds occurring within the measurement period must be netted consistently "
        "across Revenue, Transactions, and derived ratios \u2014 the netting rule must be documented and applied uniformly.",
      ],
      audit_requirements=[
        "Access to margin figures (view, export, share) shall be individually logged given their "
        "commercial sensitivity.",
      ],
      acceptance_criteria=[
        dict(given="a user lacks the finance-sensitive margin permission",
             when="they view or export this section",
             then="the Attributed Margin column is absent entirely, not shown redacted or as zero"),
        dict(given="a return is processed within the measurement period",
             when="Business Outcomes figures are computed",
             then="Revenue, Transactions, and all derived ratios reflect the net (post-return) position consistently"),
      ],
      dependencies=["Story 2.4 (Conversion Performance)"],
      assumptions=["Margin data, where available, flows from a retailer finance system with its own access controls."],
      open_questions=[
        "Which retailers currently permit margin disclosure to advertisers, and under what "
        "contractual terms? This determines default visibility per retailer.",
      ],
      future_enhancements=["Product-category breakdown within Business Outcomes."],
    ),
    dict(
      id="2.6", title="Repeat Purchase Analysis",
      business_objective=(
        "Show how many of the campaign's purchasing shoppers came back to buy again, as an early "
        "signal of loyalty impact beyond the first purchase."
      ),
      user_story=(
        "As a report viewer, I want to see how many purchasing shoppers bought again, so that I "
        "can judge whether the campaign built repeat buying, not just a single transaction."
      ),
      business_context=[
        "Maps to wireframe report Section 8 (Repeat purchase): a readout plus a proportion card "
        "(purchasing shoppers \u2192 repeat shoppers).",
      ],
      functional_requirements=[
        "The system shall display Loyal Shoppers (count) and Loyal Shopper Rate (percentage of "
        "attributed shoppers with 2+ transactions).",
        "The platform shall display this as a proportion (purchasing shoppers to repeat shoppers) "
        "for intuitive visual framing.",
      ],
      business_rules=[
        SUPPRESSION_RULE,
        "The measurement window for 'repeat' shall be fixed to the campaign's defined measurement "
        "period and shall not silently extend beyond it; any proposal to extend the repeat-purchase "
        "window must be a distinct, explicitly labeled metric.",
      ],
      data_requirements=["Attributed transaction counts per shopper within the measurement period."],
      kpi_dependencies=[21, 22],
      permission_requirements=["Visible to any user entitled to view the campaign, subject to the suppression rule."],
      reporting_requirements=[UNAVAILABLE_DATA_HANDLING],
      export_requirements=["Included by default in any export or share of the report."],
      validation_rules=["The system shall validate Loyal Shoppers never exceeds total attributed Shoppers for the same population."],
      error_states=["If attributed shopper counts are unavailable, this section shall inherit Story 2.4's data state rather than compute independently from incomplete inputs."],
      empty_states=["If zero shoppers repeat-purchased, the system shall state a 0% rate explicitly rather than omitting the section."],
      edge_cases=[
        "A shopper with two transactions on the same day/same basket split across receipts must "
        "be counted once per the organization's transaction-deduplication rule, not double-counted as 'repeat'.",
      ],
      audit_requirements=["Standard section-level audit logging per Cross-Product Section 4."],
      acceptance_criteria=[
        dict(given="an attributed shopper has two separate attributed transactions in the measurement period",
             when="Repeat Purchase figures are computed",
             then="that shopper is counted once within Loyal Shoppers, and the Loyal Shopper Rate reflects it correctly against total attributed Shoppers"),
      ],
      dependencies=["Story 2.4 (Conversion Performance)"],
      assumptions=["The transaction-deduplication rule used elsewhere in the platform (e.g., for Transactions, KPI #15) applies identically here."],
      open_questions=["Should the repeat-purchase window ever extend beyond the campaign's defined measurement period for a 'longer-term loyalty' variant metric?"],
      future_enhancements=["Repeat-purchase trend by week within the measurement period."],
    ),
    dict(
      id="2.7", title="Channel Performance",
      business_objective=(
        "Show how attributed sales split across retailer sales channels (e.g., e-commerce vs. "
        "in-store), distinct from the campaign's media channel, and benchmark that split against the category."
      ),
      user_story=(
        "As a report viewer, I want to see how much of the campaign's sales happened online "
        "versus in-store, compared to the category, so that I understand where the impact landed."
      ),
      business_context=[
        "Maps to wireframe report Section 9 (Performance by retailer channel): a readout, a KPI "
        "card (e-commerce revenue share), and a 3-channel-plus-total data table, with an explicit "
        "hint distinguishing retailer sales channel from campaign media channel.",
      ],
      functional_requirements=[
        "The system shall display E-commerce Revenue Share and its breakdown across retailer "
        "sales channels (e.g., e-commerce, in-store, other).",
        "The platform shall display E-commerce Revenue Share Difference vs. Category as a "
        "benchmark comparison.",
        "The system shall visibly disambiguate 'retailer sales channel' (this section) from "
        "'campaign media channel' (Story 2.3) to prevent reader confusion.",
      ],
      business_rules=[BENCHMARK_RULE, SUPPRESSION_RULE],
      data_requirements=[
        "Attributed sales broken out by retailer sales channel.",
        "Category-level channel-share benchmark data at the same retailer and time period.",
      ],
      kpi_dependencies=[23, 24, 38, 39, 40],
      permission_requirements=["Visible to any user entitled to view the campaign, subject to the suppression and benchmark rules."],
      reporting_requirements=[UNAVAILABLE_DATA_HANDLING],
      export_requirements=["Included by default in any export or share of the report."],
      validation_rules=["The system shall validate that channel-level sales shares sum to 100% of attributed sales before publication."],
      error_states=["If category benchmark data is unavailable, the brand-level channel figures shall still render, with the benchmark comparison shown as Awaiting Data rather than blocking the whole section."],
      empty_states=["If a retailer channel has zero attributed sales, its row shall show an explicit zero rather than being omitted, to preserve the channel mix picture."],
      edge_cases=[
        "A retailer offering channels beyond the standard e-commerce/in-store split (e.g., "
        "ship-from-store, curbside) must be configurable per retailer without requiring a code change.",
      ],
      audit_requirements=["Standard section-level audit logging per Cross-Product Section 4."],
      acceptance_criteria=[
        dict(given="category benchmark data for channel share is unavailable",
             when="a user views this section",
             then="brand-level channel figures render normally while the benchmark comparison shows Awaiting Data"),
      ],
      dependencies=["Story 2.3 (Campaign Delivery Performance)", "Story 2.5 (Business Outcomes)"],
      assumptions=["Category benchmark data is sourced from the same retailer's broader category sales data, refreshed on a defined cadence."],
      open_questions=["What is the refresh cadence and lag for category benchmark data, and does it match the campaign's own reporting cadence?"],
      future_enhancements=["Channel performance trend over the campaign's measurement period."],
    ),
    dict(
      id="2.8", title="Shopper Profile Analysis",
      business_objective=(
        "Show which kinds of shoppers (by lifestage and consumption style) bought the brand "
        "during the campaign, benchmarked against the category, to inform future targeting."
      ),
      user_story=(
        "As a report viewer, I want to see the lifestage and shopping-style profile of buyers "
        "during the campaign, compared to the category, so that I can refine future targeting."
      ),
      business_context=[
        "Maps to wireframe report Section 10 (Shopper profile \u2014 lifestage) and Section 11 "
        "(Shopper profile \u2014 consumption style): paired stacked-bar charts, brand vs. category, "
        "five segments each. Section 11 is shown as a Not-Ready ('insufficient') state in the "
        "source wireframe's default data scenario.",
      ],
      functional_requirements=[
        "The system shall display a paired stacked-bar comparison of brand buyers vs. category "
        "buyers across five lifestage segments.",
        "The platform shall display the same paired comparison across five consumption-style segments.",
        "The system shall display, per segment, the Buyer Share Difference vs. Category.",
      ],
      business_rules=[BENCHMARK_RULE, SUPPRESSION_RULE],
      data_requirements=[
        "Brand buyer counts by lifestage and consumption-style profile dimension.",
        "Category buyer counts by the same profile dimensions, at the same retailer and period.",
      ],
      kpi_dependencies=[25, 26, 27],
      permission_requirements=["Visible to any user entitled to view the campaign, subject to the suppression and benchmark rules."],
      reporting_requirements=[
        UNAVAILABLE_DATA_HANDLING,
        "Where a required shopper-profile dimension is not yet available for a given retailer "
        "(e.g., consumption-style data not yet onboarded), the sub-section shall render in "
        "Awaiting Data state with the specific missing data source named, consistent with the "
        "wireframe's existing 'insufficient' example.",
      ],
      export_requirements=["Included by default where available; sub-sections in Awaiting Data state shall be clearly marked as such in exports, not silently dropped."],
      validation_rules=["The system shall validate that profile-segment shares sum to 100% of brand buyers (and, separately, of category buyers) before publication."],
      error_states=["If category profile data is unavailable for a retailer, the comparison shall show Awaiting Data rather than a one-sided (brand-only) chart presented as if it were a comparison."],
      empty_states=["Not applicable beyond the Awaiting Data state above."],
      edge_cases=[
        "A retailer that does not license consumption-style data at all (structurally, not "
        "temporarily) must show a distinct 'Not Available for this Retailer' message, separate "
        "from a temporary Awaiting Data condition \u2014 these are different situations and must not "
        "share the same message.",
      ],
      audit_requirements=["Standard section-level audit logging per Cross-Product Section 4."],
      acceptance_criteria=[
        dict(given="a retailer has not licensed consumption-style profile data",
             when="a user views the Shopper Profile Analysis section",
             then="the consumption-style sub-section shows a distinct 'Not Available for this Retailer' message rather than being blank or showing a generic Awaiting Data message"),
      ],
      dependencies=["Story 2.5 (Business Outcomes)"],
      assumptions=["Shopper-profile dimensions (lifestage, consumption style) are sourced from retailer loyalty demographic/behavioral data, licensed per retailer."],
      open_questions=[
        "Which profile dimensions are licensed for which retailers today, and is there a "
        "roadmap to close current gaps (e.g., consumption style)?",
      ],
      future_enhancements=["Additional profile dimensions (e.g., household composition) as retailer data licensing expands."],
    ),
    dict(
      id="2.9", title="Attribution Measurement",
      business_objective=(
        "Show the attributed-result KPIs that quantify how purchases were linked to media "
        "exposure, including the diagnostic rates that back the credibility of that linkage."
      ),
      user_story=(
        "As a report viewer, I want to see the campaign's attributed results and understand how "
        "reliable the attribution linkage is, so that I can judge how much to trust the figures."
      ),
      business_context=[
        "Maps to wireframe report Section 12 (Attributed result): a 3-card KPI row explicitly "
        "marked 'illustrative, not real yet' and rendered as a Not-Ready ('unsupported') state in "
        "the source wireframe's default scenario.",
        "This story also incorporates the attribution diagnostic KPIs (#36\u2013#37, #45\u2013#47) that "
        "the wireframe does not surface but which Data Science requires to certify attribution quality.",
      ],
      functional_requirements=[
        "The system shall display Attributed ROAS, Cost per Attributed Shopper, and Cost per "
        "Attributed Transaction as the primary attributed-result KPI cards.",
        "The platform shall display Average and Median Time to Purchase as supporting context.",
        "The system shall expose, for internal roles only, the underlying diagnostic rates "
        "(Attribution Eligibility Rate, Attribution Link Creation Rate, Direct/Halo Classification "
        "Coverage) used to certify this section before publication.",
      ],
      business_rules=[
        "This section shall not transition out of Draft/Processing into Published until the "
        "diagnostic rates above meet the organization's governed minimum thresholds for "
        "attribution quality, to be defined jointly by Data Science and Governance.",
        SUPPRESSION_RULE,
        "Any 'illustrative' or placeholder figure (as seen in the current wireframe) shall never "
        "be shown in a Published report; illustrative content is permitted only in internal "
        "pre-release review modes, visibly labeled as such.",
      ],
      data_requirements=[
        "Attribution link-level fact data, including winning media event, purchase event, and "
        "classification (direct/halo).",
        "Diagnostic pipeline counters feeding Attribution Eligibility Rate and Attribution Link "
        "Creation Rate (KPIs #45, #46).",
      ],
      kpi_dependencies=[33, 34, 35, 36, 37, 45, 46, 47],
      permission_requirements=[
        "Primary attributed-result KPIs are visible to any user entitled to view the campaign.",
        "Underlying diagnostic/certification rates are visible only to internal roles (Retail "
        "Media Manager, Measurement & Data Science); Advertiser users shall not see raw "
        "diagnostic rates, only the resulting certified status.",
      ],
      reporting_requirements=[UNAVAILABLE_DATA_HANDLING],
      export_requirements=["Diagnostic/certification detail shall never be included in advertiser-facing exports or shares."],
      validation_rules=[
        "The system shall block publication of this section if any governed diagnostic threshold "
        "is not met, marking the section Failed Validation with the specific failing metric named internally.",
      ],
      error_states=["If attribution linkage has not yet completed processing, this section shall show Processing, not an illustrative placeholder."],
      empty_states=["Not applicable \u2014 if attribution has run, results exist; if it has not, the section shows Processing or Awaiting Data."],
      edge_cases=[
        "A campaign using a non-standard attribution rule (e.g., a different media-partner "
        "integration) must still pass through the same governed diagnostic thresholds before publication.",
      ],
      audit_requirements=[
        "Every publish/block decision driven by diagnostic thresholds shall be logged with the "
        "specific threshold values and outcome, for Governance audit.",
      ],
      acceptance_criteria=[
        dict(given="the Attribution Link Creation Rate falls below the governed minimum threshold",
             when="an operator attempts to publish this section",
             then="publication is blocked, the section is marked Failed Validation, and the specific failing diagnostic is logged for internal review"),
        dict(given="an Advertiser user views a Published attribution section",
             when="they inspect the section detail",
             then="they see the certified KPI values but not the underlying diagnostic rates"),
      ],
      dependencies=["Cross-Product Section 3 (KPI Governance)"],
      assumptions=["Data Science will define concrete minimum thresholds for the diagnostic KPIs prior to general availability; none exist today."],
      open_questions=[
        "What are the exact minimum diagnostic thresholds required to certify attribution results "
        "as publishable? This is explicitly undefined in the current wireframe ('illustrative, not real yet').",
      ],
      future_enhancements=["Self-serve diagnostic drill-down for internal QA users."],
    ),
    dict(
      id="2.10", title="Incrementality Measurement",
      business_objective=(
        "Show the portion of business outcomes that the campaign caused, beyond what would have "
        "happened anyway, once a validated incrementality methodology is in place."
      ),
      user_story=(
        "As a report viewer, I want to see how much of the campaign's results were truly caused "
        "by the campaign (versus would have happened anyway), so that I can judge real causal impact."
      ),
      business_context=[
        "Maps to wireframe report Section 13 (Incremental impact): a 3-card KPI row, one showing "
        "a range, explicitly marked 'illustrative' and rendered as a Not-Ready ('unsupported') "
        "state in the current wireframe. No incrementality KPI currently exists in the governed "
        "KPI Catalog \u2014 this is a confirmed gap, not an oversight, and is carried forward here as "
        "an explicit open item rather than invented.",
      ],
      functional_requirements=[
        "The system shall reserve a dedicated report section for incrementality results, "
        "structurally ready to display an Incremental Sales (or Incremental Lift) KPI and a "
        "confidence range once the methodology and KPI Catalog entry are approved.",
        "The platform shall, until that methodology is approved, render this section in a "
        "distinct 'Not Yet Supported' state \u2014 different from Awaiting Data \u2014 that clearly "
        "communicates the capability is planned, not broken or delayed.",
      ],
      business_rules=[
        "No incrementality figure, range, or illustrative value shall ever be shown in a "
        "Published report until a corresponding KPI Catalog entry exists with an approved "
        "formula, data model, and Data Science sign-off.",
        "Once defined, incrementality figures shall be subject to the same suppression and "
        "benchmark rules as other KPIs in this document.",
      ],
      data_requirements=[
        "Not yet defined \u2014 pending methodology selection (e.g., geo-holdout, PSA/holdout panel, "
        "or model-based incrementality) by Measurement & Data Science.",
      ],
      kpi_dependencies=[],
      permission_requirements=[
        "Once available, visibility shall follow the same entitlement model as other sections; no "
        "distinct permission is anticipated today.",
      ],
      reporting_requirements=[
        "This section shall always report its own distinct 'Not Yet Supported' state rather than "
        "being folded into Awaiting Data or Failed Validation, since the absence here is a "
        "roadmap/capability gap, not a data-pipeline problem.",
      ],
      export_requirements=["This section shall be excluded from exports entirely until a governed methodology exists, rather than exporting a 'Not Yet Supported' placeholder."],
      validation_rules=["Not applicable until a methodology and KPI Catalog entry exist."],
      error_states=["Not applicable \u2014 see 'Not Yet Supported' state above."],
      empty_states=["The 'Not Yet Supported' state itself serves as this section's only state until methodology approval."],
      edge_cases=["Not applicable pending methodology definition."],
      audit_requirements=["Once implemented, standard section-level audit logging per Cross-Product Section 4 shall apply."],
      acceptance_criteria=[
        dict(given="no approved incrementality methodology or KPI Catalog entry exists",
             when="a user views any campaign report",
             then="the Incrementality Measurement section displays a 'Not Yet Supported' message and contains no illustrative or placeholder figures"),
        dict(given="an approved incrementality methodology and KPI Catalog entry are later published",
             when="a campaign qualifying for that methodology completes measurement",
             then="this section computes and displays the approved KPI and confidence range, subject to standard suppression and benchmark rules"),
      ],
      dependencies=["Cross-Product Section 3 (KPI Governance)"],
      assumptions=["Incrementality is a genuine roadmap item, not an MVP commitment, consistent with the current wireframe's own 'illustrative' labeling."],
      open_questions=[
        "What incrementality methodology will Measurement & Data Science standardize on, and "
        "what is the committed timeline? This directly blocks any real build of this section.",
        "Should a KPI Catalog entry (formula, data model, assumptions) be drafted now, ahead of "
        "methodology finalization, so Engineering has a target to build toward?",
      ],
      future_enhancements=["Support for multiple concurrent incrementality methodologies as retailer data maturity varies."],
    ),
    dict(
      id="2.11", title="Campaign Conclusions",
      business_objective=(
        "Provide a clear, human-authored narrative summary of what the campaign achieved, what "
        "stood out, and what should change next time, grounded in the system-generated readouts above it."
      ),
      user_story=(
        "As a report viewer, I want a short written summary of what worked, what didn't, and "
        "what to do differently next time, so that I don't have to interpret every number myself."
      ),
      business_context=[
        "Maps to wireframe report Section 14 (Conclusion): campaign metadata (result type, data "
        "used, data period, result version), a two-column Learnings/Recommendations list (3 "
        "bullets each), and an always-visible Limitations box, with an explicit hint that this "
        "prose is human-authored on top of system-generated data.",
      ],
      functional_requirements=[
        "The system shall display result type, data used, data period, and result version as "
        "structured metadata preceding the narrative.",
        "The platform shall provide an authoring interface for internal roles to write Learnings "
        "and Recommendations (up to a configurable maximum, default 3 each).",
        "The system shall always display a Limitations box, distinct from Learnings/Recommendations, "
        "regardless of how positive the quantitative results are.",
        "The platform shall visibly disclose that this section's prose is human-authored, "
        "distinguishing it from the system-generated readouts in prior sections.",
      ],
      business_rules=[
        "Conclusions shall only be authorable by internal roles (Retail Media Manager, "
        "Measurement & Data Science) and shall require Governance approval before publication, "
        "consistent with the publishing workflow in Story 3.1.",
        "The Limitations box shall be mandatory, non-empty content \u2014 the system shall block "
        "publication of a conclusion with an empty Limitations box.",
        "Result version shown here shall always match the report's current published version "
        "exactly; this section shall never display a conclusion authored against a prior, "
        "now-superseded data version.",
      ],
      data_requirements=[
        "Authored narrative text fields (Learnings, Recommendations, Limitations), versioned "
        "alongside the report they describe.",
        "Result version/publication metadata from the publishing workflow (Story 3.1).",
      ],
      kpi_dependencies=[50, 48],
      permission_requirements=[
        "Authoring is restricted to internal roles; all entitled viewers (including Advertiser "
        "users) may read the published conclusion.",
      ],
      reporting_requirements=[
        "This section shall not be publishable independently of the report's overall publication "
        "workflow \u2014 see Story 3.1.",
      ],
      export_requirements=["Included by default in any export or share of the report."],
      validation_rules=[
        "The system shall reject publication if Learnings, Recommendations, or Limitations "
        "content references a data period or version other than the one currently being published.",
      ],
      error_states=["If no conclusion has been authored yet, the report's overall status shall remain below Published, since this section is mandatory for publication."],
      empty_states=["Not applicable once published \u2014 this section is mandatory content for publication, per the business rule above."],
      edge_cases=[
        "A report later republished after a data correction (Story 3.1) must prompt the author to "
        "review and, if needed, update the conclusion \u2014 the system must not silently carry "
        "forward a conclusion written against the superseded data.",
      ],
      audit_requirements=[
        "All conclusion authoring, edits, and approvals shall be logged with author, approver, "
        "timestamp, and the specific result version the conclusion was written against.",
      ],
      acceptance_criteria=[
        dict(given="an internal author submits a conclusion with an empty Limitations box",
             when="they attempt to publish",
             then="publication is blocked until Limitations content is provided"),
        dict(given="a report is republished after a data correction",
             when="the new version is prepared for publication",
             then="the author is prompted to review the existing conclusion against the new result version before it can be re-published"),
      ],
      dependencies=["Story 3.1 (Publish Campaign Results)"],
      assumptions=["A single named author/approver pair is sufficient for MVP; multi-reviewer workflows are a future enhancement."],
      open_questions=[
        "Should Recommendations be structured (e.g., tagged by theme) to support aggregation "
        "across many campaigns for broader account-level insights?",
      ],
      future_enhancements=["Cross-campaign aggregation of Learnings/Recommendations themes for account-level reviews."],
    ),
  ],
)

EPICS = [EPIC_1, EPIC_2]

# ---------------------------------------------------------------------------
# EPIC 3: CAMPAIGN RESULT DISTRIBUTION
# ---------------------------------------------------------------------------
EPIC_3 = dict(
  id=3, title="CAMPAIGN RESULT DISTRIBUTION",
  screenshot="04-share-dialog.png",
  screenshot_caption="Reference wireframe: Share Approved Result dialog, overlaying the Campaign Report screen (low-fidelity, structure and states only).",
  overview=(
    "Epic 3 governs how a finished, trustworthy result leaves the platform and reaches its "
    "intended audience \u2014 internally through publication, and externally through sharing and "
    "export \u2014 with full control over who approved it, who received it, and what exact version "
    "they saw."
  ),
  business_problem=[
    "The source wireframe includes a 'Share approved result' action and an 'Export' button with "
    "no defined approval workflow, recipient access model, version control, or export format "
    "\u2014 today, results could be shared informally with no record of who saw what, when.",
    "Without a defined publish/approval gate, there is no guarantee that what a stakeholder sees "
    "has passed the same quality bar every time.",
    "Without export/download controls, commercially sensitive figures (e.g., margin) risk leaking "
    "beyond their intended, permissioned audience.",
  ],
  user_value=[
    "Confidence that anything shared or exported has been through a defined approval step.",
    "A clear, auditable record of exactly who has access to a given result.",
    "The ability to export results in the format needed for the recipient's own workflow, without "
    "compromising sensitive figures.",
  ],
  business_outcomes=[
    "Reduced risk of sharing unapproved or stale results.",
    "A defensible audit trail for every external disclosure of campaign results.",
    "Reduced support burden from recipients confused about why a number they received differs "
    "from what they now see in-platform (version control).",
  ],
  success_metrics=[
    "Percentage of shared/exported results that went through the approval workflow (target: 100%).",
    "Time from approval request to share/export completion.",
    "Number of post-share data corrections requiring a republish, trending down over time.",
    "Zero confirmed incidents of a recipient retaining access after their entitlement was revoked.",
  ],
  stories=[
    dict(
      id="3.1", title="Publish Campaign Results",
      business_objective=(
        "Ensure every campaign result that becomes visible beyond its working/draft state has "
        "passed a defined quality and approval gate, so published numbers can be trusted by default."
      ),
      user_story=(
        "As a Retail Media Manager, I want to formally publish a campaign's results only once "
        "they have been reviewed and approved, so that nothing reaches stakeholders before it is ready."
      ),
      business_context=[
        "This story defines the governance gate implied, but not specified, by the wireframe's "
        "'Published' status label and the Section 2.11 requirement that conclusions require "
        "approval before publication.",
        "Publishing is the single event that transitions a campaign's Reporting Data State "
        "(Cross-Product Section 2) from Processing/Draft into Published, and is the precondition "
        "for Stories 3.2 and 3.3.",
      ],
      functional_requirements=[
        "The system shall require every section marked as mandatory for publication (at minimum: "
        "Campaign Overview, Audience Definitions, and Campaign Conclusions) to pass validation "
        "before the Publish action becomes available.",
        "The platform shall require an explicit named approver, distinct from the preparer where "
        "the organization's policy requires segregation of duties, before publication completes.",
        "The system shall assign a monotonically increasing result version number to each publication.",
        "The platform shall allow republishing after a data correction, creating a new version "
        "rather than overwriting the prior one.",
        "The system shall record the exact set of sections and their states at the moment of publication.",
      ],
      business_rules=[
        "A campaign shall not be publishable while any mandatory section is in Failed Validation, "
        "Awaiting Data, or Draft state.",
        "A campaign may be published while some non-mandatory sections remain Awaiting Data, "
        "provided the overall status is set to Partially Available rather than fully Published.",
        "Republishing shall never silently replace a previously shared/exported version; prior "
        "recipients shall be notified per Story 3.2's republishing rule.",
      ],
      data_requirements=[
        "Section-level Reporting Data State for every section in the report.",
        "Approver identity and role, and the organization's segregation-of-duties policy flag.",
        "A version history table recording each publication event and its section-state snapshot.",
      ],
      kpi_dependencies=[],
      permission_requirements=[
        "Only users holding a Publisher or Approver role may initiate or approve publication; "
        "Report Viewer-level users shall not see a Publish action.",
        "Where segregation of duties is enabled, the preparer and approver must be different users.",
      ],
      reporting_requirements=[
        "The system shall surface, at the point of publication, which (if any) non-mandatory "
        "sections remain incomplete, so the approver makes an informed decision.",
      ],
      export_requirements=["Not applicable \u2014 export is governed separately in Story 3.3."],
      validation_rules=[
        "The system shall block publication and return a specific list of failing mandatory "
        "sections if any validation check fails.",
      ],
      error_states=[
        "If the approval step itself fails (e.g., approver session expires mid-approval), the "
        "system shall roll back to the pre-publication state rather than leaving the campaign in "
        "an ambiguous partially-published condition.",
      ],
      empty_states=["Not applicable \u2014 a campaign with no sections populated cannot reach the Publish action."],
      edge_cases=[
        "A campaign republished multiple times must retain full version history, not just the "
        "latest and original versions.",
        "A campaign with a mandatory section that later degrades (e.g., a data correction "
        "invalidates a previously passing validation) must be flagged for mandatory republication "
        "review, not left silently Published against now-invalid data.",
      ],
      audit_requirements=[
        "Every publish and republish event shall be logged with preparer, approver, timestamp, "
        "version number, and the section-state snapshot at that moment.",
      ],
      acceptance_criteria=[
        dict(given="a campaign has one mandatory section in Failed Validation",
             when="a Publisher attempts to publish",
             then="publication is blocked and the specific failing section is listed"),
        dict(given="a previously Published campaign receives a data correction invalidating a mandatory section",
             when="the correction is detected",
             then="the campaign is flagged for mandatory republication review rather than remaining silently Published"),
      ],
      dependencies=["Cross-Product Section 2 (Reporting Data State Management)",
                    "Story 2.11 (Campaign Conclusions)"],
      assumptions=["Segregation of duties (preparer \u2260 approver) is configurable per organization, not universally mandatory."],
      open_questions=[
        "Which specific sections are mandatory for publication across all campaign types, versus "
        "optional? The wireframe does not define a mandatory-section list; a confirmed list is "
        "needed from Product before build.",
      ],
      future_enhancements=["Scheduled/automatic publication once all mandatory sections reach Published state."],
    ),
    dict(
      id="3.2", title="Share Approved Results",
      business_objective=(
        "Let an approved result be shared with a specific, named set of recipients, with "
        "re-checked access control and a clear record of exactly what was shared."
      ),
      user_story=(
        "As a Retail Media Manager, I want to share an approved campaign result with specific "
        "people, so that the right stakeholders see it without me having to export and email it manually."
      ),
      business_context=[
        "Maps directly to the wireframe's 'Share approved result' modal: a recipient search "
        "field, a fixed 'export will state' preview (campaign scope, result type, data period, "
        "status/version), and a note that 'the link re-checks the recipient's access when it is opened'.",
        "The wireframe's Share button is presently non-functional (no defined backend behavior); "
        "this story defines the real behavior required to make it functional.",
      ],
      functional_requirements=[
        "The system shall allow searching for and selecting one or more recipients (people or "
        "teams) scoped to the organization's directory.",
        "The platform shall display, before sharing, a fixed preview stating campaign scope, "
        "result type, data period, and status/version \u2014 independent of final export format.",
        "The system shall generate a share link that re-validates the recipient's current "
        "entitlement every time the link is opened, not only at share time.",
        "The platform shall allow the sharer to revoke a share at any time, immediately "
        "invalidating the link for all recipients.",
      ],
      business_rules=[
        "Only Published (or Partially Available, if explicitly permitted by organization policy) "
        "results may be shared; Draft, Processing, or Failed Validation results shall never be shareable.",
        "If a shared campaign is later republished (Story 3.1), all existing recipients shall be "
        "notified that a newer version exists; the original share link shall continue to point to "
        "the version it was created against unless the sharer explicitly updates it.",
        "A recipient whose entitlement is revoked after a share was created shall lose access on "
        "their next attempt to open the link, per the re-check-on-open rule.",
      ],
      data_requirements=[
        "Recipient directory (people/teams) with current entitlement status.",
        "Share event records: sharer, recipients, campaign/version shared, timestamp, revocation status.",
      ],
      kpi_dependencies=[],
      permission_requirements=[
        "Only users holding a Sharer role (typically Retail Media Manager) may initiate a share; "
        "recipients require their own independent, valid entitlement to the campaign to actually "
        "view it \u2014 a share invitation does not itself grant entitlement.",
      ],
      reporting_requirements=["Shared content shall always reflect the exact version stated in the share preview, never a silently updated version."],
      export_requirements=["Not applicable here \u2014 see Story 3.3 for file-based export."],
      validation_rules=["The system shall reject an attempt to share a non-Published/non-Partially-Available result."],
      error_states=[
        "If a recipient's entitlement cannot be verified when they open a share link (e.g., "
        "directory service unavailable), the system shall deny access with a retryable error, "
        "not grant access by default.",
      ],
      empty_states=["If no recipients are selected, the Share action shall remain disabled."],
      edge_cases=[
        "A recipient added to a share and later removed from the organization entirely must lose "
        "access immediately, verified via the re-check-on-open rule.",
        "A team-based share (rather than individual) must re-evaluate current team membership at "
        "open time, not membership frozen at share time.",
      ],
      audit_requirements=[
        "Every share creation, modification, revocation, and recipient access event (including "
        "denied access attempts) shall be logged for audit history, per Cross-Product Section 4.",
      ],
      acceptance_criteria=[
        dict(given="a recipient's entitlement is revoked after a share is created",
             when="they attempt to open the share link",
             then="access is denied, and the denial is logged"),
        dict(given="a shared campaign is republished to a new version",
             when="republication completes",
             then="all existing recipients receive a notification that a newer version exists"),
      ],
      dependencies=["Story 3.1 (Publish Campaign Results)",
                    "Cross-Product Section 1 (User Roles & Permissions)"],
      assumptions=["An organizational directory service (people/teams with entitlement status) exists or will be integrated."],
      open_questions=[
        "Should share links expire automatically after a configurable period, independent of "
        "manual revocation?",
      ],
      future_enhancements=["Scheduled recurring shares (e.g., auto-share every campaign a given stakeholder is entitled to, as it publishes)."],
    ),
    dict(
      id="3.3", title="Export Campaign Results",
      business_objective=(
        "Let an approved result be downloaded in a usable file format for offline use, without "
        "compromising figures the recipient is not permissioned to see."
      ),
      user_story=(
        "As a report viewer, I want to export an approved campaign result to a file, so that I "
        "can use it in my own documents and presentations offline."
      ),
      business_context=[
        "Maps to the wireframe's 'Export' button (present on List, Compare, and the Share dialog "
        "preview) with no defined export format, contents, or permission model \u2014 this story "
        "closes that gap.",
      ],
      functional_requirements=[
        "The system shall support exporting a published campaign report to, at minimum, PDF and "
        "a structured data format (e.g., XLSX/CSV) for the numeric tables.",
        "The platform shall apply the same section-level permission rules at export time as are "
        "applied in-app (e.g., Attributed Margin excluded for users lacking that permission).",
        "The system shall stamp every export with the result version, export timestamp, and the "
        "exporting user's identity.",
        "The platform shall exclude suppressed rows/sections from the export exactly as they are "
        "suppressed in-app \u2014 export must never be usable as a suppression bypass.",
      ],
      business_rules=[
        "Only Published (or explicitly permitted Partially Available) results may be exported; "
        "exporting a Draft, Processing, or Failed Validation result shall be blocked.",
        "An exported file shall be a frozen snapshot of the version at export time; it shall never "
        "silently update after a later republication \u2014 a new export is required to obtain updated figures.",
        "Diagnostic/internal-only data (e.g., Story 2.9's attribution certification detail) shall "
        "never be included in any export available to non-internal roles.",
      ],
      data_requirements=[
        "Export templates for each supported file format, respecting the same section/permission "
        "structure as the in-app report.",
        "Export event records: user, format, version, timestamp.",
      ],
      kpi_dependencies=[],
      permission_requirements=[
        "Download/export permission shall be a distinct, assignable permission from view "
        "permission \u2014 an organization may wish to allow viewing but not downloading for certain roles.",
      ],
      reporting_requirements=["Exported figures shall exactly match the in-app figures for the stated version at the time of export."],
      export_requirements=[
        "Supported formats: PDF (presentation-ready) and XLSX/CSV (structured data) at minimum, "
        "per Functional Requirements above.",
        "Exact export format list, pagination behavior for very long reports, and branding "
        "requirements remain open pending Design/Brand input (see Open Questions).",
      ],
      validation_rules=["The system shall reject an export request for a non-Published/non-Partially-Available result or for a user lacking export permission."],
      error_states=["If export generation fails (e.g., rendering timeout for a very large report), the system shall surface a retryable error rather than delivering a partial/corrupt file."],
      empty_states=["Not applicable \u2014 export is only available once a result exists and is Published."],
      edge_cases=[
        "A report containing sections in mixed states (e.g., Partially Available) must clearly "
        "label incomplete sections within the exported file itself, not only in-app.",
        "A very large comparison export (Story 4.3) spanning many campaigns must paginate or "
        "chunk sensibly rather than producing an unusably large single file.",
      ],
      audit_requirements=["Every export event shall be logged with user, format, version, timestamp, and whether any sections/rows were excluded due to permission or suppression."],
      acceptance_criteria=[
        dict(given="a user lacking Attributed Margin visibility exports a report",
             when="the export file is generated",
             then="the Margin column is absent from the exported file exactly as it is absent in-app"),
        dict(given="a report is republished to a new version after an earlier export was taken",
             when="a user opens the earlier exported file",
             then="it still shows the version it was generated against, not the newer republished figures"),
      ],
      dependencies=["Story 3.1 (Publish Campaign Results)", "Cross-Product Section 1 (User Roles & Permissions)"],
      assumptions=["A report-rendering/export service capable of producing PDF and XLSX/CSV from the same underlying section data will be built or integrated."],
      open_questions=[
        "What is the final list of required export formats, and are there retailer-specific "
        "branding/template requirements for exported files? Not specified in the current wireframe.",
        "Should exports be watermarked or otherwise marked as a point-in-time snapshot to "
        "discourage stale-data confusion downstream?",
      ],
      future_enhancements=["Scheduled/automatic export delivery (e.g., emailed PDF on every publication)."],
    ),
  ],
)

EPICS = [EPIC_1, EPIC_2, EPIC_3]

# ---------------------------------------------------------------------------
# EPIC 4: CAMPAIGN COMPARISON
# ---------------------------------------------------------------------------
EPIC_4 = dict(
  id=4, title="CAMPAIGN COMPARISON",
  screenshot="03-compare-full.png",
  screenshot_caption="Reference wireframe: Compare Campaigns screen (low-fidelity, structure and states only).",
  overview=(
    "Epic 4 lets a user place multiple campaigns side by side to see which performed better and "
    "by how much, using the same governed KPIs and the same data-readiness rules as a single "
    "campaign report, so comparisons are never misleadingly apples-to-oranges."
  ),
  business_problem=[
    "Stakeholders managing a portfolio of campaigns need to know which campaigns outperformed "
    "others, but the wireframe does not define selection rules, comparability requirements, or "
    "how to handle campaigns at different data-readiness states shown side by side.",
    "Without comparability rules, a naive comparison could put a fully Published campaign next "
    "to a Partially Available one and imply a false difference.",
  ],
  user_value=[
    "A fast way to see relative performance across campaigns without opening each report individually.",
    "Confidence that only genuinely comparable campaigns (same KPIs, compatible measurement "
    "periods) are being compared.",
    "The same export capability available for a single report, extended to a comparison set.",
  ],
  business_outcomes=[
    "Faster portfolio-level decision-making (budget reallocation, retailer/channel mix decisions).",
    "Reduced risk of decisions based on misleading, non-comparable figures.",
    "Reusable foundation for benchmarking across advertisers/retailers as the portfolio grows.",
  ],
  success_metrics=[
    "Percentage of multi-campaign advertisers who use Compare at least once per quarter.",
    "Number of comparisons flagged as non-comparable (and thus blocked) per month, trending down "
    "as campaign setup consistency improves.",
    "Time from opening Compare to exporting or acting on a comparison.",
  ],
  stories=[
    dict(
      id="4.1", title="Campaign Benchmarking",
      business_objective=(
        "Let a user select two or more campaigns and see their key performance KPIs side by "
        "side, with benchmark context, to judge relative performance quickly."
      ),
      user_story=(
        "As a Retail Media Manager, I want to compare several campaigns' key results side by "
        "side, so that I can quickly see which performed best and by how much."
      ),
      business_context=[
        "Maps to the wireframe's Compare screen, which lists campaigns with a result and links "
        "the top row through to a full report; this story defines the actual comparison logic the "
        "wireframe does not specify.",
      ],
      functional_requirements=[
        "The system shall allow selecting two or more campaigns the user is entitled to view for "
        "side-by-side comparison.",
        "The platform shall display a shared set of core KPIs (at minimum: Reach, Conversion "
        "Rate, Revenue, Revenue per Shopper, Attributed ROAS) across all selected campaigns in a "
        "single table or chart.",
        "The system shall allow navigating from any compared campaign directly into its full report.",
      ],
      business_rules=[
        "Campaigns shall only be selectable for comparison if their core comparison KPIs are at "
        "least Partially Available; a campaign still fully in Draft/Processing shall not be "
        "selectable.",
        "Comparison figures shall apply the same suppression rule as single-campaign reports "
        "(Epic 2); a suppressed KPI for one campaign shall show as Suppressed in the comparison, "
        "not be silently omitted or estimated.",
      ],
      data_requirements=["Core comparison KPI values and data states for every campaign the user is entitled to view."],
      kpi_dependencies=[7, 11, 14, 16, 33],
      permission_requirements=["A campaign shall only appear as selectable for comparison if the user holds Report Viewer entitlement for it, consistent with Story 1.1."],
      reporting_requirements=["Comparison views shall reflect each campaign's live Reporting Data State, consistent with single-report display rules."],
      export_requirements=["See Story 4.3."],
      validation_rules=["The system shall prevent comparison of fewer than two campaigns or more than a configurable maximum (default: 10) in a single view."],
      error_states=["If one selected campaign's data becomes unavailable mid-session (e.g., entitlement revoked), it shall be removed from the comparison with a visible notice, not silently blanked."],
      empty_states=["If fewer than two campaigns are entitled/selectable, the Compare action shall be disabled with an explanatory message."],
      edge_cases=[
        "Campaigns with materially different measurement periods (e.g., 2 weeks vs. 8 weeks) "
        "shall be flagged as having limited comparability rather than compared without caveat \u2014 "
        "see Story 4.2 for the filtering/comparability logic.",
      ],
      audit_requirements=["Standard view-level audit logging consistent with Story 1.1; no additional sensitivity beyond single-report viewing."],
      acceptance_criteria=[
        dict(given="a user selects three campaigns they are entitled to view, two Published and one Processing",
             when="they open the comparison",
             then="all three appear, with the Processing campaign's incomplete KPIs shown as such rather than estimated or blank"),
      ],
      dependencies=["Story 1.1 (View Campaigns)", "Epic 2 (Campaign Measurement Reporting)"],
      assumptions=["The set of 'core comparison KPIs' is a fixed, governed subset of the full KPI Catalog, not user-configurable in the initial release."],
      open_questions=["Should users be able to customize which KPIs appear in the comparison table, or is a fixed core set sufficient for MVP?"],
      future_enhancements=["User-configurable comparison KPI sets.", "Visual (chart-based) comparison in addition to tabular."],
    ),
    dict(
      id="4.2", title="Campaign Comparison Filtering",
      business_objective=(
        "Help users quickly narrow a large campaign portfolio down to a genuinely comparable set, "
        "preventing misleading comparisons between structurally different campaigns."
      ),
      user_story=(
        "As a Retail Media Manager, I want to filter and narrow which campaigns I'm comparing, so "
        "that I only compare campaigns that are genuinely similar enough to compare fairly."
      ),
      business_context=[
        "The wireframe's Compare screen provides no filtering mechanism; this story defines both "
        "the UX filtering capability and, more importantly, the comparability guardrails that "
        "prevent misleading comparisons.",
      ],
      functional_requirements=[
        "The system shall allow filtering the comparison candidate set by advertiser, retailer, "
        "media channel, and campaign date range, consistent with Story 1.2's filter model.",
        "The platform shall flag, for any two or more selected campaigns, material structural "
        "differences that limit comparability (different media channels, materially different "
        "measurement-period lengths, different attribution methodologies).",
        "The system shall allow the user to proceed with a flagged comparison after "
        "acknowledging the caveat, rather than hard-blocking it outright.",
      ],
      business_rules=[
        "KPI alignment requirement: only KPIs that are defined and available for every campaign "
        "in the selected set shall be shown as comparable rows; a KPI unavailable for even one "
        "selected campaign shall be shown as 'Not comparable for this set' rather than silently omitted.",
        "Comparability flags shall be advisory, not permission-based \u2014 they do not restrict "
        "access, only surface a data-quality/fairness caveat.",
      ],
      data_requirements=["Campaign structural metadata (channel, measurement-period length, attribution methodology) to compute comparability flags."],
      kpi_dependencies=[],
      permission_requirements=["Filter candidate sets shall be scoped to the user's entitlements, consistent with Story 1.2."],
      reporting_requirements=["Not applicable beyond standard comparison reporting rules in Story 4.1."],
      export_requirements=["Comparability caveats acknowledged by the user shall be carried into any export per Story 4.3."],
      validation_rules=["The system shall compute comparability flags deterministically from governed structural metadata, not from a subjective/manual judgment."],
      error_states=["If structural metadata required to compute a comparability flag is missing for a campaign, the system shall default to flagging it as 'comparability unknown' rather than assuming comparable."],
      empty_states=["If filtering narrows the candidate set to fewer than two campaigns, the Compare action shall be disabled with an explanatory message."],
      edge_cases=[
        "Two campaigns from different retailers using different attribution methodologies must "
        "always be flagged, even if every other structural attribute matches.",
      ],
      audit_requirements=["Comparability caveat acknowledgments shall be logged (user, campaigns compared, flags acknowledged) for governance review of comparison quality."],
      acceptance_criteria=[
        dict(given="a user selects two campaigns with a 2-week and an 8-week measurement period respectively",
             when="they attempt to compare them",
             then="a comparability caveat is shown, and the user must explicitly acknowledge it before the comparison renders"),
      ],
      dependencies=["Story 1.2 (Filter and Search Campaigns)", "Story 4.1 (Campaign Benchmarking)"],
      assumptions=["A defined, governed set of 'structural' attributes (channel, period length, methodology) drives comparability flags; this set is confirmed by Product/Data Science."],
      open_questions=["What is the complete, governed list of structural attributes that should trigger a comparability flag?"],
      future_enhancements=["Automated suggestion of a 'most comparable' campaign set given a starting campaign."],
    ),
    dict(
      id="4.3", title="Campaign Comparison Export",
      business_objective=(
        "Let a user export a multi-campaign comparison to a file for offline use, carrying "
        "forward the same permission, suppression, and comparability safeguards as the in-app view."
      ),
      user_story=(
        "As a Retail Media Manager, I want to export a campaign comparison to a file, so that I "
        "can include it in a business review without rebuilding the table manually."
      ),
      business_context=[
        "Extends Story 3.3's single-report export rules to the multi-campaign comparison context "
        "defined in Stories 4.1 and 4.2.",
      ],
      functional_requirements=[
        "The system shall export the current comparison view (selected campaigns, filters "
        "applied, comparability caveats) to PDF and a structured data format (XLSX/CSV).",
        "The platform shall include any acknowledged comparability caveats visibly within the "
        "exported file, not only in-app.",
        "The system shall stamp the export with the versions of each included campaign's data at "
        "export time.",
      ],
      business_rules=[
        "The same per-user, per-campaign, per-KPI permission and suppression rules from Epic 2 "
        "and Story 3.3 shall apply independently to each campaign within the exported comparison "
        "\u2014 a user's lack of permission for one campaign's margin figure, for example, shall not "
        "be bypassed by viewing it alongside other campaigns.",
        "A comparison export shall only include campaigns the exporting user is individually "
        "entitled to view and export; it must never be used to indirectly expose a campaign "
        "outside the user's scope.",
      ],
      data_requirements=["Per-campaign KPI values, data states, and comparability flags for the exported set, consistent with Stories 4.1 and 4.2."],
      kpi_dependencies=[],
      permission_requirements=["Export/download permission shall be checked per campaign within the comparison set, not once for the comparison as a whole."],
      reporting_requirements=["Exported figures shall match the in-app comparison exactly as of export time, per Story 3.3's version-freezing rule."],
      export_requirements=["Supported formats: PDF and XLSX/CSV, consistent with Story 3.3.", "Row/column layout must remain legible for comparisons of up to the configurable maximum campaign count (default: 10)."],
      validation_rules=["The system shall reject a comparison export containing any campaign the requesting user is not entitled to export individually."],
      error_states=["If one campaign in the set fails to export (e.g., data service error), the system shall fail the entire export with a clear error rather than silently omitting that campaign's data."],
      empty_states=["Not applicable \u2014 export requires an active comparison with at least two campaigns, per Story 4.1."],
      edge_cases=["A very large comparison (near the maximum campaign count) exported to PDF must paginate sensibly rather than producing an unreadably dense single page."],
      audit_requirements=["Every comparison export shall be logged with user, campaigns included, formats, version stamps, and any permission-driven exclusions, consistent with Story 3.3."],
      acceptance_criteria=[
        dict(given="a user exports a comparison of 4 campaigns, lacking margin permission for one of them",
             when="the export file is generated",
             then="the Margin figure for that one campaign is excluded from the export while all other figures and campaigns are included normally"),
      ],
      dependencies=["Story 3.3 (Export Campaign Results)", "Story 4.1 (Campaign Benchmarking)", "Story 4.2 (Campaign Comparison Filtering)"],
      assumptions=["The same export-rendering service built for Story 3.3 is reused/extended for multi-campaign comparisons."],
      open_questions=["Is there a need for a dedicated comparison export template distinct from the single-report export template?"],
      future_enhancements=["Scheduled recurring comparison exports (e.g., a weekly portfolio performance digest)."],
    ),
  ],
)

EPICS = [EPIC_1, EPIC_2, EPIC_3, EPIC_4]

# ---------------------------------------------------------------------------
# CROSS-PRODUCT REQUIREMENTS
# ---------------------------------------------------------------------------
ROLES = [
  ("Platform Administrator", "Configures organizations, roles, retailer/advertiser onboarding, "
   "and system-wide settings. Does not author or approve campaign content."),
  ("Retail Media Manager (RMM)", "Internal role; day-to-day owner of campaigns on behalf of the "
   "retailer/platform. Prepares, authors conclusions, publishes, shares."),
  ("Measurement & Data Science (MDS)", "Owns KPI definitions, attribution/incrementality "
   "methodology, and diagnostic certification thresholds."),
  ("Governance / Compliance Approver (GOV)", "Approves publication where segregation of duties "
   "is enabled; owns suppression/privacy policy and KPI Catalog sign-off."),
  ("Retailer Data Operations (RDO)", "Resolves data-pipeline issues (Awaiting Data, Failed "
   "Validation); does not author business conclusions."),
  ("Advertiser User", "External, client-side role. Views Published (and, if permitted, "
   "Partially Available) results for campaigns they are entitled to; cannot author, publish, or "
   "see internal diagnostic detail."),
  ("System (automated)", "Non-human actor for audit-log attribution of automated state "
   "transitions (e.g., scheduled suppression re-checks)."),
]

PERMISSION_MATRIX_ROWS = [
  ("View Published / Partially Available results", "Yes", "Yes", "Yes", "Yes", "Yes", "Yes"),
  ("View Draft / Processing results", "Yes", "Yes", "Yes", "Yes", "No", "No"),
  ("View internal diagnostic / certification detail (Story 2.9)", "Yes", "Yes", "Yes", "Yes", "No", "No"),
  ("View Attributed Margin (finance-sensitive)", "Yes", "Configurable", "Configurable", "Yes", "Configurable", "No"),
  ("Author Campaign Conclusions (Story 2.11)", "No", "Yes", "Yes", "Yes", "No", "No"),
  ("Approve Publication (Story 3.1)", "No", "Configurable", "No", "Yes", "No", "No"),
  ("Share Approved Results (Story 3.2)", "No", "Yes", "No", "Configurable", "No", "No"),
  ("Export / Download (Stories 3.3, 4.3)", "Yes", "Yes", "Yes", "Yes", "Configurable", "Configurable"),
  ("Manage Users & Permissions", "Yes", "No", "No", "Configurable", "No", "No"),
  ("Configure / Approve KPI Catalog entries", "No", "No", "Yes", "Yes", "No", "No"),
]
PERMISSION_MATRIX_COLS = ["Capability", "Platform Admin", "RMM", "MDS", "GOV", "RDO", "Advertiser User"]

DATA_STATES = [
  ("Draft", "Report content exists but has not entered the publication workflow.",
   "Internal roles only (RMM, MDS, GOV, RDO).",
   "Created when a campaign report is first instantiated; exits when a Publish request is initiated."),
  ("Processing", "One or more required pipelines (media delivery, attribution, etc.) are still "
   "running for the current reporting period.",
   "Internal roles only.",
   "Entered automatically when upstream processing begins; exits to Awaiting Data, Partially "
   "Available, Published, or Failed Validation depending on outcome."),
  ("Awaiting Data", "A required upstream data source has not yet delivered; no estimated or "
   "default value is substituted.",
   "Internal roles only; Advertiser users see only the aggregate campaign-level status, not this "
   "section-level detail.",
   "Entered when a required feed misses its expected delivery window; exits once the feed "
   "arrives and passes validation."),
  ("Partially Available", "Some, but not all, mandatory or optional sections have published "
   "figures; the rest remain in an earlier state.",
   "All entitled roles, with incomplete sections clearly marked.",
   "Entered when a campaign is published with some non-mandatory sections still incomplete "
   "(Story 3.1); exits to Published once remaining sections complete, or may remain indefinitely "
   "if a section is structurally Not Yet Supported (Story 2.10)."),
  ("Published", "All mandatory sections have passed validation and been formally approved.",
   "All entitled roles, per the permission matrix above.",
   "Entered via the Publish action (Story 3.1); exits to Suppressed (if a later privacy breach "
   "occurs) or Archived (after the retention period)."),
  ("Suppressed", "A privacy/suppression threshold has been breached for one or more values; "
   "those values are withheld from all roles, including internal roles, except via a governed "
   "override process.",
   "No role sees the suppressed underlying value; all roles see the Suppressed indicator.",
   "Entered automatically when population counts fall below the governed threshold (Cross-"
   "Product rule, applied throughout Epic 2); exits only if the underlying population grows back "
   "above threshold on recomputation."),
  ("Failed Validation", "A required data-integrity or diagnostic-certification check failed.",
   "Internal roles only; Advertiser users see a generic 'results delayed' status, not the "
   "specific validation failure.",
   "Entered automatically when a validation rule fails during Processing or at publish-time "
   "(e.g., Story 2.9's diagnostic thresholds, Story 2.2's mutual-exclusivity check); exits once "
   "the underlying issue is corrected and validation is re-run."),
  ("Archived", "The result has passed the organization's configured retention period and is "
   "retained for compliance/audit purposes only.",
   "Restricted to Governance and Platform Administrator roles by default; not shown in standard "
   "list/report views.",
   "Entered automatically after the retention period elapses from the most recent Published "
   "version; terminal state (no further automatic transitions)."),
]

AUDIT_ACTIONS = [
  "Entitlement resolution used to render the Campaign List (Story 1.1).",
  "Every Reporting Data State transition, including the before/after state and trigger (Story 1.3).",
  "Suppression decisions (which rows/values were suppressed and why) at publication time (Epic 2, multiple stories).",
  "Access to Attributed Margin or other finance-sensitive figures, including exports (Story 2.5, 3.3).",
  "Post-publication corrections to campaign facts or figures (Story 2.1, 2.3).",
  "Authoring, editing, and approval of Campaign Conclusions (Story 2.11).",
  "Every publish and republish event, including preparer, approver, version, and section-state snapshot (Story 3.1).",
  "Every share creation, modification, revocation, and recipient access attempt, including denials (Story 3.2).",
  "Every export event, including user, format, version, and any permission-driven exclusions (Story 3.3, 4.3).",
  "Publish/block decisions driven by attribution diagnostic thresholds (Story 2.9).",
  "Comparability caveat acknowledgments in Campaign Comparison (Story 4.2).",
  "Role and permission changes for any user (Cross-Product Section 1).",
  "KPI Catalog entry creation, modification, or status changes (Cross-Product Section 3).",
]

def add_permission_matrix(doc):
    table = doc.add_table(rows=1, cols=len(PERMISSION_MATRIX_COLS))
    table.style = 'Light Grid Accent 1'
    for i, h in enumerate(PERMISSION_MATRIX_COLS):
        table.rows[0].cells[i].text = h
    for row_data in PERMISSION_MATRIX_ROWS:
        cells = table.add_row().cells
        for i, v in enumerate(row_data):
            cells[i].text = v
    style_table_header(table)
    doc.add_paragraph()

def add_roles_table(doc):
    table = doc.add_table(rows=1, cols=2)
    table.style = 'Light Grid Accent 1'
    table.rows[0].cells[0].text, table.rows[0].cells[1].text = "Role", "Description"
    for name, desc in ROLES:
        cells = table.add_row().cells
        cells[0].text, cells[1].text = name, desc
    style_table_header(table)
    doc.add_paragraph()

def add_state_table(doc):
    table = doc.add_table(rows=1, cols=4)
    table.style = 'Light Grid Accent 1'
    hdr = table.rows[0].cells
    hdr[0].text, hdr[1].text, hdr[2].text, hdr[3].text = (
        "State", "Meaning", "Visible To", "Entry / Exit Conditions")
    for name, meaning, visible, transitions in DATA_STATES:
        cells = table.add_row().cells
        cells[0].text, cells[1].text, cells[2].text, cells[3].text = name, meaning, visible, transitions
    style_table_header(table)
    doc.add_paragraph()

def add_cross_cutting(doc):
    doc.add_page_break()
    doc.add_heading("CROSS-PRODUCT REQUIREMENTS", level=1)

    doc.add_heading("1. User Roles & Permissions", level=2)
    doc.add_paragraph(
      "The platform shall enforce a role-based permission model, evaluated server-side on every "
      "request, independent of any client-side UI restriction. The following roles are "
      "recognized across all epics in this document."
    )
    add_roles_table(doc)
    doc.add_paragraph("Permission matrix (capability by role):").runs[0].bold = True
    add_permission_matrix(doc)
    add_label_block(doc, "Additional Rules", [
      "A user may hold more than one role; the platform shall apply the union of permissions "
      "across all held roles, with any explicit deny rule taking precedence over an allow.",
      "Role assignment shall itself be audited (Section 4, Auditability).",
      "Advertiser Users shall never be assignable Publisher, Approver, or KPI Governance roles.",
    ])

    doc.add_heading("2. Reporting Data State Management", level=2)
    doc.add_paragraph(
      "Every campaign report, and every section within it, shall carry one of the following "
      "eight governed states at all times. This model supersedes and formalizes the ad-hoc "
      "status labels seen in the source wireframe (e.g., 'Data issue', 'Partly suppressed')."
    )
    add_state_table(doc)
    add_label_block(doc, "Capability Availability \u2014 a Distinct Dimension", [
      "Separate from the eight lifecycle states above, a section may also be 'Not Yet Supported' "
      "(the capability does not exist yet, e.g., Story 2.10 Incrementality) or 'Not Available for "
      "this Retailer' (the capability exists but required data is not licensed for a given "
      "retailer, e.g., Story 2.8 consumption-style profile).",
      "These two capability-availability flags shall never be presented using the same visual "
      "language as Awaiting Data, since they do not resolve on their own as a pipeline run completes.",
    ])

    doc.add_heading("3. KPI Governance", level=2)
    add_label_block(doc, "Ownership", [
      "Measurement & Data Science owns the KPI Catalog's formulas, data model mappings, and "
      "calculation logic.",
      "Governance approves any KPI Catalog change that affects disclosure (e.g., margin, "
      "diagnostic detail) or suppression policy.",
      "Product owns the roadmap for which KPIs are prioritized for a given release.",
    ])
    add_label_block(doc, "Process", [
      "Propose a new KPI with a plain-language business definition and population/scope clarification.",
      "Define its formula and required source tables/fields.",
      "Assess data-model readiness and assign a tier: Supported, Conditional, Requires additional "
      "table, Requires confirmed physical table, Requires confirmed dimension(s), or Requires "
      "supporting governance.",
      "Obtain Governance sign-off for any KPI touching disclosure-sensitive or diagnostic data.",
      "Release into the governed catalog with a version number; changes to an existing KPI's "
      "formula require a new version, not a silent edit.",
    ])
    add_label_block(doc, "Calculation & Benchmark Dependencies", [
      "Ratio/derived KPIs (e.g., Average Basket Value, Conversion Rate) shall always be computed "
      "from their governed component KPIs, never independently re-derived per screen.",
      "Benchmark KPIs (category-level comparisons) depend on an equivalent category-level dataset "
      "being available at the same retailer and period as the brand-level figure; absent that, "
      "the comparison shall show Awaiting Data, not a one-sided figure (Stories 2.7, 2.8).",
    ])
    add_label_block(doc, "Future Extensibility", [
      "New KPIs (e.g., a future Incremental Sales KPI, Story 2.10) shall enter through the process "
      "above before any figure reaches a Published report.",
      "The Data Model Status tiering shall drive Engineering prioritization: 'Supported' KPIs are "
      "MVP-ready; all other tiers require additional data-model or governance work before they "
      "can be built.",
    ])
    doc.add_paragraph("Full governed KPI Catalog (reference, all 50 entries):").runs[0].bold = True
    add_kpi_table(doc, sorted(KPI.keys()))

    doc.add_heading("4. Auditability", level=2)
    doc.add_paragraph(
      "The following actions shall, at minimum, generate an immutable audit record containing "
      "actor, action, target entity, timestamp, and (where applicable) the before/after state:"
    )
    add_label_block(doc, None, AUDIT_ACTIONS)
    add_label_block(doc, "Retention", [
      "Audit records shall be retained for a minimum of 13 months, or the organization's "
      "configured compliance retention period, whichever is longer.",
      "Audit records themselves shall be immutable and not subject to the Archived state's "
      "visibility restrictions \u2014 Governance and Compliance roles shall retain access regardless "
      "of the underlying campaign's lifecycle state.",
    ])

    doc.add_heading("5. Non-Functional Requirements", level=2)
    add_label_block(doc, "Performance", [
      "A single campaign report (14 sections) shall render within 3 seconds at the 95th "
      "percentile under normal load.",
      "Comparison views of up to the configured maximum campaign count (default: 10) shall "
      "render within 5 seconds at the 95th percentile.",
    ])
    add_label_block(doc, "Scalability", [
      "The platform shall support onboarding additional retailers and advertisers without "
      "degradation to list/filter/report performance, validated via load testing against at "
      "least 10x current expected campaign volume.",
    ])
    add_label_block(doc, "Security", [
      "All entitlement and permission checks shall be enforced server-side; client-side checks "
      "are a UX convenience only and must never be the sole control.",
      "Data shall be encrypted in transit and at rest.",
      "Suppression and permission rules shall be enforced identically across in-app viewing, "
      "sharing (Story 3.2), and export (Stories 3.3, 4.3) \u2014 no distribution channel may be used "
      "to bypass another's controls.",
      "Audit logs shall be tamper-evident and access-restricted to Governance/Compliance roles.",
    ])
    add_label_block(doc, "Availability", [
      "The reporting platform shall target a minimum of 99.5% monthly uptime for read access to "
      "Published results.",
      "Upstream pipeline delays shall degrade gracefully into the Awaiting Data / Processing "
      "states (Section 2) rather than causing application downtime or errors.",
    ])
    add_label_block(doc, "Usability & Accessibility", [
      "Status and data-state language shall be consistent across every screen and export \u2014 the "
      "same state must never be worded differently in two places.",
      "The product shall target WCAG 2.1 Level AA conformance, including keyboard navigation and "
      "screen-reader support for all interactive elements.",
      "The Share dialog (Story 3.2) and any other modal shall implement a focus trap, "
      "Escape-to-close, and ARIA labeling \u2014 explicitly closing a gap present in the current "
      "wireframe, which has no defined accessibility behavior for its modal.",
      "Charts (e.g., the paired stacked-bar shopper-profile comparisons in Story 2.8) shall "
      "provide an accessible data-table equivalent, not rely on visual-only comprehension.",
    ])

# ---------------------------------------------------------------------------
# FINAL REVIEW: PRODUCT READINESS REVIEW
# ---------------------------------------------------------------------------
GAPS_RESOLVED = [
  ("Campaign filtering", "No filter criteria were defined in the source wireframe.",
   "Resolved in Story 1.2: minimum filterable fields (advertiser, retailer, channel, lifecycle "
   "status, measurement status) and search scope defined."),
  ("Publish / approval workflow", "The wireframe showed a 'Published' status with no defined "
   "approval gate.",
   "Resolved in Story 3.1: mandatory-section validation, named approver, segregation of duties, "
   "and versioning defined."),
  ("Share functionality", "The 'Share approved result' button had no defined backend behavior.",
   "Resolved in Story 3.2: recipient model, re-check-on-open access control, revocation, and "
   "republish notification defined."),
  ("Export formats", "The 'Export' button had no defined file format or permission model.",
   "Resolved in Stories 3.3 / 4.3: PDF and XLSX/CSV proposed as the minimum format set, with "
   "permission/suppression parity with the in-app view."),
  ("Privacy / suppression threshold", "No minimum population threshold existed anywhere in the "
   "wireframe or KPI Catalog.",
   "Resolved (proposed default) throughout Epic 2: a 100-attributed-shopper minimum threshold, "
   "pending final Legal/Privacy confirmation (remains an open question below)."),
  ("Reporting Data State model", "The wireframe showed four ad-hoc, inconsistent status labels "
   "with no governed taxonomy.",
   "Resolved in Cross-Product Section 2: a governed eight-state model, with the wireframe's "
   "example states mapped onto it and a separate Capability Availability dimension introduced "
   "for 'Not Yet Supported' / 'Not Available for this Retailer' conditions."),
  ("Non-existent Incrementality KPI", "The wireframe's Incremental Impact section displayed "
   "illustrative, non-real figures with no backing KPI Catalog entry.",
   "Resolved in Story 2.10: the section is explicitly scoped as 'Not Yet Supported' with a "
   "structural placeholder only; no illustrative figures permitted in a Published report."),
  ("Accessibility of the Share modal and charts", "The wireframe defines no keyboard, "
   "focus-trap, ARIA, or chart-accessibility behavior.",
   "Resolved in Cross-Product Section 5 (NFRs): focus trap, Escape-to-close, ARIA labeling, and "
   "accessible data-table equivalents for charts are now explicit requirements."),
  ("Hardcoded single-campaign navigation", "Every row in the source wireframe's List and "
   "Compare screens links to the same single hardcoded report.",
   "Resolved implicitly throughout Epics 1 and 4: all story-level functional requirements assume "
   "per-campaign routing (e.g., Story 1.1's per-row navigation to that specific campaign's report)."),
]

OPEN_QUESTIONS = [
  ("1.1", "What is the correct entitlement granularity \u2014 advertiser, retailer, or the "
   "combination of both?", "Identity/Access Architecture", "High"),
  ("1.2", "What is the complete target list of filterable fields for the Campaign List?",
   "Product", "Medium"),
  ("2.1", "Who owns and versions the governed measurement-method description library?",
   "Product / Data Science", "Low"),
  ("2.2", "Should audience segment definitions be fully custom per campaign or drawn from a "
   "shared retailer-level template library?", "Product", "Medium"),
  ("2.3", "Who is accountable for validating media-partner-reported delivery figures, if any "
   "validation beyond passive sanity checks is planned?", "Data Operations", "Medium"),
  ("2.4 / Epic 2", "What is the organization's final minimum suppression threshold, pending "
   "Legal/Privacy confirmation? (100 shoppers proposed as default.)", "Governance / Legal", "High"),
  ("2.5", "Which retailers currently permit margin disclosure to advertisers, and under what "
   "contractual terms?", "Legal / Retailer Partnerships", "High"),
  ("2.7", "What is the refresh cadence and lag for category benchmark data, relative to "
   "campaign reporting cadence?", "Data Science", "Medium"),
  ("2.8", "Which shopper-profile dimensions are licensed for which retailers today, and is "
   "there a roadmap to close current gaps (e.g., consumption style)?", "Retailer Partnerships", "Medium"),
  ("2.9", "What are the exact minimum diagnostic thresholds required to certify attribution "
   "results as publishable?", "Measurement & Data Science", "High"),
  ("2.10", "What incrementality methodology will Data Science standardize on, and what is the "
   "committed delivery timeline?", "Measurement & Data Science", "High"),
  ("2.11", "Should Recommendations be structured/tagged to support cross-campaign aggregation?",
   "Product", "Low"),
  ("3.1", "Which specific sections are mandatory for publication across all campaign types, "
   "versus optional?", "Product", "High"),
  ("3.2", "Should share links expire automatically after a configurable period, independent of "
   "manual revocation?", "Product / Security", "Medium"),
  ("3.3", "What is the final list of required export formats, and are there retailer-specific "
   "branding requirements for exported files?", "Design / Brand", "Medium"),
  ("4.1", "Should users be able to customize which KPIs appear in a comparison, or is a fixed "
   "core set sufficient for MVP?", "Product", "Low"),
  ("4.2", "What is the complete, governed list of structural attributes that should trigger a "
   "comparability flag between campaigns?", "Data Science / Product", "Medium"),
  ("4.3", "Is a dedicated comparison export template needed, distinct from the single-report "
   "export template?", "Design", "Low"),
]

def add_gap_table(doc):
    table = doc.add_table(rows=1, cols=3)
    table.style = 'Light Grid Accent 1'
    hdr = table.rows[0].cells
    hdr[0].text, hdr[1].text, hdr[2].text = "Gap Identified", "Why It Mattered", "How It Was Resolved in This PRD"
    for gap, why, how in GAPS_RESOLVED:
        cells = table.add_row().cells
        cells[0].text, cells[1].text, cells[2].text = gap, why, how
    style_table_header(table)
    doc.add_paragraph()

def add_open_questions_table(doc):
    table = doc.add_table(rows=1, cols=4)
    table.style = 'Light Grid Accent 1'
    hdr = table.rows[0].cells
    hdr[0].text, hdr[1].text, hdr[2].text, hdr[3].text = "Story", "Open Question", "Proposed Owner", "Priority"
    for story_id, q, owner, pri in OPEN_QUESTIONS:
        cells = table.add_row().cells
        cells[0].text, cells[1].text, cells[2].text, cells[3].text = story_id, q, owner, pri
    style_table_header(table)
    doc.add_paragraph()

def add_final_review(doc):
    doc.add_page_break()
    doc.add_heading("PRODUCT READINESS REVIEW", level=1)
    doc.add_paragraph(
      "This section documents the gap-analysis performed while converting the source wireframe "
      "into this Product Requirements package. Its purpose is to make explicit what was "
      "ambiguous or missing in the original artifact, how each gap was resolved into a concrete "
      "requirement wherever reasonably possible, and which items remain genuinely open and "
      "require a named owner before build can begin with full confidence."
    )
    doc.add_heading("Gaps Identified and Resolved", level=2)
    add_gap_table(doc)
    doc.add_heading("Remaining Open Questions", level=2)
    doc.add_paragraph(
      "The following items could not be fully resolved from the source wireframe, KPI Catalog, "
      "or reasonable product judgment alone, and require a named owner's decision before the "
      "corresponding story can be considered build-ready."
    )
    add_open_questions_table(doc)
    doc.add_heading("Overall Readiness Assessment", level=2)
    add_label_block(doc, None, [
      "Epics 1 and 4 (Campaign Discovery, Campaign Comparison) are structurally well-defined and "
      "ready for design and engineering estimation, pending the entitlement-granularity and "
      "filterable-fields decisions above.",
      "Epic 2 (Campaign Measurement Reporting) is ready for the sections backed by 'Supported' "
      "or near-Supported KPIs (Stories 2.1\u20132.7, 2.11); Stories 2.8 and 2.9 are ready for build "
      "but gated on retailer data-licensing and diagnostic-threshold decisions; Story 2.10 "
      "(Incrementality) is explicitly not ready for build and should be tracked as a distinct "
      "roadmap initiative, not an MVP commitment.",
      "Epic 3 (Campaign Result Distribution) is ready for design, pending final export-format "
      "and mandatory-section decisions.",
      "The cross-product suppression threshold and attribution-certification thresholds are the "
      "two highest-priority open items blocking confident estimation of Epic 2, and should be "
      "resolved first.",
    ])

# ---------------------------------------------------------------------------
# TITLE PAGE
# ---------------------------------------------------------------------------
def add_title_page(doc):
    title = doc.add_heading("Retail Media Measurement Reporting", level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub = doc.add_paragraph("Product Requirements Document")
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub.runs[0].font.size = Pt(20)
    sub.runs[0].font.color.rgb = ACCENT
    doc.add_paragraph()
    meta = doc.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    meta.add_run(
      "Epics 1\u20134: Campaign Discovery \u00b7 Campaign Measurement Reporting \u00b7 "
      "Campaign Result Distribution \u00b7 Campaign Comparison\n"
      "Source artifact: retail-media-wireframe.html (low-fidelity structural wireframe)\n"
      "Source KPI Catalog: Retail Media Phase 1 MVP KPI Catalog (50 governed KPIs)"
    ).font.size = Pt(11)
    doc.add_paragraph()
    note = doc.add_paragraph()
    note.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = note.add_run(
      "This document transforms the referenced wireframe and KPI catalog into enterprise-grade, "
      "build-ready product requirements. It does not describe what appears on screen; it "
      "specifies what the system shall do, challenges unstated assumptions, and resolves "
      "identified gaps into concrete requirements. Remaining open items are tracked explicitly "
      "in the Product Readiness Review at the end of this document."
    )
    r.italic = True
    r.font.size = Pt(10)
    r.font.color.rgb = RULE_GREY
    doc.add_page_break()

def add_how_to_read(doc):
    doc.add_heading("How to Read This Document", level=1)
    add_label_block(doc, "Structure", [
      "Four Epics (Campaign Discovery, Campaign Measurement Reporting, Campaign Result "
      "Distribution, Campaign Comparison), each opening with a reference screenshot of the "
      "relevant wireframe section and an Epic-level business overview.",
      "Each Epic contains its full set of user Stories; every Story specifies twenty structured "
      "fields, from Business Objective through Future Enhancements, including Given/When/Then "
      "acceptance criteria.",
      "Cross-Product Requirements apply across all four Epics: User Roles & Permissions, "
      "Reporting Data State Management, KPI Governance, Auditability, and Non-Functional Requirements.",
      "A final Product Readiness Review documents every gap found in the source wireframe, how "
      "it was resolved, and the open questions that remain.",
    ])
    add_label_block(doc, "Requirements Language", [
      "Requirements are written as system obligations and user entitlements (\u201cThe system "
      "shall\u2026\u201d, \u201cAuthorized users can\u2026\u201d, \u201cThe report shall\u2026\u201d), not as descriptions of "
      "what a screen currently shows.",
      "Where the source wireframe left a behavior undefined, this document proposes a concrete "
      "requirement and flags it as such; genuinely unresolved items are listed only in the "
      "Product Readiness Review, not hidden inside a story as if settled.",
    ])
    doc.add_page_break()

# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    doc = Document()
    doc.styles['Normal'].font.name = 'Calibri'
    doc.styles['Normal'].font.size = Pt(10.5)
    add_title_page(doc)
    add_how_to_read(doc)
    for epic in EPICS:
        add_epic(doc, epic)
    add_cross_cutting(doc)
    add_final_review(doc)
    out = os.path.join(BASE, 'Retail-Media-PRD.docx')
    doc.save(out)
    print("Saved", out)


