#!/usr/bin/env python3
"""Load a Parquet/JSONL sample into raw.unlimitail_impression, then invoke canonical SQL transformation.
Requires: pandas, pyarrow, sqlalchemy, psycopg[binary].
Environment: DATABASE_URL=postgresql+psycopg://user:password@host:5432/database
"""
import argparse, hashlib, os
from pathlib import Path
import pandas as pd
from sqlalchemy import create_engine, text

def checksum(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def read_source(path: Path) -> pd.DataFrame:
    if path.suffix.lower()=='.parquet': return pd.read_parquet(path, engine='pyarrow')
    if path.suffix.lower() in {'.jsonl','.ndjson','.json'}: return pd.read_json(path, lines=True, dtype=False)
    raise ValueError('Expected .parquet, .jsonl, .ndjson, or line-delimited .json')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('file'); ap.add_argument('--source-system',default='UNLIMITAIL')
    ap.add_argument('--chunk-size',type=int,default=100_000); args=ap.parse_args()
    url=os.environ['DATABASE_URL']; path=Path(args.file); engine=create_engine(url, future=True)
    sha=checksum(path)
    with engine.begin() as cx:
        batch_id=cx.execute(text("""INSERT INTO ops.load_batch(source_system,source_file,file_checksum)
          VALUES (:s,:f,:h) ON CONFLICT(source_system,source_file,file_checksum)
          DO UPDATE SET received_at=now() RETURNING load_batch_id"""), {'s':args.source_system,'f':path.name,'h':sha}).scalar_one()
    df=read_source(path); df.columns=[c.lower() for c in df.columns]
    df=df.where(pd.notna(df), None); df.insert(0,'source_file',path.name); df.insert(0,'source_row_number',range(1,len(df)+1)); df.insert(0,'load_batch_id',batch_id)
    # Preserve source fidelity: landing business columns are text.
    meta={'load_batch_id','source_row_number','source_file'}
    for c in df.columns:
        if c not in meta: df[c]=df[c].map(lambda x: None if x is None else str(x))
    df.to_sql('unlimitail_impression',engine,schema='raw',if_exists='append',index=False,chunksize=args.chunk_size,method='multi')
    with engine.begin() as cx: cx.execute(text('CALL core.load_unlimitail_impressions(:b)'),{'b':batch_id})
    with engine.connect() as cx:
        print(dict(cx.execute(text('SELECT * FROM ops.load_batch WHERE load_batch_id=:b'),{'b':batch_id}).mappings().one()))
if __name__=='__main__': main()
