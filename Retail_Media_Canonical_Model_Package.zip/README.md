# Canonical Retail Media Exposure Model Package

Files:
- `Retail_Media_Exposure_Canonical_Model.docx`: architecture, ERD, mappings, metrics, controls, and implementation guidance.
- `canonical_retail_media_schema.sql`: PostgreSQL 15+ DDL. Requires `pgcrypto` for `digest()`.
- `load_unlimitail_impressions.sql`: idempotent dimension/fact load procedure.
- `ingest_unlimitail_feed.py`: Parquet/JSONL landing loader and procedure caller.
- `retail_media_erd.png`: ERD image.

Run order:
1. `CREATE EXTENSION IF NOT EXISTS pgcrypto;`
2. Execute the schema SQL.
3. Execute the load procedure SQL.
4. Set `DATABASE_URL`.
5. Run `python ingest_unlimitail_feed.py <file.parquet>`.

Assumptions:
- PostgreSQL 15+ is the reference dialect.
- Source cost fields containing “in bucks” are treated as USD, then converted using the supplied USD-to-advertiser rate. Validate this with the partner contract.
- The sample does not contain viewability, click, conversion, sales, IVT, or usable person identity values. Those metrics cannot be inferred from this feed.
