# AI pods

*Generated 16 August 2026, 17:42 from each pod's board, decision log and open
questions. Do not edit — run `python scripts/build_portfolio.py`.*

| Pod | Docs | Board items | Done | In progress | Blocked | Open questions | Decisions |
|---|---|---|---|---|---|---|---|
| [offer-allocation](offer-allocation/) | 23 | 19 | 0 | 1 | 0 | 22 | 9 |
| [retail-media](retail-media/) | 7 | 3 | 0 | 1 | 0 | 13 | 1 |

## Gates

| Pod | Gate A | Gate B | Gate C | Gate D |
|---|---|---|---|---|
| offer-allocation | in progress | not started | not started | not started |
| retail-media | in progress | not started | not started | not started |
