# Working agreement — for whoever (or whatever) implements here

## Before building
- Read `WORKING-AGREEMENT.md`, `features/BOARD.md`, `docs/00-README.md`, and the ticket.
- State your plan and your open questions BEFORE writing code. Wait for rulings on them.
- Conflict with a landed decision → STOP AND SURFACE. Never guess past it.

## While building
- One feature at a time, end to end: data → model → API → UI → the question answered.
- Each layer carries its own check inside the feature. No integration phase at the end.
- Numbers in reports are computed, never typed. Counts, totals and status come from the
  thing they describe.
- Refusal messages are built from the check that actually failed.
- Fixtures must be non-degenerate: a test that would pass on empty input proves nothing.

## Landing
- Judged commit: the suite is green on a frozen tree, or it does not land.
- Land together: code, tests, migration, the decision and its reason, the session log,
  and the regenerated index.
- Report: what landed, what it cost, what was decided and why, what is owed.
- Commit by pathspec — never `git add -A`.

## Honesty rules
- Say what is built, what is stubbed, and what is absent. Never describe a plan as a state.
- A green suite is necessary, not sufficient. If a deliberately broken calculation would
  still pass, the test is not evidence.
- A defect class that recurs becomes a mechanism — fix it in the tooling, once.
