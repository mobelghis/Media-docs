Produce the market and competitive context for this initiative (`docs/12-market-and-competitive-context.md`).

Read `docs/01-REQUIREMENTS.md` and `docs/13-personas-and-business-questions.md` first, then
research: who else solves this problem, how they approach it, what they are strong and weak at,
and where a credible difference exists for us. Use search where it helps and cite what you find;
say plainly when something is your judgement rather than a source.

Produce: the market shape in a paragraph · a table of "weakness in the field → what we would do
instead → which requirement" · what a buyer would need to believe to choose us · and the two or
three things that would make this initiative *not* worth doing. That last section is the valuable
one — write it honestly.
