I am the product owner and I want to work up a feature or change properly. Walk me through it.
Ask one thing at a time, and stop between stages — I decide whether to continue.

Read `docs/01-REQUIREMENTS.md`, `docs/07-open-questions.md` and `pod/DECISIONS.md` first so nothing
you produce contradicts what is already landed. If something does contradict, stop and surface it.

---

## Stage 1 · What is this?
Ask me which of these it is, and take only the branch that applies:

**(a) A change to something that already exists.** Ask me for: the URL of the page or report, a
screenshot of the part that changes, and a few sentences on what is wrong or missing. The
screenshot's visible labels are your search keys into the code — say so, so I know why you want it.

**(b) Something entirely new.** Ask me: who wants it, what they do today instead, and what they
would do with the answer. Skip the reverse engineering; go to Stage 3.

**(c) A new field, rule or number on an existing surface.** Ask for the surface and the rule in my
own words, then treat it as (a) but scoped to that surface.

Do not proceed until you can state, in one sentence back to me, what we are working on.

## Stage 2 · Reverse-engineer the current state — from the code, not from tickets
Only for (a) and (c).

**Read the actual repository.** The repositories this pod touches are listed in `pod/REPOS.yml`
with their URLs and local paths. Use whichever access you have — the repository checked out beside
this one, or a GitHub connector if one is available. **If you cannot reach the code, say so at the
top of the dossier and stop**; a description of the system assembled from ticket text or from
memory is worse than no description, because it will be trusted.

Do not use Jira or ticket descriptions as a source for how the system behaves. Tickets describe
what someone intended to build; only the code says what runs, and the two diverge whenever
something was scoped and then cut. Tickets are useful later, for *who else is working nearby* —
not for establishing behaviour.

Produce a dossier written so that a developer, or a later AI session, can act on it without opening
anything else:

- **The trace**: URL → route → front-end components → API calls → services → queries → tables. One
  row per hop, with file paths, **stamped with the commit you traced against**.
- **Steps to reproduce, on the front end**: how to reach that screen as a user, what state it needs
  (a wave in draft, a policy with a bank attached, a client with certain data), and what the screen
  shows in that state. This is what makes a later UI change safe to attempt.
- **The contracts**: what the front end sends and receives; what the back end passes to the model
  or the data layer and gets back; which of them are shared with other screens, and what breaks if
  the shape changes.
- **What it computes today**, precisely, including the parts that are wrong.
- **Consumers**: everything else that reads the same data or endpoint — the blast radius.
- **Permissions**: who can reach it, and how that is enforced.
- **Configuration**: which of its behaviour is retailer-configurable, and where those settings live.

Mark anything inferred rather than traced as **[verify]**. "This does not exist" is a valuable
finding — record it rather than assuming it must be somewhere.

## Stage 3 · Frame it as questions
Turn what I have said into business questions in a user's own words, each with an owner and what
they do with the answer. Show me the list and let me correct it. **Everything downstream is sliced
from these**, so we agree them before going further.

## Stage 4 · Optional passes — ask me which, do not assume
- **Market and competitor work** (`/market`) — how others solve this, where we would differ, and
  what would make this not worth doing.
- **Current-state PRD refresh** (`/prd`) — if the surrounding system has changed since the last one.
- **Data check** — what data this needs, whether it exists, and at what grain and freshness.

## Stage 5 · The panel — not optional for anything substantial
Run the personas in `pod/personas/` against what we have (`/panel`). Each reviews in their own
voice against their own standing. Return comments as **RULED** (unanimous, applies as a dated
delta) or **FOR DECISION** (mine, with the trade-off named). End with the panel's closing statement
including the risk it names. Do not resolve FOR DECISION items yourself.

## Stage 6 · Ideation, kept separate
Two short lists, clearly marked as **not part of the requirement**:
- **Low-hanging** — things that would add value inside what we already have, cheaply.
- **Further out** — more advanced capabilities this opens up later.

These inform the roadmap conversation. They must not leak into the requirement text, and you should
say so where they appear.

## Stage 7 · The requirement, and the epics
Produce:
1. A **requirements document** in this pod's shape: purpose, who it serves, the capability with
   what fails today and a **satisfied-when** line, cross-cutting requirements, dependencies, and
   open questions with owners. Land it in `docs/` at the next number.
2. **Suggested epics and stories**, one story per discipline that has real work (data science,
   data, back end, front end, design), each with the business problem, what happens today, scope,
   acceptance criteria, dependencies and any design note.
3. A **Jira import file** at `features/` in the same shape as the existing one — issue type, epic
   link, summary, description in Jira wiki markup, labels, component.
4. Any new **open questions**, into `docs/07-open-questions.md` with owners.
5. A **decision entry** recording what was settled here and why.

Then tell me what you could not answer, and what would settle it.

---

**Throughout:** dated amendments rather than silent edits · a decision without a because is not
landed · anything you inferred is marked `[verify]` · and if a stage produces nothing worth keeping,
say so instead of filling the section.
