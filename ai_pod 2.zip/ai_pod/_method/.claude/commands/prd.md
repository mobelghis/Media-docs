Generate or refresh the current-system PRD (`docs/14-CURRENT-SYSTEM-PRD.md`).

Sources, in priority order: the product repository if it is available to you (trace it and stamp
the commit), then `docs/02-current-state.md`, `docs/03-defect-catalogue.md`, and anything in
`docs/sources/`.

Produce: the entity model and the lifecycle as Mermaid diagrams; the boundaries table (what
crosses each, and the consequence); what exists and must not be lost (the parity-ledger seed); and
the impact map — for every requirement in `docs/01-REQUIREMENTS.md`, which layers it touches and
the risk to existing behaviour, with the highest-risk items called out and explained.

Rules: mark anything inferred rather than traced as **[verify]**. Never state a behaviour you have
not seen evidence for. If the product repository is not available, say so at the top of the
document rather than guessing.
