Run a panel review on whatever I name — the requirements, the design brief, a contract, or a plan.

Use the personas in `pod/personas/`, adding any this initiative needs. Give every persona the same
material. Each reviews in their own voice, against their own standing, and says what they would
refuse to accept.

Output: numbered comments grouped by persona; each marked **RULED** (unanimous, applies as a dated
delta on the artifact it changes) or **FOR DECISION** (the owner decides, with the options and the
trade-off named). End with the panel's closing statement, including the risk it names.

Do not resolve FOR DECISION items yourself. Route them to `docs/07-open-questions.md` with owners.
