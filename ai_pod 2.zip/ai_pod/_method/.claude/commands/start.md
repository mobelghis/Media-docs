Read `start/00-READ-ME-FIRST.md`, then ask me which discipline I am (data science, engineering,
product, or design). Read that discipline's file in `start/`, then read the documents it tells
you to read — `docs/01-REQUIREMENTS.md` first and in full — and run the kick-off prompt at the
end of that file. Do not write code and do not propose solutions yet: produce the artifact that
file asks for, and list anything in the requirements that is ambiguous as written.
