I am the product owner adding raw material to the pod. I will paste or point you at documents,
notes, emails, briefs, screenshots, URLs, or spreadsheets.

For each item: read it, then tell me — briefly — what it contains, which existing document in
`docs/` it belongs to, and what it changes. Do not merge anything yet.

Then, on my go, integrate it:
- New or changed requirements → a dated amendment section in `docs/01-REQUIREMENTS.md`, never a
  silent edit to the original text.
- New questions → the question register, each with an owner and an expected use.
- Constraints → `docs/04-non-negotiables.md` with an owner.
- Things needing an answer from outside the pod → `docs/07-open-questions.md` with an owner.
- Anything about how the current system behaves → `docs/14-CURRENT-SYSTEM-PRD.md`, marked
  **[verify]** unless it is traced from code.
- Raw source material → `docs/sources/` verbatim, with a one-line provenance note.

Tell me plainly what you did NOT integrate and why. Never invent detail to fill a gap — an
unanswered question is a valid output.
