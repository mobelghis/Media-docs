I am the product owner starting a new initiative. Interview me.

Work through these in order, one topic at a time, asking follow-ups until each is solid. Do not
write documents yet — this is a conversation, and I expect you to push back when an answer is
vague or when two answers contradict each other.

1. **The problem.** What is wrong today, for whom, and what does it cost them? Who complains, and
   what do they do instead?
2. **The users.** Who touches this, in what role, how often? What is each judged on?
3. **The questions.** What does each of them actually ask, in their own words? (These become the
   spine of everything — a capability that answers nobody's question does not get built.)
4. **What exists today.** Is there a current system, a manual process, a spreadsheet? Where does
   it live and can we read it?
5. **Constraints.** What is already decided and cannot change — platform, contracts, deadlines,
   regulation, data we cannot use?
6. **What "better" looks like.** How would we know this worked, six months in?
7. **Boundaries.** What is explicitly NOT in scope, and what is deferred with a condition that
   would bring it back?
8. **The team.** Which disciplines does this need? Is there a data-science question here at all,
   or is it product, engineering and design?

When we are done, summarise what you heard, list every contradiction and gap you noticed, and ask
me to resolve them. Then, on my go, run `/frame` to write the documents.
