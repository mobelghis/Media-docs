Produce the design brief and wireframe document for this programme (or, if I name one, for a
single requirement).

Read first: `docs/01-REQUIREMENTS.md`, `docs/08-FRONTEND-SURFACE-REQUIREMENTS.md` (which fields,
which screens), `docs/10-ENTITY-PLACEMENT.md` (which entity owns each field — it decides where a
field is authored versus merely shown), `docs/13-personas-and-business-questions.md` (whose
question each screen answers), `docs/14-CURRENT-SYSTEM-PRD.md` (what exists today), and the design
system or token definitions if they are linked.

Produce, per surface:
- the questions it answers, by Q-id or persona question
- the screen's job in one sentence
- a structural wireframe in text or simple markup — regions, what is in each, what the primary
  action is (exactly one), and what is deliberately absent
- which fields are new, which are fixed, and which entity owns each
- states: empty, loading, refused (with its reason), and insufficient-evidence
- links in and out — nothing is an island: name what reaches this screen and where every number
  and action leads

Then a short section on what you could not resolve and what decision would resolve it.

Rules: structure, not pixels. Token names only, never hardcoded colours or sizes. Exact values and
estimates must be visibly different. Every number opens. One primary action per screen. Anything
above about ten items is a table. Grey means insufficient evidence and nothing else.
