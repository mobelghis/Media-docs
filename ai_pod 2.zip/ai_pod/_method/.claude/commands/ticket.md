Draft the feature tickets for a signed I/O contract (I will name the contract or the question).

Inputs: the contract in `docs/`, the question register, `docs/08-FRONTEND-SURFACE-REQUIREMENTS.md`,
`docs/10-ENTITY-PLACEMENT.md`, the engineering non-negotiables, and the design brief if one exists.

For each ticket use `pod/templates/feature-ticket.md`: the question quoted from the register; data;
model/DS taken from the contract; API; UI; tests including the deliberately broken case; and the
done-when list. One ticket answers exactly one question, end to end.

Then check your own work and report: every question in the register that now has a ticket, every
ticket that maps to exactly one question, and any orphan in either direction. Orphans are the
finding — say so rather than inventing a mapping.

Add the tickets to `features/BOARD.md` as backlog rows, gated on Gate C. Do not build anything.
