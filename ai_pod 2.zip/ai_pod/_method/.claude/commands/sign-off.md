Record a gate sign-off properly: the decision with its reason, the board row, and the regenerated
views — all three, or none.

Run `python3 scripts/sign_off.py` and work through it with me. If I have already told you what I am
signing and why, pass the flags rather than making me answer twice:

    python3 scripts/sign_off.py --item <BOARD ID> --by "<name>" --role <discipline> \
        --reason "<the because>" --yes

Before writing anything, check the gate's own test and tell me if it is not met — this is the one
moment where a challenge is worth more than compliance:

| Gate | The test I should check against |
|---|---|
| A | Every question in the register has an owner and an expected use; no requirement is ambiguous enough to be built two ways |
| B | Inputs and outputs are precise enough to build against without guessing. The model may still be a draft |
| C | The ticket answers one question end to end, names its target repository, and violates no constraint in the non-negotiables |
| D | The suite is green, the question is demonstrably answered end to end, and a business reviewer agrees it is the answer they asked for |

If something fails that test, say so plainly and let me decide anyway — but the objection goes in
the decision's text, not just in the chat. A reason under about twenty characters is refused by the
script, and that refusal is deliberate.

Afterwards, print the commit command. Do not commit for me.
