Show me what I can do here, and what to do next.

Read `features/BOARD.md`, `pod/DECISIONS.md` and `docs/00-README.md` first so the answer is about
THIS pod's actual state, not a generic menu. Then reply with, in this order:

1. **Where this pod is right now** — one line: which gate is open, what is in progress, what is
   blocked and on whom.
2. **What I should probably do next**, given that state and which discipline I say I am (ask if it
   is not obvious). One recommendation, not five.
3. **The commands**, as a table — name, what it does, when to use it:

| Command | What it does | When |
|---|---|---|
| `/start` | Routes you by discipline and tells you what to read first | First day |
| `/help` | This. Where the pod is, and what to do next | Any time |
| `/intake` | Absorbs briefs, emails, exports, screenshots, URLs into the right documents | Whenever new material arrives |
| `/research` | The guided product-owner flow: current state → reverse engineering → optional market and competitor work → panel review → requirements → suggested epics | Starting a new feature or change |
| `/prd` | Generates or refreshes the current-system description and the impact map | Once early, then when the system changes |
| `/panel` | The expert personas argue with what you have written | Before anything is built |
| `/market` | Competitive context, including what would make this not worth doing | When positioning matters |
| `/contract` | Drafts or replaces an I/O contract (data science) | Gate B |
| `/design-brief` | Turns requirements into structural wireframes, states and links | Before the UI work |
| `/ticket` | Drafts feature tickets from a signed contract, then checks its own work | After Gate B |
| `/sign-off` | Records a gate sign-off: decision, board row and views in one step | At each gate |
| `/brainstorm` · `/frame` | Interview for a brand-new initiative, then write its opening documents | Greenfield only |

4. **The make targets**: `make index` (regenerate the views), `make plan` (timeline, dependencies,
   build order), `make sign-off` (the interactive sign-off).

5. **One reminder that fits the current state** — for example, if a gate is open with unowned
   questions, say so; if the board has items in progress with no recent decisions, say that.

Keep it short. If I ask "help" while mid-task, answer the task first and put the menu second.
