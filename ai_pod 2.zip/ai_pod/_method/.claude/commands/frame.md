Turn our brainstorm (and anything in `docs/sources/`) into the pod's opening documents. Write them
from what I actually said — where you have to infer, mark it **[assumed]** so I can correct it.

Produce:
1. `docs/01-REQUIREMENTS.md` — purpose, who it serves, the capabilities as R-1..R-n each with the
   requirement, what fails today, and a **satisfied-when** line; cross-cutting requirements;
   anything that must exist from day one or is lost forever.
2. `docs/13-personas-and-business-questions.md` — the users and their questions in their own words.
3. `docs/04-non-negotiables.md` — the constraints, each with an owner.
4. `docs/05-scope-boundary.md` — what this replaces, what it does not, and deferrals with the
   condition that would bring each back.
5. `docs/07-open-questions.md` — everything unresolved, each with an owner and what it blocks.
6. `features/BOARD.md` — the gate rows so the board is never empty.
7. `pod/DECISIONS.md` — D-1 recording that this initiative exists and why, with its reason.

Then tell me what you could not answer from the brainstorm, and what I need to find out.
