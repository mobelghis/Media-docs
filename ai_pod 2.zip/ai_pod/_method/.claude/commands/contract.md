Read `docs/09-PROPOSED-IO-CONTRACTS.md` and `pod/templates/io-contract.md`. I will name a
contract (C-1..C-5) or a new quantity. Draft or revise that I/O contract to the template's
shape: inputs with their grain and source, outputs with type/range/meaning and what is returned
when the answer cannot be supported, method with parameters named as parameters, assumptions,
validation including a deliberately broken case, and an explicit "not yet known" section.
Where the proposed contract in docs/09 is wrong, say so and replace it — it is a draft to argue
with, not a specification to comply with.
