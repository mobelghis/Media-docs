---
name: frontend-conventions
description: How the existing Angular offer-management application is actually built — metadata-driven forms, the generic constraint model, permissions, the 127 ceiling, and the patterns to extend rather than replace. Use whenever specifying, designing or building any front-end change to the current product.
---

# The front end as it actually is

Claude already knows Angular. This carries what it cannot know: how **this** application is put
together, and which patterns to extend rather than replace.

## Forms are retailer-metadata-driven
Field visibility, requiredness, labels and options come from configuration (`fromMetaData.<field>`:
`hide`, `required`, `options`, `labelTranslate`). **Any new field must join that system** or it
cannot be turned on and off per retailer like everything else on the screen. A field that ignores
this is a field that cannot ship to a client who does not want it.

## The marketing policy editor
Three collapsible sections:
- **General** — name, description, coupon bank, eligibility segment, campaign control %, control
  offers, offer-control and default-offer toggles, delivery channels.
- **Campaign Strategy** — coupons per shopper, per brand, per in-house brand (min/max each); and
  **Frequency Criteria** — an allocations threshold and a period in days. **That is chilling today.**
- **Segment Strategy** — a generic constraint model: tabs by constraint **type**, collapsible
  panels per constraint **value**, and a min/max row per **segment**.

That last one is the important pattern: `type × value × segment → min/max` already exists. New
constraint kinds extend it; they do not need a new rule builder.

## The coupon editor
Coupon type is already SKU / Catalog / **Virtual Category** (behind a permission). The product
picker already filters by CPG, brand and category, offers a searchable checkbox list with
select-all, exports CSV and imports a SKU list with parent detection. What it lacks is **excludes**
and **dynamic re-resolution**.

## Constraints inherited by anything new
- **Every min/max is capped at 127** (`Byte.MAX_VALUE`) in the wave-template DTOs. A new limit
  inherits that unless a decision changes it — raise it, do not assume it.
- **Permissions gate whole capabilities**, not just menu items. Check which permission governs a
  surface before assuming a user can reach it.
- The policy DTOs are shared by create, update, metadata and response paths, plus merge logic that
  lets existing templates pick up newly added constraint types with empty values. A new type must
  keep that merge working.

## Density is a real constraint
Segment Strategy can hold hundreds of min/max pairs across its tabs. Adding another section is
cheap to build and expensive to use. Where a change makes the screen denser, say so, and put the
density problem in front of design rather than solving it by adding rows.

## When something is unclear
The recreation guide and the code are the source; this skill is a summary. Anything not traced is
marked `[verify]` rather than asserted.
