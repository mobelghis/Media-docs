---
name: pod-method
description: How work moves in this pod — the six stations, the four gates, what a feature is, and what may never be guessed past. Use whenever planning work, deciding what to build next, slicing features, drafting tickets, or when asked what happens next.
---

# The pod method

## The unit of work
A **feature** is the smallest testable, deployable unit that answers **one business question**,
built end to end: data -> model -> API -> UI -> the question answered. Pages are not features;
technical tasks are not features. A ticket that cannot name its question is not ready.

## The six stations
1. **Frame the questions** — business questions in users' words + the current-state dossier.
2. **Define the method** — data science answers "how is this computed?".
3. **Slice into features** — one ticket per feature, all layers inside it.
4. **Build the slice** — layer by layer, each carrying its own check.
5. **Ship and measure.**
6. **Learn** — findings become new questions.

## The four gates — the only places work changes hands
| Gate | Signed by | The test |
|---|---|---|
| A | Product | Every question has an owner and an expected use |
| B | Data science | Inputs and outputs precise enough to build against. **The model may still be a draft** |
| C | Product + DS + Engineering | One question, end to end, violating no constraint. The build gate |
| D | Product, with engineering | Green suite - question demonstrably answered - business agrees |

Nothing is built before Gate C. After it, the build proceeds without asking again.

## Rules that hold everywhere
- **Stop and surface.** Anything conflicting with a landed decision stops the work and is raised
  as a question. Never guess past a gate; never work around a landed decision quietly.
- **Plan before building.** State the approach and the open questions, and wait for rulings.
- **One feature per track.** Parallel tracks only when they touch different subsystems and share
  no contract.
- **Tiered verification.** Scoped tests per feature; the full suite at phase boundaries and before
  any claim that something is green.
- **A dependency that does not exist is named, never faked.**

## Before answering "what next?"
Read `features/BOARD.md` — it governs; the folders only mirror it. Never restate a set of items
from memory when a file lists them: reference the source.
