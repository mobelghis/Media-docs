---
name: reverse-engineering
description: How to produce a current-state dossier — tracing a screen or report from its URL down to its tables, mapping consumers and blast radius, and marking what is inferred rather than traced. Use whenever describing how the existing system works, assessing the impact of a change, or generating a PRD of what exists.
---

# Reverse engineering the current state

## The trace
Start from what a user can see and work inward:

`URL / route -> front-end components -> API calls -> services -> queries -> tables`

One row per hop, with file paths. Screenshot labels are search keys: the visible text is what
identifies the right component when names in code differ from names on screen.

## Always include
- **The permission chain** on the route — who can reach it and how that is enforced.
- **Consumers** — everything else that reads the same quantity. This is the blast radius for any
  change, and it is the section people actually use.
- **What it computes today**, stated precisely, **including the parts that are wrong**. A dossier
  that describes intended behaviour is worse than none.
- **Defects observed**, each with what it causes.

## The source is the code
Read the repository. `pod/REPOS.yml` lists which repositories this pod touches and where they are.
**Never establish behaviour from ticket descriptions, specifications or memory** — those describe
what someone intended, and intent and behaviour diverge whenever something was scoped and then cut.
If the code cannot be reached from this session, say so at the top of the document and stop.

## Honesty rules
- **Stamp the commit** the trace was made against. A dossier without a commit is folklore.
- Mark anything inferred rather than traced as **[verify]**. Never state a behaviour you have not
  seen evidence for.
- If the code is not available to you, say so at the top of the document instead of guessing.
- "This does not exist" is a valuable finding — record it rather than assuming it must be
  somewhere.

## Keeping it true
Regenerate rather than hand-edit. When the traced paths change in the product repository, the
dossier is stale and is refreshed deliberately — the record rots silently otherwise.
