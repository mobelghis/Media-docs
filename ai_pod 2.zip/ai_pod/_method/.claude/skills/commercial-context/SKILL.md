---
name: commercial-context
description: How supplier funding, commitments and costs actually work in this business — pools, minimums, cost models, fiscal attribution, and the obligations the system is expected to honour. Use whenever work touches budgets, supplier commitments, pricing, cost estimation or anything money-denominated.
---

# Commercial context

Retail personalization is largely **supplier-funded**. That single fact shapes most of the hard
requirements: the money is committed in advance, to a named supplier, for a period, and the system
is expected to deliver against it.

## Commitments and minimums
- A commitment is a promise to a supplier — typically a volume of issued offers, sometimes a spend.
- **Minimums are counted in issued coupons unless the contract says otherwise**, and the counting
  rule is stated **per pool** rather than assumed globally.
- Missing a minimum is a commercial event, not a technical one. It is why feasibility must be
  provable before a wave runs, and why "infeasible" and "failed to find" are different verdicts.

## Funding pools and cost models
- Cost is attributed to a **funding pool** with a stated cost model — issuance-denominated or
  redemption-denominated.
- The cost model belongs to the pool and is **never overridable per offer**; otherwise the same
  spend is counted two ways.
- **Test and control arms never debit a pool.** A holdout that costs a supplier money is
  indefensible.

## Fiscal attribution
A coupon issued in one fiscal year and redeemed in the next needs an explicit rule, agreed with
finance. The ledger carries both the issuance period and the event period so either view can be
produced without re-deriving.

## What finance needs from the system
Total, consumed, committed, remaining and forecast — per supplier, per period — reconciling to the
coupons actually issued. Adjustments are recorded with a reason and an author, never overwriting
history. An append-only ledger is the only structure that survives an audit.

## Selling what can be delivered
Commitments are sold before the system is asked whether they are possible. Sales-time feasibility
and pricing exist to stop that gap widening — and any estimate given at sales time carries its
uncertainty, because a point estimate becomes a promise the first time it is quoted.

## Why honesty is commercially useful here
Buyers in this market are used to measurement they cannot verify. Reporting what cannot be
supported as unsupported is a differentiator, not a weakness — several buyers have said value-linked
pricing would only be credible if the measurement is honest.
