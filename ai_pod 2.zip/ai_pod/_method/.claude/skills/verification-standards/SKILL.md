---
name: verification-standards
description: What counts as evidence here — planted-truth tests, mutation proofs, non-degenerate fixtures, honest power reporting, and the demo that joins the definition of done. Use whenever writing tests, claiming something works, reviewing a result, or deciding whether a feature is finished.
---

# Verification standards

**A green suite is necessary, not sufficient.** These rules exist because each was paid for by a
defect that a green suite did not catch.

## Planted truth
Where a computation claims an effect, a simulator injects a **known** effect the pipeline must
recover — and a null case that must stay null. A test that only checks the code runs proves that
the code runs.

## Mutation proof
Deliberately break the calculation. If the suite still passes, the suite is not evidence. Every
computational feature carries at least one mutation proof in its definition of done.

## Non-degenerate fixtures
A fixture must actually exercise the thing under test. An exclusion test where the excluded set is
empty compares zero to zero and passes forever. Assert the planted subset is **non-empty and
strict** before asserting the outcome.

## Honest reporting of uncertainty
- Results below the stated power threshold are reported as **underpowered**, never as effects.
- Estimates carry their intervals; exact values and estimates are visibly different.
- Grey (or its equivalent) means "not enough evidence" and is reserved for that meaning.

## Freshness by content, not metadata
A cached, resumed or replayed computation proves its inputs match — by fingerprint of the source,
not by a timestamp or a parameter. Metadata that agrees while content differs is the failure mode.

## Demo as done
A human-readable run — a command whose output a person can read — is part of the definition of
done. Defects that tests miss are routinely caught by reading what the thing actually prints.

## Escalation
A defect class that recurs after being raised becomes a **mechanism**: fixed once, in the tooling,
so it cannot recur. Record it where the tooling lives, not only in a session log.
