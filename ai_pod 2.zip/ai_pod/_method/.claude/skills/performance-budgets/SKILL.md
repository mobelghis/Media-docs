---
name: performance-budgets
description: How this programme keeps a long allocation run inside its window — runtime budgets per rule, precompute once versus per-pair, pruning before scoring, and measuring rather than estimating. Use whenever adding a rule, a filter or a computation to the wave run, or reviewing one.
---

# Runtime budgets

The wave has a fixed window. Every rule added spends part of it, so cost is a property of the
ticket, not a discovery made at scale.

## Every rule states its cost
A rule story carries a runtime claim — "adds no more than X% at N offers" — and the claim is
**measured, not estimated**. That is an acceptance criterion, not a nice-to-have. It finds the
problem at ticket time rather than when four rules are assembled at ten thousand offers.

## Precompute once, look up per pair
The difference between cheap and ruinous is almost always where the expensive part happens:

| Rule | Ruinous | Cheap |
|---|---|---|
| Exposure / chilling | query history per candidate pair | build a per-shopper structure once per wave, then look up |
| Blocking | compare product sets per shopper | compute coupon-to-coupon overlap once, then test membership |
| Availability | check items per shopper | build offer × store availability once, then one lookup via the shopper's store |

The rule of thumb: if the work depends only on offers, coupons or stores, it belongs **once per
run**. Only the final lookup should scale with shoppers.

## Hard constraints run before scoring
A pair eliminated by a hard constraint can never be allocated, so scoring it is work thrown away.
Applying eliminating rules **before** the scoring stage shrinks what the expensive step processes —
which is how new rules can be added without the run getting slower.

**The exception:** anything that depends on what a shopper has already been given in this run —
category limits, per-shopper slot limits — can only resolve during assignment. Do not promise
otherwise.

## Measure the right thing
- Report added runtime against a stated offer and shopper volume, not against a convenient sample.
- Count what is scored versus what is allocated: a large gap is wasted work and a target.
- Synthetic benchmarks that do not reproduce real catalogue structure will understate cost. Say so
  where a number comes from a synthetic run.

## When a rule cannot fit
Say it plainly and early. A rule that cannot meet its budget is a design conversation, not a
failure to be absorbed quietly at the end of the increment.
