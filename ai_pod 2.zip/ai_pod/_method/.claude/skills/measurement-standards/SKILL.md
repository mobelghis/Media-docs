---
name: measurement-standards
description: What this programme will and will not claim about effect — estimands, randomised arms, ghost logging, power thresholds, interference, and the artifacts that can only be captured while a wave runs. Use whenever designing, implementing or reporting anything about lift, uplift, incrementality or campaign impact.
---

# Measurement standards

## The four irreversibles
These can only be captured while a wave runs, and no later work recovers them:
1. **Randomised arms** — properly randomised, implemented **separately** from any stratification or
   targeting logic, and deterministic from the wave seed.
2. **Ghost logging** — for a held-out shopper, what they *would* have received. Without it, only
   programme-level effect is computable; per-offer effect is lost.
3. **Frozen eligibility snapshot** per wave — who was eligible at decision time, in a compact form.
4. **The seed and frozen parameters** — what the wave decided from.

A wave that runs without these is permanently unmeasurable by anything better than a model.

## The outcome is purchase, not redemption
Redemption measures coupon use. The business question is whether the programme changed what people
bought. Measure purchase of the offer's product set; report redemption separately as a mechanic.

## Underpowered is a verdict
A result below its power threshold is reported **as underpowered**, never as an effect and never
coloured as one. Estimates carry intervals. Exact counts and estimates must be visibly different
wherever both appear.

## Say which estimand
"Lift" is several different quantities: versus no offer, versus the next-best alternative, versus
no programme at all. State which one, and against what counterfactual, before reporting a number.

## Interference is real here
Per-shopper caps mean holding a shopper out of one offer changes which other offers they receive.
Offers sharing products make attribution ambiguous. Both must be handled by the **design**, not
assumed away in the analysis.

## Reproducibility
Any past wave must re-measure to the same numbers from its frozen inputs. If a re-run gives a
different answer, the difference is a defect, not a nuance.

## Verification that counts
Planted-effect recovery — a known injected effect must be recovered, and a null must stay null.
A deliberately broken calculation must fail the harness. A green suite that cannot detect breakage
is not evidence.
