---
name: design-gate
description: The rules every screen and generated interface must satisfy — token-only styling, exact-versus-estimated, refusals with reasons, required states, tables versus charts, one primary action. Use whenever designing, generating or reviewing any user interface in this pod.
---

# The design gate

Structure and honesty are checked; taste belongs to design.

## Non-negotiable
- **Token-only styling.** No hardcoded colours, spacing or type values anywhere. A design system
  change must be a configuration change, never a rewrite.
- **Exact and estimated are visibly different.** Counts are exact; response, cost and effect are
  estimates and carry their interval. A user must never have to guess which they are reading.
- **Every number opens** to what produced it.
- **A refusal states its reason, with numbers** — which rule, what threshold, what was observed.
- **Nothing that spends money commits without an explicit action** on a screen showing what will
  happen.
- **One primary action per screen**, everything else secondary.
- **Collections above about ten items are tables** — sortable, exportable. Every chart has a table
  twin.
- **Grey means "not enough evidence"** and nothing else.

## Every surface needs four states
Empty (with its next action) - loading (as a first-class surface, with an honest estimate) -
refused (with its reason) - insufficient evidence (rendered as such, never as a value).

## Every surface declares its links
What reaches it, and where every action and number leads. No orphan screens, no dead-end drills.

## Where a field belongs
Consult the entity placement document before adding a field: a value that must freeze belongs to
the execution; a rule that many executions obey belongs to the policy; intent spanning executions
belongs to the campaign. A field is **authored** in one place and **shown** in others.

## Every screen cites its questions
A surface that answers no question does not get built; a question with no surface is an
unfinished design.
