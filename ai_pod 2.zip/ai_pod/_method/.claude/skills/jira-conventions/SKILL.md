---
name: jira-conventions
description: How work is expressed in Jira for this programme — epic and story shape, the fields that matter, the import format, labels and phases, and the one-way relationship between the board and Jira. Use when drafting epics or stories, preparing an import, or reconciling the board with Jira.
---

# Jira conventions

## The board governs; Jira is a view
Work is defined, prioritised and tracked in the pod. Jira is a **one-way projection**, refreshed
when a feature lands. Status is never read back, and a feature invented in Jira is not a feature
until it enters the pod as a question. Two editable places for one fact is the drift this method
exists to remove.

## Board rows use real Jira keys
Once an epic exists in Jira, the board row carries its key. New epics the pod proposes carry a
placeholder (`XXX-1`, `XXX-2`…) until they are created, then the real key replaces it everywhere —
the board, the story file and any document that references it.

## Epic shape
Follow the existing epics in this programme: **business objectives · scope · out of scope ·
acceptance criteria · why now**. "Out of scope" matters most on foundation epics, which attract
work; "why now" matters most on anything whose value is not visible in the current increment.

## Story shape
One story per discipline that has real work — data science, data, back end, front end, design.
Each carries:
- **Business problem** — why this exists, in business terms
- **What happens today** — the specific current behaviour
- **Scope** — bullets, concrete enough to build against
- **Acceptance criteria** — checkable, behavioural, including what happens when data is missing
- **Depends on** · **Blocked until answered** · **Design note**, where each applies

Where a story is blocked on a decision nobody has made, say so in a **Blocked until answered**
section rather than inventing the answer.

## The import file
`features/JIRA-IMPORT-stories.csv`, columns: `Issue Type · Epic Link · Phase · Summary ·
Description · Labels · Component`. Descriptions use Jira wiki markup (`h3.` headings, `*` bullets).
Labels carry the phase and the discipline. Never import a file that still contains placeholder
epic keys.

## Fields that matter here
`Modules`, `Parent Link`, `PI / Quarter`, `Customer`, `Generic`, `Customer facing change`,
`UX Required`, and the WSJF fields. A proposed epic should state a suggested PI rather than leaving
it blank — an unscheduled epic is invisible in planning.

## What is never projected to Jira
Decisions and their reasons, contracts, the record, open questions, session logs, evidence. A link
from the epic to the pod is enough. If someone asks for status, send them the generated PMO view.
