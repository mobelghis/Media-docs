---
name: product-requirements
description: How this pod writes requirements, questions and amendments — satisfied-when lines, questions in the user's own words, dated amendments, and the difference between a requirement and a constraint. Use whenever writing or revising a requirement, a question register, a scope boundary or a priority list.
---

# Writing requirements here

## A requirement has three parts, always
1. **The requirement** — what the system must do, in one or two sentences.
2. **What fails today** — the specific current behaviour, not a general complaint.
3. **Satisfied when** — the acceptance target. If it cannot be checked, it is not written yet.

"Satisfied when" describes the **end state**, not the current increment. A requirement may be
partly satisfied in one phase and completed later; the phasing lives in the trace, not in the
requirement text.

## Questions, not features
Features are sliced from questions, so the question register sets the shape of the whole build.
A question is written **in the user's own words**, with who asks it and what they do with the
answer. Two judge rules:
- **No question without a surface** once design is signed.
- **No surface that answers no question.**

If something does not resolve into a user-facing question, it is probably a **constraint** — it
belongs in the non-negotiables, not the register.

## Amendments, never silent edits
A claim that others have read is never quietly changed. Add a dated amendment section; the original
stays visible beside its correction. This applies to requirements, scope, contracts and reports
alike. The history of what was believed when is part of what makes the record trustworthy.

## Deferral is a decision with a condition
"Out of scope" on its own rots. Every deferred item names **the condition that would bring it
back** — and, once it exists, the epic or ticket where it now lives.

## Open questions
Every open question has an **owner** and states **what it blocks**. An open question with no owner
is not open, it is ignored. When it is answered, it moves to a closed section with its answer and
the date — it is not deleted, because the answer is often the most useful part.

## What not to write
- Solutions. A requirement says what must be true, not how.
- Estimates. Sizing belongs to the pod, not the specification.
- Invented specifics to fill a template. An empty section is more honest than a plausible one.
