# Skills

Loaded automatically when the work matches, so the pod's rules hold whether or not anyone
remembers to invoke them. Commands (`.claude/commands/`) are typed; skills are ambient.

## Method — how this pod works
| Skill | Fires when |
|---|---|
| `pod-method` | planning work, slicing features, drafting tickets, deciding what is next |
| `record-keeping` | writing or changing any document, recording a decision, reporting a landing |
| `panel-review` | pressure-testing a design, a requirement set, a contract or a plan |
| `product-requirements` | writing requirements, questions, scope boundaries, amendments |
| `jira-conventions` | drafting epics or stories, preparing an import, reconciling the board with Jira |

## Building — what we build against
| Skill | Fires when |
|---|---|
| `stack-conventions` | writing or reviewing code, choosing a library, designing an interface between layers |
| `frontend-conventions` | specifying, designing or building any change to the current Angular application |
| `performance-budgets` | adding a rule, filter or computation to the wave run, or reviewing one |
| `verification-standards` | writing tests, claiming something works, judging whether a feature is done |
| `reverse-engineering` | describing how the existing system works, assessing blast radius |
| `design-gate` | designing, generating or reviewing any interface |

## Domain — what we cannot look up
| Skill | Fires when |
|---|---|
| `measurement-standards` | anything about lift, uplift, incrementality or campaign impact |
| `commercial-context` | budgets, supplier commitments, pricing, cost estimation, anything money-denominated |
| `competitive-analysis` | market research, positioning, or any material making a commercial claim |
| `domain-knowledge` | **stub — fill this in.** The platform's vocabulary, data model and traps |

## What does not belong here
Role-playing skills — "act as a Java developer", "act as a designer" — add nothing. The model
already writes Java, React and Python and already knows design practice. What it cannot know is
**our** vocabulary, **our** data model, **our** rulings and **our** conventions, which is what the
skills above carry.

The test for a new skill: *would a competent new hire need to be told this, and would they get it
wrong otherwise?* If yes, it is a skill. If it is general professional knowledge, it is not.

## The one to complete first
`domain-knowledge/` is still a stub. Filling it in — the data model, the vocabulary, the joins that
look correct and are not, what does not exist — is worth more than every other skill here combined,
because it is the context every session would otherwise rebuild from scratch.
