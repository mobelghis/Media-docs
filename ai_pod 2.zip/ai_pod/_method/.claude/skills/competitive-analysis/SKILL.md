---
name: competitive-analysis
description: How this pod does market and competitor work — what to look for, how to state a difference honestly, and the section most analyses leave out. Use when researching how others solve a problem, positioning a capability, or preparing material that makes a commercial claim.
---

# Competitive analysis, done honestly

## What the analysis is for
Not to prove we should build something. To find out **what is already solved**, where a real
difference exists, and what would make the work not worth doing. An analysis that only supports the
plan was not an analysis.

## The shape
1. **The market in a paragraph** — who serves this problem today and how they approach it.
2. **A table: weakness in the field → what we would do instead → which requirement it maps to.**
   A weakness with no requirement behind it is an observation, not a strategy.
3. **What a buyer would have to believe** to choose us — stated as beliefs, because that is what
   sales has to establish.
4. **What would make this not worth doing** — the section most analyses omit, and the most useful
   one. Write it honestly.

## Rules
- **Cite what you find, and say when something is judgement.** A confident sentence about a
  competitor's roadmap, unsourced, is a liability.
- **Distinguish what a competitor claims from what they demonstrate.** Marketing pages are
  evidence of positioning, not capability.
- **Do not translate a weakness into a promise.** "They cannot prove incrementality" becomes "we
  will report power and intervals" — a described behaviour, not a superiority claim.
- **Check whether the weakness is deliberate.** Some gaps are choices; a competitor may have
  decided that market is not worth serving, and they may be right.

## Personas over pitches
Where possible, test the position against the buyer personas rather than an abstract market: what
would this specific buyer refuse to accept, and what would make them switch? A panel review of a
positioning claim is worth more than another feature comparison.
