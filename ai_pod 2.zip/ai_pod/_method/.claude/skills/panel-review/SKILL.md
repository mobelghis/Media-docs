---
name: panel-review
description: How to run an expert panel review — the ceremony, the persona rules, and how verdicts become dated deltas or decisions with owners. Use when asked to review a design, a requirement set, a contract, a plan, or to pressure-test anything before it is built.
---

# Running a panel review

A panel is how work gets argued with before it is built. It is a ceremony, not a vibe check.

## The rules
1. **State what is being reviewed** and what a "no" would mean.
2. **Every persona sees the same material.** No private briefings, no pre-agreement.
3. **Each reviews in their own voice, against their own standing** — the merchant cares about
   category economics, finance about defensibility, the practitioner about throughput, the
   experience principal about whether it can be used at all. A persona that agrees with everything
   is not being used properly.
4. **Every comment is numbered** and marked:
   - **RULED** — unanimous; applies as a dated delta on the artifact it changes.
   - **FOR DECISION** — the owner decides; state the options and the trade-off, and do not resolve
     it yourself.
5. **Deltas are routed, not applied invisibly**: comment → the artifact it changes → the track that
   owns it. Nothing jumps a gate because a panel liked it.
6. **The closing statement goes on the record**, including the risk the panel names. A review with
   no named risk was not a review.

## What personas are for
Pressure, not permission. Their job is to find what the authors are too close to see: the
unstated assumption, the screen nobody could use on a Monday morning, the number that would not
survive an auditor.

Personas live in `pod/personas/`. Add ones this initiative needs — and give each a standing, what
they judge, and what they will not accept.

## What comes out
Dated deltas on the artifacts, decisions with reasons in the decision log, and open questions with
owners for anything the panel could not settle. Never a summary that changes nothing.
