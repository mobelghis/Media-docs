---
name: domain-knowledge
description: Placeholder for this platform's domain facts — the data model, table and field names, the business vocabulary, and how core entities relate. Fill this in from the team's existing material; it is the highest-value skill in the repository.
---

# Domain knowledge — TO BE FILLED IN

This is deliberately a stub, and it is the single most valuable file to complete. Everything else
in this repository is method; this is the part that stops every session from re-deriving what the
team already knows.

## What belongs here
- **The vocabulary**, with each term's precise meaning — especially where the same word means
  different things to different teams.
- **The data model**: the tables that matter, their grain, their keys, and the joins that are
  correct (and the ones that look correct and are not).
- **Field-level traps**: values that are frequently null, columns that mean something other than
  their name, units and currencies, time zones, effective-dating.
- **Entity relationships** at the level a newcomer needs to reason without opening the schema.
- **What does not exist** — the absences people assume are present.

## How to fill it
If the team already maintains this knowledge — a data-model document, an internal wiki page, an
existing skill — copy it in here rather than rewriting it, and note where it came from so it can
be refreshed. Splitting it into several skills (one per subject area) is fine and often better.

## Why it lives in the repository
So it travels with the work: every session in this repo has it, nobody pastes it into a prompt,
and when it is wrong it gets fixed once, in a place that has a history.
