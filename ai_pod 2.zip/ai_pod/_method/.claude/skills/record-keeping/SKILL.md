---
name: record-keeping
description: How to write into this repository — decisions with their reasons, dated amendments instead of silent edits, session logs, landing reports, and the rule that numbers are computed rather than typed. Use whenever writing or changing any document, recording a decision, or reporting what landed.
---

# Record-keeping

The repository is the memory. If it only exists in a conversation, it does not exist.

## Decisions
Every decision lands in `pod/DECISIONS.md` with: what was decided - **because** (the reason) -
what it supersedes, if anything - what must now be true elsewhere.
**A decision without a because is not landable.** A superseded decision is never deleted — the
new one names it, so the history of what was believed when stays readable.

## Corrections
Never silently edit a claim that has been read by others. Add a **dated amendment** section; the
original stays visible beside its correction. This applies to requirements, contracts,
methodology and reports alike.

## Numbers
Counts, totals and status are **computed from the thing they describe, never typed**. A hand-typed
count is a claim that will eventually be wrong, and it will be wrong silently. The same rule
applies to completion claims: derive them from the board rows, never from memory of what was done.

## Refusals and honesty
- State what is built, what is stubbed, and what is absent. Never describe a plan as a state.
- A refusal message is built from the check that actually failed — never a template beside it.
- A result that cannot be supported is refused, not softened.

## Session logs and landing reports
A session log records: the goal - decisions with reasons - **deviations, never smoothed away** -
defects found including in our own work - what is owed next.
A landing report records: what landed - the verification result on a frozen tree - decisions
recorded - deviations - what is still open, **verbatim**, not summarised away.

## Commits
By pathspec, never `git add -A`. Every commit in any repository carries its feature id, and the
ticket records the repository and commit that landed it.
