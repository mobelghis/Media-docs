# How this pod works

## The stations and gates
See `pod/PIPELINE.md`. Four gates, all human:
- **A — questions signed** (product). Every question has an owner and an expected use.
- **B — I/O contract signed** (data science). Inputs, outputs, assumptions defined; the
  model may still be a draft.
- **C — tickets approved** (product + data science + engineering). The build gate.
- **D — feature accepted**. Suite green, question answered end to end, business agrees.

## The record
- `docs/NN-name.md`, numbered in landing order, never renumbered.
- Corrections are dated amendment sections, not edits to the original claim.
- Decisions live in `pod/DECISIONS.md` with a D-number, a date, and a because.
- Open questions needing someone outside the pod live in `docs/` with named owners.

## The rhythm
- Morning: each discipline on its own thread.
- Midday: the gate window — plan checkpoints, ticket reviews, sign-offs.
- Afternoon: build and review; features land as they finish.
- End of day: the landing report, which is tomorrow's starting context.

## Cadence
- One feature in flight per build track. Two or three tracks only when they touch
  different subsystems and share no contract.
- Scoped tests per feature; the full suite at phase boundaries and before any seal.
