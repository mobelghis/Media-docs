#!/usr/bin/env python3
"""
Build the AI-pod record index: a static, self-contained browser for the project record.

Run from the ai_pod root:      python scripts/build_index.py
Or point it anywhere:          python scripts/build_index.py --root . --out _index

Everything on the page is derived from the tree at build time. Nothing is typed by hand,
so adding or deleting a document changes the index the next time this runs.
Standard library only.
"""
from __future__ import annotations
import argparse, datetime as dt, html, os, re, subprocess, sys
from pathlib import Path

# ---------------------------------------------------------------- sections
# (path prefix, section id, title, what this part of the record is for)
SECTIONS = [
    ("docs",            "record",    "The record",   "Requirements, current state, defects, constraints, evidence and open questions."),
    ("start",           "start",     "Start here",   "One kick-off file per discipline, with a paste-ready first prompt."),
    ("pod/personas",    "personas",  "Personas",     "The expert voices that pressure-test the work, and how a panel session is run."),
    ("pod/templates",   "templates", "Templates",    "The forms the pod fills in: intake artifacts, the I/O contract, the feature ticket, the logs."),
    ("pod",             "method",    "The method",   "How the pod works: the pipeline, the principles and the decision log."),
    ("features",        "board",     "The board",    "Feature specs and status. BOARD.md governs; the folders mirror it."),
    ("service",         "service",   "The service",  "The deployable and its installation."),
    ("scripts",         "scripts",   "Scripts",      "Tooling the record depends on, including this generator."),
    ("assets",          "assets",    "Assets",       "Screenshots and diagrams referenced by documents."),
]
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "_index", ".pytest_cache", "dist", "build", ".mypy_cache"}
DOC_EXT = {".md", ".txt"}

# ---------------------------------------------------------------- palette
CSS = """
:root{
  --ink:#14181F; --paper:#FAF8F3; --card:#FFFFFF; --navy:#101826; --navy2:#1B2434;
  --gold:#A8801B; --gold-l:#E3C96B; --teal:#146553; --teal-l:#E4EFEB; --clay:#A2481F;
  --slate:#6B747F; --hair:#E2DED4; --hair2:#EFEBE2;
  --mono:ui-monospace,"SF Mono",Menlo,Consolas,monospace;
  --sans:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  --display:Georgia,"Iowan Old Style","Times New Roman",serif;
  --shadow:0 1px 2px rgba(16,24,38,.04),0 8px 24px rgba(16,24,38,.06);
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--paper);color:var(--ink);font-family:var(--sans);font-size:15px;line-height:1.55;-webkit-font-smoothing:antialiased}
a{color:inherit}
a:focus-visible,input:focus-visible{outline:2px solid var(--teal);outline-offset:2px}
.wrap{display:grid;grid-template-columns:290px minmax(0,1fr);min-height:100vh}

/* rail */
.rail{border-right:1px solid var(--hair);background:#FFFDF9;position:sticky;top:0;height:100vh;overflow:auto;padding:0 0 60px}
.rail-head{padding:22px 20px 16px;border-bottom:1px solid var(--hair);background:var(--navy)}
.mark{font-family:var(--mono);font-size:10px;letter-spacing:.18em;color:var(--gold-l);text-transform:uppercase}
.rail-title{font-family:var(--display);font-size:20px;font-weight:700;margin:8px 0 2px;color:#fff;line-height:1.2}
.rail-sub{font-family:var(--mono);font-size:10px;color:#8C97A6}
.navlinks{display:flex;flex-wrap:wrap;gap:6px;padding:12px 14px 6px}
.navlinks a{flex:1 1 28%;text-align:center;padding:7px 6px;border:1px solid var(--hair);border-radius:6px;font-size:11.5px;font-weight:600;text-decoration:none;color:var(--slate);background:#fff}
.navlinks a.on{background:var(--navy);color:#fff;border-color:var(--navy)}
.roles{padding:10px 12px;display:flex;flex-direction:column;gap:8px}
.role-card{display:block;position:relative;padding:11px 34px 11px 13px;border:1px solid var(--hair);border-radius:9px;background:#fff;text-decoration:none;color:inherit}
.role-card:hover{border-color:var(--navy)}
.role-card.on{border-color:var(--navy);background:var(--hair2)}
.role-card-title{font-size:12.5px;font-weight:650;color:var(--navy);letter-spacing:.01em}
.role-card-blurb{font-size:11px;color:var(--slate);margin-top:3px;line-height:1.4}
.role-card-count{position:absolute;top:11px;right:11px;font-family:var(--mono);font-size:10px;color:var(--slate);background:var(--hair2);padding:1px 7px;border-radius:9px}
.role-card.on .role-card-count{background:var(--navy);color:#fff}

/* main */
main{padding:0 0 90px;max-width:1240px}
.hero{padding:40px 44px 26px;border-bottom:1px solid var(--hair)}
.eyebrow{font-family:var(--mono);font-size:10.5px;letter-spacing:.2em;color:var(--gold);text-transform:uppercase}
h1{font-family:var(--display);font-size:40px;line-height:1.1;margin:12px 0 10px;color:var(--navy);font-weight:700;letter-spacing:-.015em}
.stamp{font-family:var(--mono);font-size:11px;color:var(--slate)}
.census{display:flex;flex-wrap:wrap;gap:34px;margin:24px 0 0}
.fig b{display:block;font-family:var(--mono);font-size:27px;font-weight:600;color:var(--teal);line-height:1}
.fig span{font-size:11px;color:var(--slate)}
.body{padding:26px 44px 0}
.note{font-size:12.5px;color:var(--slate);margin:0 0 22px;font-style:italic}
.tools{display:flex;gap:10px;align-items:center;margin:0 0 32px}
#q{flex:1;max-width:440px;padding:11px 14px;border:1px solid var(--hair);border-radius:8px;background:#fff;font:inherit;font-size:13.5px;box-shadow:var(--shadow)}
#q:focus{outline:2px solid var(--teal);outline-offset:1px;border-color:transparent}
.kbd{font-family:var(--mono);font-size:11px;color:var(--slate);border:1px solid var(--hair);border-radius:5px;padding:3px 7px;background:#fff}
section{margin:0 0 46px;scroll-margin-top:20px}
.sec-head{display:flex;align-items:baseline;gap:12px;margin-bottom:4px}
.sec-head h2{font-family:var(--display);font-size:22px;margin:0;color:var(--navy);font-weight:700}
.sec-head .n{font-family:var(--mono);font-size:10.5px;color:var(--slate);background:var(--hair2);padding:2px 8px;border-radius:9px}
.sec-rule{height:2px;background:var(--navy);margin:8px 0 6px;width:46px;border-radius:2px}
.sec-blurb{font-size:13px;color:var(--slate);margin:0 0 18px;max-width:70ch}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(272px,1fr));gap:15px}
.card{display:block;background:var(--card);border:1px solid var(--hair);border-radius:10px;padding:16px 17px 14px;text-decoration:none;color:inherit;transition:border-color .14s,transform .14s,box-shadow .14s;box-shadow:var(--shadow)}
.card:hover{border-color:var(--navy);transform:translateY(-2px);box-shadow:0 10px 26px rgba(16,24,38,.10)}
.card .id{font-family:var(--mono);font-size:10px;color:var(--gold);letter-spacing:.09em;text-transform:uppercase}
.card h3{font-size:14.5px;margin:8px 0 6px;line-height:1.32;color:var(--navy);font-weight:650}
.card p{margin:0;font-size:12.5px;color:var(--slate);line-height:1.45;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.card .meta{margin-top:12px;padding-top:9px;border-top:1px solid var(--hair2);font-family:var(--mono);font-size:10px;color:var(--slate);display:flex;gap:10px}
.empty{display:none;padding:28px;border:1px dashed var(--hair);border-radius:10px;color:var(--slate);font-size:13.5px}
footer{margin:40px 44px 0;padding-top:16px;border-top:1px solid var(--hair);font-family:var(--mono);font-size:10.5px;color:var(--slate)}

/* status page */
.gates{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px;margin:0 0 34px}
.gate{background:#fff;border:1px solid var(--hair);border-radius:10px;padding:16px;box-shadow:var(--shadow);position:relative;overflow:hidden}
.gate:before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--hair)}
.gate.done:before{background:var(--teal)} .gate.active:before{background:var(--gold)} .gate.blocked:before{background:var(--clay)}
.gate .g{font-family:var(--mono);font-size:10.5px;letter-spacing:.14em;color:var(--slate)}
.gate h3{margin:7px 0 4px;font-size:15px;color:var(--navy)}
.gate .who{font-size:11.5px;color:var(--slate)}
.gate .state{margin-top:10px;font-size:11.5px;font-weight:700}
.gate.done .state{color:var(--teal)} .gate.active .state{color:var(--gold)} .gate.blocked .state{color:var(--clay)}
table.st{border-collapse:collapse;width:100%;background:#fff;border:1px solid var(--hair);border-radius:10px;overflow:hidden;box-shadow:var(--shadow);font-size:13px;margin-bottom:32px}
table.st th{background:var(--navy);color:#fff;text-align:left;padding:10px 13px;font-weight:600;font-size:11.5px;letter-spacing:.04em}
table.st td{border-top:1px solid var(--hair2);padding:10px 13px;vertical-align:top}
.pill{display:inline-block;font-family:var(--mono);font-size:10px;padding:2px 8px;border-radius:9px;background:var(--hair2);color:var(--slate)}
.pill.done{background:var(--teal-l);color:var(--teal)} .pill.prog{background:#FBF2DC;color:#7A5D12} .pill.block{background:#FBE9E2;color:var(--clay)}
.rel{background:#fff;border:1px solid var(--hair);border-radius:10px;padding:18px 20px;box-shadow:var(--shadow);margin-bottom:16px}
.rel h3{margin:0 0 3px;font-size:15px;color:var(--navy);font-family:var(--display)}
.rel .when{font-family:var(--mono);font-size:10.5px;color:var(--slate)}
.rel ul{margin:10px 0 0;padding-left:20px} .rel li{font-size:13px;margin-bottom:5px}
.banner{background:var(--navy);color:#fff;border-radius:10px;padding:18px 20px;margin:0 0 30px}
.banner b{color:var(--gold-l)}

/* documents */
.doc{max-width:820px;padding:34px 44px 0}
.crumb{font-family:var(--mono);font-size:11px;color:var(--slate);margin-bottom:8px}
.crumb a{color:var(--teal);text-decoration:none}
.role-line{font-size:12.5px;color:var(--slate);margin:0 0 22px;padding-bottom:16px;border-bottom:1px solid var(--hair)}
.role-line b{color:var(--navy)}
.doc-body h1{font-size:30px;margin:4px 0 16px}
.doc-body h2{font-family:var(--display);font-size:21px;color:var(--navy);margin:32px 0 8px;padding-bottom:6px;border-bottom:1px solid var(--hair)}
.doc-body h3{font-size:15.5px;margin:22px 0 6px;color:var(--navy)}
.doc-body h4{font-size:12.5px;margin:18px 0 5px;color:var(--slate);text-transform:uppercase;letter-spacing:.07em;font-family:var(--mono)}
.doc-body p{margin:0 0 12px}
.doc-body ul,.doc-body ol{margin:0 0 14px;padding-left:22px}
.doc-body li{margin-bottom:5px}
.doc-body code{font-family:var(--mono);font-size:12.5px;background:var(--hair2);padding:1.5px 5px;border-radius:4px}
.doc-body pre{background:var(--navy);color:#E8E5DC;padding:15px 17px;border-radius:9px;overflow:auto;font-size:12.5px;line-height:1.5}
.doc-body pre code{background:none;color:inherit;padding:0}
.doc-body blockquote{margin:0 0 14px;padding:11px 17px;border-left:3px solid var(--gold);background:#FDF8EC;color:#4A4436;font-size:13.5px;border-radius:0 8px 8px 0}
.doc-body table{border-collapse:collapse;width:100%;margin:0 0 16px;font-size:12.5px;display:block;overflow-x:auto}
.doc-body th{background:var(--navy);color:#fff;text-align:left;padding:9px 11px;font-weight:600;white-space:nowrap}
.doc-body td{border-bottom:1px solid var(--hair2);padding:9px 11px;vertical-align:top}
.doc-body tr:nth-child(even) td{background:#FCFBF7}
.doc-body hr{border:none;border-top:1px solid var(--hair);margin:26px 0}
.doc-body a{color:var(--teal)}
.raw{font-family:var(--mono);font-size:12.5px;white-space:pre-wrap;background:#fff;border:1px solid var(--hair);border-radius:9px;padding:17px;overflow-x:auto}
.pager{display:flex;justify-content:space-between;gap:16px;margin-top:38px;padding-top:16px;border-top:1px solid var(--hair);font-size:12.5px}
.pager a{color:var(--teal);text-decoration:none;max-width:46%}

@media (max-width:900px){.wrap{grid-template-columns:1fr}.rail{position:static;height:auto}main{padding:0}.hero,.body,.doc{padding-left:20px;padding-right:20px}h1{font-size:30px}}
@media (prefers-reduced-motion:reduce){*{transition:none!important;scroll-behavior:auto!important}}
"""

JS = """
(function(){
  var q=document.getElementById('q'); if(!q) return;
  var cards=[].slice.call(document.querySelectorAll('.card'));
  var secs=[].slice.call(document.querySelectorAll('section[data-sec]'));
  var empty=document.getElementById('empty');
  function roleCard(sid){ return document.querySelector('.role-card[data-role=\"'+sid+'\"] .role-card-count'); }
  function apply(){
    var t=q.value.trim().toLowerCase(); var shown=0;
    cards.forEach(function(c){
      var hit=!t||c.dataset.search.indexOf(t)>-1;
      c.style.display=hit?'':'none'; if(hit)shown++;
    });
    secs.forEach(function(s){
      var visible=[].slice.call(s.querySelectorAll('.card')).filter(function(c){return c.style.display!=='none';});
      s.style.display=visible.length?'':'none';
      var rc=roleCard(s.dataset.sec);
      if(rc) rc.textContent = t ? visible.length : rc.getAttribute('data-count');
    });
    if(empty) empty.style.display=shown?'none':'block';
  }
  q.addEventListener('input',apply);
  document.addEventListener('keydown',function(e){
    if(e.key==='/'&&document.activeElement!==q){e.preventDefault();q.focus();q.select();}
    if(e.key==='Escape'&&document.activeElement===q){q.value='';apply();q.blur();}
  });
})();
"""

# ---------------------------------------------------------------- cross-links
# PATH_INDEX maps every known document path (and, where unambiguous, its bare
# filename) to the page it renders to, longest candidate first. Set once per
# build() so every rendered document can link to any other it mentions.
PATH_INDEX: list = []
PATHCHARS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-./")
_TAG_RE = re.compile(r'(<[^>]+>)')

def build_path_index(all_docs):
    by_rel = {d.rel: d.slug for d in all_docs}
    basename_count: dict = {}
    for d in all_docs:
        basename_count[Path(d.rel).name] = basename_count.get(Path(d.rel).name, 0) + 1
    candidates = dict(by_rel)
    for d in all_docs:
        name = Path(d.rel).name
        if basename_count[name] == 1 and name not in candidates:
            candidates[name] = d.slug
    return sorted(candidates.items(), key=lambda kv: -len(kv[0]))

def linkify_segment(text: str) -> str:
    """Wrap any occurrence of a known document path in this plain-text segment
    in a link to that document's page. Longest candidate wins at each position,
    and a match must sit on a path boundary so it doesn't fire mid-word."""
    if not PATH_INDEX:
        return text
    out, i, n = [], 0, len(text)
    while i < n:
        matched = False
        if i == 0 or text[i - 1] not in PATHCHARS:
            for cand, slug in PATH_INDEX:
                j = i + len(cand)
                if text[i:j] == cand and (j == n or text[j] not in PATHCHARS):
                    out.append(f'<a href="{slug}">{cand}</a>')
                    i = j
                    matched = True
                    break
        if not matched:
            out.append(text[i])
            i += 1
    return "".join(out)

def auto_link(s: str) -> str:
    """Link bare/coded document-path mentions in already-rendered inline HTML,
    without ever linking inside an existing <a>...</a> (no double-linking, no
    nested links)."""
    if not PATH_INDEX:
        return s
    parts = _TAG_RE.split(s)
    inside_a, out = 0, []
    for idx, part in enumerate(parts):
        if idx % 2 == 1:                      # an HTML tag, passed through untouched
            out.append(part)
            low = part.lower()
            if low.startswith("<a "):
                inside_a += 1
            elif low.startswith("</a"):
                inside_a = max(0, inside_a - 1)
            continue
        out.append(part if inside_a or not part else linkify_segment(part))
    return "".join(out)

def check_numbering(all_docs):
    """Documents directly under docs/ are numbered in landing order and are
    never renumbered. Report a shared or skipped number; never fix it here.
    Subfolders (docs/sources/, dated source snapshots, etc.) are out of scope -
    their filenames may start with a year, not a landing number."""
    numbered: dict = {}
    for d in all_docs:
        if Path(d.rel).parent != Path("docs"):
            continue
        m = re.match(r'^(\d{2})-', Path(d.rel).name)
        if m:
            numbered.setdefault(int(m.group(1)), []).append(d.rel)
    msgs = []
    for n, rels in sorted(numbered.items()):
        if len(rels) > 1:
            msgs.append(f"numbering: {n:02d} is shared by {', '.join(sorted(rels))} "
                        f"- left as is, not renumbered")
    nums = sorted(numbered)
    for a, b in zip(nums, nums[1:]):
        if b - a > 1:
            gap = ", ".join(f"{x:02d}" for x in range(a + 1, b))
            msgs.append(f"numbering: gap between {a:02d} and {b:02d} - {gap} not used")
    return msgs

# ---------------------------------------------------------------- markdown
def md_inline(s: str) -> str:
    s = html.escape(s, quote=False)
    s = re.sub(r'`([^`]+)`', r'<code>\1</code>', s)
    s = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', s)
    s = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', s)
    s = re.sub(r'(?<![\w*])\*([^*\n]+)\*(?![\w*])', r'<em>\1</em>', s)
    s = auto_link(s)
    return s

def md_to_html(text: str) -> str:
    lines, out, i = text.split("\n"), [], 0
    def close(stack):
        while stack: out.append("</%s>" % stack.pop())
    stack = []
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("```"):
            close(stack); out.append("<pre><code>")
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                out.append(html.escape(lines[i], quote=False)); i += 1
            out.append("</code></pre>"); i += 1; continue
        if re.match(r'^\s*\|.*\|\s*$', ln) and i + 1 < len(lines) and re.match(r'^\s*\|[\s:\-|]+\|\s*$', lines[i+1]):
            close(stack)
            cells = [c.strip() for c in ln.strip().strip('|').split('|')]
            out.append("<table><thead><tr>" + "".join("<th>%s</th>" % md_inline(c) for c in cells) + "</tr></thead><tbody>")
            i += 2
            while i < len(lines) and re.match(r'^\s*\|.*\|\s*$', lines[i]):
                cs = [c.strip() for c in lines[i].strip().strip('|').split('|')]
                out.append("<tr>" + "".join("<td>%s</td>" % md_inline(c) for c in cs) + "</tr>"); i += 1
            out.append("</tbody></table>"); continue
        m = re.match(r'^(#{1,6})\s+(.*)$', ln)
        if m:
            close(stack); lvl = min(len(m.group(1)), 4)
            out.append("<h%d>%s</h%d>" % (lvl, md_inline(m.group(2)), lvl)); i += 1; continue
        if re.match(r'^\s*(---+|\*\*\*+|___+)\s*$', ln):
            close(stack); out.append("<hr>"); i += 1; continue
        if ln.startswith(">"):
            close(stack); buf = []
            while i < len(lines) and lines[i].startswith(">"):
                buf.append(lines[i].lstrip(">").strip()); i += 1
            out.append("<blockquote>%s</blockquote>" % md_inline(" ".join(buf))); continue
        m = re.match(r'^\s*[-*+]\s+(.*)$', ln)
        if m:
            if not stack or stack[-1] != "ul": close(stack); out.append("<ul>"); stack.append("ul")
            out.append("<li>%s</li>" % md_inline(m.group(1))); i += 1; continue
        m = re.match(r'^\s*\d+[.)]\s+(.*)$', ln)
        if m:
            if not stack or stack[-1] != "ol": close(stack); out.append("<ol>"); stack.append("ol")
            out.append("<li>%s</li>" % md_inline(m.group(1))); i += 1; continue
        if not ln.strip():
            close(stack); i += 1; continue
        close(stack)
        buf = []
        while i < len(lines) and lines[i].strip() and not re.match(r'^(#{1,6}\s|\s*[-*+]\s|\s*\d+[.)]\s|>|```|\s*\|)', lines[i]):
            buf.append(lines[i].strip()); i += 1
        out.append("<p>%s</p>" % md_inline(" ".join(buf)))
    close(stack)
    return "\n".join(out)

# ---------------------------------------------------------------- scan
class Doc:
    __slots__ = ("path", "rel", "sec", "title", "desc", "size", "mtime", "slug")

def title_and_desc(p: Path, raw: str):
    lines = raw.split("\n")
    title, desc, i = None, "", 0
    if lines and lines[0].strip() == "---":                     # yaml frontmatter
        for j in range(1, min(len(lines), 40)):
            if lines[j].strip() == "---": i = j + 1; break
            m = re.match(r'^description:\s*(.+)$', lines[j].strip())
            if m: desc = m.group(1).strip().strip('"\'')
    for ln in lines[i:]:
        m = re.match(r'^#\s+(.*)$', ln)
        if m: title = m.group(1).strip(); break
    if not title:
        title = re.sub(r'^\d+[-_. ]*', '', p.stem).replace('-', ' ').replace('_', ' ').strip().capitalize()
    if not desc:
        started = False
        for ln in lines[i:]:
            s = ln.strip()
            if not started:
                if re.match(r'^#\s+', ln): started = True
                continue
            if not s or s.startswith("#") or s.startswith("|") or s.startswith("---"): continue
            desc = re.sub(r'[*`_>]', '', s); break
    return title, (desc[:220] if desc else "")

def section_for(rel: str):
    rel = rel.replace(os.sep, "/")
    for prefix, sid, stitle, blurb in SECTIONS:
        if rel == prefix or rel.startswith(prefix + "/"):
            return sid, stitle, blurb
    return "other", "Elsewhere", "Everything else held in the tree."

def scan(root: Path):
    docs = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS and not d.startswith("."))
        for fn in sorted(filenames):
            p = Path(dirpath) / fn
            if p.suffix.lower() not in DOC_EXT: continue
            rel = str(p.relative_to(root)).replace(os.sep, "/")
            try: raw = p.read_text(encoding="utf-8", errors="replace")
            except Exception: continue
            d = Doc()
            d.path, d.rel = p, rel
            d.sec = section_for(rel)
            d.title, d.desc = title_and_desc(p, raw)
            st = p.stat(); d.size, d.mtime = st.st_size, dt.datetime.fromtimestamp(st.st_mtime)
            d.slug = re.sub(r'[^a-z0-9]+', '-', rel.lower()).strip('-') + ".html"
            docs.append((d, raw))
    return docs

STAMP = None   # set in build(): the commit time, so output is deterministic

def repo_time(root: Path):
    """The last commit's time. Using the clock would make every regeneration
    differ from the committed output, so a freshness check could never pass."""
    try:
        r = subprocess.run(["git", "-C", str(root), "log", "-1", "--format=%cI"],
                           capture_output=True, text=True, timeout=8)
        if r.returncode == 0 and r.stdout.strip():
            return dt.datetime.fromisoformat(r.stdout.strip()).replace(tzinfo=None)
    except Exception:
        pass
    return dt.datetime.now()

def git_stamp(root: Path):
    try:
        h = subprocess.run(["git", "-C", str(root), "rev-parse", "--short", "HEAD"],
                           capture_output=True, text=True, timeout=8)
        return h.stdout.strip() if h.returncode == 0 else ""
    except Exception:
        return ""

# ---------------------------------------------------------------- render

PROJECT = "Offer allocation"

# ---------------------------------------------------------------- status
def parse_board(root: Path):
    p = root / "features" / "BOARD.md"
    if not p.exists(): return []
    rows = []
    for ln in p.read_text(encoding="utf-8", errors="replace").split("\n"):
        if not ln.strip().startswith("|"): continue
        cells = [c.strip() for c in ln.strip().strip("|").split("|")]
        if len(cells) < 3: continue
        if set("".join(cells)) <= set("-: "): continue
        if cells[0].lower() in ("id", "#"): continue
        rows.append(cells)
    return rows

def parse_decisions(root: Path):
    p = root / "pod" / "DECISIONS.md"
    if not p.exists(): return []
    out = []
    for m in re.finditer(r'^###\s+(D-\d+)\s*·\s*([^·\n]*)·\s*(.+)$', p.read_text(encoding="utf-8", errors="replace"), re.M):
        out.append((m.group(1).strip(), m.group(2).strip(), m.group(3).strip()))
    return out

def parse_open_questions(root: Path):
    p = root / "docs" / "07-open-questions.md"
    if not p.exists(): return []
    rows = []
    for ln in p.read_text(encoding="utf-8", errors="replace").split("\n"):
        if not ln.strip().startswith("|"): continue
        cells = [c.strip() for c in ln.strip().strip("|").split("|")]
        if len(cells) < 4 or set("".join(cells)) <= set("-: ") or cells[0].lower() in ("#","id"): continue
        rows.append(cells)
    return rows

def git_releases(root: Path, n=12):
    try:
        r = subprocess.run(["git","-C",str(root),"log",f"-{n}","--date=short","--pretty=%h|%ad|%s"],
                           capture_output=True, text=True, timeout=8)
        if r.returncode: return []
        return [ln.split("|",2) for ln in r.stdout.strip().split("\n") if ln.count("|")>=2]
    except Exception:
        return []

def _state(txt: str):
    """Map a board status cell to (state, pill-class). Order matters:
    a negated status such as "not started" must never match "started"."""
    t = " ".join(txt.strip().lower().split())
    if not t or t.startswith("not ") or t.startswith("no ") or t in (
            "todo", "to do", "backlog", "pending", "queued", "-", "\u2014"):
        return "", ""
    if any(w in t for w in ("blocked", "waiting on", "held", "on hold", "stalled")):
        return "blocked", "block"
    if any(w in t for w in ("done", "signed", "complete", "completed", "passed",
                            "accepted", "landed", "sealed", "closed")):
        return "done", "done"
    if any(w in t for w in ("in progress", "in-progress", "progress", "in flight",
                            "drafting", "active", "started", "building", "review")):
        return "active", "prog"
    return "", ""

def parse_yaml_lite(path: Path):
    """Tiny key: value reader — enough for JIRA.yml/REPOS.yml headline facts."""
    if not path.exists(): return {}
    out, cur = {}, None
    for ln in path.read_text(encoding="utf-8", errors="replace").split("\n"):
        if not ln.strip() or ln.strip().startswith("#"): continue
        m = re.match(r'^(\w[\w_]*):\s*(.*)$', ln)
        if m:
            cur = m.group(1); out[cur] = m.group(2).strip() or {}
        else:
            m2 = re.match(r'^\s+(\w[\w_]*):\s*(.+)$', ln)
            if m2 and isinstance(out.get(cur), dict):
                out[cur][m2.group(1)] = m2.group(2).strip()
    return out

def parse_views_yaml(path: Path):
    """Dedicated reader for pod/VIEWS.yml's fixed shape: a top-level `roles:` list
    of dicts, each with scalar key/title/blurb and an inline `paths: [...]` list.
    Not a general YAML parser - this shape only. Returns None if the file is
    missing or empty, so callers can fall back to the folder-based grouping."""
    if not path.exists():
        return None
    roles, cur = [], None
    for raw in path.read_text(encoding="utf-8", errors="replace").split("\n"):
        if not raw.strip() or raw.strip().startswith("#"):
            continue
        m = re.match(r'^\s*-\s*key:\s*(.+?)\s*$', raw)
        if m:
            cur = {"key": m.group(1), "title": "", "blurb": "", "paths": []}
            roles.append(cur)
            continue
        if cur is None:
            continue
        m = re.match(r'^\s+title:\s*(.+?)\s*$', raw)
        if m:
            cur["title"] = m.group(1); continue
        m = re.match(r'^\s+blurb:\s*(.+?)\s*$', raw)
        if m:
            cur["blurb"] = m.group(1); continue
        m = re.match(r'^\s+paths:\s*\[(.*?)\]\s*(?:#.*)?$', raw)
        if m:
            cur["paths"] = [x.strip() for x in m.group(1).split(",") if x.strip()]
            continue
    return roles or None

def load_roles(root: Path):
    return parse_views_yaml(root / "pod" / "VIEWS.yml")

def role_for(rel: str, roles):
    """First role (in pod/VIEWS.yml order) whose paths list has a prefix
    matching this document. One role per document; unmatched is the caller's
    problem (they fall back to the catch-all role)."""
    for r in roles:
        for p in r["paths"]:
            if rel == p or rel.startswith(p):
                return r
    return None

def features_done(root: Path):
    d = root / "features" / "done"
    if not d.exists(): return []
    return sorted([p for p in d.glob("*.md")])


def _md_table(headers, rows):
    if not rows: return "_Nothing yet._\n"
    out = ["| " + " | ".join(headers) + " |",
           "|" + "|".join(["---"] * len(headers)) + "|"]
    for r in rows:
        cells = [(c or "").replace("|", "\\|") for c in (list(r) + [""] * len(headers))[:len(headers)]]
        out.append("| " + " | ".join(cells) + " |")
    return "\n".join(out) + "\n"

def status_md(root: Path, stamp, commit):
    board = parse_board(root); decisions = parse_decisions(root); oq = parse_open_questions(root)
    gates = [("A","Questions signed","Product"),("B","I/O contracts signed","Data science"),
             ("C","Tickets approved","Product + DS + Engineering"),("D","Features accepted","Product")]
    grows = []
    for letter, title, who in gates:
        st = ""
        for r in board:
            if (r[3] if len(r) > 3 else "").strip().lower().replace("gate ", "") == letter.lower():
                st, _ = _state(r[2] if len(r) > 2 else ""); break
        grows.append([f"Gate {letter}", title, who,
                      {"done":"passed","active":"in progress","blocked":"blocked"}.get(st,"not started")])
    lines = [f"# Status — {PROJECT}", "",
             f"*Generated {stamp}{' · ' + commit if commit else ''} from the board, the decision log and the",
             "open questions. Do not edit — run `make index`.*", "",
             "## The gates", "", _md_table(["Gate","What","Signed by","State"], grows),
             "## The board", "", "`features/BOARD.md` governs; this is a view of it.", "",
             _md_table(["ID","Item","Status","Gate","Owner"], [list(r[:5]) for r in board]),
             "## Decisions", "", _md_table(["ID","Date","Decision"], [list(d) for d in decisions]),
             "## Open questions", "", _md_table(["#","Question","Owner","Blocks","Status"],
                                                [list(r[:5]) for r in oq])]
    return "\n".join(lines) + "\n"

def pmo_md(root: Path, stamp, commit):
    board = parse_board(root); oq = parse_open_questions(root)
    decisions = parse_decisions(root); rel = git_releases(root, 15); done = features_done(root)
    counts = {"done":0,"active":0,"blocked":0,"todo":0}
    for r in board:
        st, _ = _state(r[2] if len(r) > 2 else ""); counts["todo" if not st else st] += 1
    risks = [r for r in oq if "closed" not in " ".join(r).lower()]
    lines = [f"# PMO view — {PROJECT}", "",
             f"*Generated {stamp}{' · ' + commit if commit else ''}. Nothing here is maintained by hand —",
             "if a number looks wrong, the underlying file is wrong.*", "",
             "| Accepted | In progress | Blocked | Not started | Open items | Decisions |",
             "|---|---|---|---|---|---|",
             f"| {counts['done']} | {counts['active']} | {counts['blocked']} | {counts['todo']} | {len(risks)} | {len(decisions)} |",
             "", "## Delivery", "",
             _md_table(["ID","Item","Status","Gate","Owner"], [list(r[:5]) for r in board]),
             "## Accepted features", ""]
    lines += ([f"- {p.stem}" for p in done] or ["_Nothing accepted yet._"])
    lines += ["", "## Landings", ""]
    lines += ([f"- `{h}` · {d} — {m}" for h, d, m in rel] or ["_Nothing has landed yet._"])
    lines += ["", "## Open items and blockers", "",
              _md_table(["#","Item","Owner","Blocks"], [list(r[:4]) for r in risks])]
    return "\n".join(lines) + "\n"

def release_notes_md(root: Path):
    rel = git_releases(root, 40); done = features_done(root)
    lines = ["# Release notes", "", "*Generated from the repository history and the features "
             "marked done. Do not edit — run `make index`.*", ""]
    if done:
        lines += ["## Delivered features", ""]
        for p in done:
            title = p.stem
            try:
                for ln in p.read_text(encoding="utf-8", errors="replace").split("\n"):
                    if ln.startswith("# "): title = ln[2:].strip(); break
            except Exception: pass
            lines.append(f"- **{title}**")
        lines.append("")
    if rel:
        lines += ["## Landings", ""]
        cur = None
        for h, dte, msg in rel:
            if dte != cur: lines += ["", f"### {dte}", ""]; cur = dte
            lines.append(f"- `{h}` {msg}")
    else:
        lines += ["## Landings", "", "Nothing has landed yet."]
    return "\n".join(lines) + "\n"

def pmo_page(root: Path, grouped, stamp, commit):
    board = parse_board(root); oq = parse_open_questions(root)
    decisions = parse_decisions(root); rel = git_releases(root, 15); done = features_done(root)
    jira = parse_yaml_lite(root / "pod" / "JIRA.yml")
    repos_txt = (root / "pod" / "REPOS.yml")
    repo_ids = re.findall(r'^\s*-\s*id:\s*(\S+)', repos_txt.read_text(encoding="utf-8", errors="replace"), re.M) if repos_txt.exists() else []

    phases = [("Gate A","Questions signed","Product"),("Gate B","Contracts signed","Data science"),
              ("Gate C","Tickets approved","Pod"),("Gate D","Features accepted","Product")]
    cards = []
    for code, title, who in phases:
        st = ""
        for r in board:
            if (r[3] if len(r)>3 else "").strip().lower().replace("gate ","") == code.split()[-1].lower():
                st, _ = _state(r[2] if len(r)>2 else ""); break
        label = {"done":"passed","active":"in progress","blocked":"blocked"}.get(st,"not started")
        cards.append(f'<div class="gate {st}"><div class="g">{code}</div><h3>{html.escape(title)}</h3>'
                     f'<div class="who">{html.escape(who)}</div><div class="state">{label}</div></div>')

    counts = {"done":0,"active":0,"blocked":0,"todo":0}
    for r in board:
        st,_ = _state(r[2] if len(r)>2 else "")
        counts["todo" if not st else st] += 1
    total = max(1, len(board))
    bar = ("".join(f'<div style="flex:{counts[k]};background:{c};height:16px"></div>'
           for k,c in [("done","#146553"),("active","#A8801B"),("blocked","#A2481F"),("todo","#DCD8CE")] if counts[k])
           or '<div style="flex:1;background:#DCD8CE;height:16px"></div>')

    brows = "".join("<tr>" + "".join(
        (f'<td><span class="pill {_state(c)[1]}">{html.escape(c)}</span></td>' if i==2 else f"<td>{html.escape(c)}</td>")
        for i,c in enumerate(r[:5])) + "</tr>" for r in board) or '<tr><td colspan="5">Board is empty.</td></tr>'

    risks = [r for r in oq if "closed" not in " ".join(r).lower()]
    rrows = "".join(f"<tr><td><b>{html.escape(r[0])}</b></td><td>{html.escape(r[1])}</td>"
                    f"<td>{html.escape(r[2] if len(r)>2 else '')}</td><td>{html.escape(r[3] if len(r)>3 else '')}</td></tr>"
                    for r in risks) or '<tr><td colspan="4">No open items.</td></tr>'

    delivered = "".join(f"<li>{html.escape(p.stem)}</li>" for p in done) or "<li>Nothing accepted yet.</li>"
    landings = "".join(f"<li><code>{html.escape(h)}</code> · {html.escape(d)} — {html.escape(m)}</li>" for h,d,m in rel) \
               or "<li>Nothing has landed yet.</li>"

    jira_on = str(jira.get("enabled","false")).lower().startswith("t")
    jkey = (jira.get("project") or {}).get("key","—") if isinstance(jira.get("project"), dict) else "—"
    jira_html = (f'<div class="rel"><h3>Jira projection</h3><div class="when">'
                 f'{"enabled" if jira_on else "configured, not enabled"} · project {html.escape(str(jkey))}</div>'
                 f'<ul><li>The board governs; Jira is a one-way view refreshed when a feature lands.</li>'
                 f'<li>Status is never read back from Jira, and a feature invented there is not a feature '
                 f'until it enters the pod as a question.</li>'
                 f'<li>Configuration: <code>pod/JIRA.yml</code> · rules: <code>docs/16-JIRA-PROJECTION.md</code></li></ul></div>')
    repo_html = ("".join(f"<li><code>{html.escape(i)}</code></li>" for i in repo_ids) or "<li>Not configured yet.</li>")

    body = (f'<div class="hero"><div class="eyebrow">PMO view</div><h1>{html.escape(PROJECT)}</h1>'
            f'<div class="stamp">generated {stamp}{" · " + commit if commit else ""}</div>'
            f'<div class="census">'
            f'<div class="fig"><b>{counts["done"]}</b><span>accepted</span></div>'
            f'<div class="fig"><b>{counts["active"]}</b><span>in progress</span></div>'
            f'<div class="fig"><b>{counts["blocked"]}</b><span>blocked</span></div>'
            f'<div class="fig"><b>{len(risks)}</b><span>open items</span></div>'
            f'<div class="fig"><b>{len(decisions)}</b><span>decisions</span></div></div></div>'
            f'<div class="body">'
            f'<div class="banner">Everything here is generated from the board, the decision log, the open '
            f'questions and the repository history. <b>No status was prepared for this page</b> — if a number '
            f'looks wrong, the underlying file is wrong.</div>'
            f'<div class="sec-head"><h2>Progress</h2></div><div class="sec-rule"></div>'
            f'<div style="display:flex;border-radius:8px;overflow:hidden;margin:0 0 8px">{bar}</div>'
            f'<p class="sec-blurb">{counts["done"]} accepted · {counts["active"]} in progress · '
            f'{counts["blocked"]} blocked · {counts["todo"]} not started, of {len(board)} tracked items.</p>'
            f'<div class="gates">{"".join(cards)}</div>'
            f'<div class="sec-head"><h2>Delivery</h2></div><div class="sec-rule"></div>'
            f'<table class="st"><thead><tr><th>ID</th><th>Item</th><th>Status</th><th>Gate</th><th>Owner</th>'
            f'</tr></thead><tbody>{brows}</tbody></table>'
            f'<div class="sec-head"><h2>Release notes</h2></div><div class="sec-rule"></div>'
            f'<p class="sec-blurb">Accepted features and what landed, newest first. '
            f'Also written to <code>_index/RELEASE-NOTES.md</code> for pasting into a report.</p>'
            f'<div class="rel"><h3>Accepted features</h3><ul>{delivered}</ul></div>'
            f'<div class="rel"><h3>Landings</h3><ul>{landings}</ul></div>'
            f'<div class="sec-head"><h2>Open items and blockers</h2></div><div class="sec-rule"></div>'
            f'<p class="sec-blurb">An open question with no owner is not open, it is ignored.</p>'
            f'<table class="st"><thead><tr><th>#</th><th>Item</th><th>Owner</th><th>Blocks</th></tr></thead>'
            f'<tbody>{rrows}</tbody></table>'
            f'<div class="sec-head"><h2>Integration</h2></div><div class="sec-rule"></div>'
            f'<div class="rel"><h3>Repositories this pod touches</h3><ul>{repo_html}</ul>'
            f'<div class="when">configured in pod/REPOS.yml · every commit carries its feature id, '
            f'every ticket records the repository and SHA that landed it</div></div>'
            f'{jira_html}</div>'
            f'<footer>generated with <code>make index</code></footer>')
    return page(f"PMO — {PROJECT}", rail_html(grouped, page_kind="pmo"), body)


LAYERS = ["Data", "Model", "API", "UI", "Tests"]

def parse_features(root: Path):
    """Read feature tickets from features/** — header fields plus checklist progress."""
    out = []
    base = root / "features"
    if not base.exists(): return out
    for p in sorted(base.rglob("*.md")):
        if p.name.upper() in ("BOARD.MD", "CLAUDE.MD", "README.MD"): continue
        try: txt = p.read_text(encoding="utf-8", errors="replace")
        except Exception: continue
        f = {"file": p, "folder": p.parent.name, "id": p.stem, "title": p.stem,
             "status": "", "gate": "", "owner": "", "repo": "", "question": ""}
        head = txt.split("---")[1] if txt.startswith("---") and "---" in txt[3:] else txt[:800]
        for k in ("id", "status", "gate", "owner", "repo", "question"):
            m = re.search(rf'^\s*{k}:\s*(.+)$', head, re.M)
            if m: f[k] = m.group(1).split("#")[0].strip()
        m = re.search(r'^#\s+(.*)$', txt, re.M)
        if m: f["title"] = m.group(1).strip()
        done = len(re.findall(r'-\s*\[[xX]\]', txt)); todo = len(re.findall(r'-\s*\[\s\]', txt))
        f["checks_done"], f["checks_total"] = done, done + todo
        # which layer sections the ticket actually fills in
        f["layers"] = [l for l in LAYERS if re.search(rf'^##\s+{l}\b', txt, re.M | re.I)]
        if not f["status"]:
            f["status"] = {"done": "done", "in-progress": "in progress"}.get(f["folder"], "not started")
        out.append(f)
    return out

def features_md(root: Path, stamp, commit):
    feats = parse_features(root)
    lines = [f"# Features — {PROJECT}", "",
             f"*Generated{' ' + stamp if stamp else ''}{' · ' + commit if commit else ''} from the "
             "ticket files in `features/`. Do not edit — run `make index`.*", ""]
    if not feats:
        lines += ["No feature tickets yet. They are created at Gate C — one per question, "
                  "each answering it end to end.", ""]
        return "\n".join(lines)
    counts = {}
    for f in feats:
        st, _ = _state(f["status"]); counts[st or "todo"] = counts.get(st or "todo", 0) + 1
    lines += ["| Done | In progress | Blocked | Not started | Total |", "|---|---|---|---|---|",
              f"| {counts.get('done',0)} | {counts.get('active',0)} | {counts.get('blocked',0)} | "
              f"{counts.get('todo',0)} | {len(feats)} |", "",
              "| ID | Feature | Question | Status | Gate | Layers | Checks | Owner | Repo |",
              "|---|---|---|---|---|---|---|---|---|"]
    for f in feats:
        layers = " · ".join(f["layers"]) or "—"
        checks = f'{f["checks_done"]}/{f["checks_total"]}' if f["checks_total"] else "—"
        lines.append(f'| {f["id"]} | {f["title"]} | {f["question"] or "—"} | {f["status"]} | '
                     f'{f["gate"] or "—"} | {layers} | {checks} | {f["owner"] or "—"} | {f["repo"] or "—"} |')
    lines += ["", "*A feature is done when every layer's check passes, the question is answered "
              "end to end, and the business reviewer agrees it is the answer they asked for.*", ""]
    return "\n".join(lines)

def features_page(root: Path, grouped, stamp, commit):
    feats = parse_features(root)
    counts = {}
    for f in feats:
        st, _ = _state(f["status"]); counts[st or "todo"] = counts.get(st or "todo", 0) + 1
    cards = []
    for f in feats:
        st, pill = _state(f["status"])
        pct = int(100 * f["checks_done"] / f["checks_total"]) if f["checks_total"] else 0
        chips = "".join(
            f'<span class="pill" style="margin-right:6px">{html.escape(l)}</span>' for l in f["layers"]) or \
            '<span class="pill">no layers filled in</span>'
        cards.append(
            f'<div class="rel"><h3>{html.escape(f["id"])} · {html.escape(f["title"])}</h3>'
            f'<div class="when">{html.escape(f["question"] or "no question cited")} · gate '
            f'{html.escape(f["gate"] or "—")} · {html.escape(f["owner"] or "unassigned")} · '
            f'{html.escape(f["repo"] or "repo not set")}</div>'
            f'<div style="margin:10px 0">{chips}</div>'
            f'<div style="display:flex;align-items:center;gap:10px">'
            f'<div style="flex:1;background:#EFEBE2;border-radius:6px;height:10px;overflow:hidden">'
            f'<div style="width:{pct}%;background:#146553;height:10px"></div></div>'
            f'<span class="pill {pill}">{html.escape(f["status"])}</span>'
            f'<span class="pill">{f["checks_done"]}/{f["checks_total"]} checks</span></div></div>')
    body = (f'<div class="hero"><div class="eyebrow">Features</div><h1>{html.escape(PROJECT)}</h1>'
            f'<div class="stamp">generated {stamp}{" · " + commit if commit else ""}</div>'
            f'<div class="census">'
            f'<div class="fig"><b>{counts.get("done",0)}</b><span>done</span></div>'
            f'<div class="fig"><b>{counts.get("active",0)}</b><span>in progress</span></div>'
            f'<div class="fig"><b>{counts.get("blocked",0)}</b><span>blocked</span></div>'
            f'<div class="fig"><b>{counts.get("todo",0)}</b><span>not started</span></div></div></div>'
            f'<div class="body">'
            + (f'<div class="banner">No feature tickets yet. They are created at <b>Gate C</b> — one per '
               f'question, each answering it end to end, with data, model, API, UI and tests inside it.</div>'
               if not feats else
               f'<div class="banner">Each card is a ticket file in <code>features/</code>. The bar is its '
               f'own done-when checklist. <b>Nothing here is maintained by hand.</b></div>' + "".join(cards))
            + '</div><footer>generated with <code>make index</code></footer>')
    return page(f"Features — {PROJECT}", rail_html(grouped, page_kind="features"), body)

def status_page(root: Path, grouped, stamp, commit):
    board = parse_board(root); decisions = parse_decisions(root)
    oq = parse_open_questions(root); rel = git_releases(root)
    gates = [("GATE A","Questions signed","Product"),("GATE B","I/O contracts signed","Data science"),
             ("GATE C","Tickets approved","Product + DS + Engineering"),("GATE D","Features accepted","Product")]
    gate_cards = []
    for g,(code, title, who) in zip(gates, gates):
        code, title, who = g
        st, _ = "", ""
        letter = code.split()[-1]
        for r in board:
            gate_cell = (r[3] if len(r) > 3 else "")
            if gate_cell.strip().lower().replace("gate ", "") == letter.lower():
                st, _ = _state(r[2] if len(r) > 2 else "")
                break
        cls = st or ""
        label = {"done":"passed","active":"in progress","blocked":"blocked"}.get(st, "not started")
        gate_cards.append(f'<div class="gate {cls}"><div class="g">{code}</div><h3>{html.escape(title)}</h3>'
                          f'<div class="who">{html.escape(who)}</div><div class="state">{label}</div></div>')
    brows = []
    for r in board:
        st, pill = _state(r[2] if len(r)>2 else "")
        brows.append("<tr>" + "".join(f"<td>{html.escape(c)}</td>" if i!=2 else
                     f'<td><span class="pill {pill}">{html.escape(c)}</span></td>' for i,c in enumerate(r[:5])) + "</tr>")
    done_n = sum(1 for r in board if _state(r[2] if len(r)>2 else "")[0]=="done")
    prog_n = sum(1 for r in board if _state(r[2] if len(r)>2 else "")[0]=="active")
    open_n = sum(1 for r in oq if "closed" not in " ".join(r).lower())
    census = (f'<div class="census">'
              f'<div class="fig"><b>{done_n}</b><span>items complete</span></div>'
              f'<div class="fig"><b>{prog_n}</b><span>in progress</span></div>'
              f'<div class="fig"><b>{len(decisions)}</b><span>decisions recorded</span></div>'
              f'<div class="fig"><b>{open_n}</b><span>open questions</span></div></div>')
    rel_html = ""
    if rel:
        items = "".join(f"<li><code>{html.escape(h)}</code> · {html.escape(d)} — {html.escape(m)}</li>" for h,d,m in rel)
        rel_html = f'<div class="rel"><h3>Recent landings</h3><div class="when">most recent first, from the repository history</div><ul>{items}</ul></div>'
    else:
        rel_html = ('<div class="rel"><h3>Recent landings</h3><div class="when">nothing landed yet</div>'
                    '<ul><li>Release notes appear here automatically as work lands.</li></ul></div>')
    dec_html = "".join(f"<tr><td><b>{html.escape(i)}</b></td><td>{html.escape(dte)}</td><td>{html.escape(t)}</td></tr>"
                       for i,dte,t in decisions) or '<tr><td colspan="3">No decisions recorded yet.</td></tr>'
    oq_html = "".join("<tr>" + "".join(f"<td>{html.escape(c)}</td>" for c in r[:5]) + "</tr>" for r in oq) \
              or '<tr><td colspan="5">No open questions recorded.</td></tr>'
    body = (f'<div class="hero"><div class="eyebrow">Project status</div><h1>{html.escape(PROJECT)}</h1>'
            f'<div class="stamp">generated {stamp}{" · " + commit if commit else ""}</div>{census}</div>'
            f'<div class="body">'
            f'<div class="banner">This page is generated from the board, the decision log, the open questions and the '
            f'repository history. <b>Nothing on it is maintained by hand</b> — if it is wrong, the underlying file is wrong.</div>'
            f'<div class="sec-head"><h2>The gates</h2></div><div class="sec-rule"></div>'
            f'<p class="sec-blurb">Work only changes hands at a gate, and every gate is a person.</p>'
            f'<div class="gates">{"".join(gate_cards)}</div>'
            f'<div class="sec-head"><h2>The board</h2></div><div class="sec-rule"></div>'
            f'<p class="sec-blurb">BOARD.md governs; this is a view of it.</p>'
            f'<table class="st"><thead><tr><th>ID</th><th>Item</th><th>Status</th><th>Gate</th><th>Owner</th></tr></thead>'
            f'<tbody>{"".join(brows) or "<tr><td colspan=5>Board is empty.</td></tr>"}</tbody></table>'
            f'<div class="sec-head"><h2>Release notes</h2></div><div class="sec-rule"></div>'
            f'<p class="sec-blurb">What has landed, newest first.</p>{rel_html}'
            f'<div class="sec-head"><h2>Decisions</h2></div><div class="sec-rule"></div>'
            f'<p class="sec-blurb">Every decision carries its reason; open the log for the full text.</p>'
            f'<table class="st"><thead><tr><th>ID</th><th>Date</th><th>Decision</th></tr></thead><tbody>{dec_html}</tbody></table>'
            f'<div class="sec-head"><h2>Open questions</h2></div><div class="sec-rule"></div>'
            f'<p class="sec-blurb">An open question with no owner is not open, it is ignored.</p>'
            f'<table class="st"><thead><tr><th>#</th><th>Question</th><th>Owner</th><th>Blocks</th><th>Status</th></tr></thead>'
            f'<tbody>{oq_html}</tbody></table></div>'
            f'<footer>generated with <code>make index</code></footer>')
    return page(f"Status — {PROJECT}", rail_html(grouped, page_kind="status"), body)

def page(title, rail, body, depth=0):
    up = "../" * depth
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)}</title><style>{CSS}</style></head>
<body><div class="wrap"><nav class="rail">{rail}</nav><main>{body}</main></div>
<script>{JS}</script></body></html>"""

def rail_html(groups, up="", here="", page_kind="index"):
    """Left rail: role cards (title, blurb, count), not a document tree. `here`
    is the id of the role the current document page belongs to, if any."""
    on_i = ' class="on"' if page_kind=="index" else ''
    on_s = ' class="on"' if page_kind=="status" else ''
    on_p = ' class="on"' if page_kind=="pmo" else ''
    on_f = ' class="on"' if page_kind=="features" else ''
    parts = [f'<div class="rail-head"><div class="mark">AI pod</div>'
             f'<div class="rail-title">{html.escape(PROJECT)}</div>'
             f'<div class="rail-sub">generated {(STAMP or dt.datetime.now()).strftime("%d %b %Y %H:%M")}</div></div>'
             f'<div class="navlinks"><a href="{up}index.html"{on_i}>Record</a>'
             f'<a href="{up}status.html"{on_s}>Status</a>'
             f'<a href="{up}features.html"{on_f}>Features</a>'
             f'<a href="{up}pmo.html"{on_p}>PMO</a>'
             f'<a href="{up}PLAN.md">Plan</a></div>'
             f'<div class="roles">']
    for sid, stitle, blurb, items in groups:
        cur = ' role-card on' if sid == here else ' role-card'
        parts.append(
            f'<a class="{cur.strip()}" href="{up}index.html#{sid}" data-role="{sid}" '
            f'data-search="{html.escape(stitle.lower(),quote=True)}">'
            f'<div class="role-card-title">{html.escape(stitle)}</div>'
            f'<div class="role-card-blurb">{html.escape(blurb)}</div>'
            f'<div class="role-card-count" data-count="{len(items)}">{len(items)}</div></a>')
    parts.append("</div>")
    return "".join(parts)

def build(root: Path, out: Path):
    docs = scan(root)
    all_docs = [d for d, _raw in docs]
    global PATH_INDEX
    PATH_INDEX = build_path_index(all_docs)
    for msg in check_numbering(all_docs):
        print(msg)

    def numkey(d):
        m = re.match(r'^(\d+)', Path(d.rel).name)
        return (0, int(m.group(1)), d.rel) if m else (1, 0, d.rel)

    roles = load_roles(root)
    if roles:
        catch_all = next((r for r in roles if not r["paths"]), roles[-1])
        role_groups = {r["key"]: (r["title"], r["blurb"], []) for r in roles}
        for d, _raw in docs:
            r = role_for(d.rel, roles) or catch_all
            role_groups[r["key"]][2].append(d)
        grouped = [(key, title, blurb, sorted(items, key=numkey))
                   for key, (title, blurb, items) in role_groups.items()]
    else:
        order = {sid: i for i, (_p, sid, _t, _b) in enumerate(SECTIONS)}
        groups = {}
        for d, _raw in docs:
            sid, stitle, blurb = d.sec
            groups.setdefault(sid, (stitle, blurb, []))[2].append(d)
        grouped = []
        for sid in sorted(groups, key=lambda s: order.get(s, 99)):
            stitle, blurb, items = groups[sid]
            grouped.append((sid, stitle, blurb, sorted(items, key=numkey)))

    out.mkdir(parents=True, exist_ok=True)
    (out / "_view").mkdir(exist_ok=True)
    global STAMP
    STAMP = repo_time(root)
    stamp = STAMP.strftime("%d %B %Y, %H:%M")
    commit = git_stamp(root)
    total = sum(len(items) for *_x, items in grouped)

    # ---- index
    cards = []
    for sid, stitle, blurb, items in grouped:
        cs = []
        for d in items:
            kb = max(1, round(d.size / 1024))
            cs.append(
                f'<a class="card" href="_view/{d.slug}" data-search="{html.escape((d.title+" "+d.rel+" "+d.desc).lower(),quote=True)}">'
                f'<div class="id">{html.escape(d.rel)}</div><h3>{html.escape(d.title)}</h3>'
                f'<p>{html.escape(d.desc)}</p>'
                f'<div class="meta"><span>{kb} KB</span><span>{d.mtime.strftime("%d %b %Y")}</span></div></a>')
        cards.append(
            f'<section id="{sid}" data-sec="{sid}"><div class="sec-head"><h2>{html.escape(stitle)}</h2>'
            f'<span class="n">{len(items)}</span></div><div class="sec-rule"></div>'
            f'<p class="sec-blurb">{html.escape(blurb)}</p><div class="grid">{"".join(cs)}</div></section>')

    census = (f'<div class="census">'
              f'<div class="fig"><b>{total}</b><span>documents</span></div>'
              f'<div class="fig"><b>{len(grouped)}</b><span>sections</span></div>'
              + (f'<div class="fig"><b>{commit}</b><span>commit</span></div>' if commit else "")
              + '</div>')

    body = (f'<div class="hero"><div class="eyebrow">Continuous context delivery</div>'
            f'<h1>The record</h1>'
            f'<div class="stamp">generated {stamp}{" · " + commit if commit else ""}</div>'
            f'{census}</div>'
            f'<div class="body">'
            f'<p class="note">Every card, count and link on this page is read from the tree at build time. '
            f'Add or delete a document and re-run the generator — nothing here is maintained by hand.</p>'
            f'<div class="tools"><input id="q" type="search" placeholder="Filter documents…" '
            f'aria-label="Filter documents"><span class="kbd">/</span></div>'
            f'<div id="empty" class="empty">Nothing matches that. Clear the filter to see the whole record.</div>'
            f'{"".join(cards)}</div>'
            f'<footer>{total} documents indexed · regenerate with <code>make index</code></footer>')
    (out / "index.html").write_text(page(f"The record — {PROJECT}", rail_html(grouped, page_kind="index"), body), encoding="utf-8")
    (out / "status.html").write_text(status_page(root, grouped, stamp, commit), encoding="utf-8")
    (out / "pmo.html").write_text(pmo_page(root, grouped, stamp, commit), encoding="utf-8")
    (out / "RELEASE-NOTES.md").write_text(release_notes_md(root), encoding="utf-8")
    (out / "STATUS.md").write_text(status_md(root, stamp, commit), encoding="utf-8")
    (out / "PMO.md").write_text(pmo_md(root, stamp, commit), encoding="utf-8")
    (out / "features.html").write_text(features_page(root, grouped, stamp, commit), encoding="utf-8")
    (out / "FEATURES.md").write_text(features_md(root, stamp, commit), encoding="utf-8")

    # ---- document pages (prev/next scoped to the role, not the whole record)
    raws = {d.rel: raw for d, raw in docs}
    for sid, stitle, blurb, items in grouped:
        for idx, d in enumerate(items):
            raw = raws[d.rel]
            rendered = md_to_html(raw) if d.path.suffix.lower() == ".md" else f'<div class="raw">{html.escape(raw)}</div>'
            prev_d = items[idx - 1] if idx else None
            next_d = items[idx + 1] if idx + 1 < len(items) else None
            pager = '<div class="pager">' + (
                f'<a href="{prev_d.slug}">\u2190 {html.escape(prev_d.title)}</a>' if prev_d else "<span></span>") + (
                f'<a href="{next_d.slug}" style="text-align:right">{html.escape(next_d.title)} \u2192</a>' if next_d else "<span></span>") + '</div>'
            body = (f'<div class="doc"><div class="crumb"><a href="../index.html">The record</a> / '
                    f'{html.escape(stitle)} / {html.escape(d.rel)}</div>'
                    f'<div class="role-line">Part of <b>{html.escape(stitle)}</b> \u2014 {html.escape(blurb)}</div>'
                    f'<div class="doc-body">{rendered}</div>{pager}</div>')
            (out / "_view" / d.slug).write_text(
                page(d.title, rail_html(grouped, up="../", here=sid, page_kind="doc"), body, depth=1), encoding="utf-8")

    print(f"index: {total} documents across {len(grouped)} roles -> {out/'index.html'}")
    for _s, t, _b, items in grouped:
        print(f"  {len(items):>4}  {t}")
    return total

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Generate the AI-pod record index.")
    ap.add_argument("--root", default=".", help="tree to index (default: current directory)")
    ap.add_argument("--out", default="_index", help="output directory (default: _index)")
    a = ap.parse_args()
    n = build(Path(a.root).resolve(), Path(a.out).resolve())
    sys.exit(0 if n else 1)
