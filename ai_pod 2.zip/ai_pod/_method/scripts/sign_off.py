#!/usr/bin/env python3
"""
Record a sign-off in one command: append the decision, update the board row, rebuild the views.

Recording a sign-off used to be three separate steps that could each be half-done (a decision
written but the board left stale, or the reverse). This does all three atomically, or none.

Usage (interactive):
    python3 scripts/sign_off.py

Usage (non-interactive):
    python3 scripts/sign_off.py --item G-A --by "Jane Doe" --role Product \\
        --status passed --reason "The register covers every requirement and each row has an
        owner and an intended use; nothing in it is a guess." --yes

Standard library only.
"""
from __future__ import annotations
import argparse, datetime as dt, re, subprocess, sys
from pathlib import Path

ROLES = ["Product", "Data science", "Engineering", "Design", "Pod"]
MIN_REASON_LEN = 20
THIN_REASON_MSG = ("a decision without a real reason is not landable. Say what convinced you, "
                    "not that you decided.")


def root_dir() -> Path:
    return Path(__file__).resolve().parent.parent


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def parse_board_rows(text: str):
    """Return (raw_line, cells) for every real data row of features/BOARD.md's table."""
    rows = []
    for line in text.split("\n"):
        s = line.strip()
        if not s.startswith("|"):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if len(cells) < 5:
            continue
        if set("".join(cells)) <= set("-: "):
            continue
        if cells[0].lower() in ("id", "#"):
            continue
        rows.append((line, cells))
    return rows


def prompt(msg, default=None):
    suffix = f" [{default}]" if default else ""
    val = input(f"{msg}{suffix}: ").strip()
    return val or (default or "")


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def resolve_item(rows, token):
    """token is either a 1-based list number or a board row id, case-insensitive."""
    token = token.strip()
    if token.isdigit():
        i = int(token)
        if 1 <= i <= len(rows):
            return rows[i - 1]
        return None
    for line, cells in rows:
        if cells[0].strip().lower() == token.lower():
            return line, cells
    return None


def next_decision_number(decisions_text: str) -> int:
    nums = [int(m.group(1)) for m in re.finditer(r'^###\s+D-(\d+)\b', decisions_text, re.M)]
    return (max(nums) + 1) if nums else 1


def build_decision_entry(n, today, item_id, item_name, old_status, new_status, signer, role, reason):
    consequences = (
        f"`features/BOARD.md` row {item_id} now reads `{new_status}`; work gated on it may "
        f"proceed. The generated views are refreshed from it, so nobody re-types the status."
    )
    return (
        f"\n### D-{n} · {today} · {item_id} — {item_name} signed off as {new_status}\n"
        f"**Decision.** {item_id} ({item_name}) moves from status `{old_status}` to "
        f"`{new_status}`.\n"
        f"**Because.** {reason}\n"
        f"**Consequences.** {consequences}\n"
        f"\nSigned: {signer}, {role}, {today}\n"
    )


def update_board_status(board_text: str, target_line: str, cells, new_status: str) -> str:
    new_cells = list(cells)
    new_cells[2] = new_status
    new_line = "| " + " | ".join(new_cells) + " |"
    return board_text.replace(target_line, new_line, 1)


def main():
    ap = argparse.ArgumentParser(description="Record a sign-off: decision + board + rebuilt views.")
    ap.add_argument("--item", help="board row id (e.g. G-A) or its list number")
    ap.add_argument("--by", help="signer's name")
    ap.add_argument("--role", help=f"signer's discipline: {', '.join(ROLES)}")
    ap.add_argument("--reason", help="why - the because, not the what")
    ap.add_argument("--status", help="the new status to write on the board row")
    ap.add_argument("--yes", action="store_true", help="skip the confirmation prompt")
    args = ap.parse_args()

    root = root_dir()
    board_path = root / "features" / "BOARD.md"
    decisions_path = root / "pod" / "DECISIONS.md"

    board_text = read(board_path)
    if not board_text:
        die("features/BOARD.md not found or empty - nothing to sign off.")
    rows = parse_board_rows(board_text)
    if not rows:
        die("No rows found in features/BOARD.md's table.")

    if args.item:
        token = args.item
    else:
        print("Which item is being signed off?\n")
        for i, (_line, cells) in enumerate(rows, 1):
            print(f"  {i:>2}. {cells[0]:<6} {cells[1]}  [{cells[2]}]")
        token = prompt("\nEnter a number or an item id")

    found = resolve_item(rows, token)
    if not found:
        die(f"Could not find a board row matching '{token}'.")
    line, cells = found
    item_id, item_name, old_status = cells[0], cells[1], cells[2]

    signer = args.by or prompt("Signer's name")
    if not signer:
        die("A signer's name is required.")

    role_raw = args.role or prompt(f"Discipline ({'/'.join(ROLES)})")
    role = next((r for r in ROLES if r.lower() == role_raw.strip().lower()), None)
    if not role:
        die(f"'{role_raw}' is not a recognised discipline. Choose one of: {', '.join(ROLES)}")

    new_status = args.status or prompt("New status", default="passed")

    reason = args.reason or prompt("Why? (the because, not the what)")
    if len(reason.strip()) < MIN_REASON_LEN:
        die(THIN_REASON_MSG)

    print("\n--- Sign-off summary ---")
    print(f"Item:     {item_id} - {item_name}")
    print(f"Status:   {old_status}  ->  {new_status}")
    print(f"Signed:   {signer}, {role}")
    print(f"Because:  {reason}")
    print("------------------------\n")

    if not args.yes:
        ok = prompt("Write this? (y/N)", default="N")
        if ok.strip().lower() not in ("y", "yes"):
            print("Not written.")
            sys.exit(0)

    today = dt.date.today().isoformat()
    n = next_decision_number(read(decisions_path))
    entry = build_decision_entry(n, today, item_id, item_name, old_status, new_status, signer, role, reason)

    decisions_text = read(decisions_path)
    decisions_path.write_text(decisions_text.rstrip("\n") + "\n" + entry, encoding="utf-8")

    new_board_text = update_board_status(board_text, line, cells, new_status)
    board_path.write_text(new_board_text, encoding="utf-8")

    print(f"Recorded D-{n} in pod/DECISIONS.md")
    print(f"Updated {item_id}'s status in features/BOARD.md")

    result = subprocess.run([sys.executable, str(root / "scripts" / "build_index.py")],
                            cwd=str(root), capture_output=True, text=True)
    print(result.stdout.strip())
    if result.returncode != 0:
        print(result.stderr, file=sys.stderr)
        die("build_index.py failed - the decision and board are written, but the views are stale.")

    print("\nNothing was committed. To land it:")
    print("  git add pod/DECISIONS.md features/BOARD.md _index")
    print(f'  git commit -m "Sign off {item_id}: {old_status} -> {new_status}"')


if __name__ == "__main__":
    main()
