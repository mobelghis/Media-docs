# The pipeline — six stations, four gates

1. **Frame the questions** — business questions in the user's words, plus the reverse-
   engineering dossier when an existing system is being replaced. → **GATE A**
2. **Define the method** — data science answers "how is this computed?". The output that
   unblocks the build is the I/O contract, not a finished model. → **GATE B**
3. **Slice into features** — one ticket per feature, every layer inside it. → **GATE C**
4. **Build the slice** — data → model → API → UI → the question answered. Design output is
   generated inside the feature, not in a phase before it. → **GATE D**
5. **Ship and measure** — the answer meets reality.
6. **Learn** — findings become new questions and re-enter at station 1.

Each station reads the record and writes back to it in the same step. Gates are the only
places work changes hands, and every gate is a person.
