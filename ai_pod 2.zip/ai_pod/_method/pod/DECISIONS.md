# Decisions

## Principles
The pod's operating principles apply in full. The five that bind most often:
- A feature is the smallest testable unit that answers a business question, end to end.
- Every decision carries its reason. A decision without a because is not landed.
- Conflicts with a landed decision stop work and surface — nothing is guessed past a gate.
- A defect class that recurs becomes a mechanism, fixed once in the tooling.
- Claims are bound to evidence mechanically: computed numbers, honest refusals, no overclaiming.

## Decision log
### D-n · <date> · <short title>
**Decision.** What was decided.
**Because.** The reason.
**Supersedes.** What it replaces, if anything — never deleted.
**Consequences.** What must now be true elsewhere.
