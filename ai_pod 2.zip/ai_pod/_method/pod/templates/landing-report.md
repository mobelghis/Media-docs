# Landing report — <date>

| | |
|---|---|
| Hash | |
| What landed | |
| Verification | suite result on a frozen tree |
| Decisions recorded | |
| Deviations | |
| Owed / open | |

*Numbers in this report are computed from the tree, not typed.*
