# Gate A intake — the eight artifacts

The product owner's research produces these. Together they *are* Gate A; nothing proceeds
until they exist and are signed.

| # | Artifact | Template | Done when |
|---|---|---|---|
| 1 | Question register | `question-register.md` | Every question has an owner and an expected use |
| 2 | Current-state dossier | `current-state-dossier.md` | Generated from the code, stamped with the commit |
| 3 | Enhancements ledger | `enhancements-ledger.md` | Each new capability ties to a question |
| 4 | Parity ledger | `parity-ledger.md` | Every existing capability marked carry / carry-fixed / retire-with-reason |
| 5 | Priorities | `priorities.md` | Ranked, with wave-one non-negotiables named |
| 6 | Non-negotiables | `non-negotiables.md` | Per discipline; the constraints the build cannot violate |
| 7 | Scope boundary | `scope-boundary.md` | What this replaces and what it explicitly does not |
| 8 | Open questions | `open-questions.md` | Each with a named owner, inside or outside the pod |
