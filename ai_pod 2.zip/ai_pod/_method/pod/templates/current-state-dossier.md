# Current-state dossier — <area>

> Generated against commit `<sha>` on `<date>`. Regenerate rather than hand-edit.

## Entry point
URL / route / entry command · the screens or endpoints involved.

## The chain
route → components → API calls → services → queries → tables, one row per hop with file paths.

## What it computes today
The measure or behaviour, stated precisely — including the parts that are wrong.

## Permissions
Who can reach it, and how that is enforced.

## Consumers
Everything else that reads the same quantity. This is the blast radius for any change.

## Defects observed
Each with what it causes and where it lives.
