# I/O contract — <question or measure>   *(Gate B)*

**Question.** The business question this answers, quoted from the register.

**Inputs.** Fields, grain, history depth, and where they come from.

**Outputs.** The quantity, its type, its range, what it means — and what is returned when
the answer cannot be supported.

**Method.** The approach and where it runs. Parameters are named as parameters, never
constants.

**Assumptions.** What must be true for this to be valid.

**Validation.** How we will know it is right.

**Not yet known.** Named, not hidden. This section is a feature of the document.

*Signed by data science on <date>. The model may still be a draft; this contract is what
the rest of the pod builds against.*
