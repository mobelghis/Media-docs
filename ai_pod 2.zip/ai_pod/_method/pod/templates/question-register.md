# Question register

| Q-id | The question, in the user's words | Who asks | What they do with the answer | Surface | Status |
|---|---|---|---|---|---|
| Q-1 | | | | | open |

**Rules.** No question without an owner. No surface that answers no question. No question
without a surface once design is signed.
