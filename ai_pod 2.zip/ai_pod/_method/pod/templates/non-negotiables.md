# Non-negotiables

Hard constraints the build may not violate. Each names its owner, so it can be argued with
by a person rather than discovered by a failure.

| Constraint | Owner | Applies to | Consequence if violated |
|---|---|---|---|
