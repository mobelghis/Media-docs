# Enhancements ledger

Capabilities that do not exist today — the "what is missing" list, and the stakeholder slide.

| # | Capability | The question it answers | Why it could not exist before |
|---|---|---|---|
