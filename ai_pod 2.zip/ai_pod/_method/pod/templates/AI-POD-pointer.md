# AI-POD.md — template for the PRODUCT repository root

Copy this to the root of the product repository, fill it in, and commit it. Its only job is to
tell anyone working here — human or AI — that a pod governs this work and where the record lives.

```markdown
# This area is governed by an AI pod

**Record:** <url of the pod repository>
**Pod:** <pod name>   **Product owner:** <name>
**Governs:** <paths / modules / reports this pod is currently changing>

Before changing anything under those paths:
1. Read the pod's `docs/01-REQUIREMENTS.md` and `docs/04-non-negotiables.md`.
2. Work from a feature ticket in the pod's `features/`. If there is no ticket, there is no build.
3. Reference the feature id in every commit message (e.g. `F-012: add head/tail column`).
4. Report the commit SHA back so it is recorded against the ticket.

Anything that conflicts with a landed decision in the pod's record stops and surfaces —
it is never worked around here.
```

Keep it short. It is a signpost, not a copy of the record — there is exactly one record, and it
is not in this repository.
