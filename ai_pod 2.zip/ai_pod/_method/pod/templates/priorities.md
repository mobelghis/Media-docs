# Priorities

| # | Outcome | Why it matters | Wave-one non-negotiable? |
|---|---|---|---|
