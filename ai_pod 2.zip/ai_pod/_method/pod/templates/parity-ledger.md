# Parity ledger

Every capability the current system has, dispositioned. Zero silent drops is the gate.

| Capability | Where it lives today | Disposition | Reason / replacement |
|---|---|---|---|
| | | carry / carry-fixed / retire | |
