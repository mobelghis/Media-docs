# Scope boundary

## This replaces

## This does not replace

## Deliberately deferred
Each with the condition that would bring it back.
