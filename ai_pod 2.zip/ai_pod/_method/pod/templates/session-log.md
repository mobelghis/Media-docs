# Session log — <date>

**Goal.** What this session set out to do.
**Decisions made.** With their reasons; D-numbers if they landed.
**Deviations.** What differed from the plan, and why. Never smoothed away.
**Defects found.** Including in our own work, and whether each became a mechanism.
**What is owed.** Carried to the next session.
