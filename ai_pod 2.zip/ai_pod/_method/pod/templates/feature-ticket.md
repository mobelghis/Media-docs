---
id: F-<n>
question: <Q-id from the register>
status: not started        # not started | in progress | blocked | done
gate: C                    # the gate it is waiting on
owner: <name>
repo: <id from pod/REPOS.yml>
---

# F-<n> — <feature name>

**The question.** *(quoted from the register — one feature answers one question)*

**Depends on.** *(features, contracts, or external items)*

## Data
Tables, migrations, fixtures, retention.

## Model / data science
The computation, per the method statement. How it is verified — including the planted case
that must fail if the computation breaks.

## API
Endpoints, contract, pagination, and what it refuses when a precondition is not met.

## UI
The surfaces, what they show, and what they must not claim.

## Tests
Per-layer checks, plus the end-to-end proof that the question is answered.

## Done when
- [ ] Every layer's check passes
- [ ] The question is answered end to end on real or synthetic data
- [ ] A human-readable demo exists and was run
- [ ] Decisions and their reasons are recorded
- [ ] The business reviewer agrees this is the answer they asked for

## Target
Repository: `<id from pod/REPOS.yml>`  ·  Branch or working mode: `<per that repo's rules>`
Landed as: `<commit SHA — filled in when it lands>`
