# Open questions

| # | Question | Owner | Blocks | Status |
|---|---|---|---|---|
