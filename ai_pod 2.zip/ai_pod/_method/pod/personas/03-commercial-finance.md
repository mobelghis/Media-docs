# Persona — commercial / finance

**Standing.** The person who has to defend the numbers outside the company

**What they judge.** *(what this persona is asked to rule on)*

**What they will not accept.** *(the things that make this persona say no)*

**Recorded positions.** *(their rulings as they accumulate — dated, each naming the artifact it changed)*
