# Persona — experience principal

**Standing.** The person accountable for whether it can actually be used

**What they judge.** *(what this persona is asked to rule on)*

**What they will not accept.** *(the things that make this persona say no)*

**Recorded positions.** *(their rulings as they accumulate — dated, each naming the artifact it changed)*
