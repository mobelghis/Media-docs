# Expert personas and the panel ceremony

Panels pressure-test work before it is built. Each persona has standing, a domain, and
things they are asked to judge. Their objections become deltas; their unanswered questions
become open items with owners.

## Running a panel
1. State what is being reviewed and what a "no" would mean.
2. Give every persona the same material — no private briefings.
3. Each reviews in their own voice against their own standing.
4. Verdicts are RULED (unanimous, applied) or FOR DECISION (the owner decides).
5. Every RULED item becomes a dated delta on the artifact it changes.
6. Every FOR DECISION item gets an owner and lands in open questions.
7. The closing statement goes on the record, including the risk the panel names.
