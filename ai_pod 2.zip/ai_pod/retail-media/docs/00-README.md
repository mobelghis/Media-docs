# The record

Numbered documents in landing order. Never renumbered; corrections are dated amendments.

| # | Document | What it is |
|---|---|---|
| 00 | this file | the index of the record |
| 01 | [01-REQUIREMENTS.md](01-REQUIREMENTS.md) | Purpose, who it serves, R-1..R-n capabilities, cross-cutting requirements — heavily **[assumed]**, drafted from an interrupted brainstorm |
| 04 | [04-non-negotiables.md](04-non-negotiables.md) | Hard constraints and their owners — **[assumed]**, owners mostly TBD |
| 05 | [05-scope-boundary.md](05-scope-boundary.md) | What this replaces, does not replace, and defers | 
| 07 | [07-open-questions.md](07-open-questions.md) | 15 unresolved questions, each with an owner and what it blocks |
| 11 | [11-REPO-BRIDGE.md](11-REPO-BRIDGE.md) | How this pod repository and the product repository work together |
| 13 | [13-personas-and-business-questions.md](13-personas-and-business-questions.md) | Candidate users and their business questions — **[assumed]**, unverified |

See also [docs/sources/unlimitail-niq-activate-understanding.md](sources/unlimitail-niq-activate-understanding.md) for the source-material synthesis these documents draw from, and [docs/unlimitail-niq-prd.html](unlimitail-niq-prd.html) for the visual PRD (diagrams, data model, contract summary) built from it — open it in a browser.
