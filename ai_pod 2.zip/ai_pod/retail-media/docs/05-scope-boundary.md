# 05 — Scope boundary

## This replaces

Not yet stated by the product owner. No confirmed current-state process (manual, spreadsheet, or
otherwise) has been named for this specific integration. **[open question — see Q-10]**

## This does not replace

Unlimitail's own internal measurement platform (understood to be NIQ Activate). This pod is
building the retailer side of the exchange with Unlimitail — sending a shopper selection,
receiving activation/exposure results, attributing sales — not replacing or duplicating whatever
Unlimitail runs internally. **[assumed, based on the relationship inferred from source material —
see Q-1, not confirmed]**

## Deliberately deferred

| Deferred | Condition that brings it back |
|---|---|
| Incrementality / control-group measurement (vs. plain ROAS) | Once closed-loop (exposed-vs-purchase) attribution is live and trusted |
| Personalization / 1:1 offer module | Once the base measurement loop (R-1 through R-5) is proven |
| External (brand/agency) direct access to reports | Once internal rollout succeeds and an access/permission model is designed — **[assumed from source material's Phase 1 = internal-only rule; not confirmed for this pod]** |
| Unified cross-channel (onsite + offsite + walled-garden) measurement | Once the easier channel(s) — onsite/open web — are proven; walled gardens are the hardest case per the source material and shouldn't block go-live |

All deferrals above are **[assumed]**, carried from the source material's own phasing, not
confirmed as this pod's plan. Brainstorm topic 7 ("boundaries — what is explicitly NOT in scope")
was never answered directly.
