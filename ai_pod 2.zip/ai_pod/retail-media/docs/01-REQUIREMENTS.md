# 01 — Requirements: closed-loop retail media (Unlimitail integration)

> Drafted from a brainstorm that was interrupted after topic 1 (the problem) and redirected into
> source-document review — see [docs/sources/unlimitail-niq-activate-understanding.md](sources/unlimitail-niq-activate-understanding.md).
> Topics 2–8 of the brainstorm (users, their questions, current state, constraints, success
> definition, boundaries, team) were **not** covered in conversation. Everything below that is not
> a direct quote from the product owner is marked **[assumed]**. This document is not ready to
> close Gate A — see [docs/07-open-questions.md](07-open-questions.md).

## Purpose

Build a closed-loop retail-media capability: use the retailer's own transaction log (T-Log) to
select shopper audiences, send the selection to Unlimitail (a 3rd-party retail-media network) for
media/offer activation, and receive results back so sales impact can be attributed and reported.
This is stated directly by the product owner. The detailed interface shape below (files, fields,
attribution model) is **[assumed]** — inferred from Unlimitail's own vendor documents describing
its NIQ Activate onboarding, because no contract or spec for *this* pod's direct integration with
Unlimitail has been supplied yet (see [Q-1](07-open-questions.md)).

## Who it serves

Not yet confirmed directly by the product owner. Candidate users, all **[assumed]** from the
Unlimitail-side discovery material and not verified as this pod's own users:
- The team that builds shopper selections from T-Log and decides what to send Unlimitail.
- The team that reviews attribution/ROAS results after a campaign or offer runs.
- Possibly brands/advertisers, if they are meant to see results directly rather than only through
  Unlimitail's own reporting — **unconfirmed, see [Q-9](07-open-questions.md)**.

## Capabilities

### R-1 — Select a shopper audience from T-Log
**Requirement.** Build a shopper segment/audience from the retailer's own transaction log, in a
form suitable for export to Unlimitail.
**What fails today.** Not described yet by the product owner. **[open question]**
**Satisfied when.** A defined shopper segment can be produced from T-Log data and exported in the
format Unlimitail's intake expects.

### R-2 — Send the shopper selection to Unlimitail
**Requirement.** Transmit the selected shopper list to Unlimitail so it can activate media/offers
against it.
**What fails today.** N/A — no such integration exists yet; this is new.
**Satisfied when.** A shopper list is delivered to Unlimitail in an agreed format and cadence, and
its receipt is confirmed.

### R-3 — Receive activation/exposure results back
**Requirement.** Receive from Unlimitail the record of which shoppers were exposed to which
media/offer, and when. **[assumed shape]**: this is closer to a targeting/exposure event feed
(per the source material's Targeting File / Ad Interactions File) than to literal "offer content"
coming back — see [Q-5](07-open-questions.md), unconfirmed.
**What fails today.** N/A — new capability.
**Satisfied when.** Exposure/targeting events are ingested and linked back to the original
shopper selection.

### R-4 — Attribute sales to exposure (the closed loop)
**Requirement.** Match T-Log purchases to shoppers who were exposed to the media/offer, within an
attribution window, to calculate sales impact.
**What fails today.** Unconfirmed whether any version of this exists today (manually or not at
all). **[open question]**
**Satisfied when.** A report exists showing attributed sales and a cost-effectiveness metric
(e.g. ROAS) per campaign/offer, computed from matched T-Log and exposure data — not hand-typed.

### R-5 — Report the result
**Requirement.** Present the measurement (attributed sales, ROAS, supporting KPIs) to the
stakeholders who need it.
**What fails today.** N/A — new capability.
**Satisfied when.** Unconfirmed — depends on who the audience is (see [Q-9](07-open-questions.md))
and what "better" looks like (brainstorm topic 6, not yet answered).

## Cross-cutting requirements

All **[assumed]**, carried from the Unlimitail↔NIQ source material as the closest available
reference — none confirmed as binding on this pod's own build:
- Only consented shopper/exposure data may be used for matching to T-Log purchases.
- Shopper identifiers must remain stable, or be historized, so exposure can still be matched to a
  purchase that happens later within the attribution window.
- Row-level access: one advertiser/brand's data must never be visible to another.

## Day-one-or-lost-forever

Not yet identified. This requires answers to brainstorm topics 6–8 (what "better" looks like,
scope boundaries, and which disciplines this needs) that have not yet happened.
