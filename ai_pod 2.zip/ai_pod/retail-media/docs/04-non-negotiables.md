# 04 — Non-negotiables

Hard constraints the build may not violate. All rows below are **[assumed]** — carried from the
Unlimitail↔NIQ Activate source material as the closest available reference, not confirmed as
binding on this pod's own integration. Each needs an owner who can actually rule on it.

| Constraint | Owner | Applies to | Consequence if violated |
|---|---|---|---|
| Only consented shopper/exposure data may be used to match ad or offer exposure to a T-Log purchase | Legal/Compliance — **[owner TBD]** | R-3, R-4 | Non-compliant matching; privacy exposure |
| One advertiser/brand's campaign or offer data must never be visible to another (row-level security) | Engineering — **[owner TBD]** | R-5 | Data leakage across brands/CPGs |
| Attribution window and credit model must be explicit and disclosed, not silently changed | Data science — **[owner TBD]** | R-4 | Numbers become incomparable over time / undisclosed methodology |
| Data exchange route/environment with Unlimitail (file transfer vs. API, cloud location) is undecided even on Unlimitail's own side per their workshop agenda | Engineering — **[owner TBD]** | R-2, R-3 | Integration design blocked until resolved |

**This list is known to be incomplete.** Brainstorm topic 5 ("constraints — platform, contracts,
deadlines, regulation, data we cannot use") was never answered directly by the product owner.
