# Understanding dossier — Unlimitail × NIQ Activate closed-loop retail media

> Built from source material only (see provenance below). Nothing here has been traced against
> running code or a live contract review — this is a synthesis of documents, not a verified
> current-state dossier. Anything not directly stated in a source is marked **[assumption]** or
> **[question]**. Regenerate rather than hand-edit if the source set changes.

## Provenance

Read from `Archive 4.zip` (supplied 2026-08-12, extracted for review, **not committed to this
repo** — see "A note on the raw files" at the end):

| File | What it is |
|---|---|
| `Retail Media Measurement -closed loop concept design (no incrementality).docx` | Data-entity/interface spec for a "closed loop" retail media measurement MVP |
| `Unlimitail - Kick-off Meeting.pptx` | Phase 1 onboarding kickoff deck (Carrefour data onboarding into NIQ Activate) |
| `Unlimitail - Sales to Delivery handover.pptx` | Internal NIQ sales→delivery handover: who Unlimitail is, contract terms, scope, org |
| `Unlimitail Business Stream.pptx` | Workshop deck on report structure, hierarchies, and the Phase 2 architecture/data-flow diagram |
| `Unlimitail July 2027 workshop - discovery summary.docx` | Narrative summary of Unlimitail's **current** (as-is) operating model, gaps, challenges |
| `Unlimitail Workshop June 26.xlsx` | Workshop agenda/run-of-show for a discovery workshop |
| `Unlimitail_Dataplatform RFQ_UCs list - NIQ Response V1 - UPDATED 20 Jan 26 _Phase 1 estimations.xlsx` | 107-row use-case catalog with NIQ's feasibility response per use case |
| `Unlimitail_NIQ_Discovery_Questionnaire_ to_send.docx` | Pre-workshop discovery questionnaire template |

No code repository, API spec, or live system was available — everything below is second-hand,
from decks/docs produced by NIQ (the vendor) and workshop notes. Dates in the source material are
inconsistent (see [Q9](#open-questions--ambiguities)).

## 0. Glossary — who is who

| Name | What it is |
|---|---|
| **Unlimitail** | Retail-media joint venture, HQ France, launched June 2023 by **Carrefour** (retailer — shopper data + inventory) and **Publicis Groupe** (media/ad tech, via Epsilon/CitrusAd). Sells retail-media and measurement services to brands, across ~35 retail partners (Carrefour + others), not only Carrefour. |
| **NIQ / NielsenIQ** | The measurement/data vendor. Sells to Unlimitail via a 3-year SaaS deal. |
| **NIQ Activate** | NIQ's SaaS platform — insights, audience/segment builder, "closed-loop" measurement & reporting. This is the system Unlimitail is onboarding. |
| **CitrusAd / Epsilon** | Unlimitail's existing onsite retail-media ad tech (owned by Publicis). Separate from Activate. |
| **LiveRamp** | Unlimitail's current(-ish) identity resolution / clean room / data-lake provider — being displaced or coexisting; ownership unclear (Publicis acquired LiveRamp) **[question]**. |
| **Mediarithmics** | Understood to be Unlimitail's new CDP provider **[assumption, stated as "our assumption" in source]**. |
| **TheTradeDesk (TTD)** | The DSP used as the **MVP integration partner** in the generic closed-loop spec doc — this looks like a NIQ template written for a different/earlier engagement, not confirmed Unlimitail-specific (see [Q1](#open-questions--ambiguities)). |
| **Lotame** | Appears repeatedly in the RFQ use-case answers as the party that "collects exposure/conversion data" for many offsite/social measurement use cases — implies a data/identity partner in the actual Unlimitail architecture, not mentioned anywhere else in the deck set. **[question — under-documented]** |
| **T-Log** | Transaction log — the retailer's point-of-sale/checkout data, used as the "sales" side of closed-loop attribution. |
| **RETAIL_MEDIA_ID / Universal ID** | The identifier that links an ad exposure to a shopper, and that shopper to a T-Log purchase. |

## 1. What this initiative actually is

Two things are described in the source set that must not be conflated:

1. **A commercial SaaS onboarding**: Unlimitail is buying NIQ Activate (3-year deal, ~$1.2M TCV
   for Phase 1) to run **Loyalty insights, audience/segment creation, and retail-media closed-loop
   measurement** for Carrefour France, Spain and Brazil data, with Phase 2 = onboarding other
   retailers, Phase 3 = personalization/offer monetization.
2. **A generic closed-loop measurement methodology spec** (the `.docx` design doc), which reads as
   a reusable NIQ template (dated internally "by December 31, 2022", MVP partner = TheTradeDesk) —
   it explains **how closed-loop attribution works in NIQ Activate generally**, not a Unlimitail-
   specific integration design. Treat its data model as the *closest available proxy* for how
   Activate does measurement, not as confirmed Unlimitail wiring.

## 2. The problem, in the customer's own current-state (from the discovery-summary doc)

Unlimitail's current operating model, as described by their own team in workshop:

- **Strength**: consultative, insight-led planning — using granular retailer transaction data to
  find brand problems (lost customers, lost region/store/category, competitive pressure) that
  brands can't see themselves, then turning that into a media brief.
- **Weakness — fragmented execution**: no single system shows all campaigns across channels;
  teams check Meta, DSPs, onsite tech, etc. separately. Campaign metadata (advertiser, product
  scope, audience, dates) is not unified across platforms, which blocks reliable measurement.
- **Weakness — manual reporting**: reporting is built by hand from dashboards + Excel; analysts
  spend time on report production instead of insight. Full business-impact reports land ~45 days
  after campaign end (2 days for raw media metrics, then a 2–4 week attribution window, then
  report-building time — itself described as a *people* constraint, not a technical one).
- **Weakness — walled gardens**: Meta/social platforms don't expose user-level exposure data, so
  Unlimitail must rely on "partner lift" (measured inside the walled garden) or "alternative
  lift/conversion" (using targeted-but-not-confirmed-exposed audiences) instead of true
  exposed-vs-control measurement. Onsite is comparatively easy; open web is workable; walled
  gardens are the hard case.
- **Weakness — identity fragmentation**: multiple customer IDs exist (loyalty/account/card/
  individual); without a normalized universal ID, the same shopper can be double-counted across
  channels.

**This is the problem NIQ Activate is being bought to fix**: unify campaign metadata, resolve
identity once, and produce closed-loop sales-attribution measurement (ROAS) on a standard,
less-manual cadence — starting without incrementality (no test/control), added later.

## 3. Scope as contracted (Phase 1 vs. later)

| | Phase 1 (contracted, TCV $1.2M/3yr) | Phase 2 | Phase 3 |
|---|---|---|---|
| Scope | Loyalty insights, audience creation, retail-media **closed-loop measurement** | Onboard other retailers | Sell personalization as part of the retail-media offering (+15% rev share to NIQ) |
| Countries | Carrefour France, Spain, Brazil — **3 separate Activate instances**, one shared onboarding/config | — | — |
| Modules | "Insights Premium": Event Analyzer report + Assortment Distribution report | — | — |
| Users | 100 internal Unlimitail users only, **no external (brand/agency) access in Phase 1** | User-type/permission expansion "TBD" | — |
| Reference data | NIQ provides FMCG syndicated product characteristics (category hierarchy, manufacturer mapping) per country; Unlimitail ingests into its own data lake | — | — |

Key milestone dates from the kickoff deck: data sample by 29/07/26 → data onboarding complete
14/09/26 → portal config 15–28/09/26 → internal UAT 02–12/10/26 → customer UAT ready 12/10/26 →
go-live 29/10/26 (optional, dependent on customer UAT date).

## 4. The actual data flow (as specified)

Correcting/refining the shape you described at the start of this conversation — the source docs
describe a **more circular loop than "send shoppers → get offers back"**. There is no step where
Unlimitail/NIQ sends "media offers" to the retailer. Instead:

```mermaid
flowchart LR
    subgraph Retailer["Retailer (Carrefour)"]
        TLOG[T-Log: transactions]
        MAP[Customer Mapping File\nLOYALTY_ID -> RETAIL_MEDIA_ID]
        PRODMAP[Ad Products File\nAD_ID -> product/SKU]
        ADVMAP[Advertisers Mapping File\nCPG/brand for row-level security]
    end

    subgraph DSPside["DSP / Ad platform (e.g. TheTradeDesk in the generic spec)"]
        CAMP[Campaign / Ad Group / Ad metadata]
        ENGAGE[Campaign Engagement File\ncost, impressions, clicks]
        TARGET[Targeting File\nwho was targeted, when]
        INTERACT[Ad Interactions File\nimpression/view/click/purchase events, keyed by shopper]
    end

    Retailer -- daily files --> Activate[NIQ Activate]
    DSPside -- daily files --> Activate

    Activate -->|1. attribute T-Log sales to exposed shoppers\nwithin 14-day window, last-touch| Attribution[Sales attribution]
    Attribution -->|2. ROAS = Attributed Sales / Advertising Cost| Report[Measurement Report\nself-serve in Activate UI]
    Report --> Retailer
    Report --> Brands["Brands / CPGs (Phase 1: internal Unlimitail users only)"]
```

**Inputs to Activate** (all daily refresh unless noted):
- Customers Mapping File — retailer's loyalty ID ↔ retail-media ID (e.g. RampID/UID2.0)
- Ad Interactions File — impression/view/click/purchase events per shopper, keyed by
  `RETAIL_MEDIA_ID`, `CAMPAIGN_ID`, `AD_ID`, `TIMESTAMP` — from the identity-resolution
  solution/CDP/DSP, **consented data only**
- T-Log File — the retailer's own transaction log (existing interface, reused)
- Targeting File — who was targeted with which ad group/line item, and when
- Campaign / Ad Group / Ad(Creative) Metadata Files — from the DSP
- Ad Products File — maps an ad to the retailer's product/SKU for sales measurement
- Advertisers Mapping File — maps advertiser (CPG) to brand, for row-level security

**Output**: a Measurement Report inside Activate (self-serve UI), refreshed daily, with three
sections — top-KPI summary, a trend chart, and a drillable table.

## 5. Measurement methodology (Phase 1 — no incrementality)

- **Attribution window**: default 14 days (336 hours) from impression/view to purchase,
  configurable.
- **Attribution model**: **last ad view/impression gets all the credit** for MVP (even-split and
  first-touch models are explicitly deferred, not built).
- **ROAS** = Attributed Sales ($) / Advertising Cost ($). Cost basis defaults to the
  *advertiser's* cost (incl. retailer markup), not the retailer's raw cost — configurable.
- **No incrementality in Phase 1**: this is plain ROAS (exposed shoppers' sales ÷ cost), **not**
  incremental ROAS against a control group. Incrementality/mix modeling is explicitly Phase 2.
- **Row-level security**: retailer/internal sees all campaigns; each advertiser (CPG) sees only
  its own campaigns; competitor visibility is explicitly out of scope for MVP.
- Default KPI set: Impressions, Views, Clicks, Conversions, CTR, Conversion Rate, Advertising
  Cost, Attributed Sales, ROAS, Reach, CPM, CPC.

## 6. System / integration shape (Phase 2 target, from the Business Stream deck)

The deck's own "Friends Only – phase 2 scope" diagram describes the intended future data flow as:
**audience creation → activation → attribution → measurement**, through these components:

```mermaid
flowchart LR
    Activate["Activate\n(Planning, Segments & Audience Builder,\nClosed-loop measurement & reporting)"]
    CDP["NIQ CDP\n(Universal ID · audience activation)"]
    OneDB["OneDB\n(1) Campaign metadata\n(2) Ad<->Product mapping"]
    Channel["Media Channel\n(e.g. The Trade Desk)"]

    Activate -- "NIQ hierarchy enrichment (EAN + product hierarchy levels)" --> CDP
    Activate -- "Audience file (Audience ID + Universal ID + Control flag)" --> CDP
    CDP -- "Audience (Universal ID mapped to channel-specific ID)" --> Channel
    Channel -- "Attribution loop-back (Universal ID, Audience ID, Campaign/Adgroup/Ad ID, Channel, Action, Timestamp)" --> Activate
    OneDB -- "Campaign metadata (Campaign, Channel, Adgroups, Ads)" --> Activate
    Activate -- "Activate data incl. shopper attributes/segments" --> CDP
```

Note: this is a **Phase 2 target-state diagram**, explicitly labeled as such in the source — it
is aspirational, not the current build. Phase 1 is file-based batch ingestion, not this
closed-loop API architecture.

## 7. Current-state process flow (as-is, from the discovery summary)

```
Retailer data
  → Clean Data Hub / governed data layer
  → CDP / identity resolution / universal ID
  → Audience creation and segment logic
  → Activation platforms / broadcasters (onsite tech, LiveRamp/open web, Meta/social, DSPs)
  → Campaign events: exposure, clicks, impressions (or aggregate-only, depending on channel)
  → Sales / transaction matching
  → Measurement and reporting
```

Planning → brief → audience creation/feasibility → activation → (limited) optimization →
measurement/reporting, with **Sales** owning the brief and initial audience direction,
**Insights/analytics** supporting opportunity discovery and storytelling, **Operations** owning
campaign setup once briefed, and **Platforms/partners** varying wildly in what data they expose.

## 8. Use-case catalog (RFQ response, 107 rows)

The RFQ spreadsheet is NIQ's feasibility response to a longer list of desired capabilities,
grouped into six functional areas. Native product coverage ("Full" vs "Partial" vs "None" vs
"TBD") by area, from the sheet's own pivot:

| Functional area | Full | Partial | None | TBD |
|---|---|---|---|---|
| Activation | 81% | 6% | 6% | 6% |
| Data Collab / Clean Room | 55% | 0% | 18% | 27% |
| **Media Measurement** | **67%** | 0% | **33%** | 0% |
| Shopper Insights | 47% | 35% | 6% | 12% |
| Trade Insights | 71% | 14% | 14% | 0% |

**Media Measurement is the weakest-covered area with the most "requires custom development" /
"this requirement requires further discussion" answers** — directly relevant since this
initiative *is* about measurement. Specific measurement use cases flagged as needing custom work
or unresolved: Incrementality Test, GeoLift Measurement, Omnichannel Halo Effect, Sales Uplift
Modelling, Meta Partner Lift / Alternative Lift / Alternative Conversion, Attention Measurement,
Cannibalization & Transfer Analysis (partially — "Full" under Shopper Insights instead), Sales
Impact Review (marked "Requires custom development", current coverage "**None**").

Repeated pattern in NIQ's answers: Activate **creates and exports the audience**; a partner
(named "Lotame" in most Media Measurement rows, never introduced elsewhere in the deck set)
**collects the exposure/conversion data** and feeds it back to Activate for
reporting/visualization. Activate itself does not manage activation/delivery or walled-garden
pixels.

## 9. Assumptions found stated in the source material

These are *the source authors'* own explicit assumptions, not ones I've added:

- A single loyalty customer might have more than one Retail Media ID for the same retailer.
- The retailer already has (or will onboard to) an identity-resolution relationship; if not, its
  customer base is sent to an ID-resolution company for initial matching.
- A customer's retail-media ID may change over time — history must be kept for historical
  transaction identification.
- Ad Interactions data will include **consented data only**.
- An ad can map to multiple categories/brands, but MVP measures only a **primary** category/brand.
- Ads are dynamic; their parameters (name, description, etc.) can change — history may need to be
  kept.
- Default measurement cost basis is advertiser cost (incl. markup); can be reconfigured to
  retailer cost.
- "Our assumption" (NIQ, re: LiveRamp/Mediarithmics): Unlimitail extended its LiveRamp contract
  while this deal was being negotiated, since Publicis (owner of LiveRamp) also owns half of
  Unlimitail — **not confirmed**.
- Standard shopper-ID export assumed to go to **one endpoint** for all activation channels listed
  in the RFQ (repeated across most Activation-domain rows) — flagged by NIQ as "requires dev" if
  untrue.
- Assumption throughout the RFQ answers that Carrefour's own segmentation/shopper attributes will
  be supplied to Activate to enable several Shopper Insights use cases (profiling, HML analysis).

## 10. Open questions / ambiguities

Numbered so each can be assigned an owner later (Gate A requires every question to have one):

1. **Which DSP is actually integrated for Unlimitail?** **[Answered by product owner, 2026-08-12]**
   The closed-loop spec doc naming TheTradeDesk as "the MVP integration" is confirmed to be an old
   high-level design produced for a different company, reused here as a generic template — it does
   not describe Unlimitail's actual DSP or bind our integration. Which DSP/ad platform Unlimitail
   (or our own integration) actually uses is still open and needs a fresh answer; nothing in that
   spec doc's interface fields should be treated as confirmed.
2. **Who is "Lotame"?** It appears as the data source for most Media Measurement use-case answers
   in the RFQ, but is never named in the kickoff, business-stream, or discovery-summary
   documents. Is it a confirmed partner in the Unlimitail architecture, or a leftover reference
   from a different NIQ account/template?
3. **Is Phase 1 actually delivering closed-loop measurement, or only insights/audience-builder?**
   The kickoff deck's Phase 1 scope slide lists "Insights Premium: Event Analyzer + Assortment
   Distribution reports" — it does **not** list a Retail Media Measurement report module as
   in-scope for Phase 1, even though the Sales-to-Delivery deck's phase table puts "retail media
   measurement (inc. closed loop)" under Phase 1. These two slides disagree.
4. **What replaces "send shoppers → offer comes back"?** Your framing at the start of this
   conversation (tlog-based shopper selection sent out, offers sent back, results reported) does
   not match any flow in these documents. The documents describe audience/segment **export** for
   activation (one-way, to a media channel) and a **separate** attribution loop where DSP/CDP
   events + T-Log are matched inside Activate. If personalized **offers/coupons** (not media ads)
   are part of this initiative, that is the Phase 3 "Personalization" module, barely specified
   here (mentioned only as a commercial line item, no data spec).
5. **Identity resolution vendor for Phase 1**: LiveRamp, Mediarithmics, or NIQ's own CDP? The
   Sales-to-Delivery deck says Unlimitail currently relies on LiveRamp + "Memory" (via Carrefour
   France's Nielsen subscription) and is moving to Mediarithmics as CDP — but doesn't state which
   system performs ID resolution for the Activate integration itself.
6. **Data route/environment**: "Snowflake? Other?" and "Azure/GCP cloud environment location" are
   listed as **open questions in the source workshop agenda itself** — i.e., NIQ has not yet
   determined this with Unlimitail as of the workshop.
7. **Onsite vs. offsite vs. in-store measurement parity**: the discovery summary states offsite
   compares people while in-store compares stores — "making omnichannel reporting difficult." Is
   this initiative's measurement scope onsite-only, or all channels? The MVP spec's KPI table
   doesn't distinguish.
8. **External (brand/agency) access**: Phase 1 explicitly excludes external users (100 internal
   only), yet the discovery summary frames the whole value proposition as proving campaign value
   *to brands*. Who consumes the Phase 1 measurement report if not brands?
9. **Document dates don't line up**: the closed-loop spec doc targets go-live "by December 31,
   2022"; the kickoff deck is dated 07/07/2026 for a project starting mid-2026 with go-live
   10/2026; the discovery-summary doc is titled "July 2027 workshop" but its own content
   describes a Phase 2 SOW workshop that reads as concurrent with 2026 onboarding. These are
   either different projects/timelines bundled in one archive, or template dates were never
   updated — needs the product owner to confirm which document governs current scope.
10. **Contract-sensitive commercial terms** (TCV, fee schedule, revenue share %, SLA credits) are
    present in the handover deck. Confirm these should live in a product/engineering-facing
    document at all, vs. being kept out of anything that might be shared beyond the commercial
    team.

## 11. Risks noted directly in the source material

- "Main risk: Capacity to deliver measurement rapidly" — unknown number of campaigns to measure.
- Contract negotiations were tense; low fixed fee means NIQ must pursue personalization upsell and
  cross-retailer data monetization to make the deal work; **no customer-success budget was
  allocated**.
- Timeline risk from summer vacation period.
- Variance across the three portals (France/Spain/Brazil) in data/business requirements may add
  time even though the plan assumes one shared configuration.

## A note on the raw files

The original `.docx/.pptx/.xlsx` files (extracted from `Archive 4.zip` in your Downloads folder)
were **not copied into this repository**. Several contain commercially sensitive material (deal
TCV, fee tables, revenue-share terms, named individuals). Tell me if you want them committed under
`docs/sources/` as-is (per this folder's own convention of keeping raw inputs verbatim) — I'd
recommend confirming who else has access to this repo before doing that.
