# Source material

Raw inputs exactly as received — briefs, requirement documents, emails, exports, notes,
screenshots. Never edited: if something here is wrong, the correction goes in the document that
cites it, not in the source.

Each file gets a one-line provenance note in this README: what it is, who provided it, when.

| File | What it is | From | Date |
|---|---|---|---|
| [unlimitail-niq-activate-understanding.md](unlimitail-niq-activate-understanding.md) | Synthesis of 8 docs from `Archive 4.zip` (NIQ Activate onboarding decks/specs for the Unlimitail closed-loop retail-media integration) — the raw docx/pptx/xlsx were **not** committed here (commercially sensitive contract terms); see the note at the end of the file | Product owner, 2026-08-12 | 2026-08-12 |
