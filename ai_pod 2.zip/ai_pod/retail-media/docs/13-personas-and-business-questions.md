# 13 — Personas and business questions

**Status: not confirmed by direct interview.** Brainstorm topics 2 ("the users") and 3 ("the
questions, in their own words") were never reached — the conversation moved from topic 1 (the
problem) straight into source-document review. Everything below is **[assumed]**, drawn from the
Unlimitail-side discovery-summary document (which describes *Unlimitail's own* team, not
necessarily this pod's users), and must be corrected or replaced by the product owner before
Gate A can close.

## Candidate personas [assumed — unverified]

| Persona | Role today (as described for Unlimitail, not confirmed for this pod) | Judged on |
|---|---|---|
| Sales / commercial owner | Owns the brand relationship, starts the brief, often defines the initial audience direction | Revenue, brand relationship |
| Insights / analytics | Finds the opportunity in retailer data, builds audience logic, tells the story in the report | Quality/speed of insight, storytelling |
| Operations | Sets up the campaign/offer on the chosen platform, monitors delivery/budget | Delivery reliability |
| Brand / advertiser | Provides the objective and often the budget; wants proof the spend worked | ROAS / proof of value |

## Candidate business questions [assumed — unverified]

- "Did this campaign/offer actually move sales, and for which shoppers?"
- "How much of the media/offer cost is justified by real purchases (ROAS)?"
- "Which shoppers should we select next time, based on what worked?"
- "Can I trust this number, or is it a partial/alternative measurement because we couldn't see
  exposure directly?" (relevant if any channel behaves like a walled garden for this pod's data)

## What's missing

The actual users of what **this pod** is building — not Unlimitail's internal team — and their
own words for the question they're asking, have not been captured. This needs a return to
brainstorm topics 2–3 with the product owner before this document can be trusted for design.
