# Decisions

## Principles
The pod's operating principles apply in full. The five that bind most often:
- A feature is the smallest testable unit that answers a business question, end to end.
- Every decision carries its reason. A decision without a because is not landed.
- Conflicts with a landed decision stop work and surface — nothing is guessed past a gate.
- A defect class that recurs becomes a mechanism, fixed once in the tooling.
- Claims are bound to evidence mechanically: computed numbers, honest refusals, no overclaiming.

## Decision log

### D-1 · 2026-08-12 · Closed-loop retail media initiative launched, scoped provisionally around the Unlimitail integration
**Decision.** This pod will build a closed-loop retail-media capability: select a shopper audience
from the retailer's own T-Log, send it to Unlimitail (a 3rd-party retail-media network), receive
activation/exposure results back, and attribute sales to it to produce ROAS-style measurement.
**Because.** The product owner stated this as the initiative's shape directly. In the absence of a
confirmed contract or spec for this pod's own integration, source documents describing Unlimitail's
own onboarding of NIQ Activate (`docs/sources/unlimitail-niq-activate-understanding.md`) are being
used as the best available reference for data model and methodology, pending confirmation they
apply here.
**Supersedes.** Nothing — first decision.
**Consequences.** [docs/01-REQUIREMENTS.md](../docs/01-REQUIREMENTS.md),
[docs/04-non-negotiables.md](../docs/04-non-negotiables.md) and
[docs/05-scope-boundary.md](../docs/05-scope-boundary.md) are drafted provisionally and marked
**[assumed]** throughout. Gate A cannot close until the 15 items in
[docs/07-open-questions.md](../docs/07-open-questions.md) — most critically Q-1, which side of the
Unlimitail relationship this actually is — are resolved.

### D-n · <date> · <short title>
**Decision.** What was decided.
**Because.** The reason.
**Supersedes.** What it replaces, if anything — never deleted.
**Consequences.** What must now be true elsewhere.
