# Board

**This file governs.** The folders mirror it for visibility.

| ID | Item | Status | Gate | Owner |
|---|---|---|---|---|
| G-A | Closed-loop retail media (Unlimitail integration): requirements framed, questions have owners | in progress — 15 open questions still lack a resolution, see [docs/07-open-questions.md](../docs/07-open-questions.md) | Gate A | Product |
| G-B | Contracts signed *(skip if no method question)* | not started | Gate B | Data science |
| G-C | First feature tickets drafted and approved | not started | Gate C | Pod |
