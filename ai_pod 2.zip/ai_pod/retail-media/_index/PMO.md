# PMO view — Offer allocation

*Generated 16 August 2026, 17:42. Nothing here is maintained by hand —
if a number looks wrong, the underlying file is wrong.*

| Accepted | In progress | Blocked | Not started | Open items | Decisions |
|---|---|---|---|---|---|
| 0 | 1 | 0 | 2 | 13 | 1 |

## Delivery

| ID | Item | Status | Gate | Owner |
|---|---|---|---|---|
| G-A | Closed-loop retail media (Unlimitail integration): requirements framed, questions have owners | in progress — 15 open questions still lack a resolution, see [docs/07-open-questions.md](../docs/07-open-questions.md) | Gate A | Product |
| G-B | Contracts signed *(skip if no method question)* | not started | Gate B | Data science |
| G-C | First feature tickets drafted and approved | not started | Gate C | Pod |

## Accepted features

_Nothing accepted yet._

## Landings

_Nothing has landed yet._

## Open items and blockers

| # | Item | Owner | Blocks |
|---|---|---|---|
| Q-1 | Which side of the Unlimitail relationship are we actually building? The source documents describe **Unlimitail buying NIQ Activate** (vendor→customer). The product owner described **a retailer sending a shopper list to Unlimitail and getting media/offers + results back** (retail-partner→network). These are different relationships with different data contracts. | Product owner | Every requirement in [01-REQUIREMENTS.md](01-REQUIREMENTS.md) |
| Q-3 | Who/what is "Lotame"? It appears throughout the source material's measurement answers but is never introduced — is it part of our integration? | Product owner | R-3, R-4 |
| Q-5 | What precisely comes back from Unlimitail — an exposure/targeting event feed (who was shown what, when), or literal offer/coupon content? | Product owner | R-3, R-5 |
| Q-6 | Which identity-resolution/CDP sits between our shopper IDs and Unlimitail's? | Product owner / Engineering | R-2, R-4 |
| Q-7 | What is the data exchange route and environment (file transfer vs. API, cloud location)? Unlimitail's own workshop agenda lists this as unresolved on their side too. | Engineering | R-2, R-3 |
| Q-8 | Which channels are in scope for measurement — onsite only, or also offsite/in-store/walled-garden? | Product owner | R-4, R-5 |
| Q-9 | Who consumes the R-5 report — our internal team only, or brands/advertisers directly? | Product owner | R-5, [13-personas-and-business-questions.md](13-personas-and-business-questions.md) |
| Q-10 | What is today's actual current state (manual process, spreadsheet, or nothing) that this initiative replaces? (Brainstorm topic 1/4, never answered.) | Product owner | [05-scope-boundary.md](05-scope-boundary.md), R-1 |
| Q-11 | Who are the users, in their roles, and what do they ask in their own words? (Brainstorm topics 2–3, never answered.) | Product owner | [13-personas-and-business-questions.md](13-personas-and-business-questions.md) |
| Q-12 | What constraints are already fixed for **this** integration specifically — distinct from Unlimitail's own NIQ contract terms? (Brainstorm topic 5, never answered.) | Product owner | [04-non-negotiables.md](04-non-negotiables.md) |
| Q-13 | What does "better" look like, six months in? (Brainstorm topic 6, never answered.) | Product owner | Priorities, success criteria |
| Q-14 | What's explicitly deferred, and does the product owner agree with the deferrals inferred from source material? (Brainstorm topic 7, partially inferred, not confirmed.) | Product owner | [05-scope-boundary.md](05-scope-boundary.md) |
| Q-15 | Which disciplines does this need — is there a data-science question at all, or is it product/engineering/design only? (Brainstorm topic 8, never answered.) | Product owner | Team composition, priorities |

