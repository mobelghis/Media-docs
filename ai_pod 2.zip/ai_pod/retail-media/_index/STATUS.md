# Status — Offer allocation

*Generated 16 August 2026, 17:42 from the board, the decision log and the
open questions. Do not edit — run `make index`.*

## The gates

| Gate | What | Signed by | State |
|---|---|---|---|
| Gate A | Questions signed | Product | in progress |
| Gate B | I/O contracts signed | Data science | not started |
| Gate C | Tickets approved | Product + DS + Engineering | not started |
| Gate D | Features accepted | Product | not started |

## The board

`features/BOARD.md` governs; this is a view of it.

| ID | Item | Status | Gate | Owner |
|---|---|---|---|---|
| G-A | Closed-loop retail media (Unlimitail integration): requirements framed, questions have owners | in progress — 15 open questions still lack a resolution, see [docs/07-open-questions.md](../docs/07-open-questions.md) | Gate A | Product |
| G-B | Contracts signed *(skip if no method question)* | not started | Gate B | Data science |
| G-C | First feature tickets drafted and approved | not started | Gate C | Pod |

## Decisions

| ID | Date | Decision |
|---|---|---|
| D-1 | 2026-08-12 | Closed-loop retail media initiative launched, scoped provisionally around the Unlimitail integration |

## Open questions

| # | Question | Owner | Blocks | Status |
|---|---|---|---|---|
| Q-1 | Which side of the Unlimitail relationship are we actually building? The source documents describe **Unlimitail buying NIQ Activate** (vendor→customer). The product owner described **a retailer sending a shopper list to Unlimitail and getting media/offers + results back** (retail-partner→network). These are different relationships with different data contracts. | Product owner | Every requirement in [01-REQUIREMENTS.md](01-REQUIREMENTS.md) | open |
| Q-2 | ~~Which DSP/ad platform actually delivers the media/offer in our integration?~~ Resolved: the closed-loop spec doc naming TheTradeDesk was an old high-level design produced for a different company — it does not bind our DSP choice. Which DSP/ad platform we actually integrate with is still undecided and needs a real answer. | Product owner | R-2, R-3 | open — reframed |
| Q-3 | Who/what is "Lotame"? It appears throughout the source material's measurement answers but is never introduced — is it part of our integration? | Product owner | R-3, R-4 | open |
| Q-4 | Is closed-loop measurement in scope now, or only audience/segment export, with measurement coming later? (Two source decks disagree on this for the Unlimitail↔NIQ deal itself.) | Product owner | Overall scope | open |
| Q-5 | What precisely comes back from Unlimitail — an exposure/targeting event feed (who was shown what, when), or literal offer/coupon content? | Product owner | R-3, R-5 | open |
| Q-6 | Which identity-resolution/CDP sits between our shopper IDs and Unlimitail's? | Product owner / Engineering | R-2, R-4 | open |
| Q-7 | What is the data exchange route and environment (file transfer vs. API, cloud location)? Unlimitail's own workshop agenda lists this as unresolved on their side too. | Engineering | R-2, R-3 | open |
| Q-8 | Which channels are in scope for measurement — onsite only, or also offsite/in-store/walled-garden? | Product owner | R-4, R-5 | open |
| Q-9 | Who consumes the R-5 report — our internal team only, or brands/advertisers directly? | Product owner | R-5, [13-personas-and-business-questions.md](13-personas-and-business-questions.md) | open |
| Q-10 | What is today's actual current state (manual process, spreadsheet, or nothing) that this initiative replaces? (Brainstorm topic 1/4, never answered.) | Product owner | [05-scope-boundary.md](05-scope-boundary.md), R-1 | open |
| Q-11 | Who are the users, in their roles, and what do they ask in their own words? (Brainstorm topics 2–3, never answered.) | Product owner | [13-personas-and-business-questions.md](13-personas-and-business-questions.md) | open |
| Q-12 | What constraints are already fixed for **this** integration specifically — distinct from Unlimitail's own NIQ contract terms? (Brainstorm topic 5, never answered.) | Product owner | [04-non-negotiables.md](04-non-negotiables.md) | open |
| Q-13 | What does "better" look like, six months in? (Brainstorm topic 6, never answered.) | Product owner | Priorities, success criteria | open |
| Q-14 | What's explicitly deferred, and does the product owner agree with the deferrals inferred from source material? (Brainstorm topic 7, partially inferred, not confirmed.) | Product owner | [05-scope-boundary.md](05-scope-boundary.md) | open |
| Q-15 | Which disciplines does this need — is there a data-science question at all, or is it product/engineering/design only? (Brainstorm topic 8, never answered.) | Product owner | Team composition, priorities | open |

