# What changed in this round, and how to apply it

Nine gaps were found reviewing the repository as an end user. All nine are addressed here.
Nothing was deleted silently; retired material is marked as retired.

## 1 · The method had drifted three ways
`_method/` was **behind both pods**: no `build_plan.py`, no `sign_off.py`, no `PLAN.yml` /
`VIEWS.yml`. Meanwhile `offer-allocation` had the newer scripts but was missing `/brainstorm`,
`/frame`, `/market` and `/panel`, which existed only in `retail-media`.

`_method/` is now the **superset**, and both pods plus the greenfield template have been brought
up to it. A pod copied from `_method/` now gets everything.

## 2 · Drift can no longer happen quietly
`.github/workflows/index-freshness.yml` is now **pod checks**, with two jobs:
- **views-are-current** — regenerates every pod's views and the portfolio, and fails if what is
  committed differs.
- **method-has-not-drifted** — fails if any pod's scripts, commands or skills differ from
  `_method/`.

Each pod stays self-contained, which the working agreement requires; the check removes the drift
that self-containment invites.

## 3 · The decision log now holds the decisions
`offer-allocation/pod/DECISIONS.md` carried only D-1 and D-2, both with `<date>` placeholders.
It now records **D-1 to D-9** with real dates and reasons: campaign = wave, the Phase 1 scope, the
three new epics, scale-as-budget, the availability approach, the front-end findings, and the board
speaking Jira's language.

## 4 · One set of features, not two
The board carried internal placeholders `F-1..F-24` alongside a Jira import from an earlier round,
while the epic work produced 42 stories mapped to real epic keys. The board now uses **real Jira
epic keys** grouped by phase. `features/JIRA-IMPORT-stories.csv` is the current story set;
the old file is kept as `RETIRED-JIRA-IMPORT-placeholders.csv`, and the board's *Retired* section
records why.

## 5 · The pod index is generated, not typed
`scripts/build_portfolio.py` produces `_portfolio/index.html` and `PORTFOLIO.md`, and rewrites the
pod table in `README.md` between markers. It reads each pod's board, decision log and open
questions. The README table can no longer be wrong because someone forgot to edit it.

## 6 · A front door across both pods
`_portfolio/index.html`: per-pod cards with gate states and counts, every open question across the
repository with its owner, and recent decisions from both pods.

## 7 · The new work is in the repository
- `docs/20-epic-review-and-phase-1.md` — every Jira epic reviewed, and the Phase 1 scope
- `docs/21-design-current-and-redesign.md` — the minimum for the Angular app, and three redesign options
- `docs/22-new-epic-descriptions.md` — descriptions for XXX-1/2/3, ready to paste into Jira
- `assets/` — the flow, layer, dependency, funnel, availability and design wireframes, plus the
  three decks and the design document

## 8 · Junk removed
`.DS_Store` files and `scripts/__pycache__` deleted; `.gitignore` extended.

## 9 · Everything regenerated
Both pods' views and the portfolio are current, so CI passes from the first push.

---

## To apply

```bash
cd <your ai_pod clone>
# copy this folder's contents over your working tree, then:
git add -A
git rm -r --cached --ignore-unmatch offer-allocation/scripts/__pycache__ 2>/dev/null
git commit -m "Sync the method, record the decisions, map the board to Jira, add the portfolio view"
git push
```

## Two things still for you
1. **Create XXX-1, XXX-2, XXX-3 in Jira** (descriptions in `docs/22`), then replace the `XXX-` keys
   in `features/JIRA-IMPORT-stories.csv` and `features/BOARD.md` with their real keys.
2. **`retail-media` inherits the method but is still thin** — 7 documents, and its open questions
   are mostly unanswered brainstorm items. It needs the same intake pass that offer-allocation had.

---

# Round two · cleaning the record for kickoff

Every document was reviewed against the phasing decisions. Nothing was rewritten silently — each
change is a **dated amendment** (2026-08-16) at the foot of the document it affects, so the earlier
text stays visible beside its correction.

## Documents amended, and why

| Document | What was stale |
|---|---|
| `01-REQUIREMENTS` | Read as a single rebuild. Now states the three phases, and that "satisfied when" describes the end state rather than the 2026.4 increment — with the four irreversibles explicitly **not** deferred by phasing |
| `05-scope-boundary` | Claimed the programme replaces scoring and measurement, which Phase 1 does not. Now separates what Phase 1 changes from what it explicitly leaves alone, and gives every deferred item a named epic |
| `08-FRONTEND-SURFACE-REQUIREMENTS` | Proposed building three things that already exist. Corrected against the recreation guide, plus the two inherited constraints: the retailer metadata system, and the 127 ceiling |
| `09-PROPOSED-IO-CONTRACTS` | Implied all five contracts were needed at once. Now phased: C-3 and part of C-4 are Phase 1; C-1 returns in Phase 2; C-2 and C-5 are Phase 3 — with C-5's *inputs* captured in Phase 1 |
| `10-ENTITY-PLACEMENT` | Modelled a campaign entity. Superseded by D-3: policy and wave are the two real entities, plus a `series_id` grouping key |
| `14-CURRENT-SYSTEM-PRD` | Campaign entity in the diagrams; no detail of the policy screen. Both corrected, plus the eight marketing objectives and why control sits inside allocation |
| `17-REQUIREMENT-TRACE` | Read as a single build. Now states which rows are Phase 1, 2 and 3, and which three are smaller than written |
| `03-defect-catalogue` | D-04 stated flatly. Now **partly remediated, unverified**, pending Q-12 |
| `02-current-state` | No detail of the policy screen or the product picker. Added |
| `18-question-register` | Pointed at internal placeholders. Now points at stories under real epic keys |
| `19-priorities` | Client roadmap with no reading against the pod's phasing. Added, including the two unresolved roadmap conflicts |

## Open questions rewritten
`07-open-questions.md` was a flat list mixing answered, stale and live items. It is now three
sections — **blocking Phase 1** (10 questions, each with what it blocks and when the answer is
needed), **blocking Phase 2 or 3** (8), and **Closed** (4, with their answers and dates).

Six new questions were added from this round's work: what the availability feeds actually contain,
which clients send a primary-store feed, the multi-product availability rule, whether the constraint
type enum takes a fifth value, who maintains virtual categories, and whether the 127 ceiling stays.
Four were closed: request-time serving, how blocking differs from today (it does not exist at all),
where R-9 lives, and Angular versus React — **Angular**, confirmed.

## The design material
`docs/21-design-current-and-redesign.md` is current and needed no correction: it was written after
the code review. `docs/08` now points to it, and the three wireframe options plus the full document
are in `assets/`.

## Still for you
1. Create XXX-1/2/3 in Jira and replace the placeholder keys in the CSV and the board.
2. Give `retail-media` the same intake pass — it has 7 documents and 13 unanswered brainstorm
   questions, and its open-questions file has not been through this clean-up.

---

# Round three · the guided flow, the gate command, and seven more skills

## Three new commands — in `_method/` and in every pod

**`/help`** — reads the board, the decision log and the record, then answers in this order: where
this pod is right now, what you should probably do next, the full command table, the make targets,
and one reminder that fits the current state. If you ask for help mid-task it answers the task
first.

**`/sign-off`** — records a gate properly: the decision with its reason, the board row, the
regenerated views. Before writing, it checks the gate's own test and tells you if it is not met —
and if you sign anyway, the objection goes into the decision text rather than only into the chat.

**`/research`** — the guided product-owner flow, in seven stages, stopping between each:
1. **What is this?** — a change to something that exists (URL, screenshot, a few sentences), something
   entirely new, or a field on an existing surface. It states back what you are working on before
   proceeding.
2. **Reverse-engineer the current state** — the trace from URL down to tables, **steps to reproduce
   on the front end** (how to reach the screen and what state it needs), the front-end/back-end and
   back-end/model **contracts**, what it computes today including what is wrong, the consumers, the
   permissions, and what is retailer-configurable. Then **a Jira search** for related epics and
   tickets, listed with key and status.
3. **Frame it as questions**, in the user's words, agreed before anything else.
4. **Optional passes** — market and competitor work, a PRD refresh, a data check. It asks; it does
   not assume.
5. **The panel** — the personas review it, RULED or FOR DECISION, closing statement with the risk.
6. **Ideation, kept separate** — low-hanging and further-out, explicitly marked as not part of the
   requirement so it cannot leak into it.
7. **The requirement and the epics** — a requirements document in this pod's shape, stories per
   discipline, a Jira import file, new open questions with owners, and a decision entry.

`make help` also lists the targets.

## Seven new skills — fifteen in total, grouped

| Group | Skills |
|---|---|
| **Method** | pod-method · record-keeping · panel-review · **product-requirements** · **jira-conventions** |
| **Building** | stack-conventions · **frontend-conventions** · **performance-budgets** · verification-standards · reverse-engineering · design-gate |
| **Domain** | **measurement-standards** · **commercial-context** · **competitive-analysis** · domain-knowledge *(still a stub — the most valuable one to fill)* |

The new ones carry what a session cannot look up: how we write requirements and amendments; how
epics, stories and the import file are shaped; how the Angular app is actually built (metadata-driven
forms, the generic constraint model, the 127 ceiling, permissions); how runtime budgets work
(precompute once, prune before scoring, measure rather than estimate); what we will and will not
claim about effect; how supplier funding, minimums and cost models actually work; and how to do
competitor work honestly, including the section most analyses omit.

The test applied to every one of them, and recorded in the skills README: *would a competent new
hire need to be told this, and would they get it wrong otherwise?* Role-playing skills were
deliberately not added.

## Applied everywhere
`_method/` is the master; `offer-allocation`, `retail-media` and `_templates/greenfield` all carry
13 commands and 15 skills, and CI's `method-has-not-drifted` job fails if they diverge. All views
and the portfolio are regenerated.

---

# Round three, correction · the dossier reads code, not tickets

`/research` stage 2 originally searched Jira for related work. That is removed.

**Why.** Tickets describe what someone *intended* to build; only the code says what runs, and the
two diverge whenever something was scoped and then cut. A dossier assembled from ticket text reads
authoritatively and can be wrong in ways nobody catches — the worst combination.

**What it does instead.** It reads the repositories listed in `pod/REPOS.yml`, using whichever
access the session has: the repository checked out beside the pod folder, or a GitHub connector.
And the instruction that makes it safe: **if the code cannot be reached, say so at the top of the
dossier and stop** rather than producing something plausible.

The same rule is now in the `reverse-engineering` skill, so it holds whether or not the command is
used: *never establish behaviour from ticket descriptions, specifications or memory.*

Jira still appears in the flow at the end — as the **import format** for the stories the research
produces. That is Jira as a destination, not as a source.
