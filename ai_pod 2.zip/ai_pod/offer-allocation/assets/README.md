# Assets

Screenshots and diagrams referenced by documents.
- Named for what they show, not when they were made.
- Referenced from a document, or deleted.
- Large binaries and any client data never enter this repository.
