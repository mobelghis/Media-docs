# 12 — Market and competitive context

Why this rebuild is worth doing, and what makes it different from what a retailer could buy.
Carried forward from prior product research; treat figures as directional and re-verify before
anything external quotes them.

## The market shape
Personalised offer allocation is served today by a small number of established players — the
retailer-data specialists (dunnhumby, 84.51°), the coupon networks (Catalina), the loyalty and
promotion platforms (Eagle Eye and similar), and the retail-media stacks that monetise placement
rather than outcome. Large retailers with in-house data science build the allocation core
themselves and buy the layers around it.

## Where the field is weak — and where this programme aims
| Weakness in the field | What we do instead | Requirement |
|---|---|---|
| Lift numbers that cannot be defended under scrutiny | Randomised arms from wave one, power-gated reporting, reproducible re-measurement | R-10, R-A |
| Commitments sold, then not enforced by the system | Floors in the allocator, feasibility certified before the run, joint reconciliation | R-8, R-E |
| Budgets tracked in spreadsheets beside the system | An append-only ledger inside it, with fiscal attribution | R-8, R-C |
| "Why did this offer under-issue?" answered in days, by guesswork | The explain funnel: named rule families with counts, in the same session | R-D |
| Rules that exist in people's heads because the tool cannot express them | Category limits at any level, cross-campaign rest, blocking and exclusions authored explicitly | R-2, R-4, R-5 |
| Planning by asking an analyst and waiting | Exact counts and priced scenarios, interactively, before commitment | R-7, R-9 |

## What buyers said (mock panel, three enterprise personas)
Three fictional buyers at large-retail scale were pitched the design. Verdicts and the reasoning
worth keeping:
- **Loyalty lead, top-5 grocer — would buy.** Sold by the measurement design ("the waves I already
  run become the control group"), enforcement of commitments ("we sell them today with nothing
  enforcing them"), and the explain funnel ("three days and a guess becomes a same-meeting
  answer"). Chose transparency over incumbent science: *"it stops lying to me before I stop
  believing it."*
- **Chief data officer, mass merchant — would not buy the allocator, would buy the trust layer.**
  At that scale the allocation core is built in-house; the measurement, certificate and
  commitments layer is what they cannot get politically. Gate: proof at their data volume.
- **Retail-media lead — would buy conditionally.** Values the money plumbing ("finance-grade for a
  market that runs on screenshots"); requires the supplier-facing tier, which is deferred here.

**Cross-cutting signal:** all three, unprompted, said value-linked pricing would be credible
*because* the measurement is honest. Honesty is a commercial asset, not only an engineering one.

## What this means for the build
1. The measurement and commitment layers are differentiators, not hygiene — they earn the same
   care as the allocator.
2. Scale proof is sales-critical, not merely reassuring: no benchmark is quotable until it runs at
   production shape.
3. Transparency is the product's competitive position. Anything that overclaims damages the thing
   we are selling.
