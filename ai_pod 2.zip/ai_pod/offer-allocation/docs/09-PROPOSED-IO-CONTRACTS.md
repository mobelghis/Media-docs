# 09 — Proposed I/O contracts (a draft to argue with)

**Status: PROPOSED, not agreed.** Written by product and architecture so that data science starts
from a draft rather than a blank page. Every contract here is expected to be **confirmed,
amended, or replaced** at Station 2 — that is the work, and disagreement is the point.

Five quantities cross the boundary between the method and the system. Everything else is internal
to one side or the other.

```
   TLOG + hierarchy ──▶ C-1 propensity ──▶ C-2 redemption probability
                                   │              │
   policy + ledgers ──▶ C-3 candidate set ────────┤
                                                  ▼
                                          C-4 allocation decision
                                                  │
                                                  ▼
                                          C-5 measured effect
```

---

## C-1 · Shopper–node propensity
**Question it serves.** Which products is this shopper likely to buy? (R-7, R-10)

**Inputs**
| Input | Grain | Source | Notes |
|---|---|---|---|
| Transaction lines | shopper × item × date, with units and spend | TLOG | daily deltas; history depth is a parameter |
| Product hierarchy | item → sub-category → category → department, plus brand | product master | the **grain of aggregation is a decision, not a given** — prior evidence says it dominates model choice |
| Store ranging | item × store | availability feed | grain mismatch is a known defect (D-09) |
| Recency weighting | — | parameter | half-life is a parameter, not a constant |

**Outputs**
| Field | Type | Meaning |
|---|---|---|
| `shopper_id` × `node_id` | key | node = the grain the contract settles on |
| `score` | numeric, ordered | a **ranking quantity**, explicitly not a probability |
| `support` | integer | evidence behind the score (e.g. distinct qualifying events) |
| `score_source` | enum | which path produced it, so a reader never guesses |

**Assumptions to confirm.** Past purchasing predicts future purchasing within the window; the
chosen node grain is the level at which offers are actually defined.
**Validation.** Ranking quality on held-out periods; stability under recomputation; agreement
between incremental and full computation.
**Not yet known.** The node grain. Whether one score suffices or repeat, discovery and incremental
effect need separate quantities (prior evidence says separate).

---

## C-2 · Redemption probability
**Question it serves.** What will this cost, and what will it return? (R-8, R-9)

**Inputs.** C-1 score and support; offer mechanic and depth; funding pool; historical redemption
outcomes at the same grain.

**Outputs**
| Field | Type | Meaning |
|---|---|---|
| `p_hat` | 0–1 | probability an issued coupon is redeemed in its window |
| `p_source` | enum | per-pair estimate / stratum rate / default — **never collapsed into the number** |
| `expected_cost` | money | derived from `p_hat` and the pool's cost model |

**Assumptions to confirm.** A score can be calibrated to a probability per stratum; strata are
defined by the factors that shift the base rate rather than the ranking.
**Validation.** Calibration curves and error decomposition per stratum; back-test against realised
redemption at pool level.
**Non-negotiable.** The same stored estimate drives cost **and** any benefit term that depends on
redemption, so an offer can never be attractive and unaffordable at once (N-10).
**Not yet known.** Whether per-pair estimates are trustworthy enough to use at all — the proposal
is a per-pool gate on measured forecast error, with the stratum rate as the fallback.

---

## C-3 · Candidate set (eligibility)
**Question it serves.** Who *may* receive this offer, and who was removed and why? (R-2..R-6, R-D)

**Inputs.** Offer product set (resolved to a frozen item list); policy rules — category limits,
rest periods, blocking, exclusions; cross-campaign exposure ledger; store ranging; audience
membership; shopper status (opt-outs, deletions).

**Outputs**
| Field | Type | Meaning |
|---|---|---|
| `offer_id` × `shopper_id` | key | the candidate pair |
| `eligible` | boolean | the verdict |
| `funnel counts` | per rule family | eligible → removed by each named family → remaining |
| `snapshot_id` | key | the frozen population this was computed against (N-6) |

**Assumptions to confirm.** Rules compose without ordering effects except where precedence is
stated (**exclude always wins**).
**Validation.** Counts reconcile: every removed shopper is attributed to exactly one family;
totals sum.
**Not yet known.** Whether availability can be applied at the required grain with current data
(Q-3, Q-4).

---

## C-4 · Allocation decision
**Question it serves.** Which offers does each shopper get, and can we honour what we promised?
(R-1, R-2, R-5..R-9, R-E)

**Inputs.** Candidate sets (C-3); scores (C-1); costs (C-2); per-shopper limits and category
rules; per-offer minimums and maximums; pool budgets and caps; arm assignment.

**Outputs**
| Field | Type | Meaning |
|---|---|---|
| `allocation` rows | shopper × offer × slot | the decision |
| `arm` | enum | treatment / control / ghost — recorded for held-out shoppers too (N-15) |
| `reason` | code | the binding constraint at the moment a candidate lost |
| `shadow price` per constraint | numeric | what the binding constraints cost — the basis for planning answers |
| `feasibility verdict` | enum | FEASIBLE / **INFEASIBLE with the conflict named** / NOT-FOUND — never merged (N-4) |
| `frame fingerprint` | hash | what this was decided from, so it can be re-run identically (N-6) |

**Assumptions to confirm.** The objective is stated over the whole portfolio a shopper receives;
any greedy or heuristic procedure is documented as an approximation *of* that objective, not as
the objective.
**Validation.** Constraint satisfaction proven on the output, not assumed; a measured gap against
exact solutions on real instances; a planted-infeasible case that must be reported as infeasible
rather than as a failure to find.
**Not yet known.** The optimality claim that can honestly be made, and the method that supports it.

---

## C-5 · Measured effect
**Question it serves.** What did this cause? (R-10)

**Inputs.** Arms and ghost log from C-4; frozen eligibility snapshot; outcome window transactions
(purchase of the offer's product set — **not** redemption, N-13); exposure ledger.

**Outputs**
| Field | Type | Meaning |
|---|---|---|
| `effect` | estimate | with its confidence interval |
| `power_state` | enum | powered / underpowered — underpowered is a verdict, not a footnote (N-2) |
| `decomposition` | components | direct, halo, cannibalisation, pull-forward, net |
| `basis` | references | wave, arm, snapshot and parameters that produced it |

**Assumptions to confirm.** Randomisation is valid at the unit chosen; interference from
per-shopper limits is handled by the design rather than assumed away.
**Validation.** Planted-effect recovery — a known injected effect must be recovered, and a null
must stay null.
**Not yet known.** The estimand itself, the unit of randomisation, and how attribution works where
offers share products. **These are the highest-value questions in the programme.**

---

## How to use this document
1. Data science reads it before writing anything, and treats every line as a claim to test.
2. Each contract is then rewritten in `pod/templates/io-contract.md` shape, as the real one.
3. A contract is signed when inputs and outputs are precise enough that the build can start
   without guessing — **not** when the method behind it is finished.
4. Where this draft is wrong, the correction is the valuable output. Say so plainly and replace it.

---

## Amendment · 2026-08-16 — which of these five belong to Phase 1

All five contracts remain the shape of what crosses the boundary. Phasing (D-4) changes only when
each is needed:

| Contract | Phase | Note |
|---|---|---|
| C-3 candidate set (eligibility) | **Phase 1** | This is where Phase 1 lives: limits, chilling, blocking, availability all shape the candidate set |
| C-4 allocation decision | **Phase 1, partly** | Phase 1 adds constraints and the reason codes behind the funnel. Shadow prices and the feasibility verdict follow with the engine work |
| C-1 propensity | **unchanged in Phase 1** | Scoring is untouched. The contract matters again for CR-38876 in Phase 2 |
| C-2 redemption probability | Phase 3 | Needed by the money layer and the planning forecasts |
| C-5 measured effect | Phase 3 | Needed by CR-38880 — but its **inputs** are captured in Phase 1 by CR-40346, and cannot be captured later |

The contracts remain drafts for data science to confirm, amend or replace. Where the pod has since
learned something that touches them — the shared definition of product overlap, the availability
rule's multi-product behaviour — it is recorded in the decision log, not silently merged here.
