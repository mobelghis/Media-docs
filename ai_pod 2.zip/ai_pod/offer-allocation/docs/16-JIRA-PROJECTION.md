# 16 — Jira, and how it relates to the board

Some of the organisation lives in Jira. That is fine, and it does not change where the work is
defined.

## The rule
**`features/BOARD.md` governs. Jira is a one-way projection of it.**

Work is defined, prioritised and tracked in the pod. When a feature lands, its Jira issue is
created or updated to match. Nothing is ever read back: a status changed in Jira is not a status
change, and a feature invented in Jira is not a feature until it enters the pod as a question.

## Why one-way
Two editable places for the same fact is exactly the drift this method exists to remove. Within a
month the two disagree, and every conversation starts with "which one is right?". A projection can
never disagree — it can only be out of date, and it is refreshed on the next landing.

## What gets projected
| Pod | Jira |
|---|---|
| The pod / initiative | one Epic |
| A feature ticket | one Story, carrying its feature id and its business question |
| A gate | a milestone on the epic |
| Board status | issue status, per the mapping in `pod/JIRA.yml` |
| A landed feature | issue closed, with the commit reference |

## What is deliberately not projected
Decisions and their reasons · contracts · the record · open questions · session logs · evidence.
These live in the pod because they are read, argued with and cited — none of which Jira does well.
A link from the epic to the pod is enough.

## Configuration
`pod/JIRA.yml`, disabled by default. Turn it on when somebody actually needs it, not before —
an unused integration is a maintenance cost with no reader.

## If someone asks for status
Send them the generated PMO view (`_index/pmo.html`). It is produced from the board, the decisions
and the repository history, so it is never out of date and nobody had to prepare it.
