# 17 — What each requirement needs, layer by layer

The build map. Written from a clean sheet — **as though nothing exists yet** — so the team has one
reference showing, for every requirement, what has to be built in the model, the data, the API, the
application back end and the front end, plus what it depends on and what proves it is done.

**Why written this way.** Some of it may already exist; the trace against the current code answers
that separately and can only shorten this list, never lengthen it. Planning against "what we think
is already there" is how work gets missed — planning against the full shape, then subtracting what
is genuinely found, does not.

**How to read a row.** *Model* is the computation. *Data* is what must be stored. *API* is the
contract the application consumes. *Back end* is the existing product service — the path from a
user action to the service, and policy or permissions applied there. *Front end* is the screens and
fields. *Configuration* is anything production will want to tune, which must be a parameter and
never a constant.

---

## At a glance

| # | Requirement | Model | Data | API | Back end | Front end | Config |
|---|---|:--:|:--:|:--:|:--:|:--:|:--:|
| R-1 | Run inside the operating window | ○ | ● | ● | ● | ● | ● |
| R-2 | Category limits, any level, combinable | ● | ● | ● | ● | ● | ○ |
| R-3 | Store availability | ● | ● | ● | ○ | ● | ● |
| R-4 | Cross-campaign rest and chilling | ● | ● | ● | ● | ● | ● |
| R-5 | Blocking and exclusions | ● | ● | ● | ● | ● | ○ |
| R-6 | Multi-brand / multi-SKU offers | ● | ● | ● | ○ | ● | ● |
| R-7 | Estimation and planning (7a/7b) | ● | ● | ● | ● | ● | ● |
| R-8 | Budget caps and compliance | ● | ● | ● | ● | ● | ● |
| R-9 | Sales-time estimation | ● | ● | ● | ○ | ● | ○ |
| R-10 | Lift measurement | ● | ● | ● | ● | ● | ● |

● substantial work · ○ light or none

---

## R-1 · Allocation completes within the operating window
*A wave finishes inside the agreed window, with visible progress and an honest estimate throughout.*

| Layer | What has to be built |
|---|---|
| **Model** | Nothing new in the method itself; the computation must simply be fast enough at production volume, and its stages must report where they are |
| **Data** | A job record per run: stage, progress, start and finish times, outcome, and the history that later estimates are derived from |
| **API** | Submit-and-poll for long work; stage-level progress; a run history endpoint; a failure carrying the stage and the cause |
| **Back end** | The wave trigger re-pointed at the service; failures surfaced as alerts rather than absence |
| **Front end** | A jobs-and-runs list; stage progress on the wave itself; a failure state naming the stage; "notify me" on any wait |
| **Config** | The operating-window target and the alert thresholds |
| **Depends on** | Nothing. This is buildable first, and everything else becomes visible through it |
| **Proves it** | A full wave at production-shaped volume finishing inside the window, with each stage visible and an estimate that was roughly right |

## R-2 · Category limits at any level, combinable
*Limit how many offers a shopper receives from any level of any hierarchy, combinable with AND/OR.*

| Layer | What has to be built |
|---|---|
| **Model** | The limit expressed as a constraint the allocation honours exactly — not a filter applied afterwards — and a record of when it bound |
| **Data** | Policy rule rows: hierarchy, level, limit, grouping. Client-defined hierarchies as first-class as standard ones |
| **API** | Read the rules attached to a policy; report per wave which rules bound and what they cost |
| **Back end** | Policy resolution passing the rules through to the service without reinterpreting them |
| **Front end** | A rule builder in the policy editor — repeatable rows, level pickers, AND/OR grouping. **Policy-owned: authored there, shown read-only on the wave** |
| **Config** | None. These are authored rules, not settings |
| **Depends on** | The product hierarchy being available at every level the business uses |
| **Proves it** | A wave where the limit binds, no shopper exceeding it, and a report showing where it bound and what it cost |

## R-3 · Store availability
*Never offer a shopper a product their store does not carry.*

| Layer | What has to be built |
|---|---|
| **Model** | Availability applied as a hard filter at the correct grain, with the removal counted rather than silent |
| **Data** | Ranging at item × store, at usable freshness. **The grain is the known problem: today's data is at the wrong one** |
| **API** | Coverage for a product set — how much of the audience can actually buy it |
| **Back end** | Little or nothing, if eligibility moves to the service |
| **Front end** | Coverage shown on the offer form; a warning when it is thin; the removal visible in the funnel |
| **Config** | The thin-coverage warning threshold |
| **Depends on** | Resolving the ranging grain — an open question that blocks the whole requirement |
| **Proves it** | No allocation to a shopper whose store does not range the product, and a per-offer coverage figure a planner can act on |

## R-4 · Cross-campaign do-not-repeat and chilling
*Rest rules that hold across campaigns and incentive types, not only within one campaign.*

| Layer | What has to be built |
|---|---|
| **Model** | Rest evaluated against everything a shopper has already been exposed to, at the level the rule names |
| **Data** | **One cross-campaign exposure ledger, written from the first wave.** This is the foundation the requirement rests on, and it cannot be backfilled convincingly |
| **API** | Exposure lookup; funnel counts per rule family |
| **Back end** | Any existing chilling logic retired in favour of the single ledger — two sources would drift immediately |
| **Front end** | A scope field on rest rules: this campaign / all campaigns / all incentive types. The funnel showing how many each rule removed |
| **Config** | Default rest windows per level |
| **Depends on** | The exposure ledger existing before the first production wave (a wave-one irreversible) |
| **Proves it** | A shopper suppressed because of a *different* campaign, visible with counts in the funnel |

## R-5 · Blocking and exclusions
*Item and category blocking, and the ability to exclude shoppers or products, applied consistently.*

| Layer | What has to be built |
|---|---|
| **Model** | Exclusion applied with fixed precedence — **exclude always wins over include**, everywhere it arises |
| **Data** | Exclusion sets on policies; an exclude flag on named audience lists; offer-level exclusions |
| **API** | Attach and detach exclusions; per-family funnel counts |
| **Back end** | Targeting assembly passing exclusions through unmodified |
| **Front end** | A "Blocking & exclusions" section in the policy editor; the exclude flag on audience lists; precedence stated on screen so nobody has to guess |
| **Config** | None — authored data |
| **Depends on** | R-4's exposure ledger for cross-campaign blocking |
| **Proves it** | A shopper on both an include and an exclude list is excluded, and the funnel says which rule did it |

## R-6 · Multi-brand and multi-SKU offers
*An offer may cover any set of products across brands and categories, safely.*

| Layer | What has to be built |
|---|---|
| **Model** | Product rules resolved once to a frozen item set, with a fingerprint, so the set cannot move under an allocation. A reach estimate cheap enough to run while someone is typing |
| **Data** | The frozen set and its fingerprint, versioned and immutable once used |
| **API** | Resolve a product rule to its set; return reach for a set; refuse above the ceiling with the number |
| **Back end** | The offer-creation path calling the resolver instead of storing an unresolved rule |
| **Front end** | A product-set builder taking includes **and** excludes at different levels ("all of X except Y"); live reach; refusal with the number shown at authoring time, not at wave time |
| **Config** | The reach ceiling — a parameter per client, not a constant |
| **Depends on** | The hierarchy; and R-3 for the availability half of "can they actually buy it" |
| **Proves it** | A deliberately over-broad offer refused while being authored, with the reach figure displayed |

## R-7 · Interactive estimation and planning (7a and 7b)
*Products-first and audience-first planning, with exact counts and priced options, before anything commits.*

| Layer | What has to be built |
|---|---|
| **Model** | Exact counts — not sampled — fast enough to be interactive; expected response and budget with stated intervals; scenarios comparable on the same basis |
| **Data** | Scenario storage: identity, inputs, results, and promotion to a wave |
| **API** | Exact-count endpoint; scenario create/compare/promote; estimates always carrying their interval |
| **Back end** | The path from the planning screen to the service; promotion writing a real wave |
| **Front end** | A scenario workspace: build, compare side by side, promote one. **Exact and estimated visibly different** |
| **Config** | The interactive-response budget — how long "interactive" is allowed to mean |
| **Depends on** | R-6 (product sets), R-3 (availability), and the audience machinery |
| **Proves it** | An exact count returned while a planner waits, two scenarios compared, one promoted, and nothing committed without an explicit action |

## R-8 · Supplier budget capping and compliance
*Per-supplier and per-pool budgets enforced across waves, with alerting and a hard stop.* **Launch-blocking.**

| Layer | What has to be built |
|---|---|
| **Model** | Budget as a constraint inside the allocation with a price attached, so the cost of the cap is known rather than discovered |
| **Data** | **Funding pools, commitments, and an append-only ledger carrying the fiscal period — none of this exists today.** Test and control arms never debit |
| **API** | Pool state and pacing; ledger reads; cap enforcement reported per wave; reconciliation between ledger and coupons issued |
| **Back end** | Spend recorded on issuance and redemption events reaching the ledger |
| **Front end** | Commitments and funding screens: pools, caps, pacing, ledger drill. Cap and alert fields in the policy editor. Money authored where the money lives, never on the offer form |
| **Config** | Alert thresholds per pool; cost model per pool (**never overridable per offer**) |
| **Depends on** | The redemption event feed — an open question; and the commitment denomination per contract |
| **Proves it** | A wave that stops at the cap rather than exceeding it, and a ledger reconciling to the coupons actually issued |

## R-9 · Annual budget estimation at sales time
*Before signing, price a proposed commitment and check it is feasible alongside everything already sold.*

| Layer | What has to be built |
|---|---|
| **Model** | Cost derived from the allocation's own prices; feasibility checked against existing commitments jointly, not one at a time |
| **Data** | Proposed, unsigned commitments held separately from signed ones |
| **API** | An estimate endpoint returning cost, feasibility and the interval, with the basis stated |
| **Back end** | Reachable outside the wave flow, since this happens before any wave exists |
| **Front end** | A sales-time view: propose, price, see feasibility and its uncertainty |
| **Config** | None specific |
| **Depends on** | R-8 (pools and commitments) and the pricing that comes out of the allocation |
| **Proves it** | A proposed commitment priced with its uncertainty, and an infeasible one identified as infeasible with the conflict named |

## R-10 · Lift measurement — offer, programme and halo
*Measure what the programme caused, transparently and reproducibly.*

| Layer | What has to be built |
|---|---|
| **Model** | Randomised arms, implemented separately from any stratification. The estimand chosen and stated. Interference from per-shopper limits handled by the design. Power computed, and results below threshold reported as underpowered |
| **Data** | **Arm assignment, ghost log of what a held-out shopper would have received, and a frozen eligibility snapshot per wave — all wave-one irreversibles.** Outcome measured on purchases of the offer's products, not redemptions |
| **API** | Measurement endpoints carrying intervals and power state; decomposition into direct, halo, cannibalisation and pull-forward; a re-measurement of any past wave from frozen inputs |
| **Back end** | Existing report population replaced by, or reconciled with, the new path — and the difference explained to anyone comparing to old numbers |
| **Front end** | The measurement suite: scorecard, decomposition, comparison. **Underpowered rendered as underpowered, never as an effect.** Every number opens to its basis |
| **Config** | Power threshold; holdout percentage per campaign pattern |
| **Depends on** | The four wave-one irreversibles, the redemption feed, and the measurement design being settled at Gate B |
| **Proves it** | A planted effect recovered, a null staying null, a past wave re-measured identically, and an underpowered result refusing to present itself as an effect |

---

## What this map is for
- **Product** — sizing and ordering: what a requirement really costs, and what it depends on.
- **Data science** — the Model and Config rows are the contracts to define at Gate B.
- **Engineering** — the API, Back end and Data rows are the architecture conversation, before any ticket.
- **Design** — the Front end rows, read with `docs/08` (which fields) and `docs/10` (who owns them).

## Keeping it honest
When the trace against the existing code establishes that something already exists, **strike it from
this map with a note saying where it lives**. Never mark something done here because it is expected
to exist — this document's value is that it shows the full shape of the work, and an optimistic map
is worse than no map.

---

## Amendment · 2026-08-16 — the map is the whole shape; the phases decide when

This document deliberately describes the **full** work for each requirement, as though nothing
exists. That remains correct and useful — it is what stops work being missed.

Two things to read alongside it now:
- **Phasing (D-4).** Requirements 1, 2, 4, 5 and the feed half of 3 are Phase 1. R-6's authoring is
  Phase 1; its scoring half is Phase 2. R-7 is Phase 2. R-8, R-9, R-10 are Phase 3 — with the
  exception of R-10's capture prerequisites, which are Phase 1 (CR-40346).
- **What already exists (D-8).** Three front-end rows in this map are smaller than written:
  category limits extend the existing constraint model, chilling extends two existing fields, and
  the product-set work extends the existing picker. `docs/21` carries the corrected detail.

The rule for keeping this document true is unchanged: strike something from the map only when a
trace proves it exists, citing where.
