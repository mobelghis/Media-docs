# The record

Numbered documents in landing order. Never renumbered; corrections are dated amendments.

| # | Document | What it is |
|---|---|---|
| 00 | this file | the index of the record |
| 01 | REQUIREMENTS | what the system must do, and what "satisfied" means for each requirement |
| 02 | current-state | what the existing system does, in its own vocabulary |
| 03 | defect-catalogue | known defects and what each causes — requirements in negative form |
| 04 | non-negotiables | constraints the build may not violate, each with an owner |
| 05 | scope-boundary | what this replaces, and what it explicitly does not |
| 06 | prior-evidence | proof-of-concept findings, cited as evidence and never as decisions |
| 07 | open-questions | answers needed from outside the pod, each with an owner and what it blocks |
| 08 | FRONTEND-SURFACE-REQUIREMENTS | where each requirement lands in the interface — where and what, not how |
| 09 | PROPOSED-IO-CONTRACTS | draft contracts for data science to argue with rather than start blank |
| 10 | ENTITY-PLACEMENT | whether each new capability is a campaign, wave, policy or offer property |
| 11 | REPO-BRIDGE | how the pod repository and the product repository work together |
| 12 | market-and-competitive-context | why the rebuild is worth doing, and what makes it different |
| 13 | personas-and-business-questions | who the system serves and what each of them actually asks |
| 14 | CURRENT-SYSTEM-PRD | how the system works today, plus the impact map of each requirement against it |
| 15 | WHO-WRITES-THE-MODEL-CODE | who owns the method, the computation and the wiring |
| 16 | JIRA-PROJECTION | the board governs; Jira is a one-way projection of it |
| 17 | REQUIREMENT-TRACE | the build map: what each requirement needs, layer by layer |
| 18 | question-register | every requirement as questions in a user's words, with owner and surface |
| 19 | priorities | the client's delivery sequencing, adopted as the pod's own on 2026-08-31 (D-10) |
| 20 | epic-review-and-phase-1 | every Jira epic reviewed, and the increment scope that follows |
| 21 | design-current-and-redesign | what to add to the Angular screens now, and three options for the redesign |
| 22 | new-epic-descriptions | descriptions for the pod-proposed epics, ready to paste into Jira |

Raw source material is in `sources/`, verbatim, with provenance in its own README.

*Browse everything with `make index` → `_index/index.html`.*

---

## Amendment · 2026-08-31 — this file was malformed, and it hung the index build

As landed, this document listed **one** row (00) and then three rows for 20–22 stranded *after* the
closing "browse everything" line, outside any table. Documents 01–19 were absent from the index of
the record entirely.

That was not only incomplete, it was the cause of a build failure: an orphan table row — a `|...|`
line with no header/separator pair above it — matched no branch in `md_to_html` and was refused by
its paragraph fallback, so `make index` looped forever without advancing. The parser is fixed in
`scripts/build_index.py` so malformed markdown can never hang the build again (N-22), and the table
above is now complete and well-formed.

**Still owed:** `docs/20-epic-review-and-phase-1.md` carries the H1 `# 18 — Epic review`, which
collides with `docs/18-question-register.md`. Left alone here because the fix belongs in that file,
not this index.
