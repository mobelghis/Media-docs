# 06 — Prior evidence (proof of concept)

A proof of concept ran before this pod started. **Its findings are evidence, not decisions.**
They may be cited, and they must be re-established inside this programme before anything depends
on them. Where a result carries a caveat, the caveat travels with it.

## What was established
| Finding | Status | Caveat |
|---|---|---|
| Incremental statistics agree with full recompute to ~1e-14 across a multi-year replay | Strong; reproduced twice | Establishes no need for scheduled rebuilds; re-verify on production-shaped data |
| Planted-effect recovery passes at scale | Strong | The harness standard to keep: a broken computation must fail it |
| Greedy leaves a measurable gap versus proven optimum, and **structurally misses minimums the solver proves satisfiable** | Strong — this is the core justification for the rebuild | Gap measured against exact solves on subsamples |
| Grain of the statistics matters more than the model choice | Strong | Redirected effort away from model tuning |
| Large volumes of scored rows are wasted work that can be removed structurally | Strong | Delivered a substantial cost reduction |
| Routing between scoring paths shrinks the candidate set considerably | **Finding, gated** | Discovery and new-product offers have no support under a repeat-only path; routing is disabled pending feasibility certification |
| Early synthetic benchmarks under-represented real catalogue structure | **Correction** | All pre-correction synthetic numbers are optimistic by an unknown factor; no benchmark is production-shaped until re-run at scale |

## External review
An independent data-science review raised five items, all accepted: methodology documentation
insufficient for rigorous review; the portfolio objective was conflated with a greedy procedure;
convergence guarantees do not transfer under an approximate inner solve; a single affinity signal
is insufficient for cross-sell; and per-shopper caps create interference that the measurement
design must handle. **These are inputs to Station 2, not closed questions.**

## How to use this document
Cite it for orientation and to avoid repeating dead ends. Do not treat any line as settled for
the new build: each becomes real again only when re-established under this programme's gates.
