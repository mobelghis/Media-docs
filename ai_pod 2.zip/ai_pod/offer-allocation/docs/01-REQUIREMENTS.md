# 01 — Requirements

**Status:** kickoff baseline, <date>. This document states what the system must do and what
"satisfied" means for each requirement. It is the input to Station 2 (methodology) and it is
the thing every later artifact answers to.

**Reading order for anyone joining:** this document → `02-current-state.md` →
`03-defect-catalogue.md` → `04-non-negotiables.md`. Then your discipline's file in `start/`.

---

## 1. Purpose

Replace the current wave allocation system with one that decides which offers reach which
shoppers, at scale, while honouring every commercial commitment made to suppliers and every
policy rule set by the retailer — and that can prove, afterwards, what it caused.

Three properties define success, in priority order:
1. **Correctness** — the allocation satisfies every constraint it claims to satisfy, or says
   plainly that it cannot and why.
2. **Provability** — every number the system reports can be traced to what produced it, and
   claims that are not supported by evidence are not made.
3. **Speed** — the reward for the first two, never a trade against them.

## 2. Who it serves

| Role | What they need from it |
|---|---|
| Campaign planner | Build and ship a wave of personalised offers without a specialist's help |
| Category / merchant lead | Know which offers worked, on evidence they can defend |
| Supplier-facing commercial | Sell commitments they know can be met, and report against them credibly |
| Finance | Know what was spent, against which budget, in which fiscal period |
| Data science | Change the method without changing the system around it |
| Operations | Know a wave ran, when it will finish, and what to do when it did not |

---

## 3. The ten committed capabilities

Each carries: the requirement, what fails today, and what "satisfied" means. The
**satisfied-when** line is the acceptance target — a feature is not done until it is true.

### R-1 · Allocation completes within the operating window
**Requirement.** A full wave — retrieval, scoring, pricing, allocation, verification,
publication — completes reliably within the agreed window, with visible progress and an honest
estimate of completion throughout.
**Today.** The run is long and opaque; users see nothing between "start" and "done", and a
failure is discovered by absence rather than by alert.
**Satisfied when.** A wave completes within the window on production-shaped volume, every stage
reports progress, the estimate is derived from observed history rather than assumed, and a
failure raises an alert naming the stage and the cause.

### R-2 · Category limits at any hierarchy level, combinable
**Requirement.** Limits on how many offers a shopper may receive from any level of any product
hierarchy (category, sub-category, brand-in-category, and client-defined virtual groupings),
combinable with AND/OR, expressible without code.
**Today.** Not expressible. The rule exists in people's heads and is approximated by other means.
**Satisfied when.** A planner can state such a limit in the policy editor, the allocator honours
it exactly, and a report shows how often it bound and what it cost.

### R-3 · Store availability
**Requirement.** A shopper is never offered a product their store does not carry.
**Today.** Availability data exists but at the wrong grain to be applied reliably.
**Satisfied when.** Availability is applied as a hard filter at the correct grain, the share of
audience removed by it is visible per offer, and offers whose availability is too thin are
flagged at authoring time rather than discovered after the wave.

### R-4 · Global do-not-repeat and chilling
**Requirement.** Rules preventing a shopper receiving the same or similar offer too soon, applied
**across campaigns and incentive types**, not only within one campaign.
**Today.** Partial and campaign-scoped; cross-campaign exposure is not reliably known.
**Satisfied when.** A single cross-campaign exposure ledger is the source of truth, rest periods
are enforced from it, and the funnel shows how many shoppers each rule removed.

### R-5 · Offer blocking and exclusions
**Requirement.** Item-level and category-level blocking; the ability to exclude shoppers or
products from an offer; exclusions applied consistently wherever they are expressed.
**Today.** Limited, inconsistent, and partly worked around by disabling eligibility entirely.
**Satisfied when.** Blocking and exclusion are one authored capability, **exclude always wins
over include**, and the explain funnel shows every exclusion's effect with counts.

### R-6 · Multi-brand and multi-SKU offers
**Requirement.** An offer may cover an arbitrary set of products spanning brands and categories.
**Today.** Supported in the data model but dangerous in practice — broad offers break the
allocation run.
**Satisfied when.** Broad offers run safely, and an offer whose reach exceeds a configured share
of the population is refused or routed to a different path **at authoring time**, with the reach
computed and shown before anyone commits.

### R-7 · Interactive estimation and planning (7a and 7b)
**Requirement.**
- **7a — products first:** given targeted products, an incentive type and an objective, the
  system proposes the audience, the expected response and a budget range.
- **7b — audience first:** given an audience description, the system returns its exact size,
  expected response and total budget.
Both must support review and adjustment **before** anything is committed.
**Today.** Not available; planners estimate by asking an analyst and waiting.
**Satisfied when.** Audience counts are **exact, not sampled**, returned interactively; response
and budget are estimates carrying stated intervals; scenarios can be saved, compared and
promoted to a wave; and nothing commits without an explicit human action.

### R-8 · Supplier budget capping and compliance
**Requirement.** Per-supplier and per-pool budgets enforced across waves, with alerting as
thresholds approach and a hard stop at the cap. **Launch-blocking.**
**Today.** No money tables exist. Spend against commitment is not systematically tracked.
**Satisfied when.** A funding ledger records every issuance and redemption event against its
pool and fiscal period; caps are enforced by the allocator, not by a report; thresholds alert;
and the ledger reconciles to the coupons actually issued.

### R-9 · Annual budget estimation at sales time
**Requirement.** Before signing, commercial can ask what a proposed commitment will cost and
whether it is feasible alongside existing commitments.
**Today.** Estimated by judgement; commitments are sold that the system cannot meet.
**Satisfied when.** A proposed commitment can be priced and feasibility-checked in the tool, the
answer carries its uncertainty, and the basis of the estimate is stated.

### R-10 · Lift measurement — offer, programme, and halo
**Requirement.** Measure what the programme caused: per offer where the evidence supports it,
at programme level always, including halo and cannibalisation, transparently and reproducibly.
**Today.** No randomised holdouts in practice; the control group is selected in a way that biases
the comparison; results are not reproducible.
**Satisfied when.** Randomised arms exist from wave one with counterfactual (ghost) assignment
recorded; the outcome measured is purchase of the offer's products, not redemption; results
below a stated power threshold are **reported as underpowered rather than as effects**; and any
past wave can be re-measured identically from frozen inputs.

---

## 4. Cross-cutting requirements

These apply to every feature and are not optional extras.

### R-A · Evidence and honesty
- Every reported number carries its provenance and, where it is an estimate, its uncertainty.
- A result that cannot be supported is refused, not softened. Underpowered is a verdict, not a
  footnote.
- No claim is made in a report that the system cannot reproduce on demand.

### R-B · Reproducibility
- Every wave freezes what it decided from: offer versions, eligibility snapshot, parameters,
  and the random seed.
- Re-running a wave from its frozen inputs produces the same result, byte for byte.
- Nothing that affects an allocation may change underneath it after the fact.

### R-C · Commitments and money
- Minimums are counted in issued coupons unless a contract states otherwise, and the counting
  rule is explicit per pool.
- Cost is attributed to a funding source with a stated cost model (issuance- or
  redemption-denominated); the model is a property of the pool, never overridable per offer.
- Test and control arms never consume budget.
- Every money movement is an append-only ledger entry carrying its fiscal period.

### R-D · Explainability
- Every allocation decision records **why**: the binding constraint at the moment a candidate was
  rejected, and the price that ruled it out.
- A planner or supplier asking "why did this offer under-issue?" gets a factual answer with
  counts in the same session, not a research task.

### R-E · Feasibility before failure
- Before a wave runs, the system proves whether the configured minimums are **jointly**
  satisfiable, and names the binding conflict if they are not.
- **Infeasible** and **failed to find** are different verdicts and must never be reported as the
  same thing.

### R-F · Tenancy and isolation
- Each client's data is isolated; no query may return another client's rows.
- Configuration is per client; nothing is global that should be per client.

### R-G · Operability
- Any long-running work is visible as a job with progress, an honest estimate, and a history.
- Every run is repeatable from its recorded inputs.
- Data freshness and quality are visible to users, not only to engineers.

---

## 5. The four wave-one irreversibles

These cannot be added later. If they are not in the first production wave, the capability is
permanently lost for every wave that runs without them.

1. **Randomised arms** — properly randomised, separate from any stratification logic.
2. **Ghost allocation logging** — what a held-out shopper *would* have received, recorded.
3. **Frozen eligibility snapshot per wave** — the population as it was at decision time.
4. **Exposure and funding ledgers** — written from the first wave, not backfilled later.

## 6. What "satisfied" looks like as an artifact

A requirement is met when there is:
- a **question** it answers, in a user's words;
- a **feature** that answers it end to end (data → method → contract → screen);
- a **test** that fails if the answer stops being correct — including a deliberately broken
  version that the test must catch;
- a **demonstration** a non-engineer can watch;
- and a **reviewer from the business** who agrees it is the answer they asked for.

## 7. Not in scope for this phase

See `05-scope-boundary.md`. Summary: natural-language authoring and the semantic catalogue,
supplier-facing portal and invoicing, and real-time request-time serving are **deferred by
decision, not by oversight** — each with the condition that would bring it back.

---

## Amendment — 2026-08-13 (client intake)

**R-5 clarified.** The client's own restatement of blocking makes explicit what R-5's text left
implicit: item-level and category-level blocking rules must be enforceable **both within a single
campaign and across campaigns** — this is blocking itself, not only the rest-period/chilling
scope R-4 already names. The client has asked how this differs from what is already supported;
answer not yet known — see `07-open-questions.md`.

**Candidate R-11 — Auto-suppression against mass/blanket promotions.** Raised as a pain point, not
a prior intake item: personalised offers are today disabled by hand whenever a mass promotion on
the same product overlaps in time. Requested capability: the system detects the overlap and
auto-suppresses the personalised offer for the overlapping period, without manual intervention.
This is distinct from R-5 (coupon-vs-coupon blocking) — the conflicting object is a mass promotion,
which is not itself an offer in this system's model. **Not yet prioritised or written as a
satisfied-when statement; carried as a candidate pending Gate A.**

**Scale, unresolved.** R-1 says a wave must complete "at production-shaped volume" but does not
state the unit. Intake surfaced that a coupon and an offer are different units (one coupon can
produce many offers) and that the required technical approach differs by offer-type mix (retention
vs. cross-sell). No target number or unit is stated anywhere in this document. See
`07-open-questions.md`.

---

## Amendment · 2026-08-16 — the programme is phased, and Phase 1 fixes rather than replaces

The ten requirements below remain the target and are unchanged. What has changed is **how they are
reached** (D-4).

- **Phase 1 (2026.4)** delivers priorities 1, 2, 4, 5 and the feed-based half of 3 **against the
  current allocation engine and the current Angular application**. Nothing in Phase 1 requires new
  methodology, and nothing in it is built in a way that must be discarded when the engine is
  redesigned (CR-40313).
- **Phase 2** covers what needs a method first: combined scoring for multi-category offers, and the
  planning forecasts (priorities 6 scoring half, 7a, 7b).
- **Phase 3** covers what needs the money layer or the measurement prerequisites: supplier budgets,
  sales-time estimation, and lift measurement (priorities 8, 9, 10).

Two consequences for how this document should be read. **"Satisfied when" still describes the end
state**, not the Phase 1 increment — a requirement may be partly satisfied in 2026.4 and completed
later, and the requirement trace (`docs/17`) shows which layer lands when. And **the four wave-one
irreversibles are not deferred by phasing**: they are captured in Phase 1 (CR-40346) precisely because
they cannot be added retrospectively.
