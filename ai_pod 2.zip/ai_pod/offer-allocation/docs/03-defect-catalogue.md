# 03 — Defect catalogue

Known defects in the current system, each with what it causes. These are requirements in
negative form: the new system must not reproduce them, and several are the reason a requirement
exists at all.

| # | Defect | What it causes | Requirement that answers it |
|---|---|---|---|
| D-01 | Greedy allocation fills slots with popular offers and discovers shortfalls at the end | Contractual minimums are missed **even when they were satisfiable**; commercial exposure | R-8, R-E |
| D-02 | No pre-run feasibility check | An impossible configuration is discovered by failure, hours later, instead of being named beforehand | R-E |
| D-03 | Unseeded randomisation | No wave can be re-run identically; results are not reproducible | R-B |
| D-04 | Control group selected from the allocated set, after allocation | Comparisons are biased; measured "lift" is not incremental lift | R-10 |
| D-05 | No ghost logging of held-out shoppers | Offer-level lift is uncomputable even where a holdout existed | R-10 |
| D-06 | Eligibility recomputed at analysis time | Results shift after the fact; the same wave measured twice gives two answers | R-B |
| D-07 | Category caps inexpressible | The rule lives in people's heads; the allocator cannot honour it | R-2 |
| D-08 | Rest periods scoped to one campaign | A shopper can be hit by the same category from two campaigns in a week | R-4 |
| D-09 | Store availability at the wrong grain | Offers reach shoppers who cannot buy the product | R-3 |
| D-10 | No money tables | Supplier spend and commitment progress are not systematically known | R-8, R-9 |
| D-11 | Min/max issuance frequently null | Constraints that exist commercially are absent technically | R-8 |
| D-12 | Delivery export drops offer identity | Post-hoc attribution to a specific offer is impossible past the boundary | R-10, R-D |
| D-13 | Broad offers break the run | A single wide product set can stall or fail a wave | R-6 |
| D-14 | Eligibility-off workaround for one targeting mode | Rules are silently bypassed for a whole class of offers | R-5 |
| D-15 | No visibility between start and finish | Failure is discovered by absence; no estimate, no stage, no alert | R-1, R-G |
| D-16 | No explanation of exclusions | "Why did my offer reach 40k not 100k?" takes days and produces a guess | R-D |
| D-17 | Silent configuration ignorance | A configured value can be read by nothing, and the system runs on a default | R-A |

**Rule for the rebuild:** every defect above must be either fixed, or explicitly accepted with a
reason recorded. None may be forgotten.

---

## Amendment — 2026-08-13 (client intake)

**D-04, status uncertain.** The client's delivery roadmap lists two Jira changes marked **DONE**:
CR-31111 ("Control Group selection logic") and CR-30454 ("Fix Control Group Selection Logic in
Personalization Allocation Module"). If these already moved control-group selection to
pre-allocation, D-04 may be partially or fully remediated in the current system already. **Not
verified** — per `06-prior-evidence.md`'s rule, a claim like this is cited, not trusted, until it is
re-established under this programme. See `07-open-questions.md`. If confirmed, D-04's row above is
updated with a dated correction, not silently removed.

---

## Amendment · 2026-08-16 — two defects have moved

- **D-04 (control group selected from the allocated set)** — CR-31111 and CR-30454 landed a
  corrected selection in 2026.1 and are marked Done. Whether that fully remediates D-04, or predates
  the randomisation and ghost-logging requirements, is Q-12 and is being verified rather than
  assumed in either direction. Until it is answered, treat D-04 as **partly remediated, unverified**.
- **D-07 (category caps inexpressible)** — still true, but the fix is smaller than assumed: the
  policy screen already carries a generic constraint model that category limits extend (D-8).

Everything else in the catalogue stands as written.
