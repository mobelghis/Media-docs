# 18 — Question register

Drafted per the Gate A kick-off in `start/03-PRODUCT.md`, from `01-REQUIREMENTS.md`,
`03-defect-catalogue.md` and `13-personas-and-business-questions.md`. Extends the persona
questions rather than replacing them. Every feature is sliced from a row here.

**Status column.** `surfaced` — a surface named in `08-FRONTEND-SURFACE-REQUIREMENTS.md` answers
it. `gap` — no current surface answers it; flagged for design/product to close before Gate A
signs. `constraint` — does not resolve into a user-facing question at all (see the note below the
table).

## R-1 · Allocation completes within the operating window

| Q-id | The question, in the user's words | Who asks | What they do with the answer | Surface | Status |
|---|---|---|---|---|---|
| Q-1 | Is the wave running, and when will it finish? | Planner | Decide whether to wait, escalate, or hold downstream comms | D · wave progress / F · Jobs & runs | surfaced |
| Q-2 | Did last night's run finish, and if not, where did it stop? | Operations | Decide whether to re-run or escalate to on-call | F · Jobs & runs | surfaced |

## R-2 · Category limits at any hierarchy level, combinable

| Q-id | The question, in the user's words | Who asks | What they do with the answer | Surface | Status |
|---|---|---|---|---|---|
| Q-3 | Can I cap how many offers a shopper gets from this category, brand, or our own grouping this wave — and combine that with other limits? | Planner | Decide whether the policy can express a commercial rule before building the wave | A · policy editor | surfaced |
| Q-4 | How often did this cap bind, and what did it cost us in reach? | Category / merchant lead | Decide whether the cap is too tight or too loose next cycle | E · reporting | surfaced |

## R-3 · Store availability

| Q-id | The question, in the user's words | Who asks | What they do with the answer | Surface | Status |
|---|---|---|---|---|---|
| Q-5 | Why did this offer reach fewer shoppers than expected? | Planner | Decide whether to widen the product set or accept the smaller reach | B · offer authoring (coverage warning) | surfaced |
| Q-6 | Will a shopper ever be offered something their store doesn't carry? | Planner | Trust the hard filter enough to skip manual review | — | constraint (see note) |

## R-4 · Global do-not-repeat and chilling

| Q-id | The question, in the user's words | Who asks | What they do with the answer | Surface | Status |
|---|---|---|---|---|---|
| Q-7 | Has this shopper already had a similar offer recently, from any campaign? | Planner | Decide eligibility before targeting | A · rest-period rules | surfaced |
| Q-8 | How many shoppers did the rest-period rule remove, and from which campaigns? | Planner / Operations | Understand a reach shortfall | D · explain funnel | surfaced |

## R-5 · Offer blocking and exclusions

| Q-id | The question, in the user's words | Who asks | What they do with the answer | Surface | Status |
|---|---|---|---|---|---|
| Q-9 | Can I exclude this list of shoppers or products, and will exclude always win over include? | Planner | Author the rule with confidence | A / B · blocking & exclusion section | surfaced |
| Q-10 | Why did this offer reach 40,000 shoppers instead of 100,000? | Planner | Get a factual, same-session answer | D · explain funnel | surfaced |
| Q-27 | Will a blocking rule I set stop a conflicting coupon whether it's in this campaign or a different one? | Planner | Author one blocking rule instead of duplicating it per campaign | A · blocking & exclusion section | gap — 08's blocking row doesn't state cross-campaign scope explicitly; see amendment in `01-REQUIREMENTS.md` and `07-open-questions.md` Q-9 |
| Q-28 | Will my personalised offer automatically stand down when a mass promotion on the same product overlaps, instead of me disabling it by hand? | Planner | Stop manually policing every mass-promo calendar clash | — | gap — candidate R-11, no surface named yet |

## R-6 · Multi-brand and multi-SKU offers

| Q-id | The question, in the user's words | Who asks | What they do with the answer | Surface | Status |
|---|---|---|---|---|---|
| Q-11 | Can I build an offer across these brands and categories, and will it run safely? | Planner | Decide the product set before committing | B · product-set builder | surfaced |
| Q-12 | What share of the population would this offer reach, before I save it? | Planner | Decide to narrow the offer or route it elsewhere | B · reach guard | surfaced |

## R-7 · Interactive estimation and planning

| Q-id | The question, in the user's words | Who asks | What they do with the answer | Surface | Status |
|---|---|---|---|---|---|
| Q-13 | If I target these products with this incentive, who do I reach, what response can I expect, and what will it cost? (7a) | Planner | Decide whether to proceed to a wave | B / C | surfaced |
| Q-14 | For this audience, exactly how many shoppers, what response, and what total budget? (7b) | Planner | Decide the audience before committing | C · audience builder | surfaced |
| Q-15 | Can I save this scenario, compare it against another, and promote the one I want? | Planner | Make the planning decision itself | D · scenarios | surfaced |

## R-8 · Supplier budget capping and compliance

| Q-id | The question, in the user's words | Who asks | What they do with the answer | Surface | Status |
|---|---|---|---|---|---|
| Q-16 | Can I commit to this volume for this supplier, and what will it cost us to deliver? | Commercial / supplier-facing lead | Decide whether to sign | F · Commitments & funding | surfaced |
| Q-17 | What have we spent, against which budget, in which fiscal period, and are we near a cap? | Finance | Decide whether to intervene before overspend | F · Commitments & funding | surfaced |
| Q-18 | Which suppliers are we consistently under-delivering to, and by how much? | Commercial / supplier-facing lead | Decide account-management action | E · reporting | surfaced |

## R-9 · Annual budget estimation at sales time

| Q-id | The question, in the user's words | Who asks | What they do with the answer | Surface | Status |
|---|---|---|---|---|---|
| Q-19 | Before I sign this, what will it cost across the year, and is it feasible alongside what we've already committed? | Commercial / supplier-facing lead | Decide whether to sign or renegotiate | E · sales-time view | surfaced |

## R-10 · Lift measurement — offer, programme, and halo

| Q-id | The question, in the user's words | Who asks | What they do with the answer | Surface | Status |
|---|---|---|---|---|---|
| Q-20 | Did this campaign grow the category, or just move volume around inside it? | Category / merchant lead | Decide whether to repeat the offer type | E · decomposition | surfaced |
| Q-21 | Is the effect we're reporting real, and how confident can we be? | Data science | Decide whether the number is fit to act on or report | E · power state | surfaced |
| Q-22 | What do I show this supplier that is both compelling and defensible? | Commercial / supplier-facing lead | Build the renewal case | E · reporting | surfaced |

## Cross-cutting requirements (R-A … R-G)

| Q-id | The question, in the user's words | Who asks | What they do with the answer | Surface | Status |
|---|---|---|---|---|---|
| Q-23 | Can I reproduce last quarter's numbers exactly? | Data science | Trust a re-derived number enough to publish it | F · Jobs & runs / Audit log | surfaced |
| Q-24 | Can I re-run this identically? | Operations | Recover from a failed run without re-authoring anything | F · Jobs & runs | gap — no on-screen "re-run from frozen inputs" action named in 08 |
| Q-25 | Will this configuration actually satisfy what we promised, before I run it? | Planner | Decide whether to fix the policy before running the wave | D · feasibility verdict | surfaced |
| Q-26 | Is the data fresh enough to run today? | Operations / Data science | Decide whether to proceed or hold the wave | F · Data health | surfaced |

**Note on constraints (not capabilities).** R-C (money mechanics: cost-model ownership,
append-only ledgers, control arms never spending) and R-F (tenancy and isolation) do not resolve
into a user-facing question of their own — nobody asks "is my data isolated?" as a feature
request. They are proven by tests and audits, not answered on a screen, and are carried as
non-negotiables (N-9–N-12, N-16) rather than rows here. R-3's hard-filter guarantee (Q-6) is the
same shape: the real user-facing question is Q-5 (the consequence, reach), not the guarantee
itself.

**Rules.** No question without an owner-persona and an intended use. No surface that answers no
question. No question without a surface once design is signed — `Q-24` is currently open on that
rule and needs a decision before Gate A closes.

---

## Amendment · 2026-08-16 — questions are now sliced into stories under real epic keys

The register stands as the source of business questions. What has changed is what happens next to
each row: questions now become **stories under the real Jira epic keys**, not internal feature
placeholders (D-9). `features/JIRA-IMPORT-stories.csv` carries 42 stories across 13 epics, and
`features/BOARD.md` groups them by phase.

Rows marked `gap` — no surface answers them — remain the useful output of this document. Two of
them are now answered by Phase 1 surfaces that did not exist when this was drafted: the eligibility
funnel (CR-40345) answers the explain questions, and the blocking preview answers "what would block
what" before a run.

---

## Amendment · 2026-08-31 — two `surfaced` rows are surfaced a quarter late

The register is unchanged as a statement of what people ask. What changed is **when** two of its
rows get an answer.

D-10 adopted the client's 2026-08-25 sequencing, which puts **CR-40345 — run visibility and the
eligibility funnel — in Q1 2027**, while chilling (CR-38874) and blocking (CR-38875) ship in
Q4 2026. The 2026.4 discovery pack states that both of those epics *feed the funnel*: CR-38874's
removal count "becomes the chilling row in the funnel," and CR-38875's blocking outcome "feeds the
funnel and the audit."

So two rows above are marked `surfaced` against a surface that arrives a quarter after the rules
that make them urgent:

| Q-id | The question | Marked | Actually |
|---|---|---|---|
| Q-8 | How many shoppers did the rest-period rule remove, and from which campaigns? | `surfaced` — D · explain funnel | no surface until Q1 2027, while the rule ships Q4 2026 |
| Q-10 | Why did this offer reach 40,000 shoppers instead of 100,000? | `surfaced` — D · explain funnel | same |

This is not a defect in the register — the surface is specified and funded, and the funnel *data* is
captured from Q4 2026 by the epics that produce it. But per this document's own rule ("a question
with no surface is an unfinished design"), a question whose surface exists only in a later quarter
should be visible as such rather than reading as satisfied. Carried as board row **B-3**, owner
Product + Design.

**One thing this does not change.** Q-24 ("Can I re-run this identically?") remains the register's
only true `gap` — no surface anywhere names a re-run-from-frozen-inputs action. It still needs a
decision before Gate A closes.
