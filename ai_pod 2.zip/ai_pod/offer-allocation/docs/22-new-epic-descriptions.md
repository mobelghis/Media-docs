# Descriptions for the pod-proposed epics

Written in the same shape as the existing personalization epics — business objectives, scope,
acceptance criteria — so they read consistently in Jira. Paste into the Description field.
Suggested fields: **Module** Personalization · **Parent Link** CR-29487 Personalization ·
**PI** see each epic · **Customer** All · **Generic** Yes · **Customer facing change** see each epic.

---

## CR-40344 · Cross-Campaign Exposure Record

*Customer facing change: No (foundation) · Suggested PI priority: ahead of CR-38874 and CR-38875*

### Business objectives
- Enable do-not-repeat, chilling and blocking rules to operate **across campaigns and incentive
  types**, which is what CR-38874 and CR-38875 both require and neither can deliver alone.
- Establish a single, authoritative record of what each shopper has already been exposed to, so
  every rule that asks "has this shopper seen this recently?" gets the same answer.
- Remove the current campaign boundary, which lets a shopper receive the same product as a
  discount in one campaign and as points in another within the same week.

### Scope
- One record of exposure per shopper: product grain, date, campaign, incentive type and source.
- Written on publication, for every allocation, as part of the normal run.
- Readable during eligibility cheaply enough to be consulted for every candidate pair — a
  per-pair query is not viable at 20,000 offers and 15M shoppers; the structure must be
  precomputed per wave.
- Retention long enough to serve the longest configured chilling window, stated as a parameter.
- Backfill from whatever history exists, marked as partial rather than presented as complete.
- One definition of **product overlap** — what makes two offers "the same" — used by both the
  chilling and the blocking epics, so they cannot diverge.

### Out of scope
- The rules themselves (CR-38874, CR-38875) and any user-facing screen. This epic stores and
  serves; the consuming epics expose.

### Acceptance criteria
- Every published allocation results in an exposure record.
- Rules can query exposure across campaigns and incentive types.
- The read cost per candidate pair is measured and stays within the wave's runtime budget.
- Backfilled records are distinguishable from records written live.
- Re-running publication produces no duplicate exposure.
- The overlap definition is written once and referenced by CR-38874 and CR-38875.

### Why now
Exposure cannot be reconstructed after the fact. Every wave that runs without this record is a
wave whose exposure is permanently unknown, and both dependent epics are blocked until it exists.

---

## CR-40345 · Run Visibility and the Eligibility Funnel

*Customer facing change: Yes · Suggested PI priority: alongside the rule epics, not after them*

### Business objectives
- Allow a planner to answer "why did this offer reach only N shoppers?" in the same conversation,
  rather than through a support request and several days of investigation.
- Make a 24-hour allocation run observable: which stage it is on, when it is expected to finish,
  and where it failed if it did.
- Ensure the constraint capabilities being added in 2026.4 — category limits, cross-campaign
  chilling, blocking, availability — are explainable rather than silently reducing reach.

### Scope
- Stage-level progress for the allocation run, with an estimated completion derived from observed
  history rather than assumption.
- A failure state that names the stage that failed and why.
- An eligibility funnel per offer: the eligible population, then each named rule family's removals
  with counts, then the allocated total.
- Every removed shopper attributed to **exactly one** rule family, so the funnel reconciles to the
  eligible population.
- Each funnel row opens to its detail: the rule, the policy version, and the shoppers affected.
- The pre-run preview entry point used by CR-38875's blocking preview.

### Out of scope
- The rules themselves; this epic reports what they did.
- Measurement and lift reporting, which is CR-38880.

### Acceptance criteria
- Progress and an estimate are visible for a live run; a failure names its stage.
- A funnel exists for every offer in a completed wave and reconciles to the eligible population.
- A planner can identify the rule responsible for a drop in reach without assistance.
- Instrumentation adds no measurable time to the run.
- A deliberately mis-attributed count fails the tests.

### Why now
Four new ways to remove a shopper arrive in 2026.4. Delivered without this, the first question
after go-live is one nobody can answer, and the new rules are blamed for effects they did not cause.

---

## CR-40346 · Measurement Prerequisites

*Customer facing change: No (delivers no 2026 value by design) · Suggested PI: 2026.4, ahead of CR-38880*

### Business objectives
- Ensure that waves executed from 2026.4 onward can be measured by the Advanced Lift Measurement
  Framework (CR-38880) when it is delivered in 2027.3.
- Guarantee that per-offer lift — not only programme-level lift — remains computable for those
  waves.
- Make any past wave reproducible from its recorded inputs, so a result can be re-derived rather
  than re-estimated.

### Scope
Four artifacts, each of which can only be captured while a wave runs:
- **Arm assignment** per shopper per wave, properly randomised and implemented separately from any
  stratification or targeting logic, deterministic from the wave seed.
- **Ghost log**: for a shopper held out as control, the offers they would have received. Without
  it, only programme-level lift is computable.
- **Frozen eligibility snapshot** per wave, in a compact representation — a row per shopper per
  offer is not viable at 15M shoppers.
- **Frozen parameter set and seed**: the configuration the wave decided from.

Also in scope: retention policy per artifact, and verification of what the 2026.1 control-group
selection fix (CR-31111 / CR-30454) actually covers in the current code.

### Out of scope
- Lift calculation, decomposition and reporting — all CR-38880.
- Any user-facing surface. This epic captures; the measurement framework consumes.

### Acceptance criteria
- Every wave writes all four artifacts, with no manual step.
- Arm assignment reproduces exactly from the recorded seed, and a per-wave balance check is
  reported.
- A past wave can be reconstructed from its snapshot, seed and parameters alone.
- Ghost-log volume and its storage cost are measured before scale-up.
- A wave that fails to write any artifact fails loudly rather than publishing silently.
- Added runtime and storage are measured and within the agreed budget.

### Why now — and the risk of deferring
These artifacts cannot be created retrospectively. If waves run in 2026 without them, the 2027.3
measurement framework will arrive to find a year of waves it cannot measure, and no later work
recovers that. This epic delivers no visible value in 2026; that is expected, and is the reason it
is stated explicitly here rather than assumed inside another epic.

---

## Amendment · 2026-08-31 — the three now have real keys, and three more epics have none

**The keys landed.** `XXX-1/2/3` above are now CR-40344, CR-40345 and CR-40346 (D-11). The
descriptions themselves are unchanged and still ready to paste.

**Two of the three moved quarter.** Under D-10 the board is sequenced by quarter, and the suggested
`PI 2026.4` in the header above is no longer right for all three:

| Epic | Quarter | Note |
|---|---|---|
| CR-40344 · Cross-campaign exposure record | Q4 2026 | as proposed. The client's own deck names it a shared controls gate for blocking, run visibility and chilling |
| CR-40346 · Measurement prerequisites | Q4 2026 | as proposed |
| CR-40345 · Run visibility and the eligibility funnel | **Q1 2027** | moved out of the first increment. See board row B-3: the rules that feed the funnel ship a quarter before it |

**Three epics on the board still have no description here and no stories anywhere.** They arrived
with the 2026-08-25 roadmap and are not covered by this document:

| Epic | Quarter | What it is | Owed |
|---|---|---|---|
| CR-40599 · Personalization UX research | Q4 2026 | Observing real planners using the current screens; the evidence the redesign rests on. Detailed in the discovery pack | description + stories |
| CR-40841 · Large-scale allocation, phase 2 | Q1 2027 | The 20K half, split out of CR-38871 | description + stories |
| CR-40313 · Redesigned constraint enforcement | Q4 2027 | Target architecture. Referenced in `01-REQUIREMENTS.md` since 2026-08-16 but never described | description + stories |

CR-38871 has a description in Jira already but no stories in `features/JIRA-IMPORT-stories.csv`.
Together these are board row B-4.
