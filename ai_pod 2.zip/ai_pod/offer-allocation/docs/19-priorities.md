# 19 — Priorities (from client delivery roadmap)

Populated from `Personalization 2026.xlsx` (`docs/sources/2026-08-13-personalization-2026-roadmap.md`),
the client's own PI-by-PI delivery plan. **This is the client's committed sequencing, not this
pod's decision** — it is cited as evidence of what the business already expects, the way
`06-prior-evidence.md` cites the proof of concept. It becomes a pod priority only once Gate A signs
it.

| Epic (client's name) | Jira | Maps to | PI target | Why it matters | Wave-one non-negotiable? |
|---|---|---|---|---|---|
| Support Large-Scale Offer Allocation Capacity | CR-38871 | R-1 (+ scale ambiguity, `07-open-questions.md` Q-10) | 26.4 | Blocks everything else running at real volume | Yes — R-1 is buildable first per `17-REQUIREMENT-TRACE.md` |
| Offer Limits by Category | CR-38872 | R-2 | 26.4 (risk of spillover to 27.1, FE-side) | D-07: caps are inexpressible today | No, but launch-relevant |
| Advanced Coupon Blocking | CR-38875 | R-5 (+ cross-campaign clarification, Q-9) | 26.4 | D-14: exclusions inconsistent, partly worked around | No |
| Global Do Not Repeat (DNR) and Chilling Rules | CR-38874 | R-4 | 26.4 | D-08: rest periods are campaign-scoped today | **Yes — feeds the exposure ledger (irreversible #4)** |
| Personalization Front-End Modernization (Angular → React) | CR-38870 | No requirement directly; a stack migration | 26.4 | Changes what FE work for every other epic lands on | No, but sequencing-relevant — see Q-14 |
| Multi-Brand / Multi-SKU Coupons | CR-38876 | R-6 | 26.4 → spans into 2027 | D-13: broad offers break the run today; largest single epic (700 pts) | No |
| Store Availability-Based Offer Allocation | CR-38873 | R-3 | 2027 | D-09: availability at the wrong grain | No |
| Campaign Planning & Budget Estimation (Audience Builder) | CR-38878 | R-7b | 2027 | No interactive audience-first estimation today | No |
| Campaign Planning & Budget Estimation (System-Guided) | CR-38877 | R-7a | 2027 | No interactive products-first estimation today | No |
| Supplier Budget Capping & Compliance | CR-38879 | R-8 | 2027 | **Launch-blocking per R-8's own text** — but scheduled for 2027, after 26.4 | **Conflict — see note below** |
| Advanced Lift Measurement Framework | CR-38880 | R-10 | 2027 | Carries the other three wave-one irreversibles (arms, ghost logging, frozen snapshot) | **Conflict — see note below** |
| Control Group selection logic | CR-31111, CR-30454 | D-04 / R-10 | DONE (pre-dates this programme) | May already fix control-group bias | Needs verification, `07-open-questions.md` Q-12 |

## Conflicts this roadmap surfaces against the non-negotiables

1. **R-8 (supplier budget capping) is marked launch-blocking in `01-REQUIREMENTS.md`**, but the
   client's own roadmap schedules it for 2027, after the 26.4 epics. Either the requirement's
   "launch-blocking" status or the roadmap's sequencing is wrong, and this pod cannot silently
   pick one — it is a Gate A conflict to surface, not guess past (per `CLAUDE.md`).
2. **Three of the four wave-one irreversibles** (randomised arms, ghost-allocation logging, and —
   partially — the funding ledger) live inside "Advanced Lift Measurement Framework" and "Supplier
   Budget Capping & Compliance," both scheduled for 2027. `04-non-negotiables.md` N-15 requires
   all four to ship **before the first production wave**. If any 26.4 epic produces a wave that
   goes to production before 2027, N-15 is violated by the roadmap as given.
3. **R-9 (sales-time budget estimation) has no epic at all** on this roadmap — see
   `07-open-questions.md` Q-13.
4. **No epic names R-1's visibility half** (stage progress, honest estimate, failure-names-stage)
   separately from capacity/scale — "Support Large-Scale Offer Allocation Capacity" may cover only
   the throughput half of R-1. Not yet confirmed either way.

## What this document is not

Not a sign-off. Not a commitment by this pod to the client's sequencing. `pod/templates/priorities.md`
is the actual Gate A artifact the product owner rules on; this document is the evidence that
artifact rules against.

---

## Amendment · 2026-08-16 — the client roadmap, read against the pod's phasing

This remains the **client's** committed sequencing, cited as evidence rather than adopted. Read
alongside the pod's phasing (D-4), three things are worth stating:

1. **Phase 1 takes the 2026.4 rule epics** — CR-38872, CR-38874, CR-38875, CR-39714 — plus the
   feed-based half of CR-38873, which the roadmap places at 2027.1. Moving that half earlier is a
   proposal for the discovery session, not a change.
2. **Three epics do not exist on the client roadmap and are proposed by the pod**: the exposure
   record (CR-40344), run visibility and the funnel (CR-40345), and measurement prerequisites (CR-40346).
   The first two are silent dependencies of CR-38874 and CR-38875; the third captures what
   CR-38880 will need and cannot obtain retrospectively.
3. **Two roadmap conflicts remain open for the business owner**, unchanged: R-8 is stated
   launch-blocking in the requirements but scheduled for 2027, and three of the four wave-one
   irreversibles sit inside 2027-scheduled epics while 26.4 work reaches production first.

---

## Amendment · 2026-08-31 — a newer roadmap arrived, and it *was* adopted as pod sequencing

Everything above describes `Personalization 2026.xlsx` (2026-08-13). A newer business-view roadmap
(`docs/sources/2026-08-25-personalization-roadmap-2026-2027.pptx`, dated 2026-08-25, stated as
"updated from Jira export") supersedes it, and — unlike its predecessor — **it was adopted as the
pod's own sequencing** by D-10 rather than filed as evidence. `features/BOARD.md` is now organised
by delivery quarter to match.

The deck encodes quarter positionally, so the mapping below was recovered from shape coordinates
rather than read from the text flow. It covers **18 epics**, four of which were not on the board at
all.

### What moved, against the phasing this document previously recorded

| Epic | Was | Now | Movement |
|---|---|---|---|
| CR-38871 · 10K allocation | 26.4 / Phase 1 | Q4 2026 | held. **Split** — 20K is now CR-40841 |
| CR-40344 · Exposure record | Phase 1 (pod-proposed) | Q4 2026 | held, and now a real Jira key |
| CR-38874 · DNR / chilling | 26.4 / Phase 1 | Q4 2026 | held |
| CR-38875 · Coupon blocking | 26.4 / Phase 1 | Q4 2026 | held |
| CR-40346 · Measurement prerequisites | Phase 1 (pod-proposed) | Q4 2026 | held, and now a real Jira key |
| CR-40599 · UX research | absent | Q4 2026 | **new epic** |
| CR-40345 · Run visibility + funnel | Phase 1 (pod-proposed) | Q1 2027 | **out of the first increment** |
| CR-38872 · Category limits | 26.4 / Phase 1 | Q1 2027 | **out of the first increment** |
| CR-39714 · Multi-brand coupon creation | 26.4 / Phase 1 | Q1 2027 | **out of the first increment** |
| CR-38873 · Store availability | Phase 1, feed half | Q2 2027 | **out of the first increment** |
| CR-38880 · Lift framework | 2027 / Phase 3 | Q1 2027 | **earlier** |
| CR-40841 · 20K allocation | absent | Q1 2027 | **new epic**, split from CR-38871 |
| CR-38870 · React modernization | 26.4, unphased | Q1 2027 | now dated |
| CR-38876 · Multi-brand scoring | 26.4→2027 / Phase 2 | Q2 2027 | now dated |
| CR-38879 · Supplier budgets | 2027 / Phase 3 | Q3 2027 | now dated |
| CR-38878 / CR-38877 · Planning | 2027 / Phase 2 | Q4 2027 | later |
| CR-40313 · Constraint enforcement | referenced only | Q4 2027 | now dated |

### The dependency groupings the deck states

Traced from its dependency slide. It is a **partial** view — four epics (CR-38875, CR-39714,
CR-38876, CR-38877) appear on the roadmap but in none of these groups, and no grouping is inferred
for them here.

| Track | Epics |
|---|---|
| Scale and availability | CR-38871 → CR-40841 → CR-38873 |
| Controls and visibility | CR-40344 → CR-38874 → CR-40345 → CR-40313 |
| Measurement | CR-40346 → CR-38880 |
| Experience and offer creation | CR-40599 → CR-38870 → CR-38872 |
| Commercial planning | CR-38879 → CR-38878 |

The deck also names a **shared controls gate**: the exposure record enables advanced coupon
blocking, run visibility, *and* global DNR / chilling. That is the pod's own CR-40344 argument
arriving back from the client, which is the strongest evidence yet that the epic belongs where it is.

### What adoption did and did not settle

**Settled.** The scale unit — offers, 10K in Q4 2026 — which partially answers Q-10. And the bulk
of the wave-one irreversibles conflict: arms, ghost log, snapshot, seed (CR-40346) *and* the
exposure ledger (CR-40344) are all now in the first increment, so conflict 2 above largely closes.

**Not settled, and now carried as board rows B-1 to B-4 in `features/BOARD.md`:**

1. **R-8 remains stated launch-blocking** in `01-REQUIREMENTS.md` while sitting at Q3 2027 — three
   quarters after the first Q4 2026 wave. Adopting this sequencing dated the conflict; it did not
   resolve it.
2. **The funding half of irreversible #4** lives in CR-38879 at Q3 2027. N-15 requires all four
   before the first production wave, and the funding ledger will not be there.
3. **New, and not visible before this deck.** Chilling and blocking ship Q4 2026, and the discovery
   pack says both *feed the funnel* — but CR-40345, the funnel itself, is Q1 2027. Register rows
   Q-8 and Q-10 are marked `surfaced` via the explain funnel; on this sequencing they have no
   answering surface for a quarter after the rules that make them urgent go live.
4. **Five epics carry no stories** — CR-38871, CR-40599, CR-40841, CR-38870, CR-40313 — two of them
   inside the current increment. CR-38870 (React modernization) is the least concerning of the five,
   being a stack migration rather than a requirement; the other four all answer to one.

Conflict 3 in the original list (R-9 has no epic) stays closed per Q-13. Conflict 4 (no epic names
R-1's visibility half) is now **answered**: CR-40345 is that epic, and it is Q1 2027.
