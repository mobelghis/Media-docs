# 02 — Current state

What the existing system does, in its own vocabulary. Written so that nobody joining has to
guess, and so data science never has to reverse-engineer behaviour from code.

## Vocabulary (use these words; they are the system's own)
| Term | Meaning |
|---|---|
| **Coupon** | The deal definition — the discount and its product set. Lives in a coupon bank |
| **Coupon bank** | A folder of coupons, and the unit a policy whitelists |
| **Offer** | A coupon placed into a wave with targeting: size, priority, must-get flag, min/max |
| **Wave** | One execution: the run that allocates offers to shoppers and publishes the result |
| **Marketing policy** | The rule set a wave runs under: caps, chilling, control %, whitelisted banks |
| **Allocation** | One shopper's instance of one offer — the row the whole system exists to produce |
| **Campaign** | A series container grouping related waves (thin today; see the requirements) |

## How a wave runs today
1. A wave is created from a marketing policy and offers are attached from whitelisted banks.
2. Eligibility is computed per offer by a family of rules (chilling, blocking, targeting).
3. Scoring ranks shopper–offer pairs.
4. Allocation assigns offers to shoppers greedily, respecting per-shopper limits.
5. A control group is taken and the wave is approved and published to the delivery channel.

## What is known to exist and work
- Per-shopper targeting by list, segment and objective.
- Coupon banks, bulk upload, and images.
- Chilling and rest-period logic (a reader exists; scope is limited).
- Publication and delivery export.
- Reporting of issuance and redemption at coupon grain.

## Known structural facts that constrain any redesign
- The delivery export **drops offer identity** — the boundary to the channel is coupon-grain.
- Store availability data exists but at a **different grain** than the constraint needs.
- Category caps as required are **not expressible** in the current policy model.
- **No money tables exist.** Spend against supplier commitments is not systematically recorded.
- Minimum and maximum issuance fields are **frequently null** in practice.
- Control-group selection happens **after** allocation and strips from the allocated set, which
  biases every comparison built on it.
- Randomisation is **unseeded**, so no wave can be reproduced exactly.
- One targeting mode reaches everyone by disabling eligibility — a workaround, not a feature.

*(Detail, including table and function names, lives in the legacy discovery pack referenced in
`07-open-questions.md`. This document is the summary a newcomer needs.)*

---

## Amendment · 2026-08-16 — the policy screen's real structure

The vocabulary and mechanics above are unchanged. Added from the front-end recreation guide,
because Phase 1 depends on it: the marketing policy editor is three collapsible sections —
**General**, **Campaign Strategy** (per-shopper, per-brand and per-in-house-brand min/max, plus
Frequency Criteria: an allocations threshold and a period in days, which is chilling today), and
**Segment Strategy** (tabs by constraint type, panels per value, min/max rows per segment).

Also worth recording: coupon type is already SKU / Catalog / **Virtual Category**, and the product
picker already filters by CPG, brand and category with select-all and CSV import. The gaps are
excludes and dynamic re-resolution, not the picker itself.
