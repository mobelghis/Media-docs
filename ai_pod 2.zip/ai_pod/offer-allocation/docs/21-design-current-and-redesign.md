# 21 — Design: what to add now, and what to aim at

Two parts, deliberately in tension. **Part 1** is the minimum that must land on today's Angular
screens for Phase 1 to work. **Part 2** is three options for how rules and constraints should be
presented in the redesign, for the designer to argue with.

The full document, with the wireframes, is
`assets/phase1-design-current-and-redesign.docx`. The wireframes are also in `assets/` as PNGs:
`design-option-A-matrix.png`, `design-option-B-rules-table.png`, `design-option-C-sentences.png`.

## Part 1 — the minimum, on the current Angular app

**Marketing policy editor** — most of Phase 1 lands here.
- Category limits: add **Category as a constraint type in the existing Segment Strategy model** —
  same tabs, same collapsible panels, same min/max rows. Not a new rule builder. `[verify]` that
  the constraint type enum takes a fifth value without a wider schema change.
- Chilling: the two Frequency Criteria fields already exist. Add a **scope** control (this campaign
  / all campaigns / all incentive types) and the **level** the rule matches on. Add the
  history-coverage warning where the window reaches further back than exposure history. Fix the
  tooltip binding, which references an undefined scope variable and renders empty.
- Blocking: the one genuinely new section — overlap threshold, time window, winner priority,
  declared pairs, and an entry point to the pre-run preview.

**Coupon editor** — extend the picker that exists.
- Add **excludes** alongside includes at any level; allow dynamic sets that freeze at wave freeze;
  show the resolved product count and a breadth warning; show store coverage and whether it comes
  from the client feed or is derived.

**Wave screen** — from a histogram to an explanation.
- Stage progress with an honest estimate and a failure state that names the stage.
- The eligibility funnel per offer, reconciling to the eligible population.
- The blocking preview, reachable before the run.

**Two rules that apply to every new field**
- It must join the retailer metadata system (`fromMetaData.<field>`: hide / required / options /
  labelTranslate), or it cannot be configured per retailer like everything else.
- Every min/max inherits the existing **127** ceiling (`Byte.MAX_VALUE`) unless a decision is taken
  to change it. That is a decision to raise, not a default to accept.

## Part 2 — three options for the redesign

| Option | Shape | Best for | Weak for |
|---|---|---|---|
| **A · Matrix** | values down, segments across, min/max in cells | many rules, bulk entry, power users | more than ~8 segments; explains nothing in words |
| **B · Rules as rows** | one table, one rule per row, all constraint types together | mixed rule types, scale, explaining a rule | bulk entry; comparing across segments |
| **C · Sentences + edit panel** | plain-language list, editing in a side panel | comprehension, review, showing a stakeholder | verbose at fifty rules; slowest to enter |

**Recommendation.** B as the default, A as a second view of the same data for bulk weeks, and C's
sentence rendering wherever a rule is *displayed* rather than edited — the wave screen, the funnel,
an approval summary.

**What matters more than the choice.** A rule shows its own effect (what it did in the last wave);
a rule that cannot hold says so where it is written; and a rule whose data is incomplete admits it
rather than silently doing less.

## Questions for the design review
1. Do rules belong on the policy editor at all, or on their own screen it links to?
2. How many rules does a real client actually have? Under ten favours A; over fifty rules it out.
3. Should min/max stay two numbers or become a range control? All are capped at 127.
4. Where should a rule's effect appear — inline, or only in the funnel?
5. Do declared blocking pairs belong in the same list as threshold rules?
6. How much survives the retailer-metadata system, where any column can be hidden per client?
