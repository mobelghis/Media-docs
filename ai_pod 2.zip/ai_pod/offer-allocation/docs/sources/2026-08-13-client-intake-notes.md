# Client intake notes — 2026-08-13

Raw, verbatim. Received as pasted text during intake.

---

5. Advanced Coupon Blocking

Avoid conflicting or redundant coupon exposure across campaigns and within campaigns.
The system must support blocking rules between item-level and category-level coupons.
Blocking must be applied:
- Within the same campaign
- Across different campaigns

We already have blocking rules applied, and I'd like to better understand how this requirement
differs from what is already supported.

---

A feature that is not in any intake - One of the most difficult tasks every personalization
client has is to manage the offers not to overlap with mass promotion. It's a constant manual
task to disable those personalized offers.

If we could auto-block those offers for the parallel periods it will be extremely valuable and
relevant to every retailer.

---

Hi, I suggest we setup a crash course of how the Activate personalization process in operated. I
believe It will assist you better understand what are the platform strengths and weaker points,
how each intake request relates to those points and why.

Even something simple such as "Support 10,000 coupons" is pretty complicated and requires deep
understanding to develop properly.

- Is it 10,000 coupons OR 10,000 offers?
- 10,000 coupons can be 30,000 offers
- Supporting 10K offers is easy is they are all retention. If they are all xSell offers it
  requires a totally different tech solution
- How do we handle coupon blocking rules with so many coupons? Block only those that overlap
  100%? Block partial overlap? if so, at what %? Do you count that % from the number of SKU in
  the coupon or their % sales?

And that's a very simple intake. Other get complicated real fast.

We'll need 2-3 sessions of 1.5 hours to go over the basics and continue from there. Avichai
Yom-Tov is our expert on the technical "what buttons to press" and how to operate everything. I'll
cover the strategy, measurement and improvement cycle.
