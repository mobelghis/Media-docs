# Personalization Roadmap 2026.4–2027.4 (text extraction)

Mechanical text extraction of `2026-08-25-personalization-roadmap-2026-2027.pptx`, which is the
real source. Quarter assignment in the deck is positional, so the epic-to-quarter mapping below
was recovered from shape x-coordinates rather than read from the text flow.

## Epic to quarter, recovered from shape coordinates

| Quarter | Epics |
|---|---|
| Q4 2026 | CR-38871, CR-40344, CR-38874, CR-38875, CR-40346, CR-40599 |
| Q1 2027 | CR-40841, CR-40345, CR-39714, CR-38880, CR-38870, CR-38872 |
| Q2 2027 | CR-38873, CR-38876 |
| Q3 2027 | CR-38879 |
| Q4 2027 | CR-38878, CR-38877, CR-40313 |

---

==================== slide1.xml ====================
ACTIVATE PERSONALIZATION
Business Roadmap
2026.4 to 2027.4
Updated from Jira export | 25 August 2026, 1:52 PM
Epic names are shown alongside Jira keys. Dependencies are marked directly on the roadmap and summarized on a dedicated slide.
==================== slide2.xml ====================
Activate Personalization Roadmap
Business-friendly epic names with Jira keys | Dependency arrows show recommended delivery sequence


Q4 '26

Q1 '27

Q2 '27

Q3 '27

Q4 '27

Personalization

CR-38871
Large-Scale Allocation
Phase 1 | 10K

CR-40344
Cross-Campaign
Exposure Record

CR-38874
Global DNR and
Chilling Rules

CR-38875
Advanced Coupon
Blocking

CR-40346
Measurement
Prerequisites

CR-40599
Personalization
UX Research

CR-40841
Large-Scale Allocation
Phase 2 | 20K

CR-40345
Run Visibility and
Eligibility Funnel

CR-38880
Advanced Lift
Measurement Framework

CR-39714
Improved Multi-Brand /
SKU Coupon Creation

CR-38876
Multi-Brand /
Multi-SKU Coupons

CR-38870
React
Modernization

CR-38872
Offer Limits
by Category

CR-38873
Store Availability-Based
Offer Allocation

CR-38879
Supplier Budget Capping
and Compliance

CR-38878
Campaign Planning & Budget
Estimation | Audience Builder

CR-38877
Campaign Planning & Budget
Estimation | System-Guided

CR-40313
Redesigned Constraint
Enforcement






LEGEND

Foundation / controls

Experience

Measurement

Commercial planning

Target architecture
Solid = direct predecessor   |   Dashed = broader enabling dependency
NIQ  |  ACTIVATE PERSONALIZATION ROADMAP
2
==================== slide3.xml ====================
Dependency View
Recommended direction based on epic scope and delivery sequencing
Scale and availability

CR-38871 | 10K Allocation


CR-40841 | 20K Allocation


CR-38873 | Store Availability
Controls and visibility

CR-40344 | Exposure Record


CR-38874 | DNR / Chilling


CR-40345 | Run Visibility


CR-40313 | Target Enforcement
Measurement

CR-40346 | Prerequisites


CR-38880 | Lift Framework
Experience and offer creation

CR-40599 | UX Research


CR-38870 | React Modernization


CR-38872 | Category Limits
Commercial planning

CR-38879 | Budget Capping


CR-38878 | Audience Builder

Shared controls gate
Exposure Record also enables:

• Advanced Coupon Blocking
• Run Visibility
• Global DNR / Chilling
NIQ  |  ACTIVATE PERSONALIZATION ROADMAP
3
