# Source material

Raw inputs exactly as received — briefs, requirement documents, emails, exports, notes,
screenshots. Never edited: if something here is wrong, the correction goes in the document that
cites it, not in the source.

Each file gets a one-line provenance note in this README: what it is, who provided it, when.

| File | What it is | From | Date |
|---|---|---|---|
| `2026-08-13-client-intake-notes.md` | Pasted intake text: advanced coupon blocking requirement, mass-promo auto-blocking idea, and a note on the ambiguity of "support 10,000 coupons" | Client, via chat | 2026-08-13 |
| `2026-08-13-personalization-2026-roadmap.md` | Extracted content of `Personalization 2026.xlsx` (delivery roadmap: epics, Jira CRs, sprint plan by team lane, PI targets) | Client, `Personalization 2026.xlsx` | 2026-08-13 |
| `2026-08-17-personalization-stories-jira-import.csv` | 43 stories across 13 epics in Jira import shape; supersedes `features/JIRA-IMPORT-stories.csv` and carries the first real keys for the three pod-proposed epics | Client, via intake folder | 2026-08-17 |
| `2026-08-25-personalization-roadmap-2026-2027.pptx` | Business-view roadmap deck, Q4 2026 → Q4 2027, 17 epics with dependency arrows. Stated as "updated from Jira export". Adopted as pod sequencing by D-10 | Client, via intake folder | 2026-08-25 |
| `2026-08-25-personalization-roadmap-2026-2027-extracted.md` | Text extraction of the deck above, with the epic-to-quarter mapping recovered from shape coordinates (the deck encodes quarter positionally) | Derived from the `.pptx` | 2026-08-31 |
| `2026-08-26-discovery-pack-2026Q4.docx` | Discovery pack for the six epics in the 2026.4 increment: purpose, problem today, worked examples on sample data, per-field behaviour (carried/calculated/enforced/produced), edge cases, and 25 discovery questions | Client, via intake folder | 2026-08-26 |
| `2026-08-26-discovery-pack-2026Q4-extracted.md` | Text extraction of the pack above, so its content can be grepped and cited | Derived from the `.docx` | 2026-08-31 |

**On the two `-extracted.md` files.** They are mechanical extractions, not edits. The binary is the
source of truth; where an extraction and its binary disagree, the binary wins.
