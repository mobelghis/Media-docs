# Personalization 2026.xlsx — extracted content, 2026-08-13

Raw, verbatim (re-typed from the parsed spreadsheet cells; no interpretation applied). Source
file: `Personalization 2026.xlsx`, three sheets: `Lego`, `epics`, `Dependencies`.

## Sheet: epics

| PI | Jira | Description | L1 (size) | T-shirt (sprints) | Comments |
|---|---|---|---|---|---|
| 2027 | CR-38880 | Advanced Lift Measurement Framework | 200 | | |
| 2027 | CR-38879 | Supplier Budget Capping & Compliance | 200 | 10 BE + 5 FE | |
| 2027 | CR-38878 | Campaign Planning & Budget Estimation (Audience Builder) | 150 | 10 FE + 5 BE | |
| 2027 | CR-38877 | Campaign Planning & Budget Estimation (System-Guided) | 150 | 10 FE + 5 BE | |
| 2027 | CR-38876 | Multi-Brand / Multi-SKU Coupons | 700 | 10 BE + 10 BE + 10 BE + 10 FE | this is a big project. With proper planning the work can be done by 4 developers in parallel. I'm also convinced the L1 is too exaggerated. |
| 26.4 | CR-38875 | Advanced Coupon Blocking | 60 | 6 sprints BE | |
| 26.4 | CR-38874 | Global Do Not Repeat (DNR) and Chilling Rules | 60 | 6 sprints BE | |
| 2027 | CR-38873 | Store Availability-Based Offer Allocation | 150 | 10 sprints BE | |
| 26.4 | CR-38872 | Offer Limits by Category | 200 | 6 sprints FE + 6 sprints BE | risk of spillover to 27.1 due to FE work |
| 26.4 | CR-38871 | Support Large-Scale Offer Allocation Capacity | 200 | 10x2 sprints BE split | |
| 26.4 | CR-38870 | Personalization Front-End Modernization (Angular → React) | N/A | 6 sprints | |
| DONE | CR-31111 | Control Group selection logic (DS work) | | | |
| DONE | CR-30454 | CR: Fix Control Group Selection Logic in Personalization Allocation Module | | | PI1 work |

## Sheet: Lego (roadmap grid, by team lane)

Sprint headers ran Y26S17 → Y27S26 (calendar weeks 33 of 2026 through week 51 of 2027), grouped
into PIs: 26-3, 26-4, 27-1, 27-2, 27-3, 27-4. Row labels below are the team lane; cell contents
are the epic occupying that lane's timeline (blanks omitted).

| Lane | Epics placed on the timeline, in order |
|---|---|
| BE (Oxford) | Support Large-Scale Offer Allocation Capacity → Multi-Brand / Multi-SKU Coupons → Supplier Budget Capping & Compliance |
| BE | Offer Limits by Category → Multi-Brand / Multi-SKU Coupons → Campaign Planning & Budget Estimation (Audience Builder) |
| FE | Personalization Front-End Modernization (Angular → React) → Offer Limits by Category → Multi-Brand / Multi-SKU Coupons → Campaign Planning & Budget Estimation (Audience Builder) → Store Availability-Based Offer Allocation (BE) |
| BE | Advanced Coupon Blocking → "large scale" → Advanced Lift Measurement Framework → Campaign Planning & Budget Estimation (System-Guided) |
| BE | Global Do Not Repeat (DNR) and Chilling Rules → "large scale" → Multi-Brand / Multi-SKU Coupons → Campaign Planning & Budget Estimation (System-Guided) → Supplier Budget Capping & Compliance |
| FE / DS | Personalization Front-End Modernization (Angular → React) → Multi-Brand / Multi-SKU Coupons → Advanced Lift Measurement Framework |
| DATA | Multi-Brand / Multi-SKU Coupons |

## Sheet: Dependencies

Empty — contained only "created using Freeform" (a diagram placeholder, not extractable as
text/data).
