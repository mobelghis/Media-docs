# Discovery Pack — Personalization 2026.4 (text extraction)

Mechanical text extraction of `2026-08-26-discovery-pack-2026Q4.docx`, which is the real source.
Tables are flattened with ` | ` cell separators. Nothing is reworded. Present so the content can
be grepped and cited; if the two disagree, the `.docx` wins.

---


DISCOVERY PACK
Personalization — 2026.4
The six epics in the next increment, with worked examples and every value traced
Increment   Q4 2026
For   Product owners running discovery, and the teams estimating
Companion to   The discovery deck. This is the detail behind it
Rule   Anything in the allocation repository is data science. Everything else is application.

How to use this
Each epic below is written to be verified rather than read. Every rule is shown working on sample data, so a product owner can point at a row and ask whether that is what the business actually wants.
Section
 | What to do with it
 | 
What it is
 | Confirm the one-line purpose is right before discussing anything else
 | 
The problem today
 | Check the story matches what clients actually complain about
 | 
Worked example
 | The important one. Walk the tables row by row and confirm the outcome is what should happen
 | 
Every value
 | For each field: where it is captured, how it is calculated, and who owns it. This is what the estimate rests on
 | 
Edge cases
 | What happens when the data is missing, partial or contradictory. Usually where the real work is
 | 
Questions for discovery
 | What must be answered before the epic can be estimated
 | 

The single most useful question to ask about any field
Is this value carried, or is it calculated?
A field the application only carries needs a form control, a column and a contract. A field it calculates with needs validation, edge cases, a runtime budget and a test that fails when the logic breaks. The two are routinely estimated as the same job, and the difference is usually a factor of three.
 | 

The four behaviours, used throughout
Behaviour
 | What it means
 | Who owns the work
 | 
Carried
 | The application stores it and hands it to the model unchanged
 | Application: form, column, contract. Data science: everything that uses it
 | 
Calculated
 | The application computes with it before or after the run
 | Application owns the logic, the edge cases and the tests
 | 
Enforced
 | The application validates or constrains it, then passes it on
 | Application owns validation and the failure behaviour
 | 
Produced
 | The run generates it; the application stores and shows it
 | Data science produces. Application renders it with its caveats
 | 

The six epics in this increment
Key
 | Epic
 | Produces
 | Visible?
 | 
CR-38871
 | Large-scale allocation, phase 1
 | 10K offers per allocation
 | No
 | 
CR-40344
 | Cross-campaign exposure record
 | A record of what each shopper has already received
 | No
 | 
CR-38874
 | Global do-not-repeat and chilling rules
 | Rest rules that hold across campaigns
 | Yes
 | 
CR-38875
 | Advanced coupon blocking
 | Overlapping coupons stop reaching the same shopper
 | Yes
 | 
CR-40346
 | Measurement prerequisites
 | Arms, ghost log, frozen snapshot, seed
 | No
 | 
CR-40599
 | Personalization UX research
 | Evidence for the redesign
 | No
 | 

Two of these produce nothing a client can see
The exposure record and the measurement prerequisites deliver no visible feature in 2026. They are in this increment because the epics that follow are impossible without them, and because the measurement artefacts can only be written while a wave runs.
Stating that plainly is what protects them when prioritisation tightens.
 | 


CR-38871 — Large-scale allocation, phase 1
What it is
Raise the number of offers a single allocation can carry from today's ceiling to 10,000, without the wave running past its operating window.
The problem today
A retailer with a large supplier base wants more offers in the bank than the allocation can process in the overnight window. Today the answer is to run fewer offers, which means either fewer suppliers funded or fewer shoppers reached. Both are visible to the client as a limitation of the product rather than a choice.
This epic sets the budget every later rule spends
Once 10K is achievable, every rule added afterwards has to say what it costs the run. Category limits, chilling, blocking and availability all spend from the same window.
Without a measured baseline here, four rules land separately and the combined cost is discovered at scale, in production, on a Thursday night.
 | 

Worked example — where the cost actually is
Two ways to apply the same rule, at 10,000 offers and 15 million shoppers. The difference is not the rule; it is where the work happens.
Approach
 | What it does
 | Order of work
 | 
Per candidate pair
 | For every shopper and every candidate offer, query the exposure history
 | 15M shoppers x candidate offers each = hundreds of millions of queries
 | 
Precompute once
 | Build a per-shopper exposure structure once per wave, then one lookup per pair
 | 15M structure builds, then one memory lookup per pair
 | 

The same distinction applies to coupon overlap and to store availability. It is the single design decision that decides whether Phase 1 fits in the window.
Every value
Value
 | Behaviour
 | Where it lives
 | Notes
 | 
Offer ceiling
 | Enforced
 | Platform configuration
 | The application refuses a bank above the ceiling; the model must hold within it
 | 
Stage timing
 | Produced
 | Emitted by the run, stored by the application
 | Start, finish, rows in, rows out, per stage
 | 
Measured runtime per rule
 | Produced
 | Emitted by the run
 | The number every later rule ticket quotes
 | 

Edge cases
Situation
 | What should happen
 | 
A bank exceeds the ceiling
 | Refused at configuration with the ceiling stated, not truncated silently
 | 
The run exceeds its window
 | Fails with the stage named, rather than continuing into the delivery window
 | 
Cost measured on a synthetic catalogue
 | Not accepted. Even category distribution understates the assignment loop
 | 

Questions for discovery
#
 | Question
 | Why it matters
 | 
1
 | What is today's actual ceiling, measured rather than assumed?
 | The baseline the improvement is stated against
 | 
2
 | What is the operating window, and who owns it?
 | Decides whether 10K is a target or a constraint
 | 
3
 | Is a production-shaped test environment available, and when?
 | Without one, the 10K claim cannot be verified
 | 
4
 | What offer-type mix should the test use?
 | A bank of single-SKU coupons behaves differently from one full of multi-category offers
 | 


CR-40344 — Cross-campaign exposure record
What it is
A record of every offer each shopper has already received, across every campaign and incentive type, readable while eligibility runs.
The problem today
Each campaign knows only about itself. A shopper can receive a yogurt discount on Monday from the weekly personalised campaign and a yogurt points offer on Thursday from a separate promotion, and neither campaign can see the other. Both behaved correctly by their own rules. Together they are exactly the fatigue the retailer asked us to prevent.
Worked example
Shopper 8842190, three campaigns, one product area. Below is what exists after each wave publishes.
Wave
 | Date
 | Offer
 | Product grain
 | Incentive type
 | 
W30 · Weekly personalised
 | 2 Aug
 | Activia 4pk, 50% off
 | SKU
 | Discount
 | 
W31 · Loyalty points push
 | 9 Aug
 | Dairy category, 2x points
 | Category L3
 | Points
 | 
W32 · Weekly personalised
 | 16 Aug
 | Danone Light 500ml, 50% off
 | SKU
 | Discount
 | 

A rest rule set to 30 days at category level, scoped to all campaigns, would look at 16 August and see two prior exposures inside the window: the SKU on 2 August, which rolls up to Dairy, and the category exposure on 9 August. The shopper is excluded.
The same rule scoped to this campaign only sees just the 2 August exposure, because 9 August belonged to a different campaign. That is the behaviour being fixed.
What a row looks like
Field
 | Example
 | Why it is there
 | 
shopper id
 | 8842190
 | The join to everything
 | 
campaign id
 | W31
 | So scope can be applied — this campaign or all
 | 
incentive type
 | Points
 | So a rule can span discount and points, or not
 | 
product identifier
 | Dairy L3
 | The grain the exposure happened at
 | 
product grain
 | Category
 | So a SKU exposure can be matched against a category rule
 | 
exposure date
 | 9 Aug 2026
 | The window is measured from here
 | 
source
 | Published allocation
 | Distinguishes live writes from backfill
 | 
backfilled flag
 | No
 | A backfilled row is evidence of different quality
 | 

Every value
Value
 | Behaviour
 | Where it lives
 | Notes
 | 
Exposure row
 | Carried
 | Written by the application at publication
 | The model reads a structure built from these, never the table
 | 
Per-wave exposure structure
 | Calculated
 | Built once per wave by the application
 | Shopper to set of (grain, date). This shape is the contract
 | 
Earliest exposure date
 | Calculated
 | Computed per client, refreshed daily
 | Drives the coverage warning on the chilling screen
 | 
Overlap definition
 | Carried
 | Configuration, defined by data science
 | Shared by chilling and blocking. One definition, not two
 | 

Edge cases
Situation
 | What should happen
 | 
A wave is republished after a correction
 | No duplicate exposure rows. The write must be idempotent
 | 
A client has no history yet
 | The structure is empty and rules relying on it remove nobody, rather than everybody
 | 
A shopper has no exposure at all
 | Absent from the structure. Absence means not exposed, never held out
 | 
A rule window is longer than available history
 | The rule applies to what is known, and the shortfall is reported to the planner
 | 
Retail media exposure exists elsewhere
 | Out of scope unless a decision brings it in. Worth asking
 | 

The distinction to protect
No exposure row means the shopper was not exposed. It never means the shopper was deliberately held out.
Those are different facts with different consequences for measurement, and conflating them silently corrupts the control group.
 | 

Questions for discovery
#
 | Question
 | Why it matters
 | 
1
 | Does exposure include retail media, or personalization only?
 | Changes both volume and the meaning of a cross-campaign rule
 | 
2
 | How far back must history reach, and what is retained?
 | Storage cost, and the longest rule that can honestly be offered
 | 
3
 | Is exposure written at publication or at delivery?
 | A suppressed delivery is not an exposure. Which one counts?
 | 
4
 | How are SKU and category exposures matched against each other?
 | Decides whether a SKU exposure blocks a category rule
 | 


CR-38874 — Global do-not-repeat and chilling rules
What it is
Let a planner say do not repeat this within a period, and have the rule hold across every campaign and incentive type rather than stopping at the campaign boundary.
The problem today
Two fields already exist on the policy editor, under Campaign Strategy: an allocations threshold and a period in days. They apply to the current campaign only, and they match on the offer identifier rather than on products. So the same shopper can receive effectively the same promotion twice, from two campaigns, and both rules will report themselves as satisfied.
Worked example — the same rule, three scopes
Shopper 8842190, with the exposure history from the previous epic. Today is 16 August. The planner sets: do not repeat within 30 days.
Scope
 | Level
 | What it sees
 | Outcome for this shopper
 | 
This campaign
 | Offer
 | W30's offer only, and this is a different offer
 | Not excluded
 | 
This campaign
 | Category
 | W30's Dairy exposure
 | Excluded
 | 
All campaigns
 | Category
 | W30 and W31 — both Dairy inside 30 days
 | Excluded
 | 
All incentive types
 | Category
 | Same, and would also catch a points-only exposure
 | Excluded
 | 

The three scopes produce different audiences from the same rule text. That is why scope has to be explicit on the form rather than implied.
Worked example — the coverage warning
A planner sets a 90-day brand rest rule on 16 August. Exposure history for this client begins on 12 March.
Value
 | Computed as
 | Result
 | 
Window start
 | today minus 90 days
 | 18 May
 | 
History begins
 | earliest exposure date for this client
 | 12 March
 | 
Coverage
 | history begins is before window start
 | Full coverage. No warning
 | 

Now the same rule set on 20 April, when history began on 12 March:
Value
 | Computed as
 | Result
 | 
Window start
 | today minus 90 days
 | 20 January
 | 
History begins
 | earliest exposure date
 | 12 March
 | 
Unknown days
 | history begins minus window start
 | 50 days of the 90 are unknown
 | 

What the planner sees
A warning beside the window field: exposure history begins 12 March. 50 of the 90 days are unknown, so shoppers exposed before that date will not be chilled.
It disappears on its own once history is deep enough. Nobody has to dismiss it, and nobody has to remember to re-check.
 | 

Every value
Value
 | Behaviour
 | Where it lives
 | Notes
 | 
Threshold and period
 | Carried
 | Policy editor, Campaign Strategy — already exist
 | Stored with the policy version
 | 
Scope
 | Carried
 | New control on the same section
 | This campaign / all campaigns / all incentive types
 | 
Match level
 | Carried
 | New control
 | Product, category or brand, per the shared overlap definition
 | 
Coverage warning
 | Calculated
 | Computed by the application from coverage and the window
 | Never reaches the model. It is a planner-facing concern
 | 
Removal count
 | Produced
 | Emitted by the run
 | Becomes the chilling row in the funnel
 | 

Edge cases
Situation
 | What should happen
 | 
History shorter than the window
 | Rule applies to what is known. The warning states the gap. It does not refuse to run
 | 
No exposure history at all
 | Removes nobody. A rule that removes everybody on an empty table is the worst possible failure
 | 
A shopper exposed at SKU level, rule set at category
 | Matched, per the shared overlap definition. Confirm this is intended
 | 
Same shopper evaluated twice in one run
 | Identical answer. The rule must be idempotent within a run
 | 
Coverage unavailable
 | Show no warning rather than a false reassurance
 | 

A defect worth fixing while in there
The tooltips on the two existing Frequency Criteria fields are bound to a scope variable that does not exist, so they render empty in production today.
It is a small fix, it is in the same file, and it has been shipping quietly for some time.
 | 

Questions for discovery
#
 | Question
 | Why it matters
 | 
1
 | Should a SKU exposure satisfy a category rule?
 | Changes the audience materially, and is not obvious either way
 | 
2
 | What are the default scope and level for an existing rule?
 | Existing policies must not change behaviour on upgrade
 | 
3
 | Should the warning block saving, or only inform?
 | A blocking warning changes the workflow; an informing one may be ignored
 | 
4
 | Are there rules today kept outside the product because they cannot be expressed?
 | The best source of what scope really needs to cover
 | 


CR-38875 — Advanced coupon blocking
What it is
Stop a shopper receiving two coupons that cover substantially the same products, whichever campaign each came from, and let a planner see what would block what before the wave runs.
The problem today
Blocking does not exist in any form. What exists is chilling, scoped to one campaign and matching on the offer rather than the products. Two coupons covering the same products are invisible to each other.
The result a shopper sees: fifty per cent off one litre of a cola, and fifty per cent off one and a half litres of the same cola, in the same week, from two different suppliers' campaigns. Both offers were valid. To the shopper it looks like the retailer is not paying attention.
Worked example — what overlap means
Four coupons in one bank. Overlap is the share of products two coupons have in common, measured against the smaller set.
Coupon
 | Products
 | Covers
 | Overlap with 4402
 | Blocks?
 | 
4402
 | 18
 | Cola, 1L bottles, all brands
 | —
 | —
 | 
4471
 | 14
 | Cola, 1.5L bottles, same brands
 | 11 of 14 = 79%
 | Yes, above 60%
 | 
4488
 | 46
 | All carbonated soft drinks
 | 18 of 18 = 100%
 | Yes
 | 
4502
 | 22
 | Still water, all sizes
 | 0 of 18 = 0%
 | No
 | 

With the threshold at 60%, coupons 4471 and 4488 both conflict with 4402. Coupon 4502 does not. The winner rule then decides which one a shopper actually receives.
Worked example — the winner rule
Shopper 8842190 is eligible for 4402, 4471 and 4488. All three conflict with each other. The rule has to choose deterministically, or the same shopper will get different answers on different runs.
Coupon
 | Offer priority
 | Must-receive?
 | Outcome
 | 
4402
 | High
 | No
 | Allocated
 | 
4471
 | Medium
 | No
 | Blocked by 4402
 | 
4488
 | High
 | No
 | Blocked by 4402 — tie broken by lower coupon id
 | 

The tie-break matters more than it looks
Two coupons at the same priority will happen constantly. Without a documented tie-break, the outcome depends on evaluation order, which depends on the data — and the same wave re-run can produce a different answer.
Whatever the tie-break is, it must be written down and reproducible.
 | 

Worked example — why precomputing decides the cost
Approach
 | Work at 10,000 coupons
 | Feasible?
 | 
Compare product sets per shopper
 | 15M shoppers x candidate pairs, each a set comparison
 | No
 | 
Compare coupon to coupon, once per run
 | 10,000 x 10,000 / 2 = 50M comparisons, once
 | Yes
 | 
Then per shopper
 | One membership test per candidate pair
 | Yes
 | 

Every value
Value
 | Behaviour
 | Where it lives
 | Notes
 | 
Overlap threshold
 | Carried
 | New blocking section on the policy
 | Default stated by data science; a parameter, not a constant
 | 
Concurrency window
 | Carried
 | New blocking section
 | How close in time two coupons must be to conflict
 | 
Winner priority rule
 | Carried
 | New blocking section
 | With a documented tie-break
 | 
Declared coupon pairs
 | Enforced
 | New blocking section
 | The application validates both coupons exist and are in the bank
 | 
Coupon overlap table
 | Produced
 | Computed once per run
 | Coupon A, coupon B, overlap share, decision
 | 
Blocking outcome
 | Produced
 | Per shopper, per blocked offer
 | Feeds the funnel and the audit
 | 
Preview result
 | Produced
 | Run without allocating
 | Must use the same code path as the real run
 | 

Edge cases
Situation
 | What should happen
 | 
Two coupons at identical priority
 | The documented tie-break applies, deterministically
 | 
A declared pair that also overlaps automatically
 | Both recorded, and the funnel distinguishes them
 | 
A coupon overlapping many others
 | Reported before the wave runs. One coupon suppressing half the bank should not be a surprise
 | 
Threshold set very low
 | A breadth warning with the number of pairs it would create
 | 
Preview run while a wave is scheduled
 | No interference and no lock on the wave
 | 

Questions for discovery
#
 | Question
 | Why it matters
 | 
1
 | Overlap measured against the smaller set, the larger, or the union?
 | Changes which pairs conflict, sometimes dramatically
 | 
2
 | What is the winner rule, and what is the tie-break?
 | Determinism depends entirely on this
 | 
3
 | Can a planner whitelist a specific pair?
 | A supplier may want two of their own coupons to run together
 | 
4
 | What is the expected blast radius at the default threshold?
 | Should be estimated before it is switched on, not discovered afterwards
 | 
5
 | Does blocking apply across incentive types?
 | A discount and a points offer on the same products may or may not conflict
 | 


CR-40346 — Measurement prerequisites
What it is
Capture the four artefacts that can only be written while a wave runs, so that waves running in 2026 can still be measured when the framework arrives in 2027.
The problem today
None of the four exists. They cannot be added retrospectively: a wave that ran without them can be described accurately and can never be measured causally, whatever is built afterwards.
This epic delivers no visible value in 2026, by design
That is not an argument against it. It is the reason it must be stated explicitly on the ticket, so that when prioritisation tightens the decision to drop it is taken knowingly rather than by default.
 | 

The four artefacts
Artefact
 | What it is
 | Why it cannot wait
 | 
Arm assignment
 | Which shoppers were held out, with the seed that produced the split
 | Assignment must precede exposure. Afterwards there is nothing to reconstruct it from
 | 
Ghost log
 | For a held-out shopper, what they would have received
 | The allocator knows this at the moment it strips them. A second later it is gone
 | 
Frozen eligibility snapshot
 | Who was eligible at decision time
 | Eligibility moves. Today's answer is not what the wave decided from
 | 
Seed and parameters
 | What the wave decided from
 | Without them a past wave cannot be re-run to the same numbers
 | 

Worked example — why the ghost log matters
A wave holds out 2% of 15 million shoppers. Without a ghost log, the only thing known about a held-out shopper is that they were held out. With one, we know precisely what they were denied.
Question
 | Without a ghost log
 | With a ghost log
 | 
Did the programme work?
 | Answerable
 | Answerable
 | 
Did offer 4471 work?
 | No. A held-out shopper cannot be attributed to any offer
 | Yes. The held-out shopper was denied 4471 specifically
 | 
Which audience responded?
 | Only at programme level
 | Per offer, per audience
 | 
What was wasted?
 | Not answerable
 | Answerable per offer
 | 

Per-offer measurement is what a supplier pays for. Programme-level measurement is what a retailer tolerates. The ghost log is the difference.
Worked example — arm assignment must be independent
Two implementations of the same intent, one of which quietly invalidates the measurement.
Implementation
 | What happens
 | Valid?
 | 
Random draw seeded on (wave seed, shopper)
 | Independent of everything else in the run
 | Yes. Reproducible and unbiased
 | 
Take every fiftieth shopper from the scored list
 | Correlated with score, and so with propensity to buy
 | No. The control group is systematically different
 | 
Randomise within stratification buckets, sharing code with targeting
 | Correlated with whatever the targeting logic changes
 | No. And the correlation appears only when targeting changes
 | 

Why the second and third fail in a way that is hard to detect
Both produce a control group that looks the right size and passes a casual inspection. The bias only becomes visible when someone checks balance on the attributes that matter — which is why the balance check is an acceptance criterion rather than a diagnostic.
 | 

Every value
Value
 | Behaviour
 | Where it lives
 | Notes
 | 
Wave seed
 | Carried
 | Set by the application at freeze
 | The assignment must reproduce from it exactly
 | 
Arm
 | Produced
 | Assigned by the model, stored by the application
 | Deterministic from (seed, shopper)
 | 
Ghost assignment
 | Produced
 | Emitted by the model instead of discarded
 | The only output describing something that did not happen
 | 
Eligibility snapshot
 | Calculated
 | Captured by the application at freeze
 | Compact form. A row per shopper per offer is not viable at scale
 | 
Balance report
 | Produced
 | Computed per wave
 | Differences between arms on the stated stratification keys
 | 
Holdout size
 | Produced
 | Shown read-only on the wave
 | So a planner knows a holdout was taken
 | 

Edge cases
Situation
 | What should happen
 | 
An artefact cannot be written
 | Publication fails loudly. Publishing without them is worse than not publishing
 | 
A wave is re-run from frozen inputs
 | The same shoppers land in the same arms
 | 
Ghost log volume is larger than expected
 | Measured on one real wave before being switched on everywhere
 | 
Balance check fails
 | Reported and the wave flagged. It does not silently proceed
 | 
A shopper is in two waves in the same period
 | Currently unowned. Worth raising: opposing arms across waves contaminate both
 | 

Questions for discovery
#
 | Question
 | Why it matters
 | 
1
 | What holdout share, and is it fixed or per campaign?
 | Drives ghost log volume and statistical power together
 | 
2
 | What stratification keys should balance be checked on?
 | Determines what the check can actually detect
 | 
3
 | What retention applies to each artefact?
 | They are needed long after the wave, and storage is not free
 | 
4
 | Does the 2026.1 control-group fix already cover part of this?
 | Should be verified against the code rather than assumed either way
 | 
5
 | Who owns a shopper in opposing arms across two waves?
 | Currently nobody. It contaminates both waves when it happens
 | 


CR-40599 — Personalization UX research
What it is
Establish, from real planners, how the current screens are actually used and worked around. It is the evidence the redesign and the rule-authoring decisions rest on.
The problem today
Every design decision made so far rests on the code, the documentation and reasoning. Not one planner, merchant or analyst has been observed using the product. That is a reasonable position to have started from and an unreasonable one to build from.
What is ready to put in front of someone
Artefact
 | What it tests
 | 
Three rule-authoring designs, wireframed
 | Matrix, rules-as-rows, plain-language list. Which one a planner can actually use
 | 
The eligibility funnel
 | Whether it reads to someone who did not configure the wave
 | 
The current screens
 | What is worked around today, and what lives outside the product
 | 

The question that decides a design
How many rules does a real client actually maintain?
Under ten, a grid is fine and probably preferable. Over fifty, a grid is unusable and the rules-as-rows design is the only viable one.
Nobody currently has that number. It is one question, asked of three clients, and it settles a design decision that would otherwise be argued from taste.
 | 

How to run the sessions
Practice
 | Why
 | 
Ask people to show, not tell
 | A screen share on a real campaign is worth more than any amount of description
 | 
Ask what they can see before asking what they do
 | Field visibility is configured per client. Their screen may not match the reference environment, and contradictory findings are often configuration
 | 
Follow their vocabulary
 | If they say campaign, say campaign. If they say wave, say wave. The mismatch itself is a finding
 | 
Chase every workaround to its cause
 | A spreadsheet is a requirement nobody wrote down
 | 
Ask for the last time something went wrong
 | Specific incidents are reliable. General opinions are not
 | 
Record what they do not mention
 | If nobody raises a gap we consider severe, that is a finding about our priorities
 | 

Every value
Value
 | Behaviour
 | Where it lives
 | Notes
 | 
Findings
 | —
 | Recorded as dated decisions with reasons
 | May change what is built, not only how it looks
 | 
Design changes
 | —
 | Dated amendments to the screen specification
 | The original claim stays visible beside its correction
 | 

Questions for discovery
#
 | Question
 | Why it matters
 | 
1
 | Which clients can we observe, and how soon?
 | External planners are the priority. Internal support staff are the fallback
 | 
2
 | Is a populated non-production environment available?
 | Observing on empty data teaches very little
 | 
3
 | Who owns acting on the findings?
 | Research with no route into the backlog is research nobody reads
 | 


Applies to every epic in this increment
Rule
 | What it means in practice
 | 
Every new field joins the retailer metadata system
 | Visibility, requiredness, label and options configured per client. A field that ignores this cannot be turned off for a client who does not want it
 | 
Every min and max inherits the 127 ceiling
 | It is Byte.MAX_VALUE throughout the wave template DTOs. A new limit inherits it unless a decision changes that. Raise it, do not assume it
 | 
Every rule states what it costs the run
 | Measured at a stated offer volume, not estimated. It finds the problem at ticket time rather than when four rules meet at 10K offers
 | 
Precompute once, look up per pair
 | Anything depending only on offers, coupons or stores belongs once per run. Only the final lookup should scale with shoppers
 | 
A rule with no data removes nobody
 | Never everybody. This is the failure mode that destroys a wave, and it is one line of defensive code
 | 

What to walk away from discovery with
A confirmed one-line purpose for each epic, in the business's words rather than ours.
For every field: carried, calculated, enforced or produced. That is where the estimate comes from.
An answer, or a named owner and date, for each question in the discovery lists above.
Agreement that the exposure record and the measurement prerequisites stay in this increment, with the reason stated.
A production-shaped environment confirmed, or the 10K claim cannot be verified.
The one that cannot move
Measurement prerequisites. Every wave that runs before it exists is permanently unmeasurable.
If it slips out of this increment, that decision should be recorded with its consequence attached, so that nobody in 2027 is surprised to learn the 2026 waves cannot be measured.
 | 


