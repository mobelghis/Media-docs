# 05 — Scope boundary

## This replaces
The allocation of personalised offers to shoppers: eligibility, scoring, constraint satisfaction,
publication, and the measurement of what it caused.

## This does not replace
- Mass promotion planning and its baseline-model reporting.
- The loyalty programme, the app, or the delivery channels themselves.
- Category management, pricing, or assortment systems.
- The client-facing application shell and its authentication.

## Deferred by decision, with the condition that would bring each back
| Deferred | Condition to revisit |
|---|---|
| Natural-language authoring and the semantic catalogue | After the engine is correct and the forms are stable — it is an accelerator, not a foundation |
| Supplier-facing portal and invoicing | A named buyer commitment to co-develop, plus stable ledger identifiers |
| Request-time (real-time) serving | Confirmation that a live channel exists with its own latency requirement |
| Per-offer lift for every offer regardless of power | Never — this is refused by design, not deferred |

---

## Amendment · 2026-08-16 — what Phase 1 does and does not touch

The boundary above describes the programme. Phase 1 is narrower, and the difference matters when
someone reads "this replaces … scoring … and the measurement" and expects it in 2026.4.

**Phase 1 changes**
- The eligibility step: category limits, cross-campaign chilling, blocking, store availability.
- The authoring surfaces for those rules, on the existing Angular screens.
- Run visibility: stage progress and the eligibility funnel.
- The capture of measurement prerequisites (arms, ghost log, frozen snapshot, seed).

**Phase 1 explicitly does not change**
- The scoring model. Affinity stays exactly as it is.
- The greedy assignment algorithm. It gains constraints; it is not rewritten.
- Control-group selection (already corrected in 2026.1), the delivery export contract, or the
  existing reports.
- The front-end framework. Phase 1 is built on Angular regardless of CR-38870's timing.

**Also deferred, and now with a named home rather than a general intention**
| Deferred | Where it lives |
|---|---|
| Combined scoring across categories | CR-38876 — Phase 2, blocked on a method decision |
| Planning and budget forecasts | CR-38877 / CR-38878 — Phase 2, blocked on a response model |
| Supplier budgets and sales-time estimation | CR-38879 — Phase 3, blocked on the money layer and a platform-scope decision |
| Lift measurement framework | CR-38880 — Phase 3, dependent on CR-40346 capturing its inputs from 2026.4 |
