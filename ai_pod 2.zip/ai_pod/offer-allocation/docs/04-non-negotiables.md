# 04 — Non-negotiables

Constraints the build may not violate. Each names its owner so it can be argued with by a person
rather than discovered by a failure. Several are lessons paid for in the proof of concept — see
`06-prior-evidence.md`.

## Correctness and evidence
| # | Constraint | Owner |
|---|---|---|
| N-1 | Accuracy is never traded for speed. Speed is the reward for correctness, not an alternative to it | Product |
| N-2 | A result below its power threshold is reported as underpowered, never as an effect | Data science |
| N-3 | Every number in a report is computed from what it describes, never typed or hardcoded | Engineering |
| N-4 | Infeasible and failed-to-find are distinct verdicts and are never merged | Data science |
| N-5 | A test that would pass on empty or degenerate input is not evidence. Verification includes a deliberately broken case the tests must catch | Engineering |
| N-23 | A rule with no data removes nobody — never everybody. An empty or unavailable input makes a rule a no-op, not a total exclusion | Engineering |

## Reproducibility
| # | Constraint | Owner |
|---|---|---|
| N-6 | Every wave freezes offer versions, eligibility, parameters and seed before it runs | Engineering |
| N-7 | Anything that affects an allocation is immutable once used by one | Engineering |
| N-8 | Freshness is judged by content, not by metadata. A cached or resumed computation proves its inputs match | Engineering |

## Money and commitments
| # | Constraint | Owner |
|---|---|---|
| N-9 | Minimums are counted in issued coupons unless a contract says otherwise, stated per pool | Commercial |
| N-10 | Cost model belongs to the funding pool and is never overridable per offer | Finance |
| N-11 | Test and control arms never consume budget | Finance |
| N-12 | Money records are append-only and carry their fiscal period | Finance |

## Measurement
| # | Constraint | Owner |
|---|---|---|
| N-13 | The outcome measured is purchase of the offer's product set, never redemption | Data science |
| N-14 | Randomisation is implemented separately from stratification and never shares code with it | Data science |
| N-15 | The four wave-one irreversibles ship before the first production wave | Product |
| N-24 | Absence of an exposure record means *not exposed*. It never means *deliberately held out*. The two are represented separately and never inferred from each other | Data science |
| N-25 | If a measurement artefact cannot be written, publication fails loudly. Publishing a wave without its artefacts is worse than not publishing it | Engineering |

## Platform
| # | Constraint | Owner |
|---|---|---|
| N-16 | Client data is isolated per client; configuration is per client by default | Engineering |
| N-17 | Services exchange references and control, never bulk data | Engineering |
| N-18 | No language model sits in the scoring or allocation path | Architecture |
| N-19 | A model or service never receives shopper-level data it does not need; metadata suffices where it suffices | Security |
| N-26 | No computation that depends only on offers, coupons or stores may scale with shopper count. Precompute once per run; only the final lookup scales per pair | Engineering |

## Process
| # | Constraint | Owner |
|---|---|---|
| N-20 | A decision without a stated reason is not landed | Pod |
| N-21 | Conflicts with a landed decision stop work and surface; nothing is guessed past a gate | Pod |
| N-22 | A defect class that recurs becomes a mechanism — fixed once, in the tooling | Pod |
| N-27 | Every rule states what it costs the run, **measured** at a stated offer volume, never estimated. A cost measured on a synthetic catalogue is not accepted — even category distribution understates the assignment loop | Engineering |

---

## Amendment · 2026-08-31 — five constraints from the 2026.4 discovery pack

`docs/sources/2026-08-26-discovery-pack-2026Q4.docx` closes with five rules stated as applying to
every epic in the increment, and carries two more inside individual epic bodies. Five were promoted
here; two were not.

**Promoted.** N-23 (a rule with no data removes nobody) is the strongest of them: an empty exposure
table makes a rest rule remove *everybody*, so the wave does not error — it "succeeds" with zero
allocations. The pack states it twice as an edge case and calls it "the worst possible failure."
Note it is **not** a duplicate of N-5: N-5 governs test fixtures, N-23 governs runtime behaviour.

N-24 sits beside N-14 because both protect the control group from contamination that passes casual
inspection. N-25 closes a gap in N-15, which requires the irreversibles to *ship* but says nothing
about a write failing at runtime — a wave could ship with ghost logging built and silently not
write it, producing exactly the unmeasurable wave N-15 exists to prevent.

N-26 is the pack's "precompute once, look up per pair" promoted as its **measurable consequence**
rather than as a technique. The technique is doctrine in the performance-budgets skill; what belongs
here is the property you can test — run at two shopper volumes and check the precomputable portion
is flat. A rule where precompute genuinely does not apply now needs a recorded decision rather than
a silent exception.

N-27 is a process constraint on tickets, not a runtime property, so it sits with N-20–N-22. Its
synthetic-catalogue clause is load-bearing: without it the rule is satisfiable with a meaningless
number.

**Not promoted, and why.**

| Rule from the pack | Why it is not here |
|---|---|
| Every new field joins the retailer metadata system (`fromMetaData.<field>`) | Genuinely constraint-shaped and already recorded in `docs/08` and D-8's consequences. Held for its own ruling rather than riding along in a measurement-and-correctness batch |
| Every min/max inherits the 127 (`Byte.MAX_VALUE`) ceiling | **Blocked by Q-20**, which asks whether the ceiling stays or changes. Writing it in while that question is open would be guessing past a gate, which N-21 forbids |
