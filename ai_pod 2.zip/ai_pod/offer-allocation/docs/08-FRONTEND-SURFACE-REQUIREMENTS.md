# 08 — Front-end surface requirements

Where the ten requirements land in the interface: which existing screen changes, which fields
appear, and which surfaces do not exist yet. **This states WHERE and WHAT, deliberately not HOW.**
Layout, interaction and component choices belong to design and the FE team.

Legacy screen names are used so the mapping is checkable against the current product. A field
marked **[NEW]** does not exist today; **[FIXED]** exists but is wrong or unusable as-is.

---

## A · Marketing policy / wave template editor
*The screen that defines the rules a wave runs under. Most of the ten requirements land here,
because most of them are rules.*

| Requirement | Fields / sections to add | Notes for the FE team |
|---|---|---|
| R-2 category limits | **[NEW]** repeatable rule rows: hierarchy → level → max per shopper per wave; AND/OR grouping between rows; virtual hierarchies selectable alongside standard levels | Today's cap fields are fixed-level and cannot express this. Needs an editor for a *list* of rules, not a set of numeric inputs |
| R-4 do-not-repeat / chilling | **[FIXED]** rest-period rows gain: hierarchy level, window length, and **scope = this campaign / all campaigns / all incentive types** | The cross-campaign scope is the new part and the reason the ledger exists |
| R-5 blocking & exclusions | **[NEW]** its own section: item-level vs category-level blocking, within- and cross-campaign, plus the precedence statement shown on screen (**exclude always wins**) | Currently implicit inside rest rules; needs to be authored explicitly |
| R-8 budget caps | **[NEW]** per-pool cap, alert thresholds, hard-stop toggle, fiscal period | Money fields do not exist anywhere in the current UI |
| R-10 measurement | **[NEW]** control/holdout percentage, arm design (standing holdout, staggered), and the power note that answers back as the number changes | Today a control % exists but its meaning is not what measurement requires |
| Cross-cutting | **[NEW]** version list with published/draft state, a diff between versions, and a **dry-run against the last wave** before publishing | The single highest-value addition on this screen: see the consequence before shipping the rule |

## B · Offer / coupon authoring
| Requirement | Fields to add | Notes |
|---|---|---|
| R-6 multi-brand/multi-SKU | **[FIXED]** product-set builder that takes includes AND excludes at different hierarchy levels ("all of X except Y") | Free-text or single-level selection is where mis-scoped offers come from |
| R-6 reach guard | **[NEW]** live **estimated reach** on the offer form, with a refusal or warning when it exceeds the configured share | Must appear at authoring time, not at wave time |
| R-3 availability | **[NEW]** ranged-store coverage for the product set, with a warning when coverage is thin | Answers "why did my offer reach so few?" before it is asked |
| R-8 funding | **[NEW]** funding source / pool, supplier, and the pool's cost model shown read-only | Cost model is a property of the pool — display it, never let it be edited here |
| R-1/R-7 | **[NEW]** exact eligible count and estimated cost, recomputed as the offer is edited | Exact for counts, interval for estimates — the distinction must be visible |

## C · Audience / targeting
| Requirement | Fields to add | Notes |
|---|---|---|
| R-7b | **[NEW]** audience builder returning an **exact** count, not a sample | The count is the number planners argue about; it must be correct |
| R-5 | **[NEW]** a named list can be attached as **include or exclude** | Suppression lists are the common real request |
| R-7 | **[FIXED]** named, reusable, versioned lists (replacing one-list-per-offer replace-on-upload), with an upload **match-coverage report**: matched, unmatched, downloadable | Uploading and silently losing 4% of a list is a current failure mode |
| R-B | **[NEW]** an indication that membership freezes at wave freeze | Users must understand why the number can move before freeze and not after |

## D · Wave / campaign screens
| Requirement | Fields to add | Notes |
|---|---|---|
| R-1 | **[NEW]** stage-level progress with an estimate derived from history, and a failure state naming the stage | Replaces "started / done" with something a planner can act on |
| R-E feasibility | **[NEW]** a pre-run verdict: feasible, or infeasible with the conflicting commitments named | Must be reachable *before* the wave runs |
| R-D explain | **[NEW]** the funnel: eligible → filtered by each named rule family → allocated, with counts at every step and a link from each step to the rule that caused it | The single most requested answer in the business today |
| R-10 | **[NEW]** arm summary for the wave: holdout size, ghost-logging confirmation, seed | Proof the wave is measurable, visible on the wave itself |
| R-7 | **[NEW]** scenarios: save, compare side by side, promote one to the wave | Requires scenarios to have identity, not just be a preview |

## E · Reporting and measurement
| Requirement | Fields to add | Notes |
|---|---|---|
| R-10 | **[FIXED]** results carry confidence intervals and a **power state**; underpowered lines render as underpowered rather than as effects | Non-negotiable: colouring noise is how credibility is lost |
| R-10 halo/cannibalisation | **[NEW]** decomposition: direct effect, halo, cannibalisation, pull-forward, net | One design, several outcome windows — all from the same arms |
| R-8/R-9 | **[NEW]** commitment progress per supplier: issued vs floor, spend vs cap, pace against period | Finance's screen; does not exist today |
| R-D | **[NEW]** every number opens to its basis — the wave, the arm, the frozen inputs | Provenance as a navigation property, not a footnote |
| R-9 | **[NEW]** a sales-time view: proposed commitment → feasibility + estimated cost with its interval | Used before signature, so it must be reachable outside the wave flow |

## F · Surfaces that do not exist today
| Surface | Why it is needed | Requirement |
|---|---|---|
| Jobs & runs list | Every long-running action needs a home with progress and history | R-1, R-G |
| Data health | Ingest freshness, restatements, coverage — visible to users | R-G |
| Commitments & funding | Pools, ledger, pacing, alerts | R-8, R-9 |
| Approvals queue | Review before a wave or offer ships, with what changed | R-B, governance |
| Audit log | Who changed what, when, and what it was before | R-B |

---

## Rules that apply across all of the above

1. **Exact vs estimated must be visibly different.** Counts are exact; response, cost and lift
   are estimates and always carry their interval. A user must never have to guess which they are
   looking at.
2. **Every number opens.** Any figure a user can see should be traceable to what produced it.
3. **A refusal states its reason.** When the system will not do something — reach too broad,
   configuration infeasible, evidence too thin — it says which rule and with what numbers.
4. **Nothing that spends money commits without an explicit human action** on a screen showing
   what will happen.
5. **Anything above ~10 items is a table**, sortable and exportable; every chart has a table twin.
6. **Grey means "not enough evidence"** and is reserved for that meaning alone.

## For the FE team to decide
Layout and navigation; whether policy rules are one editor or several; how the funnel is
visualised; the component library; how scenarios are compared; progressive disclosure for the
simple case. **What is not open:** which fields exist, which are exact vs estimated, and the six
rules above.

---

## Amendment · 2026-08-16 — written before the code was read — three sections now extend what exists

This document was written before the front-end recreation guide was reviewed. Its *content* stands
— the fields are still the fields — but three sections proposed building something new where
something already exists (D-8). The corrections:

| Section | As written | Corrected |
|---|---|---|
| Category limits | "a rule builder in the policy editor" | Add **Category as a constraint type in the existing Segment Strategy model** — tabs by type, collapsible panels per value, min/max rows per segment. Not a new builder |
| Rest / chilling | "rest-period rows gain a scope field" | Extend the **two Frequency Criteria fields** that already exist on Campaign Strategy, and fix their tooltip binding, which references an undefined variable and renders empty |
| Product sets | "a product-set builder" | **Extend the existing picker**, which already filters by CPG, brand and category with select-all and CSV import. The genuinely new interaction is **excludes** |

Two constraints inherited from the existing screens, which apply to every field this document adds:

1. **The forms are retailer-metadata-driven.** Every field's visibility, requiredness, label and
   options come from configuration (`fromMetaData.<field>`). A new field that does not join that
   system cannot be turned on and off per retailer like everything else on the screen.
2. **Every min/max is capped at 127** (`Byte.MAX_VALUE`) in the wave-template DTOs. New limits
   inherit that ceiling unless a decision is taken to change it — raise it rather than assume it.

Virtual categories already exist as a coupon type behind `VIEW_COUPON_VIRTUAL_CATEGORY`, and are
the same concept the category-limit requirement needs.

The full design treatment — the minimum for the current Angular app, and three options for the
redesign — is `docs/21-design-current-and-redesign.md`.
