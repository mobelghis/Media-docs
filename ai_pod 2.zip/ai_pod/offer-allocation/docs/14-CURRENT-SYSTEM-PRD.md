# 14 — The current system: how it works today, and what these changes touch

A product-level description of the existing system — the flows, the entities, the boundaries —
followed by an impact map of the ten requirements against it. This is the document that lets a
newcomer reason about consequences without reading the code, and it is what the design and
architecture work is done *against*.

> **Provenance.** Assembled from the legacy discovery work. Where a statement is inferred rather
> than confirmed it is marked **[verify]**. Regenerate the traced sections rather than hand-editing
> them, and stamp the commit they were traced against.

---

## 1. The entity model today

```mermaid
graph TD
  CB[Coupon bank<br/>folder + whitelist scope] --> C[Coupon<br/>the deal + product set]
  MP[Marketing policy<br/>caps · chilling · control % · whitelists] --> W[Wave<br/>one execution]
  C --> O[Offer<br/>coupon placed in a wave + targeting]
  W --> O
  O --> A[Allocation<br/>one shopper × one offer]
  AUD[Audience / targeting<br/>lists · segments · objective] --> O
  A --> EXP[Export to delivery channel<br/>coupon-grain]
  A --> RPT[Reporting<br/>issuance · redemption]
```

**Read it as:** the wave is the centre of gravity. Rules arrive from the policy, deals from the
bank, targeting from the audience — and everything that actually happened is an allocation row.

## 2. The wave lifecycle

```mermaid
graph LR
  D[Draft] --> S[Offers attached<br/>from whitelisted banks]
  S --> E[Eligibility computed<br/>per offer]
  E --> SC[Scoring<br/>shopper × offer]
  SC --> AL[Allocation<br/>greedy, per-shopper limits]
  AL --> CT[Control group taken<br/>from allocated set]
  CT --> AP[Approved]
  AP --> P[Published to channel]
  P --> R[Redemption + reporting]
```

**Where the value leaks, marked against the defect catalogue:**
- between *Allocation* and *Control group* — the control is carved out of the allocated set
  **after** the fact, which biases every comparison (D-04, D-05)
- inside *Allocation* — greedy filling discovers shortfalls at the end, missing minimums that were
  satisfiable (D-01, D-02)
- inside *Eligibility* — rules that cannot be expressed are approximated or bypassed (D-07, D-14)
- at *Published* — the export drops offer identity, so attribution past the boundary is lost (D-12)
- around the whole run — no progress, no estimate, no alert (D-15); no seed, so no re-run (D-03)

## 3. Data and boundaries

| Boundary | What crosses it | Consequence for the rebuild |
|---|---|---|
| Analytical store → allocation | shopper history, product hierarchy, ranging | read-only; grain of ranging is a known problem (D-09) |
| Allocation → delivery channel | coupon-grain export, offer identity dropped | anything needing offer identity must be captured before this line (R-10, R-D) |
| Delivery → redemption feed | redemption events | landing location and latency are an open question (Q-3) |
| Configuration → run | policy, banks, audiences, min/max | frequently null in practice (D-11) |
| Money | *nothing* — no tables exist | must be built from zero (R-8, R-9) |

## 4. What exists and works, and must not be lost
Coupon banks with bulk upload and images · per-shopper targeting by list, segment and objective ·
chilling logic (limited scope) · publication and delivery export · issuance and redemption
reporting at coupon grain · the client application shell, authentication and permissions.

*(These are the parity-ledger rows: each must be carried, carried-and-fixed, or retired with a
reason.)*

---

## 5. Impact map — what each requirement touches

| # | Requirement | Data | Method | Service / API | Front end | Risk to existing behaviour |
|---|---|---|---|---|---|---|
| R-1 | Run window and progress | job records | — | job status + progress | jobs list, wave header | low — additive |
| R-2 | Category limits | policy rule rows | constraint formulation | policy read + allocator | policy editor (rule builder) | **medium** — changes what the allocator honours |
| R-3 | Store availability | ranging at correct grain | eligibility | eligibility service | offer form coverage warning | **medium** — reduces reach where it was previously wrong |
| R-4 | Cross-campaign rest | exposure ledger | rest logic | eligibility | policy editor scope field, funnel | **high** — a shopper's eligibility changes across campaigns |
| R-5 | Blocking & exclusions | exclusion sets | precedence | eligibility | policy section, audience flag | medium |
| R-6 | Multi-brand / multi-SKU | frozen product sets | reach estimate | resolver + guard | offer builder, reach guard | medium — some existing offers may now be refused |
| R-7 | Estimation and planning | scenario storage | counts + response model | scenario endpoints | scenario workspace | low — new surface |
| R-8 | Budget caps | **new** pools + ledger | cost model, duals | ledger + allocator | commitments screens | **high** — new obligations enforced at run time |
| R-9 | Sales-time estimation | commitments | pricing from duals | estimate endpoint | sales-time view | low — new surface |
| R-10 | Lift measurement | arms, ghost log, snapshots | estimand + power | measurement endpoints | measurement suite | **high** — replaces how results are produced and read |

**Highest-risk changes, and why:** R-4 and R-8 change what a wave is *allowed* to do, so existing
configurations may behave differently on day one; R-10 changes what the numbers mean, so anyone
comparing to historical reports needs the transition explained rather than discovered.

## 6. What the rebuild must preserve regardless
- The delivery contract to the channel — byte-comparable output, so downstream systems cannot tell
  the difference in shape (only in content quality).
- Existing permissions and tenancy behaviour.
- The vocabulary users already have. New concepts are added; existing words keep their meaning.

## 7. Open items that block full confidence in this document
Q-3 redemption landing · Q-4 a populated environment to verify traces against · Q-5 how audiences
are shared with the segmentation tool. Until these close, sections marked **[verify]** stay marked.

---

## Amendment · 2026-08-16 — two corrections from reading the code and the product documentation

**1 · Campaign is a label, not an entity (D-3).** The entity model and the diagrams above show a
campaign record. There is none: campaign is the front-end name for the wave. Where several waves
must relate to each other, a `series_id` on the wave serves that purpose.

**2 · The marketing policy screen, as it actually is.** The front-end recreation guide gives the
real structure, which matters because most of Phase 1 lands here:

- **General** — name, description, coupon bank (single-select), eligibility segment, campaign
  control %, number of control offers, offer-control and default-offer toggles, delivery channels.
- **Campaign Strategy** — coupons per shopper (min/max, required), per brand, per in-house brand;
  and **Frequency Criteria** — an allocations threshold and a period in days. That is chilling today.
- **Segment Strategy** — tabs by constraint **type** (coupon quality, marketing objective, promotion
  type, coupon mode), each holding collapsible panels per constraint value, each panel holding a
  min/max row per segment.

That third section is already a generic `type × value × segment → min/max` model, which is why
category limits extend it rather than replacing it (D-8). Every min/max in it is capped at 127.

**3 · From the product documentation.** Eight marketing objectives exist (win-back, retention,
cross-sell, category stretch, category cross-sell, filler, offer control, campaign control), and
**each selects its own targeting and scoring algorithm** — so "the model" is several models chosen
by objective. Offer control and campaign control being objectives is also why control-group
selection sits inside the allocation path.

---

## Amendment · 2026-08-31 — what the 2026.4 discovery pack states about today's behaviour

From `docs/sources/2026-08-26-discovery-pack-2026Q4.docx`. Marked **[verify]** where the pack
asserts behaviour that has not been traced to code under this programme, per this document's own
provenance rule. Several items corroborate what the front-end recreation guide already showed
(2026-08-16 amendment), and are noted as such rather than as new findings.

| # | Statement about today | Status |
|---|---|---|
| 1 | Chilling today is two fields under **Campaign Strategy** — an allocations threshold and a period in days — applying to the current campaign only, and matching on the **offer identifier** rather than on products | **Corroborates** the 2026-08-16 amendment. The offer-identifier matching is the sharper detail, and is why a shopper can receive effectively the same promotion twice from two campaigns with both rules reporting satisfied |
| 2 | The tooltips on those two Frequency Criteria fields are bound to a scope variable that does not exist, so they render empty in production and have done for some time | **Corroborates** `docs/08`. Small, in the same file as CR-38874's work |
| 3 | Blocking does not exist in any form; two coupons covering substantially the same products are invisible to each other | **Confirms** closed question Q-9 |
| 4 | Each campaign knows only about itself — there is no cross-campaign view of what a shopper has received | **[verify]** — consistent with D-08 in the defect catalogue, not independently traced |
| 5 | Today's answer to a coupon bank larger than the allocation can process is to run fewer offers, which means either fewer suppliers funded or fewer shoppers reached | **[verify]** — an operational workaround, stated by the pack, not traced |
| 6 | The current offer ceiling is not known as a measured number | **[verify]** — and now Q-28. The 10K target has no stated baseline |
| 7 | Delivery export and the run give no stage-level progress; a failure is discovered by absence | **Corroborates** D-15 |

### One statement that is not about the system

The pack records that **no planner, merchant or analyst has been observed using the product** —
every design decision so far rests on the code, the documentation and reasoning. That is a fact
about the pod's evidence base rather than about the system, and it is the entire justification for
CR-40599. It is recorded here because anyone reading this document to "reason about consequences
without reading the code" should know the limit of what it rests on.

### The question the pack says decides a design

**How many rules does a real client actually maintain?** Under ten, a grid is workable and probably
preferable; over fifty, a grid is unusable and rules-as-rows is the only viable design. Nobody
currently has that number, and it settles a decision in `docs/21` that would otherwise be argued
from taste. It is one question asked of three clients — carried as part of Q-44.
