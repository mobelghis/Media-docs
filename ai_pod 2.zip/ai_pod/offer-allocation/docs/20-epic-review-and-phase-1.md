# 18 — Epic review, and the Phase 1 scope

Two parts. **Part A** reviews every epic currently under the Personalization parent, says what it
actually requires, and flags what the ticket does not say. **Part B** proposes Phase 1 on the
premise you set: **fix the current system, do not rebuild it.**

---

# Part A · The epics as they stand

## The three layers, so the review makes sense
A wave runs through three stages, and every epic below sits in one of them:

| Layer | Question it answers | Epics |
|---|---|---|
| **Eligibility** | Who *may* receive this offer? | limits, chilling, blocking, availability |
| **Scoring** | Of the allowed pairs, which matter? | multi-brand scoring, planning forecasts |
| **Allocation** | Given the constraints, who *gets* what? | capacity, budgets, control groups |

Measurement sits after publication and is out of scope for now, as agreed.

---

## CR-38871 · Support Large-Scale Offer Allocation Capacity — 2026.4, PI 1.1
**What it says.** 10,000 offers single-currency, 20,000 dual-currency, 15M+ shoppers, allocation
completing inside 24 hours, weekly cycles, stable under peak load.

**What it actually requires.** This is not a tuning exercise. At 20,000 offers × 15M shoppers the
naive candidate space is 300 billion pairs; the work is *not scoring more*, it is **not scoring
what cannot win** — pruning candidates before they are ever scored, and materialising only what
the allocator needs. It also forces the run to become observable: a 24-hour target is
unmanageable without stage-level progress and an honest estimate.

**Flags.**
- The epic has no acceptance criterion for *visibility*, only for completion. A run that finishes
  in 23 hours with no progress reporting satisfies this epic and fails the operator.
- "Existing policy constraints continue to function correctly" quietly makes this epic depend on
  every constraint epic below — whichever ships first sets the shape the others must fit.
- Nothing states what happens when it *cannot* finish: partial results, or fail cleanly?

**Maps to** priority 1. **Layer:** allocation, with heavy eligibility implications.

---

## CR-38872 · Offer Limits by Category — 2026.4, PI 1.4
**What it says.** Configurable maximum offers per hierarchy level (L1–L4), departments, categories,
sub-categories and retailer-defined *virtual* categories; multiple constraints in one policy;
AND/OR logic; enforced during allocation; configured per allocation, campaign, template or policy.

**What it actually requires.** Three separable pieces that the ticket treats as one: (a) a **rule
model** that can express limits over arbitrary hierarchy nodes and virtual groupings, (b) a
**policy editor** to author them, and (c) **enforcement inside the allocator** rather than as a
post-filter. Point (c) is the hard one: a limit applied after allocation throws away work and can
leave slots unfilled; applied inside, it changes which candidate wins each slot.

**Flags.**
- **Virtual categories** are a new first-class concept — retailer-defined groupings that live
  outside the product hierarchy. Nothing says who maintains them, or where they are stored.
- "AND/OR logic across category rules" is under-specified. `Fresh Food AND Organic` is an
  intersection of sets; `Snacks OR Confectionery` is a union. Both are expressible, but the editor
  and the evaluation order need defining or every retailer will read it differently.
- No statement of what happens when limits conflict with per-offer minimums — the classic case
  where a floor cannot be met without breaching a cap. That is a decision, not an implementation
  detail.

**Maps to** priority 2. **Layer:** eligibility rule, allocation enforcement.

---

## CR-38874 · Global Do Not Repeat (DNR) and Chilling Rules — 2026.4, PI 1.2
**What it says.** Extend DNR and chilling beyond campaign scope: across campaigns, across incentive
types (points vs discount vs retail media), evaluated on **overlapping products** rather than exact
offer IDs. Configurable chilling periods; product, category and brand overlap evaluation.

**What it actually requires.** A single **cross-campaign exposure record** — what each shopper was
exposed to, when, at what product grain, from which campaign type. Without it, "across campaigns"
is not implementable at all; with it, the rule itself is straightforward. This is the epic that
silently creates a new foundational data structure.

**Flags.**
- The exposure record is not mentioned anywhere in the epic. It is the whole job.
- "Overlap evaluation" needs a definition: is a coupon covering *any* of the same SKUs a repeat, or
  does it need a threshold? (CR-38875's comment answers this for blocking with an X% parameter —
  the two epics should share one definition, or they will diverge.)
- Retail media offers are named as a blocking source, which means exposure must be recorded for
  campaigns that this system does not run.

**Maps to** priority 4. **Layer:** eligibility.

---

## CR-38875 · Advanced Coupon Blocking — 2026.4, PI 1.3
**What it says.** Configurable blocking between item, category, brand and cross-campaign coupons;
within and across campaigns; enforced during allocation so the shopper receives only the
highest-priority offer; outcomes auditable.

**What Ran's comment adds, and it is a significant enlargement.**
- Blocking should be **automatic on product overlap**, not only manually configured pairs: any two
  coupons overlapping by more than **X%** of products within an overlapping time window block each
  other. X and the window are **parameters with defaults**.
- Blocking belongs at **coupon level, not offer level** — because at 10,000+ offers the same coupon
  appears in many offers with different audiences and incentives.
- It must run **across campaigns and marketing policies simultaneously**.
- A **preview tool** is needed — "what blocked what" — runnable **before** allocation, because the
  outcome is hard to foresee.
- Possible whitelisting of a specific block; he is unsure it is realistic.

**What it actually requires.** Overlap computation between product sets at scale (this is a set
intersection over potentially thousands of coupons — cheap if precomputed, expensive if naive), a
priority model for deciding the winner, and the preview surface. It shares the overlap definition
and the exposure record with CR-38874.

**Flags.**
- Priority is assumed but never defined: when two coupons block each other, what decides the
  winner — offer priority, must-get status, funding, score?
- "Auditable" needs a home: the funnel, or a dedicated blocking report.
- The preview tool is a **product surface** nobody has estimated.

**Maps to** priority 5. **Layer:** eligibility.

---

## CR-38873 · Store Availability-Based Offer Allocation — 2027.1, PI 1.7
**What it says.** Availability at the shopper's preferred store must gate eligibility; availability
via retailer feed; preferred store either supplied weekly by the client or calculated by NIQ;
allocation must still complete within performance requirements.

**What it actually requires.** Two data problems before any logic: **ingesting item × store
availability** at a usable freshness, and **establishing a preferred store per shopper** (with a
rule for shoppers who have none, or several). The filter itself is simple.

**Flags.**
- "Calculated by NIQ" is a methodology decision hiding in a bullet — it needs a definition and an
  owner.
- Availability data is the one place our own record disagrees with the epic: we found the data
  exists at the **wrong grain** for this constraint. That should be verified before this is sized.
- Interaction with reach: a broad offer minus unavailable stores can drop below its minimum. Not
  mentioned.

**Maps to** priority 3. **Layer:** eligibility.

---

## CR-38876 · Multi-Brand / Multi-SKU Coupons — 2027.1, PI 1.6
**What it says.** Coupons spanning brands, categories and hierarchy branches; dynamic category
definitions so new products are included automatically; **score calculation across the combined
product set at allocation runtime**; no manual SKU list maintenance.

**What it actually requires.** Two very different things bolted together:
1. **Authoring** — a product-set builder with includes and excludes across hierarchies, and dynamic
   groups that re-resolve as the catalogue changes. This is UI plus a resolver.
2. **Scoring across a combined set at runtime** — a genuine scoring-layer change. Today relevance
   is computed against a single node; a coupon spanning Nescafé, Lindt and Kellogg's needs a
   combined propensity, computed while the allocation runs.

**Flags.**
- These two halves have completely different risk. The authoring half is a fix; the scoring half is
  a methodology question (how do you combine affinity across unrelated categories — max? weighted
  sum? something else?) that data science must answer.
- "Dynamic category definition" conflicts with reproducibility: if a set re-resolves after a wave
  runs, that wave can no longer be explained. It must freeze at wave freeze.
- **CR-39714 is the authoring half on its own** (see below) — which is exactly the right split.

**Maps to** priority 6. **Layer:** authoring + scoring.

---

## CR-39714 · Improved Multi-Brand / SKU Coupon Creation — 2026.4, PI 1.3
**What it says.** The UI must support SKU-based coupons spanning brands and categories, without
maintaining manual SKU lists.

**What it is.** The **authoring half of CR-38876, without the runtime scoring change** — the
fixable part, deliverable against the current engine. This is the right shape for Phase 1.

**Flags.**
- Its `Epic Name` field still reads "Advanced Coupon Blocking" — a clone artifact. It will confuse
  every report until corrected.
- The relationship to CR-38876 is not stated in either ticket. One supersedes half of the other.
- "Without manual SKU lists" implies dynamic groups, which implies the freeze question above.

---

## CR-38877 · Campaign Planning & Budget Estimation (System-Guided) — 2026.4, PI 1.9
**What it says.** Products-first planning: user picks products, incentive type and objective; the
system recommends a budget range, estimates audience size, forecasts response and redemption,
breaks down targeting/incentive/total cost, supports scenarios and an approval workflow.

**What it actually requires.** A **response model** and a **cost model**, neither of which exists.
Audience size is countable today; "expected response rate" and "recommended budget to achieve an
outcome" are forecasts that need a method, historical training data, and a stated uncertainty.

**Flags.**
- The epic reads as a UI workflow but is 80% data science. Estimated with only a UI mindset it will
  be wrong by an order of magnitude.
- No mention of intervals. A recommended budget with no uncertainty attached will be treated as a
  promise the first time it is wrong.

**Maps to** priority 7a. **Layer:** scoring/allocation forecast + new surface.

---

## CR-38878 · Campaign Planning & Budget Estimation (Audience Builder) — 2026.4, PI 1.8
**What it says.** The same, entering from the audience side: define the audience in Audience
Builder, get budget, KPI forecasts, cost forecasts, scenario analysis, approval.

**What it actually requires.** The same forecasting engine as 38877 with a different entry point,
plus **exact audience counts** returned interactively.

**Flags.**
- 38877 and 38878 are one capability with two doors. Building them as separate epics risks two
  estimators that disagree — the same number reached two ways.
- Integration with Audience Builder raises the live-reference question: is a Studio audience
  referenced or copied at wave freeze? Unanswered in our record too.

**Maps to** priority 7b.

---

## CR-38879 · Supplier Budget Capping & Compliance — 2026.4, PI 2
**What it says.** Annual supplier budget caps across *all* campaign types; consumption tracking;
visibility into total/consumed/remaining/committed/forecast; **blocking approval when a cap would
be exceeded**; threshold alerts at 80/90/100%; adjustments with an audit trail; dashboards.

**What it actually requires.** A **money ledger that does not exist today** — commitments, spend
events, fiscal periods — plus enforcement at approval time and a forecasting view. The examples in
the ticket are unusually good and should survive into the specs.

**Flags.**
- "Across all personalization, loyalty, promotion and retail media campaigns" makes this a
  **platform-level** capability, not a personalization one. That is a scope decision with an owner
  outside this pod.
- Enforcement point is stated as campaign approval; our design also enforces inside allocation.
  Both are needed — approval blocks the obvious case, allocation prevents the drift.
- Committed vs consumed vs forecast requires a definition of "committed" that finance agrees with.

**Maps to** priorities 8 and 9. **Layer:** allocation + new money layer.

---

## CR-38880 · Advanced Lift Measurement Framework — 2027.3, PI 1.5
**What it says.** Lift per offer and for the total programme including halo; net vs gross
configurable; aggregation without double-counting across catalogue levels and time frames;
attribution by brand for multi-vendor mechanics; results within one week of campaign end; with or
without control groups.

**Flags.** Set aside by your decision, but two things are worth recording now because they are
irreversible:
- "**With or without control groups**" is the crux. Without randomised holdouts, lift is a modelled
  estimate, not a measurement — and the modelling assumptions must be stated.
- Whatever this framework needs from a wave (arms, ghost logs, snapshots) **must be captured while
  the wave runs**. If Phase 1 ships without them, waves executed in 2026 can never be measured this
  way retrospectively.

---

## CR-40313 · Redesigned constraint enforcement — Draft, no PI
**What it is.** Your own follow-on epic: once the engine is redesigned, limits, chilling and
blocking should be enforced **by the engine itself**, with the numbers behind each coming from the
engine's own calculation — rather than bolted on.

**Read it as the Phase 2 marker.** It correctly states the dependency ("only makes sense once the
new engine exists"), which makes Phase 1's job clear: deliver these capabilities against the
current engine, in a way that does not have to be thrown away.

---

## CR-39888 · Pay-per-Allocation billing — Draft
**What it says.** Three pricing tiers per coupon/offer; per-client, per-month allocation prices;
monthly charge = Σ (allocations per tier × tier price); a parallel export to the financial system
when an allocation is approved and sent.

**What it actually requires.** A new **offer attribute** (pricing tier), a **contract price source**
(MSD/SAP), and an **export at approval time** with counts by tier. Small, but it touches the
publication path — the same seam as delivery.

**Flags.**
- This is revenue-side and outside the ten priorities; it competes for the same publication seam.
- Needs a definition of a billable allocation: issued? approved? delivered? Not stated.

---

## CR-39882 / CR-39883 · Unlimitail retail media measurement report (BE+FE / Data)
Retail Media module, client-committed for 2026.4, with a hard data dependency between them.
**Not part of the personalization engine** — noted here only so nobody counts them in Phase 1
capacity. They do compete for the same reporting and data people.

---

## CR-31111 / CR-30454 · Control group selection logic — **Done**
The control group was biased (selected in a way that did not mirror the shopper population). DS
produced a corrected selection and engineering implemented it; a factoring step corrects residual
bias in the performance report. CR-32167, the follow-on to close remaining gaps, is **cancelled**.

**Why this matters now.** Our defect catalogue lists biased control selection as D-04. These epics
suggest it is **partly remediated** — which changes how much of the measurement problem is left.
It should be verified against the current code rather than assumed, in either direction.

---

# Part B · Phase 1 — fix the current system

## The premise
No engine rebuild. Every Phase 1 epic must be deliverable **against the current allocation engine**,
must not require new methodology, and must not have to be thrown away when the engine is redesigned
(CR-40313). Where a capability has a "hard half" that needs new science, Phase 1 takes the half that
does not — as CR-39714 already does for multi-SKU.

## What Phase 1 contains

| # | Epic | Source | Why it is in Phase 1 |
|---|---|---|---|
| **P1-0** | Exposure record (foundation) | *new — implied by CR-38874/38875* | Both DNR and blocking need it; neither is possible without it, and it cannot be backfilled |
| **P1-1** | Scale and runtime capacity | CR-38871 | Everything else must run inside the same window; and it is the epic that makes the others visible |
| **P1-2** | Category limits | CR-38872 | Pure rule capability; no new science |
| **P1-3** | Global DNR and chilling | CR-38874 | Rule capability on top of P1-0 |
| **P1-4** | Coupon blocking, overlap-driven | CR-38875 | Rule capability on top of P1-0; shares the overlap definition with P1-3 |
| **P1-5** | Multi-brand / multi-SKU **authoring** | CR-39714 | The authoring half only — no runtime scoring change |
| **P1-6** | Constraint transparency (funnel + blocking preview) | *new — Ran's request in CR-38875* | Without it, four new rule types silently remove shoppers and nobody can explain a number |

## What is deliberately not in Phase 1, and why
- **Store availability (CR-38873)** — blocked on a data question (grain, preferred store definition)
  that must be answered before it can be sized. Phase 1 can prepare the eligibility hook.
- **Planning and budget estimation (CR-38877/38878)** — needs a response model and a cost model.
  This is Phase 2 science, not a fix.
- **Supplier budget capping (CR-38879)** — needs the money layer and a platform-scope decision.
- **Multi-SKU runtime scoring (CR-38876)** — the scoring half; needs a combined-affinity method.
- **Measurement (CR-38880)** — set aside, with the irreversible caveat recorded.
- **Billing (CR-39888)** and **retail media reports (CR-39882/3)** — different value streams.

## The shape of a Phase 1 epic
Each epic below is specified to the depth of the existing ones, and adds what they lack: the
per-discipline breakdown. Every epic carries **Business value · Description & purpose · Scope ·
Examples · Acceptance criteria**, then **Data science · Data · Back end · Front end · Design** work,
then **dependencies** and **open questions with owners**.

*(The full epic specifications follow in `19-PHASE-1-EPICS.md`.)*
