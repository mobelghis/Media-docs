# 13 — Personas and their business questions

Features are sliced from questions, and questions come from people. This document names who the
system serves and what each of them actually asks — in their own words, not ours.

## The planner (campaign / personalisation manager)
Runs the weekly cycle. Judged on whether waves ship and perform.
- Which offers should go out this week, to whom, and how many will each reach — exactly?
- If I add this offer, what does it cost and who does it displace?
- Why did this offer reach 40,000 shoppers instead of 100,000?
- Will this configuration actually satisfy what we promised, before I run it?
- Is the wave running, and when will it finish?
- Will my personalised offer automatically stand down when a mass promotion on the same product
  overlaps, instead of me having to disable it by hand?

## The category / merchant lead
Owns the category's performance. Judged on units, margin and supplier relationships.
- Did this campaign grow the category or move volume around inside it?
- Which items are being propped up by offers and which are earning their place?
- What did we cannibalise, and what pulled forward from next month?
- Is this supplier's money being spent on shoppers who would have bought anyway?

## The commercial / supplier-facing lead
Sells the commitments. Judged on signed value and renewals.
- Can I commit to this volume for this supplier, and what will it cost us to deliver?
- Are we on pace against everything we have already sold?
- What do I show this supplier that is both compelling and defensible?
- Which suppliers are we consistently under-delivering to, and by how much?

## Finance
Owns the money.
- What have we spent, against which budget, in which fiscal period?
- What is committed but not yet spent?
- Does the spend reconcile to what was actually issued and redeemed?

## Data science
Owns the method.
- Is the effect we are reporting real, and how confident can we be?
- Can I change the model without changing everything around it?
- Can I reproduce last quarter's numbers exactly?

## Operations
Keeps it running.
- Did last night's run finish, and if not, where did it stop?
- Is the data fresh enough to run today?
- Can I re-run this identically?

---
**Rule.** Every feature traces to at least one question above, and every question above ends up on
at least one surface. A capability that answers nobody's question does not get built; a question
with no surface is an unfinished design.
