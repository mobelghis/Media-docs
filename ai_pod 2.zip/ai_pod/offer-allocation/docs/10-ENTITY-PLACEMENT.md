# 10 — Where each new capability lives (entity placement)

The question engineering and design ask first: **is this a campaign property, a wave property, a
policy property, or an offer property?** Getting this wrong is expensive later, so it is answered
here as a proposal, with the reasoning visible.

## The rule that decides it

| If the thing... | it belongs to |
|---|---|
| defines a rule that many waves obey | **Marketing policy** (versioned, published) |
| describes intent across a series of executions | **Campaign** |
| is decided at execution and must freeze | **Wave** |
| describes a deal and its product set | **Coupon** |
| describes a deal's placement into one execution | **Offer** |
| describes who may be reached | **Audience** |
| describes money and its obligations | **Funding pool / commitment** |

A useful test: **if re-running the same wave must produce the same answer, the value belongs to
the wave** (frozen at freeze). If changing it should change every future wave, it belongs to the
policy.

## Placement of the ten requirements

| # | Capability | Owning entity | Why there | Also visible on |
|---|---|---|---|---|
| R-1 | Run window, progress, ETA | **Wave** | it is a property of one execution | jobs list |
| R-2 | Category limits (any level, AND/OR) | **Policy** | a rule many waves obey; versioned so a change is reviewable | wave shows which policy version bound |
| R-3 | Store availability | **Coupon** (product set) + applied per **Wave** | ranging belongs to the product set; the snapshot that applied belongs to the run | offer form shows coverage |
| R-4 | Do-not-repeat / chilling, cross-campaign | **Policy** (rule) + **exposure ledger** (state) | the rule is policy; what a shopper has already seen is system state, not campaign state | funnel |
| R-5 | Blocking & exclusions | **Policy** (rules) + **Audience** (exclude lists) + **Offer** (offer-specific exclusions) | three legitimate homes; precedence is fixed: exclude always wins | funnel |
| R-6 | Multi-brand / multi-SKU | **Coupon** (the set) + **Offer** (reach guard at placement) | the set is the deal; the guard is about this placement | authoring |
| R-7a/b | Estimation and planning | **Scenario** (new entity, belongs to a **Wave** in draft) | scenarios are alternatives for one execution; they must be comparable and promotable | planning screens |
| R-8 | Budget caps and compliance | **Funding pool** + **Commitment** (new entities) | money obligations outlive any one campaign and are supplier-scoped, not campaign-scoped | wave shows spend against pool |
| R-9 | Annual estimation at sales time | **Commitment** (proposed, not yet signed) | it is a question about an obligation, asked before any wave exists | sales-time view |
| R-10 | Lift measurement | **Campaign** (design + accumulated result) + **Wave** (arms, seed, ghost log) | the design spans executions; the assignment freezes per execution | measurement screens |

## The campaign-versus-wave answers specifically

**Campaign properties** — intent that spans executions: the objective, the measurement design
(standing holdout vs staggered rollout), the recurrence pattern, the audience-splitting rule for
staggered designs, the policy attachment, and the accumulated result.

**Wave properties** — everything that must freeze so the run is reproducible: the offer versions
used, the eligibility snapshot, the parameter set, the random seed, the arm assignment, the
allocations, the publication record, and the run's own status and timings.

**Policy properties** — the rules: caps, rest periods, blocking, whitelists, control percentage,
and the capability toggles that decide which fields even appear when authoring.

**Where the current system differs.** Today the wave carries nearly everything and the campaign is
thin. Two of the ten requirements — the measurement design (R-10) and staggered rollout — are not
expressible without a real campaign entity, because they need something that owns a decision made
*once* and applied *across* several executions.

## What this means for the front end
- A field that belongs to the **policy** appears in the policy editor and is **shown, not edited,**
  on the wave.
- A field that belongs to the **campaign** appears once at campaign level and is inherited by its
  waves — never re-asked per wave.
- A field that belongs to the **wave** is editable only while the wave is in draft, and is
  displayed with its frozen value afterwards.
- Anything money-related is authored where the money lives (pool or commitment), never on the
  offer form.

**This is a proposal.** Engineering may move a row, but a move needs its reason recorded — the
placement decides what freezes, what versions, and what a re-run reproduces.

---

## Amendment · 2026-08-16 — campaign and wave are one entity (D-3)

The campaign-versus-wave distinction in this document is **superseded**. Confirmed with the team:
there is no campaign record. "Campaign" is the front-end label for the back-end wave, and the
attributes this document placed on a campaign belong on the wave.

Two entities remain real, and one grouping key replaces the third:

| | Owns |
|---|---|
| **Marketing policy** | Rules that many executions obey: caps, category limits, rest rules and their scope, blocking parameters, whitelists |
| **Wave** (shown to users as "campaign") | Everything that must freeze so a run is reproducible: offer versions, eligibility snapshot, parameters, seed, arm assignment, allocations, publication |
| **`series_id` + occurrence** *(new, on the wave)* | Only what genuinely spans executions: the measurement design and the staggered-rollout split. A grouping key, not a hierarchy |

Consequences, restated so they are not lost: **series must be set at freeze** for recurring and
staggered patterns and cannot be reconstructed afterwards; **arm assignment is deterministic from
(series, shopper)** so a shopper's arm is stable across waves without a parent record; and
**screens keep saying "campaign" to users** while the fields land on the wave — nobody should build
a campaign form.
