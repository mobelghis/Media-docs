# 15 — Who writes the model code

A question that deserves a plain answer, because the wrong answer creates the silo this method
exists to remove.

## The short version
**The production computation is written once, in the pod's service, and it is never rewritten
"properly" by someone else afterwards.** Data science owns the method inside it. Engineering owns
how it runs. Both work on the same code, in the same repository, in the same language.

There is no hand-over of an algorithm from one team to another, and no translation step.

## What is actually separate

| | Belongs to | Lives | Fate |
|---|---|---|---|
| **Exploration** — notebooks, plots, dead ends, one-off comparisons | Data science | Wherever DS already works | Kept by DS. Only what a decision depends on comes into the record |
| **The contract** — what goes in, what comes out, assumptions, validation | Data science | The pod repository | Signed at Gate B; the build starts from it |
| **The computation** — the code that runs in production | Written once, in the service | The pod repository | Reviewed by DS for method, by engineering for how it runs |
| **The wiring** — service, endpoints, tenancy, performance, deployment | Engineering | The pod repository | Never DS's problem |

## How the computation actually gets written
In practice the AI writes the first version inside the feature, from the contract and the method
statement. Then:
- **Data science reviews it as method** — is this the computation I specified, with the parameters
  I named and the validation I asked for? DS edits it directly where it is wrong. Nobody needs
  permission to fix their own method.
- **Engineering reviews it as code that has to run** — where it executes, what it costs, how it
  fails, what it must not touch.

If a data scientist prefers to write the computation themselves, they should. It lands in the same
place either way and goes through the same two reviews. What we are avoiding is not DS writing
code — it is **two implementations of the same thing**, one "for research" and one "for
production", which drift within a month.

## Why the contract exists, then
Not to separate people. Two reasons only:
1. **It lets work start before the method is finished.** Data, API and screens can be built against
   a defined shape while the method behind it is still being refined.
2. **It makes the method's claims checkable.** Inputs, outputs, assumptions and validation written
   down are what allow an external reviewer — or a test — to say "this is wrong".

## Reference implementations
If DS writes a quick implementation to prove a method works, that is evidence and it is welcome.
It is not a second deliverable to be reimplemented for ceremony: if it is correct and fits the
service, it becomes the implementation after the two reviews. If it does not fit — wrong runtime,
wrong data access, no tenancy — the parts that do not fit are changed, not the parts that do.

## When a model already exists
Existing models are not rewritten because they are old. They are:
- **kept as they are** if they satisfy the requirement, and wrapped by the contract;
- **changed where a requirement forces it**, with the reason recorded;
- **replaced only when a decision says so**, with its because.

"We rebuilt it because we were rebuilding everything" is not a reason.

## Where it runs
One service, in the pod repository, built on the organisation's service chassis. Engineering
enforces the chassis at Gate C. Data science does not deploy anything and does not own the
runtime — but the algorithm inside it stays theirs.

---

## Amendment · 2026-08-31 — a sharper boundary, and a four-way test for every field

From `docs/sources/2026-08-26-discovery-pack-2026Q4.docx`. Nothing above changes; this adds a
boundary rule and an estimation test that the pack applies to every field in the 2026.4 increment.

### The boundary, in one line

> **Anything in the allocation repository is data science. Everything else is application.**

That is compatible with everything above — the computation is still written once, in one repository,
reviewed twice — but it gives a crisper answer to *"whose ticket is this?"* than "DS owns the method
inside it" does on its own. The repository a value lives in decides who owns the work on it.

### The four behaviours

Every field carries exactly one of these, and the pack's claim is that **carried and calculated are
routinely estimated as the same job, and the difference is usually a factor of three.**

| Behaviour | What it means | Who owns the work |
|---|---|---|
| **Carried** | The application stores it and hands it to the model unchanged | Application: form, column, contract. Data science: everything that uses it |
| **Calculated** | The application computes with it before or after the run | Application owns the logic, the edge cases and the tests |
| **Enforced** | The application validates or constrains it, then passes it on | Application owns validation and the failure behaviour |
| **Produced** | The run generates it; the application stores and shows it | Data science produces. Application renders it with its caveats |

### The question worth asking about any field

> **Is this value carried, or is it calculated?**

A field the application only carries needs a form control, a column and a contract. A field it
calculates with needs validation, edge cases, a runtime budget, and a test that fails when the logic
breaks.

**Where this bites in the current increment.** The pack marks CR-38874's history-coverage warning as
*calculated* and notes it "never reaches the model — it is a planner-facing concern." An estimate
that treated it as a carried field would miss the coverage computation, the earliest-exposure-date
refresh behind it, and the edge case where coverage is unavailable and the screen must show no
warning rather than a false reassurance. That is the factor-of-three, concretely.

This pairs with N-27: a field that is *calculated* or *produced* has a runtime cost, and N-27
requires that cost to be measured rather than estimated.
