# Release notes

*Generated from the repository history and the features marked done. Do not edit — run `make index`.*

## Landings


### 2026-08-31

- `84b5bd9` Generalize CI to check every pod's views and method drift; consolidate offer-allocation model repos

### 2026-08-17

- `222ca61` update Repos
- `bac1949` Add portfolio, method skills/commands, and update pod docs across repos

### 2026-08-13

- `35395b2` change the look and feel
- `08d9e94` fix UI issues
- `776b9a5` Add planning functionality

### 2026-08-12

- `653f33b` Generate Markdown Twins of the status and pmo r\eports
- `ec7ca3e` Deterministic view generation: stamp from the last commit, not the clock
- `a87f1e7` pushing reporting views
- `7786c1a` CI: fail if the commited views are stale
- `9bff63d` Ignore local junk; commit the generated views
- `0cc344c` Ignore .DS_Store
- `86e8a82` AI pod: method, templates, and the offer-allocation pod kickoff baseline
