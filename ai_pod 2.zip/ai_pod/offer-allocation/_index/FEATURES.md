# Features — Offer allocation

*Generated 31 August 2026, 12:03 · 84b5bd9 from the ticket files in `features/`. Do not edit — run `make index`.*

No feature tickets yet. They are created at Gate C — one per question, each answering it end to end.
