# PMO view — Offer allocation

*Generated 31 August 2026, 12:03 · 84b5bd9. Nothing here is maintained by hand —
if a number looks wrong, the underlying file is wrong.*

| Accepted | In progress | Blocked | Not started | Open items | Decisions |
|---|---|---|---|---|---|
| 0 | 1 | 0 | 36 | 45 | 13 |

## Delivery

| ID | Item | Status | Gate | Owner |
|---|---|---|---|---|
| G-A | Question register + priorities + owners on every open question | in progress | Gate A | Product |
| G-B | I/O contracts and method statements for the first questions | not started | Gate B | Data science |
| G-B2 | Non-negotiables register written into upcoming tickets | not started | Gate C prep | Engineering |
| G-C | First feature tickets drafted and approved | not started | Gate C | Pod |
| CR-38871 | Large-scale allocation, phase 1 — 10K offers | not started | Gate C | Engineering |
| CR-40344 | Cross-campaign exposure record | not started | Gate C | Data + Engineering |
| CR-38874 | Global do-not-repeat and chilling, across campaigns | not started | Gate C | Engineering |
| CR-38875 | Advanced coupon blocking, overlap-driven | not started | Gate C | Engineering |
| CR-40346 | Measurement prerequisites — arms, ghost log, snapshot, seed | not started | Gate C | Data science |
| CR-40599 | Personalization UX research | not started | — | Design + Product |
| CR-40841 | Large-scale allocation, phase 2 — 20K offers | not started | Gate C | Engineering |
| CR-40345 | Run visibility and the eligibility funnel | not started | Gate C | Engineering |
| CR-39714 | Improved multi-brand / SKU coupon creation | not started | Gate C | Engineering |
| CR-38880 | Advanced lift measurement framework | not started | Gate B | Data science |
| CR-38870 | Personalization front-end modernization (Angular → React) | not started | — | Engineering |
| CR-38872 | Offer limits by category | not started | Gate C | Engineering |
| CR-38873 | Store availability-based offer allocation | not started | Gate C | Data + Engineering |
| CR-38876 | Multi-brand / multi-SKU scoring at runtime | not started | Gate B | Data science |
| CR-38879 | Supplier budget capping and compliance | not started | Gate B | Data + Engineering |
| CR-38878 | Campaign planning — audience builder (7b) | not started | Gate B | Data science |
| CR-38877 | Campaign planning — system-guided (7a) | not started | Gate B | Data science |
| CR-40313 | Redesigned constraint enforcement — target architecture | not started | Gate B | Engineering |
| B-1 | **R-8 is stated launch-blocking in `docs/01-REQUIREMENTS.md` but sits in Q3 2027**, three quarters after the first Q4 2026 wave. Adopting this sequencing did not resolve the conflict — it dated it | Product |  |  |
| B-2 | **The funding half of wave-one irreversible #4 sits in CR-38879 at Q3 2027.** Arms, ghost log, snapshot, seed and the *exposure* ledger are all now in Q4 2026, so N-15 is largely satisfied; the funding ledger is not | Product |  |  |
| B-3 | **Chilling and blocking ship Q4 2026; the funnel they feed ships Q1 2027.** Question-register rows Q-8 and Q-10 have no answering surface for a quarter after the rules that make them urgent go live | Product + Design |  |  |
| B-4 | **Five epics on this board carry no stories** — CR-38871, CR-40599, CR-40841, CR-38870, CR-40313. Two are in the current increment. CR-38870 is a stack migration and answers to no requirement; the other four each answer to one | Pod |  |  |
| Old grouping | Epics | Now |  |  |
| Phase 1 | CR-38871, CR-40344, CR-38874, CR-38875, CR-40346 | Q4 2026 |  |  |
| Phase 1 | CR-40345, CR-39714, CR-38872 | **moved to Q1 2027** |  |  |
| Phase 1 | CR-38873 (feed half) | **moved to Q2 2027** |  |  |
| Phase 2 | CR-38876 | Q2 2027 |  |  |
| Phase 2 | CR-38877, CR-38878 | Q4 2027 |  |  |
| Phase 3 | CR-38880 | **moved earlier, to Q1 2027** |  |  |
| Phase 3 | CR-38879 | Q3 2027 |  |  |
| not previously on the board | CR-40599 (Q4 2026), CR-40841 (Q1 2027), CR-38870 (Q1 2027), CR-40313 (Q4 2027) | new rows |  |  |
| F-1..F-24 | Internal placeholder features drafted 2026-08-13 | 2026-08-15 | Replaced by stories mapped to real Jira epic keys (D-9). Kept in git history; `features/JIRA-IMPORT.csv` superseded by `features/JIRA-IMPORT-stories.csv` |  |
| `XXX-1/2/3` | Placeholder keys for the three pod-proposed epics | 2026-08-31 | Jira issued real keys: CR-40344, CR-40345, CR-40346. Executes D-9's stated consequence |  |

## Accepted features

_Nothing accepted yet._

## Landings

- `84b5bd9` · 2026-08-31 — Generalize CI to check every pod's views and method drift; consolidate offer-allocation model repos
- `222ca61` · 2026-08-17 — update Repos
- `bac1949` · 2026-08-17 — Add portfolio, method skills/commands, and update pod docs across repos
- `35395b2` · 2026-08-13 — change the look and feel
- `08d9e94` · 2026-08-13 — fix UI issues
- `776b9a5` · 2026-08-13 — Add planning functionality
- `653f33b` · 2026-08-12 — Generate Markdown Twins of the status and pmo r\eports
- `ec7ca3e` · 2026-08-12 — Deterministic view generation: stamp from the last commit, not the clock
- `a87f1e7` · 2026-08-12 — pushing reporting views
- `7786c1a` · 2026-08-12 — CI: fail if the commited views are stale
- `9bff63d` · 2026-08-12 — Ignore local junk; commit the generated views
- `0cc344c` · 2026-08-12 — Ignore .DS_Store
- `86e8a82` · 2026-08-12 — AI pod: method, templates, and the offer-allocation pod kickoff baseline

## Open items and blockers

| # | Item | Owner | Blocks |
|---|---|---|---|
| Q-3 | Where do redemption events land, and at what latency? | Platform | Ledgers and measurement capture (CR-40346) |
| Q-4 | Is a populated non-production environment available, and when? | Platform | Any production-shaped verification of runtime cost (CR-38871), and observing real users (CR-40599) |
| Q-8 | Access to the org design system / theme package | Design | Front-end token layer, the redesign options in docs/21, and the wireframes CR-40599 puts in front of planners |
| Q-10 | What is the target scale, and at what offer-type mix? **Partially answered** — the discovery pack states 10,000 offers per allocation at 15M shoppers for CR-38871, and splits 20,000 into CR-40841. The unit is *offers*. The offer-type mix remains open, and it changes the technical approach | Commercial + Product | Volume assumptions behind CR-38871 and CR-40841 |
| Q-11 | What is the blocking-overlap methodology — measured how, over what window, and who wins a block? **Sharpened by the discovery pack**, which asks specifically: is overlap measured against the smaller set, the larger, or the union; and should a SKU exposure satisfy a category rule? The pack's worked examples use the smaller set at 60%, but list the same question as open — the examples are illustrative, not decided | Data science + Product | CR-38875, and CR-38874 shares the same definition |
| Q-12 | Do CR-31111 / CR-30454 fully remediate the control-group bias (D-04), or predate the randomisation and ghost-logging requirements? | Data science | D-04 status; the CR-40346 arm-assignment story verifies this |
| Q-20 | Does the existing 127 (`Byte.MAX_VALUE`) ceiling on min/max stay, or change? **Now Q4 2026, not Q1 2027**: a chilling window or a blocking concurrency window expressed in days exceeds 127 for any rule longer than about four months, and both ship in this increment | Engineering + Product | Every new limit inherits it — CR-38874, CR-38875, later CR-38872. Also blocks promoting the ceiling to a non-negotiable (docs/04) |
| Q-28 | What is today's actual offer ceiling, measured rather than assumed? | Engineering | The baseline the 10K claim is stated against |
| Q-29 | What is the operating window for a full wave, and who owns it? | Product + Platform | Decides whether 10K is a target or a constraint |
| Q-30 | Does the exposure record include retail media, or personalization only? | Product + Platform leadership | CR-40344's volume, and the meaning of every cross-campaign rule built on it |
| Q-31 | How far back must exposure history reach, and what is retained? | Product + Platform | Storage cost, and the longest chilling window that can honestly be offered |
| Q-32 | Is exposure written at publication or at delivery? A suppressed delivery is not an exposure — which one counts? | Engineering + Data science | CR-40344's write path, and whether chilling counts intended or actual exposure |
| Q-33 | What are the default scope and match level for a rest rule that already exists? | Product + Engineering | Existing policies must not change behaviour on upgrade |
| Q-34 | Should the history-coverage warning block saving, or only inform? | Product + Design | A blocking warning changes the planner's workflow; an informing one may be ignored |
| Q-35 | Are there rest or blocking rules kept outside the product today because they cannot be expressed in it? | Product | The best available evidence for what rule scope really needs to cover; feeds CR-40599 |
| Q-36 | What is the blocking winner rule, and what is its tie-break? | Data science + Product | Determinism depends entirely on this. Without a documented tie-break the same wave re-run can produce a different answer, which breaks N-6 and R-B |
| Q-37 | Can a planner whitelist a specific coupon pair out of blocking? | Product | A supplier may want two of their own coupons to run together |
| Q-38 | What is the expected blast radius at the default overlap threshold — how many pairs, and how much reach? | Data science | Should be estimated before blocking is switched on, not discovered afterwards |
| Q-39 | Does blocking apply across incentive types? A discount and a points offer on the same products may or may not conflict | Product | CR-38875's scope, and whether it shares CR-38874's scope control |
| Q-40 | What holdout share, and is it fixed or set per campaign? | Data science + Product | Drives ghost-log volume and statistical power together |
| Q-41 | What stratification keys should arm balance be checked on? | Data science | Determines what the balance check can actually detect |
| Q-42 | What retention applies to each measurement artefact? | Platform + Data science | They are needed long after the wave, and storage is not free |
| Q-43 | Who owns a shopper who lands in opposing arms across two waves in the same period? **The discovery pack states this is currently unowned**, and that it contaminates both waves when it happens | Data science | CR-40346's arm-assignment design, and the validity of any measurement built on it |
| Q-44 | Which clients can we observe using the product, and how soon? External planners are the priority; internal support staff are the fallback | Product | CR-40599 — the epic cannot start without access to users |
| Q-45 | Who owns acting on the UX research findings? | Product + Design | Research with no route into the backlog is research nobody reads |
| Q-7 | Which measurement terms are contractually committed to suppliers today? | Commercial | Estimand choice — CR-38880 (Q1 2027) |
| Q-27 | R-10 requires results "below a stated power threshold" to be reported as underpowered — what is the threshold, and who sets it? | Data science | Measurement design for CR-38880 (Q1 2027) |
| Q-18 | Can `ConstraintTypeEnum` take a fifth value without a wider schema change? | Engineering | CR-38872's cheaper design rests on it (Q1 2027) |
| Q-19 | Who maintains virtual category definitions, and where do they live? | Product + Platform | CR-38872 — limits on virtual categories (Q1 2027) |
| Q-23 | R-2 says category limits are "combinable with AND/OR" — can rules nest (groups of groups), or is combination a single flat AND/OR across rule rows? | Product | Bounds the policy-editor design for CR-38872 (Q1 2027) |
| Q-24 | R-6's reach guard refuses or reroutes an offer above "a configured share of the population" — configured at what scope (per client, per offer type, or one global default), and set by whom? | Product + Commercial | Sizes the reach-guard config surface for CR-39714 (Q1 2027) |
| Q-15 | What exactly does each client's availability feed contain — which columns, what grain, how often, and does it mean *ranged* or *in stock*? | Platform + Data | CR-38873's size: a filter (days) or an ingestion project (weeks) — Q2 2027 |
| Q-16 | Which clients send a shopper primary-store feed, and at what coverage? | Platform + Data | CR-38873 · DATA-1 (Q2 2027) |
| Q-17 | For a multi-product offer, does a store qualify if it carries *any*, *all*, or a share of the products? | Data science | CR-38873 · DS-1, and the reach it produces (Q2 2027) |
| Q-21 | How do affinities combine across unrelated categories — maximum, weighted blend, or another method? | Data science | CR-38876 — the whole epic waits on it (Q2 2027) |
| Q-1 | Which suppliers' agreements are issuance- vs redemption-denominated? | Commercial | Cost model per pool — CR-38879 (Q3 2027) |
| Q-2 | Fiscal-year attribution for a coupon issued in one year and redeemed in the next | Commercial + Finance | Ledger design — CR-38879 (Q3 2027) |
| Q-22 | Are supplier budgets enforced across *all* campaign types (loyalty, promotion, retail media), or personalization only? | Product + Platform leadership | CR-38879's scope — this is a platform decision, not a pod one (Q3 2027) |
| Q-26 | R-9's sales-time feasibility check — does it reuse R-E's joint-feasibility engine, or is it a separate, simpler estimate? | Data science + Product | Scope of the sales-time estimate in CR-38879 (Q3 2027) |
| Q-5 | Are audience definitions shared live with the segmentation tool, or copied? | Platform | Audience behaviour — CR-38878 (Q4 2027) |
| Q-25 | R-7 says response and budget estimates "carry stated intervals" — at what confidence convention? | Data science | Method design for CR-38877 / CR-38878 (Q4 2027) |
| Q-6 | Is there a live request-time channel with its own latency requirement? | Out of scope for all three phases; request-time serving is deferred until a live channel with a stated latency requirement exists (docs/05) | 2026-08-15 |
| Q-9 | How does "blocking must apply across campaigns" differ from what is supported today? | Blocking does not exist today in any form. What exists is chilling, scoped to one campaign, matching on the offer rather than the products. CR-38875 is therefore new capability, not an extension | 2026-08-16 |
| Q-13 | R-9 (sales-time budget estimation) has no epic on the roadmap — deprioritised, folded in, or missed? | Folded into CR-38879's scope as the sales-time estimate, and written as a story there. Q3 2027 | 2026-08-15 |
| Q-14 | Does the rebuild target the new React front end, or interoperate with Angular? | **Angular.** The current increment is built on the current application regardless of CR-38870's timing (D-4). The redesign options in docs/21 are the argument for the React work, not a dependency of Q4 2026 | 2026-08-15 |

