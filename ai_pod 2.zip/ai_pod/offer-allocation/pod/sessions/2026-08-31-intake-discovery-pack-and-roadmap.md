# Session log — 2026-08-31

**First session log in the repository.** The template at `pod/templates/session-log.md` existed but
nothing used it, and `pod/PIPELINE.md` does not say where logs live. Placed at
`pod/sessions/<date>-<slug>.md`; if a different convention is wanted, this is the file to move.

**Goal.** Run `/start` as product, then `/intake` three items from `~/Downloads/Personalization
Intake`: a 2026.4 discovery pack, a business roadmap deck, and a Jira story import.

## What happened, in order

1. **`/start` → product route.** Read the requirements, defect catalogue and persona questions in
   full. Found the Gate A question register already drafted (2026-08-16) and holding up against all
   three inputs — so it was **not** redrafted. Five ambiguities in `01-REQUIREMENTS.md` that were
   not tracked anywhere became Q-23 to Q-27.
2. **`/intake` three items.** Reported contents and impact per item before merging anything, as the
   command requires. Product owner ruled on three questions, then said go.

## Decisions made

| # | Decision | Ruled by |
|---|---|---|
| D-10 | The client's 2026-08-25 roadmap is adopted as **pod sequencing**, not filed as evidence. Board reorganised by quarter | Product owner, against the pod's recommendation |
| D-11 | `XXX-1/2/3` → CR-40344/40345/40346 across nine documents and the board | Product owner; executes D-9's stated condition |
| D-12 | Five of seven discovery-pack constraints promoted to N-23…N-27; the retailer-metadata rule and the 127 ceiling held | Product owner, after a written elaboration |
| D-13 | A malformed table row may not hang the index build. Fixed in the tooling, not in the two files that tripped it | Pod, under N-22 — not a ruling that was asked for |

Reasons are in `pod/DECISIONS.md`, not repeated here.

## Deviations

- **D-10 went against the pod's recommendation.** The written recommendation was to file the deck as
  evidence in `docs/19` and rule on its three conflicts separately, on the grounds that `docs/16`
  makes the board govern and Jira a one-way projection. The product owner ruled to adopt. Recorded
  because the reasoning that lost should stay visible: adopting a Jira-derived sequencing wholesale
  is the thing `docs/16` was written to prevent, and if drift reappears this is where it started.
- **The question register was not redrafted**, though the `/start` product kick-off prompt asks for
  it. It already existed and already covered the amendments. Re-running the prompt would have
  produced a duplicate of work done on 2026-08-16.
- **`features/JIRA-IMPORT-stories.csv` was edited, not just replaced.** After copying the new file
  in, its `Phase` column still carried the old Phase 1/2/3 groupings, which now disagreed with the
  board for 13 of 13 epics. Rewrote the column to the quarter and dropped the `phase-N` labels, so
  all 43 stories agree with the board. The copy in `docs/sources/` is untouched.
- **`docs/07` was restructured, not appended to.** Its two section headings ("blocking Phase 1",
  "blocking Phase 2 or 3") had become wrong under D-10 — the first table held questions blocking
  Q1 2027 and Q2 2027 work. Re-filed every existing row against the quarter of the epic it actually
  blocks.

## Defects found

**In the incoming material:**

1. **The roadmap deck encodes quarter positionally.** Text extraction loses it entirely. Recovered
   from shape x-coordinates and written into the extraction file, so nobody repeats the work or
   guesses. → *Became a mechanism:* both binary sources now have a committed `-extracted.md`
   companion, and `docs/sources/README.md` states the binary wins on disagreement.
2. **The discovery pack demonstrates undecided values in worked examples** — 60% overlap threshold,
   smaller-set denominator, lower-coupon-id tie-break, 2% holdout — while listing the same questions
   as open in the same section. None were merged as decisions. Q-11 now says explicitly that the
   pack's examples are illustrative.

**In our own work:**

3. **Q-20 was filed against the wrong quarter, and the error was ours.** It sat under "blocking
   Phase 1" pointing only at CR-38872, which D-10 moved to Q1 2027 — which would have deferred it.
   But a chilling window or a blocking concurrency window expressed in days exceeds 127 for any rule
   longer than about four months, and **both ship Q4 2026**. Q-20 is now a Q4 2026 blocker. It also
   blocked promoting the ceiling to a non-negotiable in D-12.
4. **`docs/18` marked two rows `surfaced` against a surface that moved.** Q-8 and Q-10 point at the
   explain funnel; D-10 put the funnel in Q1 2027 while the rules feeding it ship Q4 2026. Amended
   rather than silently re-marked. → Board row B-3.
5. **`docs/00-README.md` was broken, and it was hanging `make index`.** Found while trying to
   regenerate the index at the end of the landing, which never returned. Two separate defects that
   turned out to be one:
   - The README listed one row (00), then rows 20–22 stranded *after* the closing "browse
     everything" line. Documents 01–19 were absent from the index of the record.
   - Those stranded rows are **orphan table rows**, and an orphan table row makes
     `md_to_html` loop forever: no branch claims a `|...|` line without a header/separator pair
     above it, and the paragraph fallback's guard explicitly refuses pipe-prefixed lines, so `i`
     never advances. Reproduced on a clean `git worktree` at HEAD, so it is pre-existing, not
     mine. My own discovery-pack extraction triggered it too, via flattened ` | ` table cells.

   → *Became a mechanism (N-22):* fixed in `scripts/build_index.py` so malformed markdown can never
   hang the build, rather than fixing the two input files. Verified against five cases including
   "well-formed tables still render". Index now builds in ~3s. README completed with all 22
   documents. D-13.
6. **`docs/20-epic-review-and-phase-1.md` carries the H1 `# 18 — Epic review`**, colliding with
   `docs/18-question-register.md`. Pre-existing. Not fixed — the fix belongs in that file, and it
   was not otherwise in scope. Owed below.
7. **Two counts in my own first draft were wrong** and were corrected before landing: the roadmap
   deck has 18 epics, not 17, and five board rows lack stories, not four. Both came from eyeballing
   rather than counting; both are now computed. Caught by a cross-check script comparing the board
   against the CSV, which is the mechanism that should have existed first.

## What is owed

| # | Item | Owner |
|---|---|---|
| 1 | **Gate A is still not signable.** `pod/templates/priorities.md` is an empty template; docs/19 says explicitly it is not the Gate A artifact | Product |
| 2 | Rule B-1 to B-4 on the board: R-8 launch-blocking vs Q3 2027; the funding ledger vs N-15; the funnel arriving a quarter after its rules; five epics with no stories | Product |
| 3 | Q-24 remains the register's only true gap — no surface names a re-run-from-frozen-inputs action. Needed before Gate A closes | Product + Design |
| 4 | 18 new open questions (Q-28…Q-45) have owners but most have no date. Twelve of them are Q4 2026 blockers | Product |
| 5 | Descriptions and stories for CR-40599, CR-40841, CR-40313; stories for CR-38871. (CR-38870 also has none, but it is a stack migration answering to no requirement) | Pod |
| 6 | The retailer-metadata rule deserves its own ruling as a non-negotiable (held out of D-12) | Product + Engineering |
| 7 | `docs/20-epic-review-and-phase-1.md` H1 reads `# 18 — Epic review`, colliding with docs/18 | Pod |

## What this session did not touch

**One code change, not zero:** `scripts/build_index.py` gained a five-line forward-progress guard in
`md_to_html` (D-13). No product code — this repository holds none yet.

No contracts (`docs/09`), no requirement trace beyond the key rename, no design documents
(`docs/21`). `01-REQUIREMENTS.md` gained no new amendment: the discovery pack sharpens and dates the
existing ten requirements but does not add or change one, and candidate R-11 (auto-suppression
against mass promotions) appears nowhere in any of the three items and remains unprioritised.

## Honest limits of this landing

- **`make check` is still `@echo "define the gated check for this repository"`.** There is no suite,
  so "the suite is green on a frozen tree" cannot be satisfied and was not claimed. What was verified
  is narrower and stated where it was done: question IDs are unique and gapless, board story counts
  are read from the CSV rather than typed, board and CSV agree on every epic's quarter, and the index
  builds. The `md_to_html` fix was checked against five hand-written cases, not a committed test —
  there is nowhere to commit one.
- **`docs/14` gained seven statements about today's behaviour: three are `[verify]`**, asserted by
  the discovery pack and not traced to code by this session; the other four corroborate what the
  record already held from reading the front-end code. (First written as "seven `[verify]`" — wrong,
  and corrected by counting.)
- **Nothing was re-read back from Jira.** All three inputs are files the product owner supplied.
