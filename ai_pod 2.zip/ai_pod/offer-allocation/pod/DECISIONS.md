# Decisions

## Principles
The pod's operating principles apply here in full (see `_method/`). The five that bind most often
on this programme:
- A feature is the smallest testable unit that answers a business question, end to end.
- Every decision carries its reason. A decision without a because is not landed.
- Conflicts with a landed decision stop work and surface — nothing is guessed past a gate.
- A defect class that recurs becomes a mechanism, fixed once in the tooling.
- Claims are bound to evidence mechanically: computed numbers, honest refusals, no overclaiming.

## Decision log

### D-1 · 2026-08-12 · The programme starts from requirements, not from the proof of concept
**Decision.** This repository is the record for the offer-allocation rebuild. The prior proof of
concept is carried forward as **evidence** (`docs/06-prior-evidence.md`), not as decisions, and
nothing built here depends on a prior result until it has been re-established under this
programme's gates.
**Because.** The proof of concept answered "is this possible and where are the traps"; this
programme answers "what do we build and can we prove it". Treating exploratory findings as settled
decisions is how a rebuild inherits assumptions nobody re-examined.
**Consequences.** Prior results may be cited for orientation. Any claim that reaches a
specification, a contract or a report must stand on evidence produced here.

### D-2 · 2026-08-12 · The requirements document is the baseline
**Decision.** `docs/01-REQUIREMENTS.md` is the authoritative statement of what must be satisfied.
Changes to it are dated amendments, never silent edits.
**Because.** Every downstream artifact answers to it. If it can change invisibly, nothing
downstream can be trusted.
**Consequences.** A requirement change is a decision with a reason, and the artifacts derived from
it are revisited in the same round.

### D-3 · 2026-08-14 · Campaign and wave are one entity
**Decision.** "Campaign" is the front-end label for the back-end wave. There is no campaign record
and none will be created. Attributes previously placed on a campaign belong on the wave. Where
several waves must relate to each other — the measurement design and staggered rollout — a
`series_id` and occurrence number on the wave serve that purpose. The series is a grouping key,
not a hierarchy, and owns nothing else.
**Because.** Confirmed with the team: the campaign record does not exist in the system, and
modelling something that is not there would add a layer nobody maintains.
**Supersedes.** The campaign-versus-wave placement in `docs/10-ENTITY-PLACEMENT.md`.
**Consequences.** Series is required at freeze for recurring and staggered patterns and cannot be
reconstructed afterwards; arm assignment must be deterministic from (series, shopper) so a
shopper's arm is stable across waves; screens keep saying "campaign" to users while the fields
land on the wave.

### D-4 · 2026-08-15 · Phase 1 is offer assignment, on the current engine
**Decision.** Phase 1 targets the eligibility and assignment path: priorities 1, 2, 4, 5 and the
feed-based half of 3. Everything in it must be deliverable against the current allocation engine
and the current Angular application, and must not have to be discarded when the engine is
redesigned (CR-40313).
**Because.** Rebuilding everything at once carries more risk than the business will accept, and
five of the ten priorities need no new methodology. Splitting by layer — eligibility, scoring,
allocation — gives a boundary that holds.
**Consequences.** Multi-SKU scoring, planning forecasts, supplier budgets and the measurement
framework are out of Phase 1 and wait on a method or a platform decision. Category limits are in
Phase 1 but are not cheap: they must be enforced inside the assignment loop.

### D-5 · 2026-08-15 · Three new epics are proposed
**Decision.** Three epics that no existing ticket covers: the cross-campaign **exposure record**
(foundation for chilling and blocking), **run visibility and the eligibility funnel**, and
**measurement prerequisites** (arms, ghost log, frozen snapshot, seed). They carry XXX keys until
they exist in Jira.
**Because.** Two of them are silent dependencies of tickets that already exist — CR-38874 and
CR-38875 cannot work across campaigns without an exposure record. The third captures artifacts
that can only be recorded while a wave runs.
**Consequences.** Measurement prerequisites deliver no visible value in 2026 and exist so the
2027.3 framework has something to measure; that is stated explicitly so the epic survives
prioritisation.

### D-6 · 2026-08-15 · Scale is a budget in every rule, not a gate before them
**Decision.** CR-38871 keeps its own PI. Every rule story states what it adds to wave runtime,
measured rather than estimated, at a stated offer volume.
**Because.** Making capacity a prerequisite would delay every rule; ignoring it would let four
rules land and discover their combined cost at 10,000 offers. A per-ticket number finds the
problem at ticket time.
**Consequences.** Rules that are hard constraints are applied before scoring wherever possible, so
they shrink the candidate set rather than only adding work. Category limits are the exception —
they can only resolve during assignment.

### D-7 · 2026-08-15 · Store availability: two feeds, with a derived fallback
**Decision.** Availability is applied from two client feeds — shopper primary store, and store ×
product ranging. Where a client sends no ranging feed, availability is derived from recent sales
("not sold at this store in X days, default 14"), with a minimum-evidence floor. The client feed is
authoritative wherever it exists, and the source is recorded per row.
**Because.** Waiting for every client to send a ranging feed would block the requirement
indefinitely; deriving it silently would suppress slow-moving products without anyone noticing.
**Consequences.** The window and the floor are parameters, not constants. The derived rule reports
what it suppressed. The multi-product rule (any / all / threshold) is a data-science decision, and
the epic's size depends on what the feeds actually contain — an open question with an owner.

### D-8 · 2026-08-15 · Reading the front-end code changed three epics
**Decision.** Category limits extend the existing Segment Strategy constraint model (a new
constraint type) rather than introducing a rule builder; chilling extends the two Frequency
Criteria fields that already exist; multi-SKU authoring extends the existing product picker by
adding excludes and dynamic sets.
**Because.** The recreation guide shows a generic `type × value × segment → min/max` model already
in place, chilling already present as two fields, and a product picker that already filters by CPG,
brand and category with CSV import. Building parallel mechanisms would duplicate what exists and
force planners to learn two patterns.
**Consequences.** Front-end estimates for those three epics should be revisited downward. Two
constraints inherited with them: every new field must join the retailer metadata system
(`fromMetaData.<field>`), and every min/max carries the existing 127 (`Byte.MAX_VALUE`) ceiling
unless a decision is taken to change it.

### D-9 · 2026-08-15 · The board speaks Jira's language
**Decision.** Board rows use the real Jira epic keys and the stories written against them
(`features/JIRA-IMPORT-stories.csv`). The earlier internal placeholders F-1..F-24 and
`JIRA-IMPORT.csv` are retired, with a note recording why rather than being deleted silently.
**Because.** Two sets of features in two ID schemes meant nobody could tell which was
authoritative. Jira is where the work is scheduled, so the record should speak the same language.
**Consequences.** New work enters as a question, becomes a story under an epic key, and appears on
the board. `XXX-1/2/3` are replaced with real keys once the epics exist in Jira.

### D-10 · 2026-08-31 · The client's 2026-08-25 roadmap is adopted as pod sequencing
**Decision.** The business-view roadmap dated 2026-08-25 becomes the pod's own delivery sequencing,
not merely evidence cited against it. `features/BOARD.md` is reorganised by delivery quarter
(Q4 2026 → Q4 2027), replacing the Phase 1/2/3 grouping from D-4. The old vocabulary is kept as a
mapping table on the board, because eleven documents cite it.
**Because.** The product owner ruled it. The pod's previous position — hold the client roadmap as
evidence and sequence independently (docs/19) — cost more than it bought: two sequencings meant
every conversation started by establishing which one applied, and the deck is itself generated from
Jira, where the work is actually scheduled.
**Consequences.** Four epics moved out of the first increment: CR-40345 (run visibility and the
funnel), CR-38872 (category limits), CR-39714 (multi-brand coupon creation) and CR-38873 (store
availability). CR-38880 moved earlier, to Q1 2027. Four epics joined the board with no stories yet:
CR-40599, CR-40841, CR-38870, CR-40313. `features/JIRA-IMPORT-stories.csv` had its `Phase` column
rewritten to carry the quarter and its `phase-N` labels dropped, so all 43 stories now agree with
the board; the copy in `docs/sources/` is untouched, as sources always are.

Adoption did **not** resolve three conflicts, which are now board rows B-1 to B-3. R-8 is stated
launch-blocking in `01-REQUIREMENTS.md` but sits at Q3 2027. The funding half of wave-one
irreversible #4 sits in CR-38879, also Q3 2027, so N-15 cannot be fully met. And chilling and
blocking now ship a full quarter before the funnel they feed, leaving register rows Q-8 and Q-10
without an answering surface in the interim. Adopting the sequencing dated these conflicts rather
than settling them.

### D-11 · 2026-08-31 · `XXX-1/2/3` retired; the three pod-proposed epics have real keys
**Decision.** `XXX-1` → **CR-40344**, `XXX-2` → **CR-40345**, `XXX-3` → **CR-40346**, across nine
documents and the board.
**Because.** Jira issued the keys, which is the condition D-9 already set for this rename. It
executes a landed decision rather than making a new one.
**Consequences.** Two occurrences of `XXX-` deliberately remain. `pod/DECISIONS.md` keeps D-9's
original text, because a landed decision is not edited to match what happened afterwards. The
jira-conventions skill keeps its `XXX-1` example, because there it illustrates the placeholder
convention itself rather than referring to an epic.

### D-12 · 2026-08-31 · Five of seven discovery-pack constraints promoted to non-negotiables
**Decision.** N-23 (a rule with no data removes nobody, never everybody), N-24 (absence of exposure
never means held out), N-25 (an unwritable measurement artefact fails publication loudly), N-26 (no
offer/coupon/store computation scales with shopper count) and N-27 (every rule states its measured
cost) join `docs/04-non-negotiables.md`. The retailer-metadata rule and the 127 ceiling do not.
**Because.** Each of the five is universal across features, verifiable by assertion rather than by
review, and its violation is a defect rather than a trade-off — the test the existing N- rows share.
N-26 is deliberately the *consequence* of "precompute once, look up per pair" rather than the
technique: the technique is doctrine in the performance-budgets skill, while what belongs in the
non-negotiables is the property a test can check.
**Consequences.** The 127 ceiling was **not** promoted because Q-20 asks whether it stays, and
writing it in while that question is open is what N-21 forbids. That question also moved from
Q1 2027 to Q4 2026 in the process: a chilling or concurrency window expressed in days exceeds 127
for any rule longer than roughly four months, and both rules ship in the current increment. The
retailer-metadata rule is held for its own ruling rather than riding along in a
measurement-and-correctness batch.

### D-13 · 2026-08-31 · A malformed table row may not hang the index build
**Decision.** `scripts/build_index.py` guarantees forward progress in `md_to_html`: a line that no
branch claims is consumed as text rather than skipped. `docs/00-README.md` is also completed and
made well-formed.
**Because.** `make index` did not slow down on malformed markdown — it never terminated. An orphan
table row (a `|...|` line with no header/separator pair above it) matched no branch, and the
paragraph fallback's guard explicitly refuses pipe-prefixed lines, so the index never advanced.
Two files triggered it, and the defect was pre-existing: it reproduces on a clean checkout of HEAD.
Fixing only the two files would have left the next malformed document to rediscover it, which N-22
forbids.
**Consequences.** The index builds in about three seconds where it previously hung. `docs/00-README.md`
now lists all 22 documents; it previously listed one, with three more stranded outside the table and
01–19 absent altogether. One related defect is left owed rather than fixed here:
`docs/20-epic-review-and-phase-1.md` carries the H1 `# 18 — Epic review`, colliding with
`docs/18-question-register.md`.

**Worth noting for CI.** The most recent commit before this session generalised CI to check every
pod's views. If that CI runs this script against this tree, it cannot have been passing — so either
the target is not run, or it is not run here.
