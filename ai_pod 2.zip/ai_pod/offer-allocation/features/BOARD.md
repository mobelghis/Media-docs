# Board

**This file governs.** The folders mirror it for visibility. Rows use the real Jira epic keys, so
the board and Jira speak the same language (D-9). Stories per epic are in
`features/JIRA-IMPORT-stories.csv`.

Nothing is buildable before Gate C.

**Sequencing adopted 2026-08-31 (D-10).** The board is now organised by delivery quarter, taken
from the client's 2026-08-25 business roadmap. The earlier Phase 1/2/3 grouping is kept in the
mapping table at the bottom, because eleven documents still cite it.

## Gates

| ID | Item | Status | Gate | Owner |
|---|---|---|---|---|
| G-A | Question register + priorities + owners on every open question | in progress | Gate A | Product |
| G-B | I/O contracts and method statements for the first questions | not started | Gate B | Data science |
| G-B2 | Non-negotiables register written into upcoming tickets | not started | Gate C prep | Engineering |
| G-C | First feature tickets drafted and approved | not started | Gate C | Pod |

## Q4 2026 — the current increment

Six epics. The discovery pack (`docs/sources/2026-08-26-discovery-pack-2026Q4.docx`) details all
six; two of them produce nothing a client can see, by design.

| ID | Epic | Status | Gate | Owner | Stories |
|---|---|---|---|---|---|
| CR-38871 | Large-scale allocation, phase 1 — 10K offers | not started | Gate C | Engineering | none yet |
| CR-40344 | Cross-campaign exposure record | not started | Gate C | Data + Engineering | 2 |
| CR-38874 | Global do-not-repeat and chilling, across campaigns | not started | Gate C | Engineering | 3 |
| CR-38875 | Advanced coupon blocking, overlap-driven | not started | Gate C | Engineering | 3 |
| CR-40346 | Measurement prerequisites — arms, ghost log, snapshot, seed | not started | Gate C | Data science | 3 |
| CR-40599 | Personalization UX research | not started | — | Design + Product | none yet |

## Q1 2027

| ID | Epic | Status | Gate | Owner | Stories |
|---|---|---|---|---|---|
| CR-40841 | Large-scale allocation, phase 2 — 20K offers | not started | Gate C | Engineering | none yet |
| CR-40345 | Run visibility and the eligibility funnel | not started | Gate C | Engineering | 5 |
| CR-39714 | Improved multi-brand / SKU coupon creation | not started | Gate C | Engineering | 3 |
| CR-38880 | Advanced lift measurement framework | not started | Gate B | Data science | 3 |
| CR-38870 | Personalization front-end modernization (Angular → React) | not started | — | Engineering | none yet |
| CR-38872 | Offer limits by category | not started | Gate C | Engineering | 4 |

## Q2 2027

| ID | Epic | Status | Gate | Owner | Stories |
|---|---|---|---|---|---|
| CR-38873 | Store availability-based offer allocation | not started | Gate C | Data + Engineering | 5 |
| CR-38876 | Multi-brand / multi-SKU scoring at runtime | not started | Gate B | Data science | 3 |

## Q3 2027

| ID | Epic | Status | Gate | Owner | Stories |
|---|---|---|---|---|---|
| CR-38879 | Supplier budget capping and compliance | not started | Gate B | Data + Engineering | 4 |

## Q4 2027

| ID | Epic | Status | Gate | Owner | Stories |
|---|---|---|---|---|---|
| CR-38878 | Campaign planning — audience builder (7b) | not started | Gate B | Data science | 2 |
| CR-38877 | Campaign planning — system-guided (7a) | not started | Gate B | Data science | 3 |
| CR-40313 | Redesigned constraint enforcement — target architecture | not started | Gate B | Engineering | none yet |

## Open against this board

| # | Item | Owner |
|---|---|---|
| B-1 | **R-8 is stated launch-blocking in `docs/01-REQUIREMENTS.md` but sits in Q3 2027**, three quarters after the first Q4 2026 wave. Adopting this sequencing did not resolve the conflict — it dated it | Product |
| B-2 | **The funding half of wave-one irreversible #4 sits in CR-38879 at Q3 2027.** Arms, ghost log, snapshot, seed and the *exposure* ledger are all now in Q4 2026, so N-15 is largely satisfied; the funding ledger is not | Product |
| B-3 | **Chilling and blocking ship Q4 2026; the funnel they feed ships Q1 2027.** Question-register rows Q-8 and Q-10 have no answering surface for a quarter after the rules that make them urgent go live | Product + Design |
| B-4 | **Five epics on this board carry no stories** — CR-38871, CR-40599, CR-40841, CR-38870, CR-40313. Two are in the current increment. CR-38870 is a stack migration and answers to no requirement; the other four each answer to one | Pod |

## Phase-to-quarter mapping

The Phase 1/2/3 vocabulary from D-4 is cited across the record. This is the translation:

| Old grouping | Epics | Now |
|---|---|---|
| Phase 1 | CR-38871, CR-40344, CR-38874, CR-38875, CR-40346 | Q4 2026 |
| Phase 1 | CR-40345, CR-39714, CR-38872 | **moved to Q1 2027** |
| Phase 1 | CR-38873 (feed half) | **moved to Q2 2027** |
| Phase 2 | CR-38876 | Q2 2027 |
| Phase 2 | CR-38877, CR-38878 | Q4 2027 |
| Phase 3 | CR-38880 | **moved earlier, to Q1 2027** |
| Phase 3 | CR-38879 | Q3 2027 |
| not previously on the board | CR-40599 (Q4 2026), CR-40841 (Q1 2027), CR-38870 (Q1 2027), CR-40313 (Q4 2027) | new rows |

## Retired

| ID | Item | Retired | Why |
|---|---|---|---|
| F-1..F-24 | Internal placeholder features drafted 2026-08-13 | 2026-08-15 | Replaced by stories mapped to real Jira epic keys (D-9). Kept in git history; `features/JIRA-IMPORT.csv` superseded by `features/JIRA-IMPORT-stories.csv` |
| `XXX-1/2/3` | Placeholder keys for the three pod-proposed epics | 2026-08-31 | Jira issued real keys: CR-40344, CR-40345, CR-40346. Executes D-9's stated consequence |
