# Offer allocation — pod repository

The record for rebuilding the offer allocation system. Everything the pod knows lives here as
files: the requirements, what the current system does, its defects, the constraints we work
under, the decisions and their reasons, and eventually the code and its evidence.

**New here? Read `start/00-READ-ME-FIRST.md`.**

| Path | Holds |
|---|---|
| `docs/` | The record — requirements, current state, defects, non-negotiables, scope, prior evidence, open questions, front-end surfaces |
| `start/` | One kick-off file per discipline, including a paste-ready first prompt |
| `pod/` | The method: pipeline, decisions, personas, templates |
| `features/` | Specs and status. `BOARD.md` governs |
| `scripts/` | Tooling, including the index generator |
| `.claude/` | `commands/` you type (`/start`, `/intake`, `/prd`, `/contract`, `/design-brief`, `/ticket`) and `skills/` that load themselves when the work matches |
| `pod/REPOS.yml` | Every repository this pod's work touches, and what lands in each |

## Ground rules
1. If it only exists in a conversation, it does not exist. Conclusions land here.
2. Every decision carries its reason.
3. Corrections are dated amendments, never silent edits.
4. Numbers in documents are computed from what they describe, never typed.
5. `make index` after any document is added, renamed or removed.

## Status
Kickoff. Gate A in progress. Nothing is built until Gate C.
