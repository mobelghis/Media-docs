# Start here — Data Science

You are the first station after requirements, and the build genuinely waits on you. What unblocks
everyone else is **not a finished model** — it is a contract stating what goes in and what comes
out. Get that right early and the rest of the pod can work while you keep researching.

## 1. Read (about half a day)
- `docs/01-REQUIREMENTS.md` — in full. Note R-7, R-8, R-9, R-10 and the cross-cutting section:
  those are yours.
- `docs/03-defect-catalogue.md` — D-01 through D-06 are the mathematics and measurement failures
  the rebuild exists to fix.
- `docs/04-non-negotiables.md` — N-2, N-4, N-13, N-14 constrain your method directly.
- `docs/06-prior-evidence.md` — what a previous effort found, with its caveats. Argue with it.
- `docs/09-PROPOSED-IO-CONTRACTS.md` — a **draft** of the five contracts that cross the boundary,
  written so you start from something to argue with rather than a blank page. Confirm, amend or
  replace each one; where it is wrong, the correction is the valuable output.

## 2. The questions you own
Every one needs an answer that an external reviewer could challenge. Where you do not know yet,
**write that down** — "not yet known" is a valid and expected entry.

**The objective**
- What is the system maximising, stated over the whole portfolio a shopper receives — not as a
  description of how a particular algorithm walks it?
- How is attention across slots handled? Is diminishing return modelled, and on what evidence?
- Which assumptions does the formulation rest on, and under what conditions do they fail?

**Constraint satisfaction**
- How are per-shopper rules, category limits, and cross-campaign rest periods expressed
  mathematically?
- How are contractual minimums handled? They are the known structural failure (D-01): a method
  that fills slots greedily misses floors that were satisfiable.
- How is joint feasibility proven **before** a run, and how is the binding conflict named?
- What optimality claim can honestly be made — and what is the evidence for it? A measured gap
  against exact solutions on real instances is worth more than a theorem that does not transfer.

**Scoring**
- What signals drive the score, and are repeat, discovery and incremental effect estimated
  separately or blended? (A previous effort found the answer matters a great deal.)
- How does a probability get derived from a score, calibrated, and gated for use — and what
  happens where support is thin?
- Where the signal is weak by construction — a shopper with no history in a product set — what
  does the system do, and does it say so?

**Measurement**
- What is the estimand? "Lift" is not one answer, it is several: versus nothing, versus the
  next-best alternative, versus no programme at all.
- Per-shopper limits mean holding a shopper out of one offer changes the others they receive.
  How does the design handle that interference?
- Where offers share products, how is effect attributed?
- What is the power threshold, and what does the system publish below it? (N-2: underpowered is
  a verdict, not a footnote.)
- What must exist in the very first wave or the capability is lost forever? (See the four
  irreversibles in the requirements.)

## 3. What you produce — the Gate B artifacts
For each question in the register, an **I/O contract** (`pod/templates/io-contract.md`):
- **Inputs** — fields, grain, history depth, source
- **Outputs** — the quantity, its type, its range, what it means, and what is returned when the
  answer cannot be supported
- **Method** — the approach, where it runs, and which values are parameters rather than constants
- **Assumptions** — what must be true for it to be valid
- **Validation** — how we will know it is right, including the deliberately broken case that must
  fail
- **Not yet known** — named, not hidden. This section is a feature of the document.

Plus one **method statement** per area, written to a standard an external reviewer could attack.

**Gate B is signing the contracts, not finishing the models.** The model can still be a draft.
The contract is what the rest of the pod builds against.

## Where your code lives
Your model service has its own repository — see `pod/REPOS.yml`. You work there directly: write,
test, iterate, at your own pace. Engineering reviews how it runs and helps make it deployable;
they do not rewrite it. The pod folder holds the contract, the decisions and the evidence — not a
copy of your code.

## 4. How you work
Use your own tools and your own pace — notebooks, whatever you already use. The pod asks only
that the **outputs** land here as files, so that engineering can build against them and a
reviewer can challenge them. Nothing about your research method is being changed.

## 5. Your day
Mornings on the method. Midday at the gate window: sign contracts that are ready, rule on
questions the build has surfaced. Afternoons challenging what landed — the numbers that came back
from the last feature are yours to disbelieve first.

## 6. Kick-off prompt (paste into your AI session at the repository root)
> Read `docs/01-REQUIREMENTS.md`, `docs/02-current-state.md`, `docs/03-defect-catalogue.md`,
> `docs/04-non-negotiables.md` and `docs/06-prior-evidence.md`. Then draft, for review, the list
> of methodology questions this programme must answer — grouped as objective, constraints,
> scoring, and measurement — with, for each: what must be decided, what the requirements already
> constrain, what the prior evidence suggests and how far it can be trusted, and what data would
> settle it. Do not propose methods yet; produce the question list first, and flag anything in
> the requirements that is mathematically ambiguous as written.

That output is your research plan. Work it question by question; each finished one becomes an
I/O contract and a method statement.**Do you write production code?** There is no hand-over and no rewrite. The production
computation is written **once**, in the pod's service — usually first-drafted by the AI from your
contract and method statement — and then you review it as method (is this the computation I
specified, with my parameters and my validation?) and edit it directly where it is wrong.
Engineering reviews the same code for how it runs: where it executes, what it costs, how it fails.
If you would rather write it yourself, do — it lands in the same place and gets the same two
reviews. What we avoid is **two implementations of the same thing**, one "for research" and one
"for production", which drift within a month. Notebooks and exploration stay yours and stay out of
the record. Full detail: `docs/15-WHO-WRITES-THE-MODEL-CODE.md`.


