# Start here

This repository is the record for the offer-allocation rebuild. Everything the pod knows lives
here as files.

**Everyone reads, in this order:**
1. `docs/01-REQUIREMENTS.md` — what the system must do and what "satisfied" means
2. `docs/02-current-state.md` — what exists today, in its own vocabulary
3. `docs/03-defect-catalogue.md` — what is wrong with it today
4. `docs/04-non-negotiables.md` — what the build may not violate
5. `pod/PIPELINE.md` — how work moves and what the four gates are

**Then your own file:**
- `01-DATA-SCIENCE.md` — you are at the front of the queue; the build waits on your contracts
- `02-ENGINEERING.md`
- `03-PRODUCT.md`
- `04-DESIGN.md`

**Two things to know about the shape of this project:**
- A proof of concept ran before this. Its results are in `docs/06-prior-evidence.md` as
  **evidence, not decisions** — useful for orientation, re-established before anything depends
  on them. The clock starts now.
- Nothing is built until Gate C. Before that, the work is questions, methods and contracts —
  and that is deliberate, because the build is fast and the wrong build is expensive.

## The commands, in one line each
`/start` route by discipline · `/help` where the pod is and what is next · `/intake` absorb material ·
`/research` the guided product-owner flow, from current state to suggested epics · `/prd` describe the
current system · `/panel` the personas argue with it · `/market` competitive context · `/contract`
an I/O contract · `/design-brief` structural wireframes · `/ticket` draft tickets · `/sign-off`
record a gate · `/brainstorm` and `/frame` for a brand-new initiative.
