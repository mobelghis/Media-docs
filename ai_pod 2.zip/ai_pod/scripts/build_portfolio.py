#!/usr/bin/env python3
"""
The front door: one page across every pod in this repository.

    python scripts/build_portfolio.py        # writes _portfolio/index.html + PORTFOLIO.md
                                             # and rewrites the pod table in README.md

A pod is any top-level folder containing features/BOARD.md. Everything on the page is read
from those pods at build time — the README table included, so it can never be wrong by
someone forgetting to edit it. Standard library only.
"""
from __future__ import annotations
import datetime as dt, html, re, subprocess, sys
from pathlib import Path

SKIP = {"_method", "_templates", "scripts", ".git", ".github", "_portfolio"}

def repo_time(root: Path):
    try:
        r = subprocess.run(["git","-C",str(root),"log","-1","--format=%cI"],
                           capture_output=True, text=True, timeout=8)
        if r.returncode == 0 and r.stdout.strip():
            return dt.datetime.fromisoformat(r.stdout.strip()).replace(tzinfo=None)
    except Exception: pass
    return dt.datetime.now()

def commit(root: Path):
    try:
        r = subprocess.run(["git","-C",str(root),"rev-parse","--short","HEAD"],
                           capture_output=True, text=True, timeout=8)
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception: return ""

def state(txt: str):
    t = " ".join(txt.strip().lower().split())
    if not t or t.startswith("not ") or t.startswith("no ") or t in ("todo","to do","backlog","pending","-","—"):
        return ""
    if any(w in t for w in ("blocked","waiting on","held","on hold")): return "blocked"
    if any(w in t for w in ("done","signed","complete","passed","accepted","landed","sealed")): return "done"
    if any(w in t for w in ("progress","in flight","drafting","active","started","building","review")): return "active"
    return ""

def rows_of(md: Path):
    if not md.exists(): return []
    out = []
    for ln in md.read_text(encoding="utf-8", errors="replace").split("\n"):
        if not ln.strip().startswith("|"): continue
        c = [x.strip() for x in ln.strip().strip("|").split("|")]
        if len(c) < 3 or set("".join(c)) <= set("-: ") or c[0].lower() in ("id","#"): continue
        out.append(c)
    return out

def decisions(pod: Path):
    d = pod / "pod" / "DECISIONS.md"
    if not d.exists(): return []
    return re.findall(r'^###\s+(D-\d+)\s*·\s*([^·\n]*)·\s*(.+)$', d.read_text(encoding="utf-8", errors="replace"), re.M)

def open_questions(pod: Path):
    for name in ("07-open-questions.md",):
        f = pod / "docs" / name
        if f.exists():
            return [r for r in rows_of(f) if "closed" not in " ".join(r).lower()]
    return []

def scan(root: Path):
    pods = []
    for p in sorted(root.iterdir()):
        if not p.is_dir() or p.name in SKIP or p.name.startswith("."): continue
        if not (p / "features" / "BOARD.md").exists(): continue
        board = rows_of(p / "features" / "BOARD.md")
        counts = {"done":0,"active":0,"blocked":0,"todo":0}
        for r in board:
            counts[state(r[2] if len(r)>2 else "") or "todo"] += 1
        gates = {}
        for r in board:
            g = (r[3] if len(r)>3 else "").strip().lower().replace("gate ","")
            if g in ("a","b","c","d") and g not in gates:
                gates[g] = state(r[2] if len(r)>2 else "")
        docs = len(list((p/"docs").glob("*.md"))) if (p/"docs").exists() else 0
        pods.append({"name": p.name, "board": board, "counts": counts, "gates": gates,
                     "docs": docs, "decisions": decisions(p), "open": open_questions(p),
                     "has_index": (p/"_index"/"index.html").exists()})
    return pods

CSS = """
:root{--ink:#14181F;--paper:#FAF8F3;--navy:#101826;--gold:#A8801B;--gold-l:#E3C96B;--teal:#146553;
--clay:#A2481F;--slate:#6B747F;--hair:#E2DED4;--mono:ui-monospace,Menlo,Consolas,monospace;
--sans:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
--display:Georgia,"Iowan Old Style",serif;}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font-family:var(--sans);font-size:15px;line-height:1.55}
.wrap{max-width:1180px;margin:0 auto;padding:0 40px 90px}
.hero{padding:44px 0 26px;border-bottom:1px solid var(--hair)}
.eyebrow{font-family:var(--mono);font-size:10.5px;letter-spacing:.2em;color:var(--gold);text-transform:uppercase}
h1{font-family:var(--display);font-size:40px;margin:12px 0 8px;color:var(--navy);letter-spacing:-.015em}
.stamp{font-family:var(--mono);font-size:11px;color:var(--slate)}
.banner{background:var(--navy);color:#fff;border-radius:10px;padding:18px 20px;margin:26px 0 34px;font-size:13.5px}
.banner b{color:var(--gold-l)}
h2{font-family:var(--display);font-size:22px;color:var(--navy);margin:34px 0 4px}
.rule{height:2px;width:46px;background:var(--navy);border-radius:2px;margin:8px 0 18px}
.pods{display:grid;grid-template-columns:repeat(auto-fit,minmax(430px,1fr));gap:18px}
.pod{background:#fff;border:1px solid var(--hair);border-radius:10px;padding:20px 22px;box-shadow:0 1px 2px rgba(16,24,38,.04),0 8px 24px rgba(16,24,38,.06)}
.pod h3{margin:0 0 2px;font-family:var(--display);font-size:20px;color:var(--navy)}
.pod .sub{font-family:var(--mono);font-size:10.5px;color:var(--slate);margin-bottom:14px}
.figs{display:flex;gap:22px;margin:0 0 14px}
.fig b{display:block;font-family:var(--mono);font-size:22px;color:var(--teal);line-height:1}
.fig span{font-size:10.5px;color:var(--slate)}
.gates{display:flex;gap:8px;margin:12px 0 4px}
.g{flex:1;border:1px solid var(--hair);border-radius:7px;padding:8px 10px;text-align:center}
.g .n{font-family:var(--mono);font-size:10px;color:var(--slate);letter-spacing:.1em}
.g .s{font-size:11.5px;font-weight:700;margin-top:3px;color:var(--slate)}
.g.done{border-color:var(--teal)}.g.done .s{color:var(--teal)}
.g.active{border-color:var(--gold)}.g.active .s{color:var(--gold)}
.g.blocked{border-color:var(--clay)}.g.blocked .s{color:var(--clay)}
.links{margin-top:14px;padding-top:12px;border-top:1px solid var(--hair);font-size:12.5px}
.links a{color:var(--teal);text-decoration:none;margin-right:14px}
table{border-collapse:collapse;width:100%;background:#fff;border:1px solid var(--hair);border-radius:10px;overflow:hidden;font-size:13px}
th{background:var(--navy);color:#fff;text-align:left;padding:10px 13px;font-size:11.5px;letter-spacing:.04em}
td{border-top:1px solid #EFEBE2;padding:10px 13px;vertical-align:top}
.pill{font-family:var(--mono);font-size:10px;padding:2px 8px;border-radius:9px;background:#EFEBE2;color:var(--slate)}
.pill.done{background:#E4EFEB;color:var(--teal)}.pill.active{background:#FBF2DC;color:#7A5D12}
.pill.blocked{background:#FBE9E2;color:var(--clay)}
footer{margin-top:44px;padding-top:16px;border-top:1px solid var(--hair);font-family:var(--mono);font-size:10.5px;color:var(--slate)}
"""

def html_page(root: Path, pods, stamp, sha):
    cards = []
    for p in pods:
        gates = "".join(
            f'<div class="g {p["gates"].get(k,"")}"><div class="n">GATE {k.upper()}</div>'
            f'<div class="s">{ {"done":"passed","active":"in progress","blocked":"blocked"}.get(p["gates"].get(k,""),"not started") }</div></div>'
            for k in ("a","b","c","d"))
        idx = (f'<a href="{p["name"]}/_index/index.html">Record</a>'
               f'<a href="{p["name"]}/_index/status.html">Status</a>'
               f'<a href="{p["name"]}/_index/pmo.html">PMO</a>'
               if p["has_index"] else '<span style="color:#6B747F">views not generated — run make index in the pod</span>')
        cards.append(
            f'<div class="pod"><h3>{html.escape(p["name"])}</h3>'
            f'<div class="sub">{p["docs"]} documents · {len(p["board"])} board items</div>'
            f'<div class="figs">'
            f'<div class="fig"><b>{p["counts"]["done"]}</b><span>done</span></div>'
            f'<div class="fig"><b>{p["counts"]["active"]}</b><span>in progress</span></div>'
            f'<div class="fig"><b>{p["counts"]["blocked"]}</b><span>blocked</span></div>'
            f'<div class="fig"><b>{len(p["open"])}</b><span>open questions</span></div>'
            f'<div class="fig"><b>{len(p["decisions"])}</b><span>decisions</span></div></div>'
            f'<div class="gates">{gates}</div>'
            f'<div class="links">{idx}</div></div>')
    oq = []
    for p in pods:
        for r in p["open"][:20]:
            oq.append(f'<tr><td>{html.escape(p["name"])}</td><td>{html.escape(r[0])}</td>'
                      f'<td>{html.escape(r[1] if len(r)>1 else "")}</td>'
                      f'<td>{html.escape(r[2] if len(r)>2 else "")}</td>'
                      f'<td>{html.escape(r[3] if len(r)>3 else "")}</td></tr>')
    dec = []
    for p in pods:
        for i,(d,dt_,t) in enumerate(p["decisions"][-6:]):
            dec.append(f'<tr><td>{html.escape(p["name"])}</td><td><b>{html.escape(d)}</b></td>'
                       f'<td>{html.escape(dt_)}</td><td>{html.escape(t)}</td></tr>')
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>AI pods</title>
<style>{CSS}</style></head><body><div class="wrap">
<div class="hero"><div class="eyebrow">Continuous context delivery</div><h1>AI pods</h1>
<div class="stamp">generated {stamp}{' · ' + sha if sha else ''} · {len(pods)} pods</div></div>
<div class="banner">Every number here is read from each pod's board, decision log and open questions
at build time. <b>Nothing on this page is maintained by hand</b> — if something looks wrong, the
underlying file is wrong.</div>
<h2>The pods</h2><div class="rule"></div><div class="pods">{''.join(cards)}</div>
<h2>Open questions, across every pod</h2><div class="rule"></div>
<table><thead><tr><th>Pod</th><th>#</th><th>Question</th><th>Owner</th><th>Blocks</th></tr></thead>
<tbody>{''.join(oq) or '<tr><td colspan="5">None recorded.</td></tr>'}</tbody></table>
<h2>Recent decisions</h2><div class="rule"></div>
<table><thead><tr><th>Pod</th><th>ID</th><th>Date</th><th>Decision</th></tr></thead>
<tbody>{''.join(dec) or '<tr><td colspan="4">None recorded.</td></tr>'}</tbody></table>
<footer>regenerate with <code>python scripts/build_portfolio.py</code></footer></div></body></html>"""

def md_page(pods, stamp, sha):
    L = [f"# AI pods", "",
         f"*Generated {stamp}{' · ' + sha if sha else ''} from each pod's board, decision log and open",
         "questions. Do not edit — run `python scripts/build_portfolio.py`.*", "",
         "| Pod | Docs | Board items | Done | In progress | Blocked | Open questions | Decisions |",
         "|---|---|---|---|---|---|---|---|"]
    for p in pods:
        c = p["counts"]
        L.append(f'| [{p["name"]}]({p["name"]}/) | {p["docs"]} | {len(p["board"])} | {c["done"]} | '
                 f'{c["active"]} | {c["blocked"]} | {len(p["open"])} | {len(p["decisions"])} |')
    L += ["", "## Gates", "", "| Pod | Gate A | Gate B | Gate C | Gate D |", "|---|---|---|---|---|"]
    lab = {"done":"passed","active":"in progress","blocked":"blocked"}
    for p in pods:
        L.append("| " + p["name"] + " | " + " | ".join(
            lab.get(p["gates"].get(k,""),"not started") for k in ("a","b","c","d")) + " |")
    return "\n".join(L) + "\n"

def update_readme(root: Path, pods, stamp):
    f = root / "README.md"
    if not f.exists(): return
    s = f.read_text(encoding="utf-8")
    rows = ["| Pod | Board items | Open questions | Gate A | Gate B | Folder |",
            "|---|---|---|---|---|---|"]
    lab = {"done":"passed","active":"in progress","blocked":"blocked"}
    for p in pods:
        rows.append(f'| {p["name"]} | {len(p["board"])} | {len(p["open"])} | '
                    f'{lab.get(p["gates"].get("a",""),"not started")} | '
                    f'{lab.get(p["gates"].get("b",""),"not started")} | [{p["name"]}/]({p["name"]}/) |')
    block = ("<!-- pods:start -->\n" + "\n".join(rows) +
             f"\n\n*Generated {stamp} by `scripts/build_portfolio.py` — do not edit this table by hand.*\n"
             "<!-- pods:end -->")
    if "<!-- pods:start -->" in s:
        s = re.sub(r"<!-- pods:start -->.*?<!-- pods:end -->", block, s, flags=re.S)
    else:
        s = re.sub(r"\| Pod \| Owner \| Status \| Folder \|.*?(?=\n\n)", block, s, flags=re.S)
    f.write_text(s, encoding="utf-8")

def main():
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    pods = scan(root)
    if not pods:
        print("No pods found (a pod is a folder containing features/BOARD.md)."); return 1
    st = repo_time(root); stamp = st.strftime("%d %B %Y, %H:%M"); sha = commit(root)
    out = root / "_portfolio"; out.mkdir(exist_ok=True)
    (out / "index.html").write_text(html_page(root, pods, stamp, sha), encoding="utf-8")
    (root / "PORTFOLIO.md").write_text(md_page(pods, stamp, sha), encoding="utf-8")
    update_readme(root, pods, stamp)
    print(f"portfolio: {len(pods)} pods -> {out/'index.html'}, PORTFOLIO.md, README table")
    for p in pods:
        c = p["counts"]
        print(f"  {p['name']:<20} docs {p['docs']:>2} · board {len(p['board']):>2} "
              f"· done {c['done']} · active {c['active']} · open {len(p['open'])} · decisions {len(p['decisions'])}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
