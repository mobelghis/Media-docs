# Start here — Design

Design is not a phase in front of this work; it is a step inside every feature. But the structure
is decided once, early, and that is your first job.

## 1 · Read
`docs/01-REQUIREMENTS.md` · `docs/08-FRONTEND-SURFACE-REQUIREMENTS.md` (which fields land on which
screens) · `docs/10-ENTITY-PLACEMENT.md` (which entity owns each field — this decides where it is
**authored** versus merely **shown**) · `docs/13-personas-and-business-questions.md` (whose
question each screen answers) · `docs/14-CURRENT-SYSTEM-PRD.md` (what exists today).

## 2 · Generate the design brief (`/design-brief`)
This is the step that turns requirements into something you can argue with. It produces, per
surface: the questions it answers, the screen's job in one sentence, a **structural wireframe**
(regions, contents, the single primary action, what is deliberately absent), which fields are new
versus fixed and who owns them, the four states every screen needs — empty, loading, refused with
its reason, insufficient evidence — and the links in and out, because no screen is an island.

It ends with what it could not resolve and which decision would resolve it. Those are yours to
answer or to route.

Run it for the whole programme first to get the surface inventory, then per requirement when you
want depth.

## 3 · Own the system
- The tokens are the source of truth. Everything generated is built from them, so a change to a
  token is a change everywhere — that is the point.
- Generated screens are a **first draft on your tokens**. Change anything; you own the result.
- Nothing ships with a hardcoded colour, spacing or type value. That is checkable, and it is
  checked.

## 4 · The rules that are not open
These come from the requirements, not from taste:
- Exact values and estimates must be visibly different.
- Every number opens to its basis.
- A refusal states its reason, with numbers.
- Nothing that spends money commits without an explicit action on a screen showing what happens.
- Collections above about ten items are tables, sortable and exportable; every chart has a table
  twin.
- Grey means "not enough evidence" and nothing else.

## 5 · Per feature, afterwards
When a feature reaches its UI layer, its screens are generated on your tokens from the brief and
the contract — minutes, not weeks. You review and approve; that approval is part of the feature's
acceptance, not a separate phase.

## Kick-off prompt
> Read `docs/01-REQUIREMENTS.md`, `docs/08-FRONTEND-SURFACE-REQUIREMENTS.md`,
> `docs/10-ENTITY-PLACEMENT.md` and `docs/14-CURRENT-SYSTEM-PRD.md`. Produce the surface
> inventory: every screen this programme needs, marked existing-and-changing or new, with the
> questions each answers, the fields it must carry, and which entity owns each field. Flag
> anything that cannot be expressed cleanly in our current design system, and any requirement
> whose fields have no obvious home.
