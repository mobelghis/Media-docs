# Start here — Engineering

Your leverage is highest **before** any code exists. Everything built afterwards is built against
what you decide in the first week.

## 1. Read
`docs/01-REQUIREMENTS.md` (all), `docs/02-current-state.md`, `docs/03-defect-catalogue.md`
(especially D-12 through D-17 — the integration and operability failures), and
`docs/04-non-negotiables.md` (N-3, N-5, N-6, N-7, N-8, N-16, N-17 are yours).

## 2. What you produce first — the non-negotiables register
Before any ticket is approved, write down, per area, what the build may not do:
- Where computation must run, and where it must not
- Latency and volume budgets, stated as numbers
- What must extend an existing contract rather than duplicate it
- Security, tenancy and data-movement rules
- Patterns that are not allowed here, with the reason

These become part of every ticket, and the build cannot silently violate them.

## 3. What you own at each gate
- **Gate A** — sanity-check the requirements for anything technically impossible or ambiguous.
- **Gate C (your half-hour)** — architecture, blast radius, degradation behaviour, and what
  "good" means for each feature: the refusals, the failure modes, the thing that must never
  happen silently.
- **During the build** — the AI states its plan before building; you rule on it. Any conflict
  with a landed decision arrives as a question, never as a guess.
- **Gate D** — acceptance. A green suite is necessary, not sufficient.

## 4. Standing responsibilities
- **Turn repeated defects into mechanisms.** A defect class that recurs gets fixed once, in the
  tooling, so it cannot recur. This is the highest-leverage work in the pod.
- **Guard the seams.** Contracts, refusals, degradation. The build is fast; the seams are where
  fast goes wrong.
- **Reproducibility is an engineering property**, not a data-science wish: freezing, seeds,
  immutability, and content-based freshness checks are yours.

## 5. Kick-off prompt
> Read `docs/01-REQUIREMENTS.md`, `docs/02-current-state.md`, `docs/03-defect-catalogue.md` and
> `docs/04-non-negotiables.md`. Produce a draft non-negotiables register for this programme:
> per area, the hard constraints the build may not violate, each with its reason and its owner.
> Flag any requirement that cannot be satisfied without a platform decision we have not made,
> and any place where the current system's behaviour would have to change for a requirement to
> be met.
