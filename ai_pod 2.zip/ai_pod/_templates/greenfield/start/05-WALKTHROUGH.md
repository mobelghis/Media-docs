# The first two weeks, discipline by discipline

What actually happens once you have the repository link. Read your own column; the others are here
so nobody wonders what the next station is waiting for.

---

## Everyone, day one (about two hours)
1. Clone the repository. Open it in your AI session at the repository root.
2. Type **`/start`** — it asks which discipline you are and routes you.
3. Read `docs/01-REQUIREMENTS.md` **in full**. Everything else answers to it.
4. Skim `docs/02-current-state.md` and `docs/03-defect-catalogue.md`.
5. Note anything ambiguous. Ambiguity found on day one is cheap; found at build time it is not.

---

## Data science — you are first, and the build waits on you

**Days 1–2 · Frame the research.** Run the kick-off prompt in `start/01-DATA-SCIENCE.md`. It
produces a *question list*, not answers: objective, constraints, scoring, measurement. Review it
with the pod; anything missing gets added now.

**Days 2–6 · Research.** Work in your own tools at your own pace. Nothing about how you research
is being changed. Read `docs/09-PROPOSED-IO-CONTRACTS.md` early — five contracts are already
drafted for you to argue with, and where they are wrong, the correction is the output.

**What you put back into the pod — three things, and only three:**
1. **The I/O contracts** (`docs/` as `1x-contract-<name>.md`) — inputs, outputs, method,
   assumptions, validation, and what is not yet known.
2. **The method statement** per area — written so an external reviewer could attack it.
3. **Decisions** — anything you settled, with its reason, into `pod/DECISIONS.md`.

**What you do *not* have to put back:** notebooks, exploratory code, dead ends. If a decision
depends on it, it belongs in the record. If it does not, keep it.

**Do you write production code?** No. You may write a reference implementation to prove a method
works; engineering lands the production version on the service chassis. **The contract is what
crosses the boundary** — that is why the contracts matter more than the code.

**Gate B — you sign.** A contract is signed when inputs and outputs are precise enough that the
build can start without guessing. **The model may still be a draft.** This is the most common
misunderstanding: you are not being asked to finish the science before anyone else can start.

---

## Engineering — your leverage is highest before any code exists

**Days 1–3 · The non-negotiables register.** Run the kick-off prompt in `start/02-ENGINEERING.md`.
Produce, per area, what the build may not do: where computation must run, latency and volume
budgets as numbers, what must extend an existing contract, tenancy and data-movement rules,
patterns not allowed here. Each with a reason and an owner. These become part of every ticket.

**Days 3–8 · Architecture, in parallel with data science.** You are not waiting. Read
`docs/10-ENTITY-PLACEMENT.md` and rule on it — it decides what freezes, what versions, and what a
re-run reproduces. Decide the service topology, the contracts that get extended rather than
duplicated, and how the new work reaches the existing application.

**When contracts arrive at Gate B**, you convert them into a build shape: what the data layer
must hold, what the API must expose, what refuses when a precondition is not met.

**Gate C — the highest-leverage half-hour in the whole cycle.** Every ticket passes your review:
architecture, blast radius, degradation behaviour, and what "good" looks like — the refusals, the
failure modes, the thing that must never happen silently.

**During the build.** The AI states its plan before writing code; you rule on it. Any conflict
with a landed decision arrives as a question, never a guess. And when a defect class repeats, you
turn it into a mechanism — fixed once, in the tooling. That is the highest-value work you do here.

---

## Product — you own the questions and the gate that opens everything

**Days 1–4 · The question register.** Run the kick-off prompt in `start/03-PRODUCT.md`. Every
requirement becomes questions in a user's own words, each with an owner and what they do with the
answer. Features get sliced from questions — one feature answers one question — so this document
sets the shape of the entire build.

**Also days 1–4:** priorities (what is non-negotiable for the first production wave), and a named
owner plus a date against every row in `docs/07-open-questions.md`.

**Gate A — you sign** when every question has an owner and an expected use.

**Then, continuously:** rule on what the build surfaces, the same day it asks. Accept features at
Gate D — the test is not "is it green", it is "is this the answer the business asked for".

---

## Design — you own the system and the approval

**Days 1–5.** Run the kick-off prompt in `start/04-DESIGN.md`. Read
`docs/08-FRONTEND-SURFACE-REQUIREMENTS.md` (which fields, which screens) and
`docs/10-ENTITY-PLACEMENT.md` (which entity owns each field, which decides where it is *authored*
versus merely *shown*). Produce the surface inventory: every screen, existing-or-new, with the
questions it answers.

**Then, per feature.** Screens are generated on your tokens when a feature reaches its UI layer —
minutes, not weeks. They are a first draft; you change anything, and you own the result. Design is
a step inside each feature, never a phase in front of the work.

---

## How a methodology becomes tickets — the step everyone asks about

1. **Data science signs a contract** (Gate B). It states inputs, outputs, assumptions, validation.
2. **The pod drafts tickets.** One ticket per feature, each answering one question from the
   register, each carrying all layers in one place: data, model, API, UI, tests, done-when. The
   drafting is mechanical — the contract supplies the model section, the register supplies the
   question, the front-end requirements supply the UI section, engineering's register supplies the
   constraints.
3. **Everyone reviews at Gate C.** Product checks it answers the right question; data science
   checks the method section matches the contract; engineering rules on architecture and blast
   radius. This is where a ticket gets changed — after this, the build proceeds without asking
   again.
4. **The build runs**, layer by layer, inside the feature.
5. **Gate D accepts it** — green suite, question answered end to end, business reviewer agrees.

**Nobody writes tickets by hand from a methodology paper.** The contract and the register are the
inputs; the ticket is generated from them and then argued with by people.

---

## What "review" means at each gate

| Gate | Who signs | The test |
|---|---|---|
| **A** | Product | Every question has an owner and an expected use; no question without a surface |
| **B** | Data science | Inputs and outputs precise enough to build against without guessing |
| **C** | Product + data science + engineering | The ticket answers one question end to end and violates no constraint |
| **D** | Product, with engineering on behaviour | Green suite, question demonstrably answered, business agrees it is the answer asked for |

## Where the code actually lands

New code that does not exist yet — the service, the engine — is built **in this repository**,
beside its record. Changes to the existing product are built **in the product repository**, where
that code already lives; this repository holds the record for them. A build session opens both:
this repository as context, the product repository as the working tree. The full mechanics,
including the pointer file and the two-way commit references, are in
`docs/11-REPO-BRIDGE.md`.

## If you are stuck
- **Something is ambiguous** → say so in the pod channel and add a row to `docs/07-open-questions.md`.
- **Something contradicts a landed decision** → stop and surface it. Never build past it.
- **You need something that does not exist yet** → name the dependency in the ticket; the pod does
  not fake it and does not wait silently.
