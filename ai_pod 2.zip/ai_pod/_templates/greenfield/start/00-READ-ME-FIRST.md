# Start here — a new pod

This repository is empty on purpose. It holds the method, not a project. Its first job is to help
the product owner think, and its second is to turn that thinking into something a team can build.

## Day one, product owner
1. Open this repository in your AI session at the root.
2. Type **`/brainstorm`**. You will be interviewed — the problem, the users, their questions, what
   exists today, the constraints, what "better" looks like, and which disciplines this needs.
   Answer roughly; you will be pushed on anything vague.
3. Drop any material you already have into `docs/sources/` and run **`/intake`** — briefs, emails,
   client questionnaires, exports, screenshots, notes.
4. When the picture holds together, run **`/frame`**. It writes the opening documents:
   requirements, personas and questions, non-negotiables, scope boundary, open questions, the
   board, and the first decision.
5. Optional and usually worth it: **`/market`** for the competitive context (including what would
   make this *not* worth doing), **`/prd`** if a current system exists and can be read, and
   **`/panel`** to have the expert personas argue with what you have written.

## Then the disciplines join
Each reads `docs/01-REQUIREMENTS.md` first, then their own file in `start/`. If this initiative
has no data-science question — many do not — skip Station 2 and Gate B entirely; product frames
the questions, engineering and design build the answers, and the gates become A, C and D.

## The shape of the work
Six stations, four gates (`pod/PIPELINE.md`). Questions → method (if needed) → tickets → build →
ship → learn. Nothing is built before Gate C, and every gate is a person.

## The commands, in one line each
`/start` route by discipline · `/help` where the pod is and what is next · `/intake` absorb material ·
`/research` the guided product-owner flow, from current state to suggested epics · `/prd` describe the
current system · `/panel` the personas argue with it · `/market` competitive context · `/contract`
an I/O contract · `/design-brief` structural wireframes · `/ticket` draft tickets · `/sign-off`
record a gate · `/brainstorm` and `/frame` for a brand-new initiative.
