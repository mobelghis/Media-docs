# Start here — Data Science *(only if this initiative has a method question)*

Many initiatives have none. If nothing here needs a model, an estimate, an optimisation or a
measured effect, skip this station: the pipeline runs A → C → D and nobody waits.

If it does need one, you are first and the build waits on you — but not for a finished model.

## Read
`docs/01-REQUIREMENTS.md` in full · `docs/13-personas-and-business-questions.md` (the questions you
are answering mathematically) · `docs/04-non-negotiables.md` · anything in `docs/sources/`.

## What you own
- **The quantity.** What exactly is being computed, and what does it mean?
- **The method.** How it is computed, what it assumes, and where those assumptions fail.
- **The validation.** How we would know it is wrong — including a deliberately broken case the
  tests must catch.
- **The measurement.** If this initiative claims an effect: what is the estimand, what design
  supports it, what is the power threshold, and what gets published below it.

## What you put back
1. An **I/O contract** per question (`/contract`, or `pod/templates/io-contract.md`): inputs with
   grain and source, outputs with type, range and meaning — including what is returned when the
   answer cannot be supported — method with parameters named as parameters, assumptions,
   validation, and an explicit **not yet known**.
2. A **method statement** per area, written so an external reviewer could attack it.
3. **Decisions**, each with its reason, in `pod/DECISIONS.md`.

Notebooks and dead ends stay yours. If a decision depends on it, it belongs here; if not, keep it.

## Gate B
You sign when inputs and outputs are precise enough that the build can start without guessing. The
model may still be a draft. You do not write production code — engineering lands that on the
chassis. The contract is what crosses the boundary.
