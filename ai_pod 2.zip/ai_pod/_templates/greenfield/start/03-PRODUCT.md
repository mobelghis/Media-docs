# Start here — Product

You own the questions, the raw material, and the gate that opens everything.

## Your moves, in order

**The guided route: `/research`.** If you would rather be walked through it than assemble the
pieces yourself, that command runs the whole flow — what kind of change this is, reverse
engineering the current state (including a Jira search for related work), framing it as questions,
optional market and data passes, the persona panel, ideation kept separate from the requirement,
and finally a requirements document plus suggested epics in Jira-import shape. It stops between
stages and waits for you.

The individual moves, if you prefer to drive:

### 1 · Dump everything in (`/intake`)
You do not have to organise anything first. Paste or point at whatever exists — briefs,
requirement documents, emails, client questionnaires, RFP answers, spreadsheets, screenshots,
report URLs, meeting notes. Type `/intake` and hand them over one at a time or in bulk.

The pod tells you what each item contains, where it belongs, and what it changes — **before**
merging anything. On your go it integrates: requirements get dated amendment sections (never
silent edits), questions go to the register, constraints to the non-negotiables, unanswerable
things to open questions with owners, and the raw material lands verbatim in `docs/sources/`.

This is not a one-time step. Requirements keep arriving; run `/intake` whenever they do.

### 2 · Build the picture of what exists (`/prd`)
Generates or refreshes `docs/14-CURRENT-SYSTEM-PRD.md`: the entity model, the lifecycle, the
boundaries, what must not be lost, and — the part everyone uses — the **impact map**: for each
requirement, which layers it touches and what it risks breaking. Anything inferred rather than
traced is marked `[verify]`, so nobody mistakes a guess for a fact.

Run it once early, and again whenever the current system changes underneath you.

### 3 · Turn requirements into questions
Run the kick-off prompt below. Every requirement becomes questions in a user's own words, each
with an owner and what they do with the answer. Features are sliced from questions, so this
document sets the shape of the entire build. `docs/13-personas-and-business-questions.md` is your
starting material — extend it rather than starting from blank.

Also now: priorities (what is non-negotiable for the first production wave), and a named owner
plus a date on every row of `docs/07-open-questions.md`.

### 4 · Sign Gate A
When every question has an owner and an expected use, and nothing in the requirements is
ambiguous enough to be built two ways. That signature releases data science and engineering to
work in parallel.

## Then, continuously
- **Rule the same day.** A build that stops and asks needs an answer within hours, not at the next
  meeting. This is the pace-setter for the whole pod.
- **Prioritise the board.** New work arrives as questions, becomes tickets, and joins the backlog
  on `features/BOARD.md`. You decide the order.
- **Accept at Gate D.** The test is not "is it green" — it is "is this the answer the business
  asked for".

## Kick-off prompt
> Read `docs/01-REQUIREMENTS.md`, `docs/03-defect-catalogue.md` and
> `docs/13-personas-and-business-questions.md`. Draft the question register: for each requirement,
> the questions a real user would ask in their own words, who asks them, what they do with the
> answer, and which surface would answer them. Flag any requirement that does not resolve into a
> user-facing question — it may be a constraint rather than a capability — and any question that
> no surface in the front-end requirements currently answers.
