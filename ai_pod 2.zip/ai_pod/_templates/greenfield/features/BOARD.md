# Board

**This file governs.** The folders mirror it for visibility.

| ID | Item | Status | Gate | Owner |
|---|---|---|---|---|
| G-A | Requirements framed, questions have owners | not started | Gate A | Product |
| G-B | Contracts signed *(skip if no method question)* | not started | Gate B | Data science |
| G-C | First feature tickets drafted and approved | not started | Gate C | Pod |
