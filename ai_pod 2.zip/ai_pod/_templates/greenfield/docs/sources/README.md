# Source material

Raw inputs exactly as received — briefs, requirement documents, emails, exports, notes,
screenshots. Never edited: if something here is wrong, the correction goes in the document that
cites it, not in the source.

Each file gets a one-line provenance note in this README: what it is, who provided it, when.

| File | What it is | From | Date |
|---|---|---|---|
