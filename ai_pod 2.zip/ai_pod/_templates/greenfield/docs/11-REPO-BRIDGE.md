# 11 — How the pod repository and the product repository work together

The pod repository is the record. The product repository is where the running system lives.
This document states where code lands, how a build session is opened, and how the two are kept
from drifting apart.

## Two cases, two answers

### Case 1 — new code that does not exist yet (the allocation engine, the service)
**It lives in the pod repository, beside its record.** Record and code in one place means a
decision, the code implementing it, the test proving it and the document explaining it land in a
single commit. This is the case for everything being built from scratch here.

At cutover, the service is deployed from this repository like any other deployable. If the
organisation later wants it moved into the product monorepo, that is a mechanical extraction with
its own decision — not something to pre-empt now.

### Case 2 — changes to the existing product (screens, endpoints, existing services)
**The code lands in the product repository, where that code already lives.** Nothing is forked and
no shadow copy is made. The pod repository holds the record for that work: the question, the
contract, the ticket, the decisions, the evidence.

---

## How a build session is opened (Case 2)

Both repositories are open in the same session — the pod repository as **context**, the product
repository as the **working tree**:

```
~/work/
  <pod-name>/     ← the record: requirements, contracts, tickets, decisions
  <product-repo>/         ← the code being changed
```

The build prompt names both:

> Read `../<pod-name>/features/<ticket>.md` and the documents it references. Implement it
> in this repository. Follow the constraints in `../<pod-name>/docs/04-non-negotiables.md`.
> Stop and surface anything that conflicts with a landed decision. When it lands, report the
> commit SHA so it can be recorded against the ticket.

Nothing else is needed. The AI reads the record, writes the code where the code belongs.

---

## The three mechanisms that maintain the link

### 1 · A pointer in the product repository
A short file at the product repository root — `AI-POD.md` — naming which pod governs which areas
and where its record lives. It is read by anyone (or anything) working in that repository:

```
# This area is governed by a pod
Record:   <url of the pod repository>
Governs:  <paths, modules or reports this pod is changing>
Before changing anything under those paths: read the pod's requirements and non-negotiables.
Every commit references its feature id.
```

Optionally the same pointer goes in the product repository's own `CLAUDE.md`, so any AI session
opened there is told about the record before it starts.

### 2 · Two-way references on every landing
- **Product repository → pod:** every commit message carries the feature id (`F-012: …`).
- **Pod → product repository:** the ticket records the commit SHA that landed it, and the landing
  report lists the SHAs for that feature.

Either side can now answer "why does this code exist?" and "where did this decision end up?"
without anyone remembering.

### 3 · Staleness detection on the traced files
The current-state dossier records the product-repository commit it was traced against. A check in
the product repository flags the dossier as **stale** when files in the traced paths change, so
the record is refreshed deliberately rather than silently rotting.

---

## Who maintains what

| | Pod repository | Product repository |
|---|---|---|
| Requirements, contracts, decisions | ✔ | — |
| Feature tickets and their evidence | ✔ | — |
| New service and its migrations | ✔ | — |
| Changes to existing screens and services | record only | ✔ code |
| Commit references | records product SHAs | carries feature ids |
| Governing pointer | — | `AI-POD.md` |

## Rules
1. **Code lands where the code lives.** Never a shadow copy of product code in the pod repository.
2. **The record never lands in the product repository.** No requirement documents, no decision
   logs — a pointer only, so there is exactly one record.
3. **Every landing is traceable both ways** — feature id in the commit, SHA in the ticket.
4. **The dossier states which commit it was traced against**, and is refreshed when that drifts.
5. **One pod owns a given area at a time.** If a second pod needs the same module, that is a
   coordination decision, made explicitly and recorded.
