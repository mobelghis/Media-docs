# <initiative name> — pod repository

Empty by design. This repository holds the method; the project fills it in.

**Product owner, start here:** open this repository in your AI session and type `/brainstorm`.
Everyone else: read `start/00-READ-ME-FIRST.md`.

| Path | Holds |
|---|---|
| `docs/` | The record — requirements, personas and questions, constraints, scope, open questions, and whatever else the initiative produces |
| `docs/sources/` | Raw material exactly as received, never edited |
| `start/` | One kick-off file per discipline |
| `pod/` | The method: pipeline, decisions, personas, templates |
| `features/` | Specs and status. `BOARD.md` governs |
| `scripts/` | Tooling, including the index and status generator |

## The commands
| Command | What it does |
|---|---|
| `/brainstorm` | Interviews the product owner about a new initiative |
| `/intake` | Absorbs documents, notes and links into the right places |
| `/frame` | Writes the opening documents from the brainstorm |
| `/market` | Competitive context, including what would make this not worth doing |
| `/prd` | Describes the current system and maps the impact of each requirement |
| `/panel` | Expert personas argue with what you have written |
| `/contract` | Drafts an I/O contract (only where there is a method question) |
| `/design-brief` | Turns requirements into structural wireframes |
| `/ticket` | Drafts feature tickets from a signed contract |
| `/start` | Routes a new joiner by discipline |

## Ground rules
1. If it only exists in a conversation, it does not exist.
2. Every decision carries its reason.
3. Corrections are dated amendments, never silent edits.
4. Numbers are computed from what they describe, never typed.
5. `make index` after any document is added, renamed or removed.

## If there is no data science
Skip Station 2 and Gate B. Product frames the questions, engineering and design build the answers,
and the gates are A, C and D. Nothing else changes.
