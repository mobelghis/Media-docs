# AI pods

One repository, one folder per pod. The method is shared in `_method/`; each pod owns its folder
and is self-contained.

<!-- pods:start -->
| Pod | Board items | Open questions | Gate A | Gate B | Folder |
|---|---|---|---|---|---|
| offer-allocation | 19 | 22 | in progress | not started | [offer-allocation/](offer-allocation/) |
| retail-media | 3 | 13 | in progress | not started | [retail-media/](retail-media/) |

*Generated 16 August 2026, 17:42 by `scripts/build_portfolio.py` — do not edit this table by hand.*
<!-- pods:end -->

## Layout
| Path | What it is |
|---|---|
| `_method/` | The shared method — pipeline, personas, templates, commands, skills, tooling. **The master copy**; CI fails if a pod drifts from it |
| `_templates/greenfield/` | Starting point for a brand-new initiative with no existing system (`/brainstorm` first) |
| `offer-allocation/` | Personalization: the offer-allocation rebuild |
| `retail-media/` | Retail media: the Unlimitail integration |
| `scripts/` | Repository-level tooling — the portfolio view across all pods |
| `_portfolio/` | Generated: one page across every pod. `python scripts/build_portfolio.py` |

## Starting a new pod
1. Copy `_method/` (or `_templates/greenfield/` for a greenfield initiative) into a new folder
   named for the initiative.
2. Add a row to the table above.
3. Open a session in that folder and run `/brainstorm` (greenfield) or `/intake` (material exists).

## The views
| Where | What |
|---|---|
| `_portfolio/index.html` · `PORTFOLIO.md` | Across every pod: gates, counts, open questions, recent decisions |
| `<pod>/_index/index.html` | That pod's record, by role |
| `<pod>/_index/status.html` · `pmo.html` · `features.html` | Gates and board · programme view and release notes · per-ticket workflow |
| `<pod>/_index/PLAN.md` | Timeline, dependencies, build order, front-end mapping |

Regenerate with `make index` and `make plan` inside a pod, and `python scripts/build_portfolio.py`
at the root. All of it is generated — if a number looks wrong, the underlying file is wrong.

## Keeping the method current
Improvements go to `_method/` first, then are copied outward per pod. **CI enforces this**: the
`method-has-not-drifted` job fails if any pod's scripts, commands or skills differ from `_method/`.
A pod's method never changes underneath its team by accident, and it can no longer fall behind by
being forgotten.
