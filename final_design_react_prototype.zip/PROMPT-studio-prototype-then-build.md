# Two jobs: verify the epics against the code, then prototype the whole system, then build it

Attached: `console-page-requirements.zip` (unzip to `docs/requirements/`) and `epic-diagrams.zip`
(unzip to `docs/epics/`). Read `00-INDEX.md` first, then every epic diagram's text.

Unattended. Decide, record in docs/88, continue. Fix under an hour; log otherwise as DEF-nn;
continue. Stop at D-140.

---

## Job A · Verify the epic descriptions against the code

Fifteen diagrams describe what this system does, in a planner's words, with an acceptance sentence
each. They were written from memory of the build. **Check every claim against the code**, because
this project has found eleven cases of something documented that was not real.

For each diagram, one row per factual claim: claim · TRUE (file and test) · FALSE (what the code
does instead) · UNVERIFIABLE (why). Pay particular attention to:

- CR-38871 — 347 B/arc, the Hoffman certificate naming a binding cut, ranked relaxations
- CR-38875 — overlap on the smaller set, the winner rule, declared pairs, that mode does not exempt
- CR-38874 — three scopes and three levels, and the coverage warning computed not typed
- CR-40346 — arms independent of scoring (the shuffle test), the seed, balance at freeze, ghost log
- CR-38880 — the three methods, their intervals, the three gates, what each can claim
- CR-38872 — that one partition family may bind for EXACT, and category limits force LIMITED
- CR-38879 — append-only, control arms never debit, closed periods never change, the residual
- CR-40345 — attribution to the EARLIEST rule, and that eligible = removals + scored-below + allocated
- Every acceptance sentence in every dark footer — each is a test that should exist. Name the test
  or log that it does not.

Where a diagram is wrong, fix the diagram's text in `docs/epics/` and say so. Where the CODE is
wrong, log a DEF. Report the counts.

## Job B · One interactive prototype of the whole system

Before building React pages one at a time, produce a **single self-contained HTML prototype** that
demonstrates every capability, so it can be shown, clicked and argued with today.

`prototypes/studio-prototype.html` — one file, no build, no server, opens in a browser.

- All five pages from `docs/requirements/`, navigable: Campaigns (list · campaign with its tabs ·
  offer panel · QA report) · Library (policies · coupons · templates · audiences · products) ·
  Results (with the level and method selectors) · Money · Settings.
- Landing page with the single **Personalization** button.
- Realistic data taken from the seeded demo estate — real shapes, real vocabulary, real verdicts.
  Where a figure would be withheld, withhold it and show the verdict.
- Every capability the epics describe must be visible and clickable somewhere: the funnel at both
  grains, the feasibility refusal naming an offer, measurability before the run, the three
  measurement methods side by side, the reconciliation waterfall, the QA report's intent-versus-
  build table, blocking and chilling as rules with what they removed, tags and bulk edit, budget
  phasing with a weekly cap refusal, returned exclusions.
- Both themes. Highcharts for charts. The visual language in `00-INDEX.md`.

**Use your own judgement on the design.** The requirements say what must be present and what the
rules are; they do not dictate every layout. Where you can make something clearer, more intuitive
or faster to use than the requirement describes — do it, and note the change in docs/88 §B with
one line of reasoning. The bar is a modern analytics product a planner would rather use than the
spreadsheet they use today.

Rules that do not bend: every figure declares its layer; a measured figure without an interval
does not render; verdicts are never blank; explanations live behind a "why"; nothing computed is
editable; no invented data; two URL levels only.

## Job C · Then build the React pages, in order, overnight

With the prototype as the design target and `docs/requirements/` as the specification:

```
01 Campaigns → 02 Library → 03 Results → 04 Money → 05 Settings
```

One commit per page. Contract test per page (exactly the endpoints its requirement lists), visual
test per state per theme against the prototype, route-depth test, and a walkthrough step. A page
that cannot be finished is logged with what stopped it and the next page begins — do not stall the
sequence.

Where the back end cannot supply something, render the honest state with the reason, log a GAP
naming the missing endpoint, and continue. Never a placeholder number.

## Report, then stop

D-140. Report: Job A's claim table with its TRUE/FALSE/UNVERIFIABLE counts and every DEF raised ·
the prototype's URL and one screenshot per page · Job C's pages built, GAP list, and test results ·
the design decisions you made in Job B with their one-line reasons. Then stop.
